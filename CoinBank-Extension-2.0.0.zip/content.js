/* Coin Bank (extensão) — nas páginas:
   1) sugere entrar com as contas Coin salvas na extensão (só no site da própria rede)
   2) quando aparece um pagamento do sistema Coin (link de cobrança, coinbank://, QR de conta ou ID de conta a pagar),
      mostra um cartão discreto no canto para pagar direto pela extensão.
   Tudo dentro de um Shadow DOM: não mexe no visual do site e não usa alertas nem notificações do navegador. */
(function () {
  'use strict';
  if (window.top !== window || window.__coinBankExt) return;
  window.__coinBankExt = true;
  const send = (m) => new Promise((r) => { try { chrome.runtime.sendMessage(m, (x) => { void chrome.runtime.lastError; r(x || {}); }); } catch { r({}); } });
  let CFG = null, PT = (navigator.language || '').toLowerCase().startsWith('pt');
  const t = (pt, en) => (PT ? pt : en);

  // ── raiz isolada
  const host = document.createElement('coin-bank-ext');
  host.style.cssText = 'all:initial;position:fixed;z-index:2147483646;inset:auto 0 0 auto;width:0;height:0';
  const root = host.attachShadow({ mode: 'closed' });
  root.innerHTML = `<style>
  :host{all:initial}
  *{box-sizing:border-box;font-family:"Segoe UI",system-ui,-apple-system,Roboto,Arial,sans-serif}
  .menu{position:fixed;min-width:250px;background:#191b1e;border:1px solid #2a2d33;border-radius:14px;box-shadow:0 14px 40px rgba(0,0,0,.55);padding:6px;color:#e8eaed;animation:in .16s ease both}
  .mh{display:flex;align-items:center;gap:8px;padding:6px 8px 8px;font-size:11.5px;color:#a1a7b0;font-weight:700;letter-spacing:.3px}
  .mh img{width:18px;height:18px;image-rendering:pixelated}
  .acc{display:flex;align-items:center;gap:10px;padding:9px 10px;border-radius:10px;cursor:pointer}
  .acc:hover{background:#212328}
  .av{width:30px;height:30px;border-radius:9px;background:rgba(214,169,75,.14);color:#d6a94b;display:flex;align-items:center;justify-content:center;font-weight:800;font-size:13px;flex:none}
  .n1{font-weight:700;font-size:13.5px}.n2{font-size:11.5px;color:#717883}
  .card{position:fixed;right:18px;bottom:18px;width:320px;background:#191b1e;border:1px solid #2a2d33;border-radius:18px;box-shadow:0 18px 50px rgba(0,0,0,.6);color:#e8eaed;padding:14px;animation:up .25s cubic-bezier(.2,.9,.3,1.2) both}
  .row{display:flex;align-items:center;gap:10px}
  .hd img{width:26px;height:26px;image-rendering:pixelated}
  .ttl{font-weight:800;font-size:14px;flex:1}
  .x{width:28px;height:28px;border:0;border-radius:9px;background:transparent;color:#a1a7b0;cursor:pointer;font-size:16px}
  .x:hover{background:#212328;color:#e8eaed}
  .amt{font-size:24px;font-weight:900;letter-spacing:-.5px;margin:10px 0 2px}
  .amt small{font-size:11px;color:#d6a94b;margin-left:6px;letter-spacing:.6px}
  .sub{font-size:12.5px;color:#a1a7b0;word-break:break-all}
  .btns{display:flex;gap:8px;margin-top:12px}
  .b{flex:1;height:38px;border-radius:11px;border:1px solid #2a2d33;background:#212328;color:#e8eaed;font-weight:700;font-size:13px;cursor:pointer}
  .b:hover{filter:brightness(1.12)}.b.ok{background:#0ecb81;border-color:transparent;color:#fff}.b[disabled]{opacity:.5;pointer-events:none}
  input{width:100%;height:38px;margin-top:10px;border-radius:11px;border:1px solid #2a2d33;background:#212328;color:#e8eaed;padding:0 12px;font-size:14px;outline:none}
  input:focus{border-color:#d6a94b}
  .err{color:#f05a60;font-size:12.5px;margin-top:8px;min-height:16px}
  .done{display:flex;flex-direction:column;align-items:center;gap:6px;padding:8px 0 4px;color:#2fbf80;font-weight:800}
  .chk{width:54px;height:54px;border-radius:50%;background:rgba(47,191,128,.15);display:flex;align-items:center;justify-content:center;font-size:28px;animation:pop .4s cubic-bezier(.2,.9,.3,1.4) both}
  .spin{width:18px;height:18px;border:2.5px solid rgba(255,255,255,.25);border-top-color:#fff;border-radius:50%;animation:sp .8s linear infinite;display:inline-block;vertical-align:middle}
  .more{font-size:11.5px;color:#717883;margin-top:8px;text-align:center}
  @keyframes in{from{opacity:0;transform:translateY(-4px)}to{opacity:1;transform:none}}
  @keyframes up{from{opacity:0;transform:translateY(14px) scale(.98)}to{opacity:1;transform:none}}
  @keyframes pop{from{transform:scale(.4)}to{transform:none}}
  @keyframes sp{to{transform:rotate(360deg)}}
  </style><div id="wrap"></div>`;
  const wrap = root.getElementById('wrap');
  const ICON = chrome.runtime.getURL('img/icon.png');
  const el = (html) => { const d = document.createElement('div'); d.innerHTML = html; return d.firstElementChild; };
  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const mount = () => { if (!host.isConnected) (document.body || document.documentElement).appendChild(host); };

  // ════════ 1) sugerir login com as contas Coin salvas ════════
  let accounts = null, menu = null, menuFor = null;
  const fire = (inp, v) => {
    const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set;
    setter.call(inp, v); inp.dispatchEvent(new Event('input', { bubbles: true })); inp.dispatchEvent(new Event('change', { bubbles: true }));
  };
  function userFieldFor(pass) {
    const scope = pass.form || document;
    const all = [...scope.querySelectorAll('input')].filter((i) => /^(text|email|tel|)$/i.test(i.type) && i.offsetParent !== null);
    const before = all.filter((i) => i.compareDocumentPosition(pass) & Node.DOCUMENT_POSITION_FOLLOWING);
    return before.length ? before[before.length - 1] : all[0] || null;
  }
  function closeMenu() { if (menu) { menu.remove(); menu = null; menuFor = null; } }
  function openMenu(field) {
    if (!accounts || !accounts.length || menuFor === field) return;
    closeMenu(); mount();
    const r = field.getBoundingClientRect();
    menu = el(`<div class="menu"><div class="mh"><img src="${ICON}">${t('Entrar com Coin Bank', 'Sign in with Coin Bank')}</div></div>`);
    for (const a of accounts) {
      const row = el(`<div class="acc"><div class="av">${esc((a.username || '?')[0].toUpperCase())}</div><div><div class="n1">${esc(a.username)}</div><div class="n2">${esc(a.net)}</div></div></div>`);
      row.addEventListener('mousedown', async (e) => {
        e.preventDefault();
        const c = await send({ type: 'credential', sid: a.sid });
        if (!c.ok) return closeMenu();
        const pass = field.type === 'password' ? field : (field.form || document).querySelector('input[type=password]');
        const user = pass ? userFieldFor(pass) : field;
        if (user) fire(user, c.username); if (pass) fire(pass, c.password);
        closeMenu();
      });
      menu.appendChild(row);
    }
    menu.style.left = Math.max(8, Math.min(innerWidth - 268, r.left)) + 'px';
    menu.style.top = (r.bottom + 6 + 120 > innerHeight ? r.top - 6 - (52 + accounts.length * 48) : r.bottom + 6) + 'px';
    wrap.appendChild(menu); menuFor = field;
  }
  function watchForms() {
    const passes = [...document.querySelectorAll('input[type=password]')];
    for (const p of passes) {
      if (p.__cbHooked) continue; p.__cbHooked = true;
      const u = userFieldFor(p);
      for (const f of [p, u]) if (f && !f.__cbFocus) { f.__cbFocus = true; f.addEventListener('focus', () => openMenu(f)); f.addEventListener('click', () => openMenu(f)); f.addEventListener('blur', () => setTimeout(() => { if (menuFor === f && document.activeElement !== f) closeMenu(); }, 150)); }
    }
  }
  addEventListener('scroll', closeMenu, true); addEventListener('resize', closeMenu);

  // ════════ 2) pagamentos do sistema Coin na página ════════
  const seen = new Set(); const found = []; let resolves = 0, card = null, dismissed = false;
  const UUID = /\b[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}\b/gi;
  const COINURI = /coinbank:\/\/(?:pay|user)\/[A-Za-z0-9_%?=.&-]{4,80}/g;
  function candidates() {
    const out = [];
    const known = new Set(CFG.origins || []);
    for (const a of document.querySelectorAll('a[href]')) {
      const href = a.getAttribute('href') || '';
      if (/^coinbank:\/\//i.test(href)) { out.push({ kind: 'link', text: href, origin: null }); continue; }
      try {
        const u = new URL(href, location.href);
        if (known.has(u.origin) && (/^\/pay\/[A-Za-z0-9_-]{8,40}\/?$/.test(u.pathname) || /^\/pay\/u\/\d{3,32}/.test(u.pathname))) out.push({ kind: 'link', text: u.href, origin: u.origin });
      } catch { /* */ }
    }
    const txt = document.body ? document.body.innerText || '' : '';
    for (const m of txt.match(COINURI) || []) out.push({ kind: 'link', text: m, origin: null });
    // IDs de conta (bill): só quando o texto em volta fala de conta/cobrança/bill
    if (/\b(bill|billid|conta|cobran[çc]a|fatura|invoice)\b/i.test(txt)) {
      const ids = txt.match(UUID) || [];
      for (const id of ids.slice(0, 4)) {
        const i = txt.indexOf(id); const around = txt.slice(Math.max(0, i - 80), i + 120);
        if (/\b(bill|billid|conta|cobran[çc]a|fatura|invoice|paybill)\b/i.test(around)) out.push({ kind: 'bill', text: id, origin: known.has(location.origin) ? location.origin : null });
      }
    }
    return out;
  }
  async function scan() {
    if (!CFG || !CFG.detect || dismissed) return;
    for (const c of candidates()) {
      const key = c.kind + ':' + c.text; if (seen.has(key) || resolves >= 8) continue;
      seen.add(key); resolves++;
      const r = await send({ type: 'resolve', kind: c.kind, text: c.text, origin: c.origin });
      if (r.ok) { PT = r.pt; found.push(r); showCard(); }
    }
  }
  const fmt = (sats, d) => { let n = BigInt(Math.trunc(Number(sats) || 0)); const base = 10n ** BigInt(d); const ip = (n / base).toString(); const fr = d ? (n % base).toString().padStart(d, '0') : ''; return ip.replace(/\B(?=(\d{3})+(?!\d))/g, PT ? '.' : ',') + (d ? (PT ? ',' : '.') + fr : ''); };
  const parse = (s, d) => { s = String(s || '').trim().replace(/\s/g, ''); if (!s) return null; if (s.includes(',') && s.includes('.')) s = s.lastIndexOf(',') > s.lastIndexOf('.') ? s.replace(/\./g, '').replace(',', '.') : s.replace(/,/g, ''); else s = s.replace(',', '.'); if (!/^\d+(\.\d+)?$/.test(s)) return null; const [a, b = ''] = s.split('.'); if (b.length > d) return null; return Number(BigInt(a) * 10n ** BigInt(d) + BigInt(b.padEnd(d, '0') || '0')); };
  const toApi = (v) => { const n = BigInt(Math.trunc(v)); return (n / 100000000n) + '.' + (n % 100000000n).toString().padStart(8, '0'); };
  function describe(f) {
    const i = f.info;
    if (i.type === 'request') return { title: t('Cobrança Coin', 'Coin payment request'), sats: i.request.amountSats, to: i.request.toName || i.request.to, toId: i.request.to, memo: i.request.memo, open: i.request.amountSats == null };
    if (i.type === 'user') return { title: t('Enviar coins', 'Send coins'), sats: i.amountSats, to: i.name || i.userId, toId: i.userId, open: i.amountSats == null };
    if (i.type === 'bill') return { title: t('Conta Coin para pagar', 'Coin bill to pay'), sats: i.bill.amountSats, to: i.bill.to_id, toId: i.bill.to_id, memo: 'ID ' + i.bill.id, open: false };
    return null;
  }
  function showCard(idx) {
    if (!found.length || dismissed) return;
    if (card && idx === undefined) { const m = card.querySelector('.more'); if (m) m.textContent = found.length > 1 ? t(`+${found.length - 1} outro(s) pagamento(s) nesta página`, `+${found.length - 1} more payment(s) on this page`) : ''; return; }
    const f = found[idx || 0]; const d = describe(f); if (!d) return;
    mount(); if (card) card.remove();
    card = el(`<div class="card">
      <div class="row hd"><img src="${ICON}"><div class="ttl">${esc(d.title)}</div><button class="x" title="${t('Fechar', 'Close')}">✕</button></div>
      <div class="amt">${d.sats != null ? fmt(d.sats, f.disp) : t('Valor livre', 'Any amount')}<small>COINS</small></div>
      <div class="sub">${t('Para', 'To')} ${esc(d.to)}${d.toId && d.toId !== d.to ? ' · ' + esc(d.toId) : ''} · ${esc(f.net)}</div>
      ${d.memo ? `<div class="sub" style="margin-top:4px">${esc(d.memo)}</div>` : ''}
      ${d.open ? `<input inputmode="decimal" placeholder="${t('Valor a pagar', 'Amount to pay')}">` : ''}
      <div class="err"></div>
      <div class="btns"><button class="b ign">${t('Ignorar', 'Ignore')}</button><button class="b ok pay">${f.logged ? t('Pagar com Coin Bank', 'Pay with Coin Bank') : t('Entre na extensão', 'Sign in on the extension')}</button></div>
      <div class="more"></div></div>`);
    const err = card.querySelector('.err'); const payB = card.querySelector('.pay');
    const close = () => { dismissed = true; card.remove(); card = null; };
    card.querySelector('.x').onclick = close; card.querySelector('.ign').onclick = () => { found.splice(idx || 0, 1); card.remove(); card = null; if (found.length) showCard(0); };
    if (!f.logged) payB.disabled = true;
    if (f.me && d.toId === f.me) { payB.disabled = true; err.textContent = t('É uma cobrança sua.', 'This is your own request.'); }
    payB.onclick = async () => {
      let amount;
      if (d.open) { const v = parse(card.querySelector('input').value, f.disp); if (!v || v <= 0) { err.textContent = t('Digite um valor válido', 'Type a valid amount'); return; } amount = toApi(v); }
      else if (f.info.type === 'user') amount = toApi(d.sats);
      if (!payB.dataset.confirm) { payB.dataset.confirm = '1'; payB.textContent = t('Confirmar pagamento', 'Confirm payment'); err.textContent = t('Pagamentos não podem ser desfeitos.', 'Payments cannot be undone.'); err.style.color = '#a1a7b0'; return; }
      payB.disabled = true; payB.innerHTML = '<span class="spin"></span>'; err.textContent = '';
      const r = await send({ type: 'pay', sid: f.sid, info: f.info, amount });
      if (r.ok) {
        const paid = r.result.amountSats ?? d.sats;
        card.querySelector('.btns').remove(); card.querySelector('.err').remove(); const inp = card.querySelector('input'); if (inp) inp.remove();
        card.querySelector('.amt').insertAdjacentElement('beforebegin', el(`<div class="done"><div class="chk">✓</div>${t('Pago!', 'Paid!')}</div>`));
        if (paid != null) card.querySelector('.amt').firstChild.textContent = fmt(paid, f.disp);
        found.splice(idx || 0, 1);
        setTimeout(() => { if (card) { card.remove(); card = null; } if (found.length) showCard(0); }, 4000);
      } else { payB.disabled = false; payB.textContent = t('Tentar de novo', 'Try again'); err.style.color = '#f05a60'; err.textContent = /INSUFFICIENT|insufficient/i.test(r.error || '') ? t('Saldo insuficiente.', 'Insufficient balance.') : (r.error || t('Não foi possível pagar.', 'Could not pay.')); }
    };
    wrap.appendChild(card); showCard();
  }

  // ── início
  (async () => {
    CFG = await send({ type: 'settings' }); if (!CFG || CFG.ok === false) return; PT = CFG.pt;
    if (CFG.autofill) { const r = await send({ type: 'accountsFor' }); accounts = r.list || []; if (accounts.length) watchForms(); }
    scan();
    let tmr = null;
    new MutationObserver(() => { clearTimeout(tmr); tmr = setTimeout(() => { if (accounts && accounts.length) watchForms(); scan(); }, 1200); }).observe(document.documentElement, { childList: true, subtree: true });
  })();
})();
