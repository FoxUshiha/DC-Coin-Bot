/* Coin Bank (extensão) — núcleo compartilhado: redes, sessões, chamadas à API e formatação.
   Usado pelo popup (script) e pelo service worker (importScripts). */
'use strict';
var CB = (function () {
  const MAIN = { id: 'main', name: 'Coin Bank', url: 'https://bank.foxsrv.net', kind: 'main' };
  const DEF_SETTINGS = { lang: 'auto', autofill: true, detect: true, autoClaim: false, hideBalance: false, disp: {} };

  const get = (keys) => new Promise((r) => chrome.storage.local.get(keys, r));
  const set = (obj) => new Promise((r) => chrome.storage.local.set(obj, r));

  async function load() {
    const d = await get(['servers', 'active', 'sessions', 'accounts', 'settings']);
    const servers = Array.isArray(d.servers) && d.servers.length ? d.servers : [MAIN];
    if (!servers.find((s) => s.id === 'main')) servers.unshift(MAIN);
    return { servers, active: d.active && servers.find((s) => s.id === d.active) ? d.active : 'main', sessions: d.sessions || {}, accounts: d.accounts || {}, settings: Object.assign({}, DEF_SETTINGS, d.settings || {}) };
  }
  const save = (patch) => set(patch);

  function cleanUrl(u) {
    u = String(u || '').trim(); if (!u) return null;
    if (!/^https?:\/\//i.test(u)) u = (/^(localhost|127\.|10\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.)/.test(u) ? 'http://' : 'https://') + u;
    try { const x = new URL(u); return (x.protocol + '//' + x.host + x.pathname).replace(/\/+$/, ''); } catch { return null; }
  }
  const originPattern = (url) => { const u = new URL(url); return u.protocol + '//' + u.hostname + '/*'; };

  async function raw(base, method, path, body, token, timeoutMs) {
    const headers = { Accept: 'application/json' };
    if (token) headers.Authorization = 'Bearer ' + token;
    let payload;
    if (body != null && method !== 'GET') { headers['Content-Type'] = 'application/json'; payload = JSON.stringify(body); }
    if (method === 'POST' && /\/(transfer|pay|bill\/pay)/.test(path)) headers['Idempotency-Key'] = (crypto.randomUUID ? crypto.randomUUID() : String(Date.now()) + Math.random());
    const ctl = new AbortController(); const t = setTimeout(() => ctl.abort(), timeoutMs || 15000);
    try {
      const r = await fetch(base.replace(/\/+$/, '') + path, { method, headers, body: payload, signal: ctl.signal, credentials: 'omit' });
      const txt = await r.text(); let json;
      try { json = txt ? JSON.parse(txt) : {}; } catch { json = { error: 'BAD_RESPONSE', message: txt.slice(0, 160) }; }
      return { status: r.status, json };
    } finally { clearTimeout(t); }
  }

  async function login(sid, username, password, remember) {
    const st = await load(); const sv = st.servers.find((s) => s.id === sid); if (!sv) throw new Error('SERVER_NOT_FOUND');
    const r = await raw(sv.url, 'POST', '/api/login', { username, password });
    if (r.status === 429) throw new Error(r.json.error || 'IP_LOCKED');
    if (!r.json || !r.json.sessionCreated) throw new Error('WRONG_LOGIN');
    st.sessions[sid] = { token: r.json.sessionId, userId: String(r.json.userId), username, at: Date.now() };
    if (remember) st.accounts[sid] = { username, password }; else delete st.accounts[sid];
    await save({ sessions: st.sessions, accounts: st.accounts });
    return st.sessions[sid];
  }

  /** chamada à API da rede com a sessão; se venceu e a senha está salva, entra de novo sozinho */
  async function api(sid, method, path, body, opts) {
    opts = opts || {};
    const st = await load(); const sv = st.servers.find((s) => s.id === sid); if (!sv) return { status: 404, json: { error: 'SERVER_NOT_FOUND' } };
    const auth = opts.auth !== false; const ses = st.sessions[sid];
    let r = await raw(sv.url, method, path, body, auth && ses ? ses.token : null, opts.timeoutMs);
    if (auth && r.status === 401 && st.accounts[sid]) {
      try { const s2 = await login(sid, st.accounts[sid].username, st.accounts[sid].password, true); r = await raw(sv.url, method, path, body, s2.token, opts.timeoutMs); } catch { /* */ }
    }
    if (auth && r.status === 401 && !st.accounts[sid] && ses) { delete st.sessions[sid]; await save({ sessions: st.sessions }); }
    return r;
  }

  // ── valores: inteiro na menor unidade; casas exibidas da rede (o ponto só anda a partir da direita, igual ao site/app)
  const isPt = (st) => (st && st.settings.lang === 'pt') || (st && st.settings.lang === 'auto' && (navigator.language || '').toLowerCase().startsWith('pt')) || (!st && (navigator.language || '').toLowerCase().startsWith('pt'));
  function disp(st, sid) { const d = st && st.settings.disp ? st.settings.disp[sid] : undefined; return Number.isInteger(d) ? d : 8; }
  function coins(v, d, pt) {
    let n = BigInt(Math.trunc(Number(v) || 0)); const neg = n < 0n; if (neg) n = -n;
    const base = 10n ** BigInt(d); const ip = (n / base).toString(); const fr = d ? (n % base).toString().padStart(d, '0') : '';
    return (neg ? '−' : '') + ip.replace(/\B(?=(\d{3})+(?!\d))/g, pt ? '.' : ',') + (d ? (pt ? ',' : '.') + fr : '');
  }
  function parseDec(input, d, strict) {
    let s = String(input || '').trim().replace(/\s/g, ''); if (!s) return null;
    if (s.includes(',') && s.includes('.')) s = s.lastIndexOf(',') > s.lastIndexOf('.') ? s.replace(/\./g, '').replace(',', '.') : s.replace(/,/g, '');
    else s = s.replace(',', '.');
    if (!/^\d+(\.\d+)?$/.test(s) && !/^\.\d+$/.test(s)) return null;
    const [a, b0 = ''] = s.split('.'); let b = b0;
    if (b.length > d) { if (strict) return null; b = b.slice(0, d); }
    return Number(BigInt(a || '0') * 10n ** BigInt(d) + BigInt(b.padEnd(d, '0') || '0'));
  }
  const toApi = (v) => { const n = BigInt(Math.trunc(v)); return (n / 100000000n).toString() + '.' + (n % 100000000n).toString().padStart(8, '0'); };
  const fromApi = (v) => (v == null || v === '' ? null : parseDec(typeof v === 'number' ? v.toFixed(8) : String(v), 8, false));
  const satsOf = (o) => { if (!o) return 0; const s = o.amountSats ?? o.sats; if (s != null && s !== '') return Number(s); return fromApi(o.amount) || 0; };

  return { MAIN, load, save, get, set, cleanUrl, originPattern, raw, api, login, isPt, disp, coins, parseDec, toApi, fromApi, satsOf };
})();
if (typeof self !== 'undefined') self.CB = CB;
