document.documentElement.setAttribute('data-theme','dark');document.documentElement.lang=(navigator.language||'').toLowerCase().indexOf('pt')===0?'pt-BR':'en';

(() => {
  const $ = (s) => document.querySelector(s);
  const ck = (n) => { const m = document.cookie.match(new RegExp('(?:^|; )' + n + '=([^;]*)')); return m ? decodeURIComponent(m[1]) : null; };
  const setCk = (n, v) => { document.cookie = `${n}=${encodeURIComponent(v)}; Max-Age=31536000; Path=/; SameSite=Lax${location.protocol === 'https:' ? '; Secure' : ''}`; };
  let lang = (function(){try{return localStorage.getItem('coin_lang')}catch(e){return null}})() || ((navigator.language || '').toLowerCase().startsWith('pt') ? 'pt' : 'en');
  const titles = { pt: 'Coin — Política de Privacidade', en: 'Coin — Privacy Policy' };
  function toc() {
    const box = $('#toc'); box.innerHTML = '';
    document.querySelectorAll('#doc section[id]').forEach((s) => { const h = s.querySelector('h2'); if (!h) return; const n = h.querySelector('.n'), l = h.querySelector('[data-l="' + lang + '"]'); const a = document.createElement('a'); a.href = '#' + s.id; a.textContent = ((n ? n.textContent + '. ' : '') + (l ? l.textContent : h.textContent)).replace(/\s+/g, ' ').trim(); a.dataset.id = s.id; box.appendChild(a); });
  }
  function apply() { document.documentElement.lang = lang === 'pt' ? 'pt-BR' : 'en'; $('#langBtn').textContent = lang.toUpperCase(); document.title = titles[lang] || titles.en; toc(); }
  const theme = () => { $('#themeBtn').textContent = document.documentElement.getAttribute('data-theme') === 'dark' ? '☀' : '☾'; };
  $('#langBtn').addEventListener('click', () => { lang = lang === 'pt' ? 'en' : 'pt'; try{localStorage.setItem('coin_lang',lang)}catch(e){} apply(); });
  $('#themeBtn').addEventListener('click', () => { const n = document.documentElement.getAttribute('data-theme') === 'dark' ? 'light' : 'dark'; document.documentElement.setAttribute('data-theme', n); setCk('coin_theme', n); theme(); });
  document.querySelectorAll('pre').forEach((p) => { const b = document.createElement('button'); b.className = 'cpy'; b.type = 'button'; b.textContent = lang === 'pt' ? 'Copiar' : 'Copy'; b.addEventListener('click', async () => { const s = p.querySelector('code') ? p.querySelector('code').innerText : p.innerText; try { await navigator.clipboard.writeText(s); } catch {} const t = document.createElement('div'); t.className = 'toast'; t.textContent = lang === 'pt' ? 'Copiado!' : 'Copied!'; document.body.appendChild(t); setTimeout(() => t.remove(), 1600); }); p.appendChild(b); });
  const io = new IntersectionObserver((es) => { es.forEach((e) => { if (e.isIntersecting) document.querySelectorAll('#toc a').forEach((a) => a.classList.toggle('on', a.dataset.id === e.target.id)); }); }, { rootMargin: '-80px 0px -70% 0px' });
  document.querySelectorAll('#doc section[id]').forEach((s) => io.observe(s));
  addEventListener('scroll', () => $('#totop').classList.toggle('on', scrollY > 600), { passive: true });
  $('#totop').addEventListener('click', () => scrollTo({ top: 0 }));
  apply(); theme();
})();
