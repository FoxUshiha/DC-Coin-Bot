/* Coin Bank (extensão) — popup: carteira mínima igual ao site, com redes extras, rede local, cobranças com QR e pagamentos.
   Tudo em HTML: avisos, carregamento e confirmações aparecem dentro do popup (sem alertas nem notificações do navegador). */
'use strict';
const NS = 'http://www.w3.org/2000/svg';
const IC = {
  home: '<path d="M3 11 12 4l9 7"/><path d="M5 10v10h14V10"/>', qr: '<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><path d="M14 14h3v3h-3zM20 14v.01M14 20h.01M17 17h4v4h-4"/>',
  scan: '<path d="M4 8V5a1 1 0 0 1 1-1h3M16 4h3a1 1 0 0 1 1 1v3M20 16v3a1 1 0 0 1-1 1h-3M8 20H5a1 1 0 0 1-1-1v-3M4 12h16"/>', bill: '<path d="M6 3h12v18l-3-2-3 2-3-2-3 2z"/><path d="M9 8h6M9 12h6"/>',
  more: '<circle cx="5" cy="12" r="1.4"/><circle cx="12" cy="12" r="1.4"/><circle cx="19" cy="12" r="1.4"/>', gift: '<rect x="3" y="8" width="18" height="5" rx="1"/><path d="M5 13v8h14v-8M12 8v13M12 8S10.5 3 8 3.5 7 8 12 8zm0 0s1.5-5 4-4.5S17 8 12 8z"/>',
  send: '<path d="M22 2 11 13M22 2l-7 20-4-9-9-4z"/>', card: '<rect x="2.5" y="5" width="19" height="14" rx="2.5"/><path d="M2.5 10h19M6 15h4"/>', chart: '<path d="M4 19V5M4 19h16M8 15l3-4 3 2 5-6"/>',
  lan: '<path d="M2 9a15 15 0 0 1 20 0M5 12.5a10 10 0 0 1 14 0M8.5 16a5 5 0 0 1 7 0"/><circle cx="12" cy="19.5" r="1"/>', globe: '<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a14 14 0 0 1 0 18M12 3a14 14 0 0 0 0 18"/>',
  gear: '<circle cx="12" cy="12" r="3"/><path d="M12 2v3M12 19v3M4.2 4.2l2.1 2.1M17.7 17.7l2.1 2.1M2 12h3M19 12h3M4.2 19.8l2.1-2.1M17.7 6.3l2.1-2.1"/>', doc: '<path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><path d="M14 3v5h5M9 13h6M9 17h6"/>',
  logout: '<path d="M15 4h3a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2h-3M10 16l-4-4 4-4M6 12h10"/>', x: '<path d="M6 6l12 12M18 6 6 18"/>', check: '<path d="m5 12 5 5 9-10"/>', plus: '<path d="M12 5v14M5 12h14"/>',
  copy: '<rect x="8" y="8" width="12" height="12" rx="2"/><path d="M16 8V6a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h2"/>', eye: '<path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
  eyeoff: '<path d="M3 3l18 18M10.6 5.1A9.7 9.7 0 0 1 12 5c6.5 0 10 7 10 7a17 17 0 0 1-3.2 4M6.6 6.6C3.9 8.4 2 12 2 12s3.5 7 10 7a9.6 9.6 0 0 0 5.4-1.6"/>', refresh: '<path d="M20 11a8 8 0 0 0-14.5-4M4 4v4h4M4 13a8 8 0 0 0 14.5 4M20 20v-4h-4"/>',
  in: '<path d="M17 7 7 17M7 9v8h8"/>', out: '<path d="M7 17 17 7M9 7h8v8"/>', trash: '<path d="M4 7h16M10 11v6M14 11v6M6 7l1 12a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2l1-12M9 7V4h6v3"/>', chev: '<path d="m9 6 6 6-6 6"/>',
  paste: '<rect x="6" y="4" width="12" height="17" rx="2"/><path d="M9 4V3h6v1M9 10h6M9 14h6"/>', server: '<rect x="3" y="4" width="18" height="7" rx="2"/><rect x="3" y="13" width="18" height="7" rx="2"/><path d="M7 7.5h.01M7 16.5h.01"/>', ext: '<path d="M14 4h6v6M20 4l-9 9"/><path d="M18 14v4a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4"/>',
};
const ico = (n, s) => { const e = document.createElementNS(NS, 'svg'); e.setAttribute('viewBox', '0 0 24 24'); e.setAttribute('class', 'i'); if (s) e.style.width = e.style.height = s + 'px'; e.innerHTML = IC[n] || IC.more; return e; };
function h(tag, a, ...kids) {
  const e = document.createElement(tag);
  for (const [k, v] of Object.entries(a || {})) {
    if (v == null || v === false) continue;
    if (k === 'class') e.className = v; else if (k === 'style' && typeof v === 'object') Object.assign(e.style, v);
    else if (k.startsWith('on')) e.addEventListener(k.slice(2), v); else if (k === 'value') e.value = v; else if (v === true) e.setAttribute(k, ''); else e.setAttribute(k, v);
  }
  for (const k of kids.flat(Infinity)) if (k != null && k !== false) e.append(k instanceof Node ? k : document.createTextNode(String(k)));
  return e;
}
// append() aceita listas e ignora null/false (telas montadas com "cond ? h(...) : null")
(function () { const o = Element.prototype.append; Element.prototype.append = function (...k) { return o.apply(this, k.flat(Infinity).filter((x) => x != null && x !== false)); }; })();
const clear = (e) => { while (e.firstChild) e.removeChild(e.firstChild); return e; };
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

let ST = null, PT = true, PAGE = 'home';
const t = (pt, en) => (PT ? pt : en);
const sid = () => ST.active;
const server = (id) => ST.servers.find((s) => s.id === (id || sid()));
const ses = (id) => ST.sessions[id || sid()];
const D = () => CB.disp(ST, sid());
const fmt = (v) => CB.coins(v, D(), PT);
const parse = (s) => CB.parseDec(s, D(), true);
const W = { bal: null, claimLeft: -1, claimAt: 0, claimSats: 0, cooldown: 0, online: false, toPay: 0 };

async function reload() { ST = await CB.load(); PT = CB.isPt(ST); document.documentElement.lang = PT ? 'pt-BR' : 'en'; }
class ApiErr extends Error { constructor(m, b) { super(m); this.body = b; } }
async function call(method, path, body, opts) {
  let r;
  try { r = await CB.api(sid(), method, path, body, opts); }
  catch { throw new ApiErr(t('A rede não respondeu. Confira a internet.', 'The network did not respond. Check your internet.'), {}); }
  if (r.status >= 400 || r.json.success === false) throw new ApiErr(r.json.message || r.json.error || 'HTTP ' + r.status, r.json);
  return r.json;
}
function errText(e) {
  const c = e && e.body && (e.body.error || e.body.code);
  const m = { INSUFFICIENT_FUNDS: t('Saldo insuficiente.', 'Insufficient balance.'), 'Insufficient funds': t('Saldo insuficiente.', 'Insufficient balance.'), INVALID_TARGET: t('ID de destino inválido.', 'Invalid destination ID.'), SELF_TRANSFER: t('Você não pode enviar para você mesmo.', 'You cannot send to yourself.'), 'Cooldown active': t('Resgate ainda não liberado.', 'Claim not available yet.'), PAYREQ_NOT_FOUND: t('Cobrança não encontrada ou vencida.', 'Payment request not found or expired.'), BILL_NOT_FOUND: t('Conta não encontrada.', 'Bill not found.'), WRONG_LOGIN: t('Usuário ou senha incorretos.', 'Wrong username or password.'), 'Invalid parameters': t('Valor ou dados inválidos.', 'Invalid amount or data.') };
  if (c && m[c]) return m[c]; if (e && m[e.message]) return m[e.message];
  return (e && e.message) || String(e);
}
let toastT = null;
function toast(msg, kind) { document.querySelectorAll('.toast').forEach((x) => x.remove()); const el = h('div', { class: 'toast ' + (kind || '') }, kind === 'ok' ? ico('check', 16) : null, msg); document.body.append(el); clearTimeout(toastT); toastT = setTimeout(() => el.remove(), 2800); }
async function copy(text, what) { try { await navigator.clipboard.writeText(text); toast(t(`${what} copiado`, `${what} copied`), 'ok'); } catch { toast(t('Não consegui copiar', 'Could not copy'), 'bad'); } }
function sheet(title, body, onClose) {
  const box = h('div', { class: 'sheet' }, h('div', { class: 'sh' }, h('h3', {}, title), h('button', { class: 'ib', onclick: () => close() }, ico('x'))), body);
  const ov = h('div', { class: 'ov', onmousedown: (e) => { if (e.target === ov) close(); } }, box);
  let done = false; const close = () => { if (done) return; done = true; ov.remove(); if (onClose) onClose(); };
  document.body.append(ov); return { close, box };
}
function ask(title, text, ok, danger) {
  return new Promise((res) => {
    let v = false;
    const s = sheet(title, h('div', { class: 'col' }, h('div', { class: 'muted', style: { whiteSpace: 'pre-line' } }, text), h('div', { class: 'row' }, h('button', { class: 'btn grow', onclick: () => { s.close(); } }, t('Cancelar', 'Cancel')), h('button', { class: 'btn grow ' + (danger ? 'danger' : 'ok'), onclick: () => { v = true; s.close(); } }, ok))), () => res(v));
  });
}
const qr = (text, px) => { const c = CoinQR.toCanvas(text, px * 2, { margin: 1 }); c.style.width = c.style.height = px + 'px'; return c; };
const sw = (on, fn) => { const i = h('input', { type: 'checkbox' }); i.checked = !!on; i.onchange = () => fn(i.checked); return h('label', { class: 'sw' }, i, h('span')); };
const amountInput = (ph) => h('input', { class: 'inp', inputmode: 'decimal', placeholder: ph || (D() ? '0' + (PT ? ',' : '.') + '0'.repeat(D()) : '0') });
const fdate = (d) => { const x = new Date(d); return isNaN(x) ? '—' : x.toLocaleString(PT ? 'pt-BR' : 'en-US', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' }); };
const countdown = (ms) => { const s = Math.max(0, Math.ceil(ms / 1000)); const hh = Math.floor(s / 3600), mm = Math.floor((s % 3600) / 60), ss = s % 60; const p = (x) => String(x).padStart(2, '0'); return (hh ? hh + ':' + p(mm) : mm) + ':' + p(ss); };
async function needHost(url) {
  if (/^https:\/\/bank\.foxsrv\.net/.test(url)) return true;
  const origins = [CB.originPattern(url)];
  try { if (await chrome.permissions.contains({ origins })) return true; return await chrome.permissions.request({ origins }); } catch { return false; }
}

/* ═══════════ estrutura ═══════════ */
const app = document.getElementById('app');
let els = {};
function shell() {
  clear(app);
  els.n1 = h('div', { class: 'n1' }); els.n2 = h('div', { class: 'n2' }); els.gift = h('span', { class: 'b', style: { display: 'none' } });
  els.body = h('div', { class: 'body' });
  const nav = (id, i, l) => h('button', { 'data-p': id, onclick: () => go(id) }, ico(i, 20), l);
  els.nav = h('div', { class: 'nav' }, nav('home', 'home', t('Início', 'Home')), nav('receive', 'qr', t('Receber', 'Receive')), nav('pay', 'scan', t('Pagar', 'Pay')), nav('bills', 'bill', t('Contas', 'Bills')), nav('more', 'more', t('Mais', 'More')));
  app.append(h('div', { class: 'hd' }, h('img', { src: 'img/icon.png' }), h('div', { class: 'net', onclick: pickNet, title: t('Trocar de rede', 'Switch network') }, els.n1, els.n2),
    h('button', { class: 'ib', title: t('Resgate', 'Claim'), onclick: openClaim }, ico('gift', 20), els.gift), h('button', { class: 'ib', title: t('Atualizar', 'Refresh'), onclick: () => { refresh(true); toast(t('Atualizado', 'Updated'), 'ok'); } }, ico('refresh'))),
  els.body, els.nav);
  paintHead();
}
function paintHead() {
  if (!els.n1) return;
  const s = server(); const se = ses();
  els.n1.textContent = s.name;
  clear(els.n2).append(h('span', { class: 'dot ' + (W.online ? 'ok' : se ? 'bad' : '') }), se ? (se.username || se.userId) : t('sem login', 'signed out'));
  const left = W.claimLeft < 0 ? -1 : Math.max(0, W.claimLeft - (Date.now() - W.claimAt));
  els.gift.style.display = left === 0 ? '' : 'none';
  els.nav.querySelectorAll('button').forEach((b) => b.classList.toggle('on', b.dataset.p === PAGE || (PAGE !== 'home' && !['receive', 'pay', 'bills'].includes(PAGE) && b.dataset.p === 'more')));
}
async function refresh(force) {
  const se = ses(); if (!se) return;
  try {
    const [b, c] = await Promise.all([call('GET', '/api/user/' + se.userId + '/balance'), call('GET', '/api/claim/status')]);
    W.bal = Number(b.sats); W.online = true; W.claimLeft = Number(c.cooldownRemainingMs); W.claimAt = Date.now(); W.claimSats = Number(c.claimAmountSats); W.cooldown = Number(c.cooldownMs);
  } catch { W.online = false; }
  paintHead(); if (force && VIEW && VIEW.update) VIEW.update();
  chrome.runtime.sendMessage({ type: 'refreshBadge' }, () => void chrome.runtime.lastError);
}
let VIEW = null;
function go(p) {
  PAGE = p; if (!ses() && !['networks', 'docs', 'settings', 'lan'].includes(p)) return renderLogin();
  if (!els.body || !app.contains(els.body)) shell();
  clear(els.body); const pg = h('div', { class: 'col fi' }); els.body.append(pg); els.body.scrollTop = 0;
  VIEW = (V[p] || V.home)(pg) || {}; paintHead();
}
async function pickNet() {
  const list = h('div', { class: 'col', style: { gap: '2px' } });
  const s = sheet(t('Escolher rede', 'Choose network'), h('div', { class: 'col' }, list, h('button', { class: 'btn w', onclick: () => { s.close(); go('networks'); } }, ico('plus', 16), t('Adicionar ou gerenciar redes', 'Add or manage networks'))));
  for (const sv of ST.servers) list.append(h('div', { class: 'li click', onclick: async () => { s.close(); await CB.save({ active: sv.id }); await reload(); Object.assign(W, { bal: null, claimLeft: -1, online: false }); go(ses() ? 'home' : 'login'); refresh(true); } },
    h('div', { class: 'av ' + (sv.id === sid() ? 'ok' : 'n') }, ico('globe', 16)), h('div', { class: 'grow' }, h('div', { class: 't1' }, sv.name), h('div', { class: 't2' }, ST.sessions[sv.id] ? ST.sessions[sv.id].username || ST.sessions[sv.id].userId : t('não conectado', 'not signed in'))), sv.id === sid() ? ico('check', 16) : null));
}

/* ═══════════ login ═══════════ */
function renderLogin() {
  PAGE = 'login'; els = {}; clear(app);
  let mode = 'login';
  const sel = h('select', { class: 'inp' }); for (const s of ST.servers) sel.append(h('option', { value: s.id }, s.name)); sel.value = sid();
  sel.onchange = async () => { await CB.save({ active: sel.value }); await reload(); };
  const user = h('input', { class: 'inp', placeholder: t('Usuário', 'Username'), maxlength: '64' }); const pass = h('input', { class: 'inp', type: 'password', placeholder: t('Senha', 'Password') });
  const pass2 = h('input', { class: 'inp', type: 'password', placeholder: t('Repita a senha', 'Repeat password'), style: { display: 'none' } });
  const rem = h('input', { type: 'checkbox' }); rem.checked = true;
  const err = h('div', { class: 'bad', style: { fontSize: '12px', minHeight: '16px' } });
  const btn = h('button', { class: 'btn pri w', type: 'submit' }, t('Entrar', 'Sign in'));
  const tabs = h('div', { class: 'tabs', style: { justifyContent: 'center' } });
  const setMode = (m) => { mode = m; pass2.style.display = m === 'reg' ? '' : 'none'; btn.textContent = m === 'reg' ? t('Criar conta', 'Create account') : t('Entrar', 'Sign in'); tabs.querySelectorAll('button').forEach((b) => b.classList.toggle('on', b.dataset.m === m)); err.textContent = ''; };
  tabs.append(h('button', { type: 'button', 'data-m': 'login', class: 'on', onclick: () => setMode('login') }, t('Entrar', 'Sign in')), h('button', { type: 'button', 'data-m': 'reg', onclick: () => setMode('reg') }, t('Criar conta', 'Create account')));
  const form = h('form', { class: 'col', onsubmit: async (e) => {
    e.preventDefault(); err.textContent = '';
    if (!user.value.trim() || !pass.value) { err.textContent = t('Preencha usuário e senha.', 'Fill in username and password.'); return; }
    if (mode === 'reg' && pass.value !== pass2.value) { err.textContent = t('As senhas não conferem.', 'Passwords do not match.'); return; }
    btn.disabled = true; clear(btn).append(h('span', { class: 'spin' }));
    try {
      if (mode === 'reg') {
        const r = await CB.raw(server().url, 'POST', '/api/register', { username: user.value.trim(), password: pass.value });
        if (r.status >= 400 || r.json.success === false) throw new ApiErr(r.json.message || r.json.error || 'HTTP ' + r.status, r.json);
      }
      await CB.login(sid(), user.value.trim(), pass.value, rem.checked);
      await reload(); shell(); go('home'); refresh(true); toast(t('Bem-vindo(a)!', 'Welcome!'), 'ok');
    } catch (x) { err.textContent = errText(x); btn.disabled = false; setMode(mode); }
  } }, tabs, h('div', { class: 'row' }, h('div', { class: 'grow' }, sel), h('button', { type: 'button', class: 'btn', title: t('Adicionar rede', 'Add network'), onclick: () => addNetwork(renderLogin) }, ico('plus', 16))), user, pass, pass2,
  h('label', { class: 'row', style: { fontSize: '11.5px', color: 'var(--fg2)', cursor: 'pointer' } }, rem, t('Lembrar e sugerir esta conta no site da rede', 'Remember and suggest this account on the network website')), err, btn);
  const others = ST.servers.filter((s) => ST.sessions[s.id] && s.id !== sid());
  app.append(h('div', { class: 'body', style: { justifyContent: 'center' } },
    h('div', { style: { textAlign: 'center' } }, h('img', { src: 'img/icon.png', style: { width: '72px', height: '72px', imageRendering: 'pixelated' } }), h('div', { style: { fontSize: '20px', fontWeight: '850' } }, 'Coin Bank'), h('div', { class: 't2' }, t('Carteira da moeda virtual Coin', 'Wallet for the Coin virtual currency'))),
    h('div', { class: 'card' }, form),
    others.length ? h('div', { class: 'card p0' }, others.map((s) => h('div', { class: 'li click', onclick: async () => { await CB.save({ active: s.id }); await reload(); shell(); go('home'); refresh(true); } }, h('div', { class: 'av ok' }, ico('globe', 16)), h('div', { class: 'grow' }, h('div', { class: 't1' }, s.name), h('div', { class: 't2' }, ST.sessions[s.id].username)), ico('chev', 16)))) : null,
    h('div', { class: 'row', style: { justifyContent: 'center', gap: '14px', fontSize: '11.5px' } }, h('a', { href: '#', class: 'dim', onclick: (e) => { e.preventDefault(); openDoc('terms'); } }, t('Termos', 'Terms')), h('a', { href: '#', class: 'dim', onclick: (e) => { e.preventDefault(); openDoc('privacy'); } }, t('Privacidade', 'Privacy')), h('a', { href: '#', class: 'dim', onclick: (e) => { e.preventDefault(); shell(); go('settings'); } }, t('Configurações', 'Settings')))));
  setTimeout(() => user.focus(), 30);
}

/* ═══════════ telas ═══════════ */
const V = {};
function txRow(tx) {
  const me = ses().userId; const out = String(tx.from_id) === me; const claim = /^0+$/.test(String(tx.from_id)); const sats = CB.satsOf(tx);
  return h('div', { class: 'li click', onclick: () => receipt(tx) }, h('div', { class: 'av ' + (claim ? '' : out ? 'n' : 'ok') }, ico(claim ? 'gift' : out ? 'out' : 'in', 16)),
    h('div', { class: 'grow' }, h('div', { class: 't1', style: { fontSize: '12.5px' } }, claim ? t('Resgate', 'Claim') : out ? t('Enviado', 'Sent') : t('Recebido', 'Received')), h('div', { class: 't2 mono', style: { fontSize: '11px' } }, (claim ? 'Coin Bank' : (out ? '→ ' + tx.to_id : '← ' + tx.from_id)) + ' · ' + fdate(tx.date))),
    h('div', { class: 'amt ' + (out ? '' : 'ok') }, (out ? '−' : '+') + fmt(sats)));
}
V.home = (pg) => {
  const bal = h('div', { class: 'bal' }); const seg = h('div', { class: 'seg' }); const claimRow = h('div', { class: 'card row', style: { cursor: 'pointer' }, onclick: openClaim }); const recent = h('div', { class: 'card p0' }, h('div', { class: 'li' }, h('span', { class: 'sk', style: { width: '70%' } })));
  const eyeB = h('button', { class: 'ib', onclick: async () => { ST.settings.hideBalance = !ST.settings.hideBalance; await CB.save({ settings: ST.settings }); update(); } });
  pg.append(h('div', { class: 'card' }, h('div', { class: 'row' }, h('div', { class: 't2 grow' }, t('Saldo disponível', 'Available balance')), eyeB), bal, h('div', { class: 'row wrap', style: { marginTop: '8px' } }, seg, h('span', { class: 'pill', onclick: () => copy(ses().userId, 'ID') }, 'ID ' + ses().userId))),
    h('div', { class: 'card', style: { padding: '6px' } }, h('div', { class: 'qa' },
      h('div', { onclick: () => sendSheet() }, h('span', { class: 'c' }, ico('send')), t('Enviar', 'Send')), h('div', { onclick: () => go('receive') }, h('span', { class: 'c' }, ico('qr')), t('Cobrar', 'Charge')),
      h('div', { onclick: () => go('pay') }, h('span', { class: 'c' }, ico('scan')), t('Pagar', 'Pay')), h('div', { onclick: () => go('card') }, h('span', { class: 'c' }, ico('card')), t('Cartão', 'Card')))),
    claimRow, h('div', { class: 'row' }, h('div', { class: 't1 grow' }, t('Últimas transações', 'Recent transactions')), h('button', { class: 'btn sm', onclick: () => go('history') }, t('Ver tudo', 'See all'))), recent);
  async function loadTx() { try { const r = await call('GET', '/api/transactions?page=1'); clear(recent); const l = (r.transactions || []).slice(0, 5); if (!l.length) recent.append(h('div', { class: 'empty' }, ico('gift'), t('Nenhuma transação ainda. Resgate seus primeiros coins no 🎁.', 'No transactions yet. Claim your first coins with 🎁.'))); l.forEach((x) => recent.append(txRow(x))); } catch (e) { clear(recent).append(h('div', { class: 'empty' }, errText(e))); } }
  let lastBal = null;
  function update() {
    clear(eyeB).append(ico(ST.settings.hideBalance ? 'eyeoff' : 'eye'));
    clear(bal).append(W.bal == null ? h('span', { class: 'dim' }, '— — —') : ST.settings.hideBalance ? '••••••' : fmt(W.bal), h('small', {}, 'COINS'));
    clear(seg); for (const [d, l] of [[8, PT ? '0,00000000' : '0.00000000'], [2, PT ? '0,00' : '0.00'], [0, t('Inteiro', 'Integer')]]) seg.append(h('button', { class: D() === d ? 'on' : '', onclick: async () => { ST.settings.disp[sid()] = d; await CB.save({ settings: ST.settings }); update(); loadTx(); } }, l));
    const left = W.claimLeft < 0 ? -1 : Math.max(0, W.claimLeft - (Date.now() - W.claimAt));
    clear(claimRow).append(h('div', { class: 'av ' + (left === 0 ? 'ok' : '') }, ico('gift', 16)), h('div', { class: 'grow' }, h('div', { class: 't1' }, left === 0 ? t('Resgate disponível!', 'Claim available!') : t('Resgate', 'Claim')), h('div', { class: 't2' }, left > 0 ? t('Próximo em ', 'Next in ') + countdown(left) : left === 0 ? t('Toque para resgatar', 'Tap to claim') : '—', ST.settings.autoClaim ? t(' · automático', ' · automatic') : '')), ico('chev', 16));
    if (W.bal !== lastBal) { lastBal = W.bal; loadTx(); }
  }
  update(); return { update };
};
V.receive = (pg) => {
  let req = null, stop = false;
  const amt = amountInput(t('Valor (vazio = livre)', 'Amount (empty = any)')); const memo = h('input', { class: 'inp', maxlength: '140', placeholder: t('Descrição (opcional)', 'Description (optional)') });
  const area = h('div', { class: 'col', style: { alignItems: 'center' } });
  pg.append(h('div', { class: 'card col' }, h('div', { class: 't1' }, t('Cobrar com QR', 'Charge with a QR')), amt, memo, h('div', { class: 'row' }, h('button', { class: 'btn pri grow', onclick: create }, ico('qr', 16), t('Gerar cobrança', 'Create request')), h('button', { class: 'btn', onclick: mine }, t('Meu QR', 'My QR')))), area);
  async function create() {
    let a; if (amt.value.trim()) { a = parse(amt.value); if (!a || a <= 0) { toast(t('Valor inválido (casas demais?)', 'Invalid amount (too many decimals?)'), 'bad'); return; } }
    clear(area).append(h('span', { class: 'spin' }));
    try { const r = await call('POST', '/api/pay/request', { amount: a ? CB.toApi(a) : undefined, memo: memo.value || undefined, expires: '1d' }); req = r.request; show(); watch(); }
    catch (e) { clear(area); toast(errText(e), 'bad'); }
  }
  async function mine() { try { const r = await call('GET', '/api/pay/me'); clear(area).append(h('div', { class: 'qrbox' }, qr(r.url, 190)), h('div', { class: 't1' }, t('Envie coins para ', 'Send coins to ') + (r.name || r.userId)), h('button', { class: 'btn sm', onclick: () => copy(r.url, 'Link') }, ico('copy', 14), t('Copiar link', 'Copy link'))); } catch (e) { toast(errText(e), 'bad'); } }
  function show() {
    clear(area).append(h('div', { class: 'qrbox' }, qr(req.url, 190)), h('div', { style: { fontSize: '20px', fontWeight: '900' } }, req.amountSats != null ? fmt(req.amountSats) + ' coins' : t('Valor livre', 'Any amount')), req.memo ? h('div', { class: 't2' }, req.memo) : null,
      h('div', { class: 'row t2' }, h('span', { class: 'spin', style: { color: 'var(--gold)', width: '12px', height: '12px' } }), t('Aguardando pagamento…', 'Waiting for payment…')),
      h('div', { class: 'row' }, h('button', { class: 'btn sm', onclick: () => copy(req.url, 'Link') }, ico('copy', 14), t('Copiar link', 'Copy link')), h('button', { class: 'btn sm danger', onclick: async () => { try { await call('POST', '/api/pay/request/' + req.id + '/cancel'); stop = true; clear(area); toast(t('Cobrança cancelada', 'Request cancelled')); } catch (e) { toast(errText(e), 'bad'); } } }, t('Cancelar', 'Cancel'))));
  }
  async function watch() {
    let since = req.paidCount || 0; const myReq = req;
    while (!stop && req === myReq && PAGE === 'receive') {
      try {
        const r = await call('GET', `/api/pay/request/${req.id}?wait=20&since=${since}`, null, { auth: false, timeoutMs: 26000 }); const q = r.request;
        if (q.paidCount > since) { stop = true; clear(area).append(h('div', { class: 'paid' }, h('div', { class: 'ck' }, ico('check', 28)), t('Recebido!', 'Received!')), h('div', { style: { fontSize: '20px', fontWeight: '900' } }, '+' + fmt(q.paidTotalSats) + ' coins'), h('div', { class: 't2 mono' }, t('de ', 'from ') + (q.lastPayer || ''))); refresh(); break; }
        if (q.status !== 'open') { clear(area).append(h('div', { class: 't2' }, t('Cobrança ', 'Request ') + q.status)); break; }
      } catch { await sleep(3000); }
    }
  }
  return { update() {} };
};
V.pay = (pg, prefill) => {
  const inp = h('textarea', { class: 'inp', rows: '3', placeholder: t('Cole o link do QR, coinbank://…, um ID de conta ou de cobrança', 'Paste the QR link, coinbank://…, an account ID or a bill ID') });
  const area = h('div', { class: 'col' });
  pg.append(h('div', { class: 'card col' }, h('div', { class: 't1' }, t('Pagar', 'Pay')), inp, h('div', { class: 'row' }, h('button', { class: 'btn', onclick: async () => { try { inp.value = await navigator.clipboard.readText(); check(); } catch { toast(t('Cole com Ctrl+V', 'Paste with Ctrl+V')); } } }, ico('paste', 16), t('Colar', 'Paste')), h('div', { class: 'grow' }), h('button', { class: 'btn pri', onclick: () => check() }, t('Continuar', 'Continue')))), area,
    h('div', { class: 'hint' }, t('Dica: quando um link de cobrança ou uma conta Coin aparece em qualquer site, a extensão mostra um cartão no canto da página para pagar direto.', 'Tip: when a Coin payment link or bill shows up on any website, the extension shows a card in the corner of the page to pay right there.')));
  async function check() {
    const text = inp.value.trim(); if (!text) return; clear(area).append(h('span', { class: 'sk', style: { width: '60%' } }));
    try {
      let r;
      if (/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(text)) { try { const b = await call('GET', '/api/bill/' + text, null, { auth: false }); r = { type: 'bill', bill: b.bill }; } catch { r = await call('POST', '/api/pay/scan', { data: text }, { auth: false }); } }
      else r = await call('POST', '/api/pay/scan', { data: text }, { auth: false });
      clear(area);
      if (r.type === 'user') return sendSheet(r.userId, r.amountSats, r.name);
      if (r.type === 'transaction') return receipt(r.tx);
      if (!['request', 'bill'].includes(r.type)) { area.append(h('div', { class: 'card bad' }, r.type === 'invalid' ? errText({ body: { error: r.error } }) : t('Não reconheci esse código nesta rede.', 'Code not recognized on this network.'))); return; }
      const isBill = r.type === 'bill'; const q = r.request; const b = r.bill;
      if (!isBill && q.status !== 'open') { area.append(h('div', { class: 'card bad' }, t('Esta cobrança está ', 'This request is ') + q.status)); return; }
      const sats = isBill ? b.amountSats : q.amountSats; const open = !isBill && sats == null; const a = open ? amountInput() : null;
      const btn = h('button', { class: 'btn ok w', onclick: async () => {
        let amount; if (open) { const v = parse(a.value); if (!v || v <= 0) { toast(t('Digite o valor', 'Type the amount'), 'bad'); return; } amount = CB.toApi(v); }
        if (!(await ask(t('Confirmar pagamento', 'Confirm payment'), `${open ? fmt(parse(a.value)) : fmt(sats)} coins\n${t('para', 'to')} ${isBill ? b.to_id : q.toName || q.to}\n${server().name}\n\n${t('Pagamentos não podem ser desfeitos.', 'Payments cannot be undone.')}`, t('Pagar', 'Pay')))) return;
        btn.disabled = true; clear(btn).append(h('span', { class: 'spin' }));
        try { const x = isBill ? await call('POST', '/api/bill/pay', { billId: b.id }) : await call('POST', '/api/pay/request/' + q.id + '/pay', amount ? { amount } : {}); paid(x); inp.value = ''; clear(area); }
        catch (e) { btn.disabled = false; btn.textContent = t('Pagar', 'Pay'); toast(errText(e), 'bad'); }
      } }, ico('check', 16), t('Pagar', 'Pay'));
      area.append(h('div', { class: 'card col', style: { gap: '4px' } }, h('div', { class: 't2' }, isBill ? t('Conta para', 'Bill to') : t('Pagar para', 'Pay to')), h('div', { class: 't1' }, isBill ? b.to_id : q.toName || q.to), !isBill && q.memo ? h('div', { class: 't2' }, q.memo) : null, h('div', { style: { fontSize: '22px', fontWeight: '900', margin: '4px 0' } }, open ? t('Valor livre', 'Any amount') : fmt(sats) + ' coins'), a, btn));
    } catch (e) { clear(area).append(h('div', { class: 'card bad' }, errText(e))); }
  }
  if (prefill) { inp.value = prefill; check(); } else setTimeout(() => inp.focus(), 30);
  return { update() {} };
};
function paid(x) {
  const s = sheet('', h('div', { class: 'col', style: { alignItems: 'center' } }, h('div', { class: 'paid' }, h('div', { class: 'ck' }, ico('check', 28)), t('Pagamento enviado', 'Payment sent')), h('div', { style: { fontSize: '22px', fontWeight: '900' } }, fmt(CB.satsOf(x)) + ' coins'),
    h('div', { class: 'row' }, x.txId ? h('button', { class: 'btn', onclick: () => { s.close(); receipt({ id: x.txId }); } }, t('Comprovante', 'Receipt')) : null, h('button', { class: 'btn pri', onclick: () => s.close() }, 'OK'))));
  refresh(true);
}
function sendSheet(toId, sats, name) {
  const to = h('input', { class: 'inp mono', placeholder: t('ID de destino', 'Destination ID'), value: toId || '' }); const a = amountInput(); if (sats) a.value = fmt(sats).replace(PT ? /\./g : /,/g, '');
  const b = h('button', { class: 'btn ok w', onclick: async () => {
    const v = parse(a.value); const id = to.value.trim();
    if (!/^\d{3,32}$/.test(id)) { toast(t('ID inválido', 'Invalid ID'), 'bad'); return; } if (!v || v <= 0) { toast(t('Valor inválido', 'Invalid amount'), 'bad'); return; }
    if (!(await ask(t('Confirmar envio', 'Confirm transfer'), `${fmt(v)} coins\n${t('para', 'to')} ${name ? name + ' · ' : ''}${id}\n\n${t('Transferências não podem ser desfeitas.', 'Transfers cannot be undone.')}`, t('Enviar', 'Send')))) return;
    b.disabled = true; clear(b).append(h('span', { class: 'spin' }));
    try { const x = await call('POST', '/api/transfer', { toId: id, amount: CB.toApi(v) }); s.close(); paid(x); } catch (e) { b.disabled = false; b.textContent = t('Enviar', 'Send'); toast(errText(e), 'bad'); }
  } }, ico('send', 16), t('Enviar', 'Send'));
  const s = sheet(t('Enviar', 'Send'), h('div', { class: 'col' }, name ? h('div', { class: 't1' }, name) : null, h('label', { class: 'f' }, t('Para (ID)', 'To (ID)'), to), h('label', { class: 'f' }, t('Valor · saldo ', 'Amount · balance ') + (W.bal != null ? fmt(W.bal) : '—'), a), b));
  setTimeout(() => (toId ? a : to).focus(), 30);
}
V.bills = (pg) => {
  let tab = 'toPay'; const list = h('div', { class: 'card p0' }); const tabs = h('div', { class: 'tabs' });
  const set = (x) => { tab = x; tabs.querySelectorAll('button').forEach((b) => b.classList.toggle('on', b.dataset.t === x)); load(); };
  tabs.append(h('button', { 'data-t': 'toPay', class: 'on', onclick: () => set('toPay') }, t('A pagar', 'To pay')), h('button', { 'data-t': 'toReceive', onclick: () => set('toReceive') }, t('A receber', 'To receive')));
  pg.append(h('div', { class: 'row' }, tabs, h('div', { class: 'grow' }), h('button', { class: 'btn sm pri', onclick: newBill }, ico('plus', 14), t('Gerar', 'New'))), list);
  async function load() {
    clear(list).append(h('div', { class: 'li' }, h('span', { class: 'sk', style: { width: '60%' } })));
    try {
      const r = await call('POST', '/api/bill/list', { page: 1 }); const l = r[tab] || []; clear(list);
      if (!l.length) list.append(h('div', { class: 'empty' }, ico('bill'), tab === 'toPay' ? t('Nada para pagar', 'Nothing to pay') : t('Nenhuma conta a receber', 'No bills to receive')));
      for (const b of l) list.append(h('div', { class: 'li' }, h('div', { class: 'av ' + (tab === 'toPay' ? 'bad' : 'ok') }, ico('bill', 16)), h('div', { class: 'grow' }, h('div', { class: 't1', style: { fontSize: '12.5px' } }, fmt(CB.satsOf(b)) + ' coins'), h('div', { class: 't2 mono', style: { fontSize: '11px' } }, (tab === 'toPay' ? '→ ' + b.to_id : b.from_id ? '← ' + b.from_id : t('qualquer pessoa', 'anyone')) + ' · ' + fdate(b.date))),
        h('button', { class: 'ib', title: t('Copiar ID', 'Copy ID'), onclick: () => copy(b.id, 'ID') }, ico('copy', 15)),
        tab === 'toPay' ? h('button', { class: 'btn sm ok', onclick: async () => { if (!(await ask(t('Pagar esta conta?', 'Pay this bill?'), `${fmt(CB.satsOf(b))} coins → ${b.to_id}`, t('Pagar', 'Pay')))) return; try { const x = await call('POST', '/api/bill/pay', { billId: b.id }); paid(x); load(); } catch (e) { toast(errText(e), 'bad'); } } }, t('Pagar', 'Pay')) : null));
    } catch (e) { clear(list).append(h('div', { class: 'empty' }, errText(e))); }
  }
  function newBill() {
    const a = amountInput(); const from = h('input', { class: 'inp mono', placeholder: t('ID de quem paga (vazio = qualquer)', 'Payer ID (empty = anyone)') });
    const b = h('button', { class: 'btn pri w', onclick: async () => {
      const v = parse(a.value); if (!v || v <= 0) { toast(t('Valor inválido', 'Invalid amount'), 'bad'); return; }
      b.disabled = true;
      try { const x = await call('POST', '/api/bill/create', { fromId: from.value.trim() || undefined, toId: ses().userId, amount: CB.toApi(v), time: '30d' }); s.close(); const s2 = sheet(t('Conta criada', 'Bill created'), h('div', { class: 'col', style: { alignItems: 'center' } }, h('div', { class: 'qrbox' }, qr(x.billId, 160)), h('div', { class: 'mono t2 sel', style: { wordBreak: 'break-all', textAlign: 'center' } }, x.billId), h('button', { class: 'btn w', onclick: () => { copy(x.billId, 'ID'); s2.close(); } }, ico('copy', 16), t('Copiar ID', 'Copy ID')))); load(); }
      catch (e) { b.disabled = false; toast(errText(e), 'bad'); }
    } }, t('Gerar conta', 'Create bill'));
    const s = sheet(t('Gerar conta', 'New bill'), h('div', { class: 'col' }, h('label', { class: 'f' }, t('Valor', 'Amount'), a), h('label', { class: 'f' }, t('Quem paga', 'Payer'), from), b));
  }
  load(); return { update() {} };
};
V.more = (pg) => {
  const item = (i, l, d, fn) => h('div', { class: 'li click', onclick: fn }, h('div', { class: 'av n' }, ico(i, 16)), h('div', { class: 'grow' }, h('div', { class: 't1' }, l), d ? h('div', { class: 't2' }, d) : null), ico('chev', 16));
  pg.append(h('div', { class: 'card p0' }, item('chart', t('Histórico', 'History'), t('Extrato completo e comprovantes', 'Full statement and receipts'), () => go('history')), item('card', t('Cartão', 'Card'), t('Código para pagamentos pela API', 'Code for API payments'), () => go('card')), item('lan', t('Rede local', 'Local network'), t('Encontrar redes Coin hospedadas por perto', 'Find Coin networks hosted nearby'), () => go('lan'))),
    h('div', { class: 'card p0' }, item('globe', t('Redes', 'Networks'), t('Adicionar outra API (rede Coin)', 'Add another API (Coin network)'), () => go('networks')), item('gear', t('Configurações', 'Settings'), t('Resgate automático, sugestões de login, detecção de pagamentos', 'Auto-claim, login suggestions, payment detection'), () => go('settings')), item('doc', t('Termos, privacidade e documentação', 'Terms, privacy and documentation'), t('Dentro da extensão, sem internet', 'Inside the extension, offline'), () => go('docs'))),
    h('div', { class: 'card p0' }, h('div', { class: 'li click', onclick: async () => { if (!(await ask(t('Sair da conta?', 'Sign out?'), t('A senha salva desta rede também é apagada.', 'The saved password for this network is removed too.'), t('Sair', 'Sign out'), true))) return; try { await CB.api(sid(), 'POST', '/api/logout', {}); } catch { /* */ } delete ST.sessions[sid()]; delete ST.accounts[sid()]; await CB.save({ sessions: ST.sessions, accounts: ST.accounts }); renderLogin(); } }, h('div', { class: 'av bad' }, ico('logout', 16)), h('div', { class: 't1 bad' }, t('Sair da conta', 'Sign out')))),
    h('div', { class: 'hint', style: { textAlign: 'center' } }, 'Coin Bank ' + chrome.runtime.getManifest().version));
  return { update() {} };
};
V.history = (pg) => {
  let page = 1; const list = h('div', { class: 'card p0' }); const more = h('button', { class: 'btn w' }, t('Carregar mais', 'Load more'));
  pg.append(h('div', { class: 't1' }, t('Histórico', 'History')), list, more);
  async function load() { more.disabled = true; try { const r = await call('GET', '/api/transactions?page=' + page); const l = r.transactions || []; if (page === 1 && !l.length) list.append(h('div', { class: 'empty' }, ico('chart'), t('Nenhuma transação', 'No transactions'))); l.forEach((x) => list.append(txRow(x))); more.style.display = l.length < 20 ? 'none' : ''; page++; } catch (e) { list.append(h('div', { class: 'empty' }, errText(e))); } more.disabled = false; }
  more.onclick = load; load(); return { update() {} };
};
async function receipt(tx) {
  const body = h('div', { class: 'col' }, h('span', { class: 'sk', style: { width: '60%' } })); sheet(t('Comprovante', 'Receipt'), body);
  try {
    if (!tx.date) { const r = await call('GET', '/api/tx/' + encodeURIComponent(tx.id), null, { auth: false }); tx = Object.assign({ from_id: r.tx.from, to_id: r.tx.to }, r.tx); }
    const link = server().url + '/tx/' + encodeURIComponent(tx.id);
    clear(body).append(h('div', { style: { textAlign: 'center' } }, h('span', { class: 'pill ok' }, ico('check', 12), t('CONFIRMADA', 'CONFIRMED')), h('div', { style: { fontSize: '24px', fontWeight: '900', margin: '6px 0' } }, fmt(CB.satsOf(tx)) + ' coins')),
      h('div', { class: 't2 mono', style: { wordBreak: 'break-all' } }, t('De ', 'From ') + (tx.from_id || tx.from), h('br'), t('Para ', 'To ') + (tx.to_id || tx.to), h('br'), fdate(tx.date), h('br'), 'ID ' + tx.id),
      h('div', { class: 'qrbox' }, qr(link, 140)), h('div', { class: 'row' }, h('button', { class: 'btn grow', onclick: () => copy(link, 'Link') }, ico('copy', 15), t('Copiar link', 'Copy link')), h('button', { class: 'btn grow', onclick: () => chrome.tabs.create({ url: link }) }, ico('ext', 15), t('Abrir', 'Open'))));
  } catch (e) { clear(body).append(h('div', { class: 'bad' }, errText(e))); }
}
V.card = (pg) => {
  let code = null, hidden = true; const num = h('div', { class: 'num' }); const showB = h('button', { class: 'btn grow' });
  const paint = () => { num.textContent = !code ? '•••• •••• •••• ••••' : hidden ? '•••• •••• •••• ' + code.slice(-4).toUpperCase() : code.replace(/(.{4})/g, '$1 ').trim().toUpperCase(); clear(showB).append(ico(hidden ? 'eye' : 'eyeoff', 15), hidden ? t('Mostrar', 'Show') : t('Ocultar', 'Hide')); };
  showB.onclick = () => { hidden = !hidden; paint(); };
  pg.append(h('div', { class: 'bcard' }, h('div', { class: 'top' }, h('img', { src: 'img/icon.png' }), h('span', { class: 'brand' }, 'COIN'), h('span', { class: 'badge' }, 'BLACK')), h('div', { style: { flex: '1' } }), h('div', { class: 'chip' }), h('div', { style: { flex: '1' } }), num, h('div', { style: { marginTop: '8px' } }, h('div', { class: 'lbl' }, t('TITULAR', 'CARD HOLDER')), h('div', { class: 'val' }, (ses().username || '').toUpperCase()))),
    h('div', { class: 'row' }, showB, h('button', { class: 'btn grow', onclick: () => code && copy(code, t('Código', 'Code')) }, ico('copy', 15), t('Copiar', 'Copy')), h('button', { class: 'btn grow danger', onclick: async () => { if (!(await ask(t('Resetar código do cartão?', 'Reset card code?'), t('O código atual para de funcionar na hora. Seu saldo não muda.', 'The current code stops working right away. Your balance does not change.'), t('Resetar', 'Reset'), true))) return; try { const r = await call('POST', '/api/card/reset'); code = r.newCode; hidden = false; paint(); toast(t('Novo código gerado', 'New code generated'), 'ok'); } catch (e) { toast(errText(e), 'bad'); } } }, ico('refresh', 15), t('Resetar', 'Reset'))),
    h('div', { class: 'hint' }, t('O código do cartão autoriza pagamentos pela API (bots, plugins, sites). Não é um cartão bancário — mantenha em segredo.', 'The card code authorizes payments through the API (bots, plugins, websites). It is not a bank card — keep it secret.')));
  paint(); call('POST', '/api/card').then((r) => { code = r.cardCode; paint(); }).catch((e) => toast(errText(e), 'bad'));
  return { update() {} };
};
V.lan = (pg) => {
  const base = h('input', { class: 'inp mono', value: '192.168.0' }); const port = h('input', { class: 'inp mono', value: '26450', style: { width: '90px' } });
  const list = h('div', { class: 'card p0' }); const status = h('div', { class: 't2' });
  const btn = h('button', { class: 'btn pri w', onclick: scan }, ico('lan', 16), t('Procurar redes por perto', 'Search nearby networks'));
  pg.append(h('div', { class: 'card col' }, h('div', { class: 't1' }, t('Rede local', 'Local network')), h('div', { class: 't2' }, t('Procura redes Coin hospedadas na sua rede Wi-Fi/cabo (pelo app do celular ou do Windows). Para ver pessoas por perto e cobrar por aproximação, use o app do celular ou do PC.', 'Looks for Coin networks hosted on your Wi-Fi/wired network (by the phone or Windows app). To see people nearby and charge by tap, use the phone or PC app.')),
    h('div', { class: 'row' }, h('label', { class: 'f grow' }, t('Faixa (ex.: 192.168.0)', 'Range (e.g. 192.168.0)'), base), h('label', { class: 'f' }, t('Porta', 'Port'), port)), btn, status), list);
  async function scan() {
    const b = base.value.trim().replace(/\.$/, ''); if (!/^\d{1,3}\.\d{1,3}\.\d{1,3}$/.test(b)) { toast(t('Faixa inválida', 'Invalid range'), 'bad'); return; }
    let ok = false; try { ok = await chrome.permissions.request({ origins: ['http://*/*'] }); } catch { /* */ }
    if (!ok) { toast(t('Permissão necessária para procurar na rede local', 'Permission required to search the local network'), 'bad'); return; }
    btn.disabled = true; clear(list); let found = 0, done = 0;
    const ips = Array.from({ length: 254 }, (_, i) => `${b}.${i + 1}`);
    const probe = async (ip) => {
      const url = `http://${ip}:${port.value.trim() || 26450}`;
      try { const r = await CB.raw(url, 'GET', '/api/health', null, null, 1200); if (r.status === 200 && r.json.ok) { found++; const known = ST.servers.find((s) => s.url === url);
        list.append(h('div', { class: 'li' }, h('div', { class: 'av' }, ico('server', 16)), h('div', { class: 'grow' }, h('div', { class: 't1' }, url.replace('http://', '')), h('div', { class: 't2' }, t('Rede Coin hospedada', 'Hosted Coin network'))), known ? h('span', { class: 'pill ok' }, t('adicionada', 'added')) : h('button', { class: 'btn sm', onclick: () => addNetwork(() => go('lan'), url) }, ico('plus', 14), t('Adicionar', 'Add')))); } } catch { /* */ }
      done++; status.textContent = t(`Procurando… ${done}/254 · ${found} encontrada(s)`, `Searching… ${done}/254 · ${found} found`);
    };
    for (let i = 0; i < ips.length; i += 32) await Promise.all(ips.slice(i, i + 32).map(probe));
    status.textContent = found ? t(`${found} rede(s) encontrada(s)`, `${found} network(s) found`) : t('Nenhuma rede Coin nessa faixa', 'No Coin network in that range');
    if (!found) list.append(h('div', { class: 'empty' }, ico('lan'), t('Ninguém hospedando nessa faixa e porta.', 'Nobody hosting on that range and port.')));
    btn.disabled = false;
  }
  return { update() {} };
};
function addNetwork(after, preset) {
  const url = h('input', { class: 'inp', placeholder: 'https://… ou 192.168.0.10:26450', value: preset || '' }); const name = h('input', { class: 'inp', placeholder: t('Nome (opcional)', 'Name (optional)') }); const err = h('div', { class: 'bad', style: { fontSize: '12px' } });
  const b = h('button', { class: 'btn pri w', onclick: async () => {
    const u = CB.cleanUrl(url.value); if (!u) { err.textContent = t('Endereço inválido', 'Invalid address'); return; }
    if (!(await needHost(u))) { err.textContent = t('Permissão de acesso a esse endereço recusada.', 'Access permission to that address was denied.'); return; }
    b.disabled = true; clear(b).append(h('span', { class: 'spin' }));
    try {
      const r = await CB.raw(u, 'GET', '/api/health', null, null, 8000); if (r.status !== 200) throw new Error('HTTP ' + r.status);
      if (!ST.servers.find((s) => s.url === u)) ST.servers.push({ id: 's' + Math.random().toString(36).slice(2, 9), name: name.value.trim() || new URL(u).host, url: u, kind: 'custom' });
      const sv = ST.servers.find((s) => s.url === u); await CB.save({ servers: ST.servers, active: sv.id }); await reload(); s.close(); toast(t('Rede adicionada', 'Network added'), 'ok');
      if (!ses()) renderLogin(); else if (after) after();
    } catch (e) { err.textContent = t('Não encontrei uma rede Coin nesse endereço', 'No Coin network found at that address') + ' (' + e.message + ')'; b.disabled = false; b.textContent = t('Adicionar', 'Add'); }
  } }, t('Adicionar', 'Add'));
  const s = sheet(t('Adicionar rede (API)', 'Add network (API)'), h('div', { class: 'col' }, h('label', { class: 'f' }, t('Endereço da API', 'API address'), url), name, err, b));
  setTimeout(() => url.focus(), 30);
}
V.networks = (pg) => {
  const list = h('div', { class: 'card p0' });
  pg.append(h('div', { class: 'row' }, h('div', { class: 't1 grow' }, t('Redes', 'Networks')), h('button', { class: 'btn sm pri', onclick: () => addNetwork(() => go('networks')) }, ico('plus', 14), t('Adicionar', 'Add'))), list, h('div', { class: 'hint' }, t('Cada rede é um servidor Coin Bank (uma API) com moeda e contas próprias.', 'Each network is a Coin Bank server (an API) with its own coin and accounts.')));
  for (const s of ST.servers) list.append(h('div', { class: 'li' }, h('div', { class: 'av ' + (s.id === sid() ? 'ok' : 'n') }, ico('globe', 16)), h('div', { class: 'grow' }, h('div', { class: 't1' }, s.name), h('div', { class: 't2', style: { wordBreak: 'break-all' } }, s.url + (ST.sessions[s.id] ? ' · ' + (ST.sessions[s.id].username || '') : ''))),
    s.id !== sid() ? h('button', { class: 'btn sm', onclick: async () => { await CB.save({ active: s.id }); await reload(); Object.assign(W, { bal: null, claimLeft: -1 }); go(ses() ? 'home' : 'login'); refresh(true); } }, t('Usar', 'Use')) : null,
    s.kind === 'custom' ? h('button', { class: 'ib', onclick: async () => { if (!(await ask(t('Remover rede?', 'Remove network?'), s.name, t('Remover', 'Remove'), true))) return; ST.servers = ST.servers.filter((x) => x.id !== s.id); delete ST.sessions[s.id]; delete ST.accounts[s.id]; await CB.save({ servers: ST.servers, sessions: ST.sessions, accounts: ST.accounts, active: ST.active === s.id ? 'main' : ST.active }); await reload(); go('networks'); } }, ico('trash', 15)) : null));
  return { update() {} };
};
V.settings = (pg) => {
  const s = ST.settings; const setS = async (k, v) => { s[k] = v; await CB.save({ settings: s }); toast(t('Salvo', 'Saved'), 'ok'); chrome.runtime.sendMessage({ type: 'refreshBadge' }, () => void chrome.runtime.lastError); };
  const row = (tl, d, c) => h('div', { class: 'li' }, h('div', { class: 'grow' }, h('div', { class: 't1' }, tl), d ? h('div', { class: 't2' }, d) : null), c);
  const lang = h('div', { class: 'seg' }); for (const [v, l] of [['auto', 'Auto'], ['pt', 'PT'], ['en', 'EN']]) lang.append(h('button', { class: s.lang === v ? 'on' : '', onclick: async () => { await setS('lang', v); await reload(); shell(); go('settings'); } }, l));
  pg.append(h('div', { class: 't1' }, t('Configurações', 'Settings')), h('div', { class: 'card p0' },
    row(t('Resgate automático', 'Auto-claim'), t('Em todas as redes em que você entrou, com o navegador aberto', 'On every network you signed in to, while the browser is open'), sw(s.autoClaim, (v) => setS('autoClaim', v))),
    row(t('Sugerir login', 'Suggest sign-in'), t('Mostra suas contas salvas nos campos de login do site da rede', 'Shows your saved accounts on the network website login fields'), sw(s.autofill, (v) => setS('autofill', v))),
    row(t('Pagar pelo site', 'Pay from websites'), t('Quando aparece uma cobrança ou conta Coin numa página, mostra o cartão para pagar', 'When a Coin request or bill shows up on a page, shows the card to pay'), sw(s.detect, (v) => setS('detect', v))),
    row(t('Esconder saldo', 'Hide balance'), null, sw(s.hideBalance, (v) => setS('hideBalance', v))),
    row(t('Idioma', 'Language'), null, lang)));
  return { update() {} };
};
V.docs = (pg) => {
  const item = (k, l, d) => h('div', { class: 'li click', onclick: () => openDoc(k) }, h('div', { class: 'av n' }, ico('doc', 16)), h('div', { class: 'grow' }, h('div', { class: 't1' }, l), h('div', { class: 't2' }, d)), ico('ext', 15));
  pg.append(h('div', { class: 't1' }, t('Documentos', 'Documents')), h('div', { class: 'card p0' }, item('terms', t('Termos de Uso', 'Terms of Use'), t('Regras do serviço', 'Service rules')), item('privacy', t('Privacidade', 'Privacy'), t('O que é guardado e como é protegido', 'What is stored and how it is protected')), item('documentation', t('Documentação da API', 'API documentation'), t('Endpoints para desenvolvedores', 'Endpoints for developers'))),
    h('div', { class: 'hint' }, t('Os documentos estão dentro da extensão e abrem sem internet.', 'The documents are inside the extension and open offline.')));
  return { update() {} };
};
const openDoc = (k) => chrome.tabs.create({ url: chrome.runtime.getURL('docs/' + k + '.html') });

/* ═══════════ resgate ═══════════ */
function openClaim() {
  if (!ses()) return;
  const box = h('div', { class: 'claimbox' }, h('img', { class: 'wb', src: 'img/wallet_back.png' }), h('img', { class: 'wf', src: 'img/wallet_front.png' }));
  const st = h('div', { style: { textAlign: 'center', minHeight: '50px' } }); const sub = h('div', { class: 'hint', style: { textAlign: 'center' } });
  const btn = h('button', { class: 'btn pri w' }, t('Resgatar', 'Claim'));
  const autoRow = h('div', { class: 'li', style: { padding: '6px 0 0' } }, h('div', { class: 'grow' }, h('div', { class: 't1' }, t('Resgate automático', 'Auto-claim')), h('div', { class: 't2' }, t('Com o navegador aberto', 'While the browser is open'))), sw(ST.settings.autoClaim, async (v) => { ST.settings.autoClaim = v; await CB.save({ settings: ST.settings }); toast(t('Salvo', 'Saved'), 'ok'); }));
  let busy = false, got = 0, gotUntil = 0, timer = null;
  const paint = () => {
    const left = W.claimLeft < 0 ? -1 : Math.max(0, W.claimLeft - (Date.now() - W.claimAt));
    clear(st).append(Date.now() < gotUntil ? h('div', { class: 'ok', style: { fontSize: '20px', fontWeight: '900' } }, '+' + fmt(got) + ' coins') : left === 0 ? h('div', { class: 'ok', style: { fontSize: '20px', fontWeight: '900' } }, t('Disponível agora', 'Available now')) : [h('div', { class: 't2' }, t('Próximo resgate em', 'Next claim in')), h('div', { style: { fontSize: '26px', fontWeight: '800' } }, left < 0 ? '—' : countdown(left))]);
    sub.textContent = W.claimSats ? `${fmt(W.claimSats)} coins ${t('a cada', 'every')} ${Math.round(W.cooldown / 60000)} min` : '';
    btn.disabled = busy || left !== 0;
  };
  const drop = (n) => { box.classList.remove('shake'); void box.offsetWidth; for (let i = 0; i < n; i++) { const c = h('img', { class: 'coin', src: 'img/coin.png', style: { left: (68 + (Math.random() - 0.5) * 50) + 'px', animationDelay: (i * 0.12) + 's' } }); box.append(c); setTimeout(() => c.remove(), 900 + i * 120); } setTimeout(() => box.classList.add('shake'), 650); };
  box.onclick = () => { box.classList.remove('shake'); void box.offsetWidth; box.classList.add('shake'); };
  btn.onclick = async () => {
    busy = true; clear(btn).append(h('span', { class: 'spin' })); paint();
    try { const r = await call('POST', '/api/claim', {}); got = Number(r.claimedSats ?? CB.fromApi(r.claimed)); gotUntil = Date.now() + 3500; W.claimLeft = Number(r.nextClaimInMs || W.cooldown); W.claimAt = Date.now(); drop(Math.max(1, Math.min(12, got))); refresh(true); }
    catch (e) { toast(errText(e), 'bad'); }
    busy = false; btn.textContent = t('Resgatar', 'Claim'); paint();
  };
  sheet(t('Resgate', 'Claim'), h('div', { class: 'col' }, box, st, sub, btn, autoRow), () => clearInterval(timer));
  paint(); timer = setInterval(paint, 1000);
}

/* ═══════════ início ═══════════ */
(async () => {
  await reload();
  document.getElementById('loading').remove();
  if (!ses()) renderLogin(); else { shell(); go('home'); refresh(true); }
  setInterval(() => { if (ses() && PAGE !== 'login') { paintHead(); if (PAGE === 'home' && VIEW && VIEW.update) VIEW.update(); } }, 1000);
  setInterval(() => { if (ses()) refresh(); }, 8000);
})();
