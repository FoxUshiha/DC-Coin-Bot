# Coin Bank — extensão de navegador 2.0.0 (Chrome, Edge, Brave, Opera)

## Instalar para testar
1. Abra `chrome://extensions` e ligue o **Modo do desenvolvedor**.
2. **Carregar sem compactação** → escolha esta pasta.

Para a Chrome Web Store, envie o zip desta pasta (o `manifest.json` fica na raiz). As capturas `screenshot1-5.png` (1280×800), `promo-tile.png` (440×280) e `big-promo-tile.png` (1400×560) já estão no tamanho da loja.

## O que tem
- **Carteira (igual ao site, mínima e escura):** saldo (esconder; 8 casas · 2 casas · inteiro), enviar, cartão black (mostrar/copiar/resetar), extrato com comprovante (QR e link) e resgate com a carteira e as moedinhas caindo.
- **Cobrar com QR:** valor livre ou fixo, descrição; a tela muda para **"Recebido!"** sozinha quando pagam. Também o QR fixo da conta.
- **Pagar:** cole o link do QR, `coinbank://…`, um ID de conta ou de conta a pagar; confirma antes.
- **Contas:** a pagar / a receber, pagar, gerar conta (com QR do ID).
- **Redes:** adicione outra API (outra rede Coin); cada rede tem a sua sessão. A extensão pede permissão só para o endereço adicionado.
- **Rede local:** procura redes Coin hospedadas na sua rede (pelo app do celular ou do Windows) e adiciona com 1 clique. Navegadores não podem usar UDP, então "pessoas por perto" ficam nos apps do celular e do PC.
- **Pagar pelo site:** quando aparece numa página um link de cobrança Coin, um `coinbank://` ou uma conta (ID) para pagar, surge um cartão escuro no canto da página para pagar direto, com confirmação.
- **Login sugerido:** no site de cada rede, os campos de login mostram as contas salvas na extensão (só no site da própria rede).
- **Resgate automático** (opcional) em todas as redes em que você entrou, com o navegador aberto; o ícone mostra **!** quando o resgate está liberado.
- **Termos, Privacidade e Documentação da API** dentro da extensão (abrem sem internet).
- Tudo em HTML: avisos, carregamento e confirmações aparecem dentro da extensão/página — sem alertas nem notificações do navegador.

## Arquivos
`manifest.json` · `popup.html/css/js` (janela) · `core.js` (redes, sessões, API, valores) · `background.js` (resgate automático, selo, API para as páginas) · `content.js` (login sugerido e pagamento pelo site, em Shadow DOM) · `qr.js` (QR offline) · `docs/` (documentos) · `img/`.

## Privacidade
As sessões e (se marcar "Lembrar") as senhas ficam só no armazenamento local da extensão neste navegador. Nada é enviado a terceiros: a extensão fala apenas com as redes Coin que você adicionou.
