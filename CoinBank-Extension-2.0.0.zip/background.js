/* Coin Bank (extensão) — service worker: API para o overlay das páginas, resgate automático e selo do ícone. */
'use strict';
importScripts('core.js');

const originOf = (u) => { try { return new URL(u).origin; } catch { return ''; } };

async function serverForOrigin(origin) {
  const st = await CB.load();
  return st.servers.find((s) => originOf(s.url) === origin) || null;
}

async function handle(msg, sender) {
  const st = await CB.load();
  const tabOrigin = sender && sender.tab ? originOf(sender.tab.url || sender.url || '') : '';
  switch (msg && msg.type) {
    case 'settings':
      return { autofill: st.settings.autofill, detect: st.settings.detect, pt: CB.isPt(st), origins: st.servers.map((s) => originOf(s.url)) };
    // contas salvas para sugerir login (só no site da própria rede)
    case 'accountsFor': {
      if (!st.settings.autofill) return { list: [] };
      const sv = await serverForOrigin(tabOrigin); if (!sv) return { list: [] };
      const list = [];
      if (st.accounts[sv.id]) list.push({ sid: sv.id, username: st.accounts[sv.id].username, net: sv.name });
      return { list };
    }
    case 'credential': {
      const sv = await serverForOrigin(tabOrigin); if (!sv || sv.id !== msg.sid || !st.accounts[sv.id]) return { ok: false };
      return { ok: true, username: st.accounts[sv.id].username, password: st.accounts[sv.id].password };
    }
    // algo de pagamento apareceu na página: descobre o que é na rede certa
    case 'resolve': {
      if (!st.settings.detect) return { ok: false };
      let sv = msg.origin ? await serverForOrigin(msg.origin) : null;
      if (!sv) sv = st.servers.find((s) => s.id === st.active) || st.servers[0];
      const ses = st.sessions[sv.id];
      if (msg.kind === 'bill') {
        const r = await CB.api(sv.id, 'GET', '/api/bill/' + encodeURIComponent(msg.text), null, { auth: false, timeoutMs: 8000 }).catch(() => null);
        if (!r || r.status !== 200 || !r.json.bill) return { ok: false };
        return { ok: true, sid: sv.id, net: sv.name, logged: !!ses, me: ses ? ses.userId : null, info: { type: 'bill', bill: r.json.bill }, disp: CB.disp(st, sv.id), pt: CB.isPt(st) };
      }
      const r = await CB.api(sv.id, 'POST', '/api/pay/scan', { data: msg.text }, { auth: false, timeoutMs: 8000 }).catch(() => null);
      if (!r || r.status !== 200 || !['request', 'user', 'bill'].includes(r.json.type)) return { ok: false };
      if (r.json.type === 'request' && r.json.request.status !== 'open') return { ok: false };
      return { ok: true, sid: sv.id, net: sv.name, logged: !!ses, me: ses ? ses.userId : null, info: r.json, disp: CB.disp(st, sv.id), pt: CB.isPt(st) };
    }
    case 'balance': {
      const ses = st.sessions[msg.sid]; if (!ses) return { ok: false };
      const r = await CB.api(msg.sid, 'GET', '/api/user/' + ses.userId + '/balance', null).catch(() => null);
      return r && r.status === 200 ? { ok: true, sats: Number(r.json.sats) } : { ok: false };
    }
    case 'pay': {
      const ses = st.sessions[msg.sid]; if (!ses) return { ok: false, error: 'NOT_LOGGED' };
      const i = msg.info; let r;
      if (i.type === 'request') r = await CB.api(msg.sid, 'POST', '/api/pay/request/' + i.request.id + '/pay', msg.amount ? { amount: msg.amount } : {});
      else if (i.type === 'user') r = await CB.api(msg.sid, 'POST', '/api/transfer', { toId: i.userId, amount: msg.amount });
      else if (i.type === 'bill') r = await CB.api(msg.sid, 'POST', '/api/bill/pay', { billId: i.bill.id });
      else return { ok: false, error: 'UNKNOWN' };
      updateBadge();
      return r.status === 200 && r.json.success !== false ? { ok: true, result: r.json } : { ok: false, error: r.json.message || r.json.error || 'HTTP ' + r.status };
    }
    case 'refreshBadge': updateBadge(); return { ok: true };
  }
  return { ok: false, error: 'UNKNOWN_MESSAGE' };
}
chrome.runtime.onMessage.addListener((msg, sender, reply) => { handle(msg, sender).then(reply, (e) => reply({ ok: false, error: e.message })); return true; });

// ── resgate automático (todas as redes em que você entrou) e selo "!" quando o resgate está liberado
async function autoClaim() {
  const st = await CB.load();
  for (const sid of Object.keys(st.sessions)) {
    try {
      const s = await CB.api(sid, 'GET', '/api/claim/status', null, { timeoutMs: 10000 });
      if (s.status === 200 && Number(s.json.cooldownRemainingMs) === 0) await CB.api(sid, 'POST', '/api/claim', {}, { timeoutMs: 10000 });
    } catch { /* rede fora do ar */ }
  }
}
async function updateBadge() {
  try {
    const st = await CB.load(); const ses = st.sessions[st.active];
    if (!ses) { chrome.action.setBadgeText({ text: '' }); return; }
    const s = await CB.api(st.active, 'GET', '/api/claim/status', null, { timeoutMs: 10000 });
    const ready = s.status === 200 && Number(s.json.cooldownRemainingMs) === 0;
    chrome.action.setBadgeBackgroundColor({ color: '#0ecb81' });
    chrome.action.setBadgeText({ text: ready ? '!' : '' });
  } catch { /* */ }
}
chrome.alarms.create('tick', { periodInMinutes: 1 });
chrome.alarms.onAlarm.addListener(async (a) => {
  if (a.name !== 'tick') return;
  const st = await CB.load();
  if (st.settings.autoClaim) await autoClaim();
  updateBadge();
});
chrome.runtime.onInstalled.addListener(updateBadge);
chrome.runtime.onStartup.addListener(updateBadge);
