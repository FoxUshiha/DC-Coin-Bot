package net.foxsrv.coinbank

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest
import java.security.SecureRandom
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.UUID
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

/** Erro de regra da moeda (vira {error: CODE} com o status HTTP). */
class CoinError(val code: String, val status: Int = 400, val extra: JSONObject? = null) : Exception(code)

/**
 * Banco da moeda hospedada neste aparelho (SQLite do Android). Mesmas regras da rede principal:
 * valores inteiros em sats, todo mundo começa com 0, resgate (claim) com tempo de espera, transferências atômicas,
 * cobranças (bills), pedidos de pagamento por QR, códigos de backup e cartão.
 */
class HostDb(ctx: Context) : SQLiteOpenHelper(ctx.applicationContext, "hostcoin.db", null, 1) {
    companion object {
        const val SYSTEM_ID = "000000000000"
        private val rnd = SecureRandom()
        fun hex(b: ByteArray): String { val sb = StringBuilder(); for (x in b) sb.append(String.format("%02x", x.toInt() and 0xff)); return sb.toString() }
        fun randHex(bytes: Int): String { val b = ByteArray(bytes); rnd.nextBytes(b); return hex(b) }
        fun sha256(s: String): String = hex(MessageDigest.getInstance("SHA-256").digest(s.toByteArray(Charsets.UTF_8)))
        fun iso(ms: Long): String { val f = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US); f.timeZone = TimeZone.getTimeZone("UTC"); return f.format(Date(ms)) }
        fun randId(n: Int): String {
            val a = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789_-"
            val sb = StringBuilder(); repeat(n) { sb.append(a[rnd.nextInt(a.length)]) }; return sb.toString()
        }
    }

    val lock = Any()

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE users(id TEXT PRIMARY KEY, username TEXT COLLATE NOCASE, pass TEXT, salt TEXT, sats INTEGER NOT NULL DEFAULT 0, last_claim INTEGER NOT NULL DEFAULT 0, last_tx INTEGER NOT NULL DEFAULT 0, card TEXT, created INTEGER NOT NULL)")
        db.execSQL("CREATE UNIQUE INDEX users_name ON users(username COLLATE NOCASE) WHERE username IS NOT NULL")
        db.execSQL("CREATE UNIQUE INDEX users_card ON users(card) WHERE card IS NOT NULL")
        db.execSQL("CREATE TABLE sessions(hash TEXT PRIMARY KEY, user_id TEXT NOT NULL, expires INTEGER NOT NULL)")
        db.execSQL("CREATE TABLE txs(id TEXT PRIMARY KEY, ts INTEGER NOT NULL, from_id TEXT NOT NULL, to_id TEXT NOT NULL, amount INTEGER NOT NULL)")
        db.execSQL("CREATE INDEX txs_from ON txs(from_id, ts)")
        db.execSQL("CREATE INDEX txs_to ON txs(to_id, ts)")
        db.execSQL("CREATE TABLE bills(id TEXT PRIMARY KEY, from_id TEXT, to_id TEXT NOT NULL, amount INTEGER NOT NULL, ts INTEGER NOT NULL, expires INTEGER)")
        db.execSQL("CREATE TABLE payreqs(id TEXT PRIMARY KEY, to_id TEXT NOT NULL, amount INTEGER, memo TEXT, reusable INTEGER NOT NULL DEFAULT 0, status TEXT NOT NULL, created INTEGER NOT NULL, expires INTEGER NOT NULL, paid_count INTEGER NOT NULL DEFAULT 0, paid_total INTEGER NOT NULL DEFAULT 0, last_tx TEXT, last_payer TEXT, paid_at INTEGER)")
        db.execSQL("CREATE INDEX payreqs_to ON payreqs(to_id, created)")
        db.execSQL("CREATE TABLE backups(code TEXT PRIMARY KEY, user_id TEXT NOT NULL)")
        db.execSQL("CREATE TABLE meta(k TEXT PRIMARY KEY, v TEXT)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}

    override fun onConfigure(db: SQLiteDatabase) { super.onConfigure(db); db.enableWriteAheadLogging() }

    private fun <T> tx(block: (SQLiteDatabase) -> T): T = synchronized(lock) {
        val db = writableDatabase
        db.beginTransaction()
        try { val r = block(db); db.setTransactionSuccessful(); r } finally { db.endTransaction() }
    }

    private inline fun <T> q(sql: String, args: Array<String>, map: (Cursor) -> T): List<T> {
        val out = ArrayList<T>()
        readableDatabase.rawQuery(sql, args).use { c -> while (c.moveToNext()) out.add(map(c)) }
        return out
    }

    private fun long1(sql: String, vararg args: String): Long = readableDatabase.rawQuery(sql, arrayOf(*args)).use { c -> if (c.moveToFirst() && !c.isNull(0)) c.getLong(0) else 0L }

    // ───────────────────────── contas ─────────────────────────
    private fun hashPass(pw: String, salt: String): String {
        val spec = PBEKeySpec(pw.toCharArray(), salt.toByteArray(Charsets.UTF_8), 12_000, 256)
        return hex(SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1").generateSecret(spec).encoded)
    }

    class User(val id: String, val username: String?, val sats: Long, val lastClaim: Long, val lastTx: Long, val card: String?, val created: Long, val pass: String?, val salt: String?)

    private fun userOf(c: Cursor) = User(c.getString(0), if (c.isNull(1)) null else c.getString(1), c.getLong(2), c.getLong(3), c.getLong(4), if (c.isNull(5)) null else c.getString(5), c.getLong(6), if (c.isNull(7)) null else c.getString(7), if (c.isNull(8)) null else c.getString(8))
    private val USER_COLS = "id, username, sats, last_claim, last_tx, card, created, pass, salt"

    fun user(id: String): User? = q("SELECT $USER_COLS FROM users WHERE id=?", arrayOf(id)) { userOf(it) }.firstOrNull()
    fun userByName(name: String): User? = q("SELECT $USER_COLS FROM users WHERE username=? COLLATE NOCASE", arrayOf(name)) { userOf(it) }.firstOrNull()
    fun userByCard(card: String): User? = q("SELECT $USER_COLS FROM users WHERE card=?", arrayOf(card.lowercase())) { userOf(it) }.firstOrNull()

    private fun newUserId(db: SQLiteDatabase): String {
        while (true) {
            val id = (100_000_000_000L + (rnd.nextDouble() * 899_999_999_999L).toLong()).toString()
            db.rawQuery("SELECT 1 FROM users WHERE id=?", arrayOf(id)).use { c -> if (!c.moveToFirst()) return id }
        }
    }

    fun register(username: String, password: String, maxUsers: Int): String {
        if (!Regex("^[A-Za-z0-9_.-]{3,24}$").matches(username)) throw CoinError("INVALID_USERNAME", 400, JSONObject().put("message", "Username must be 3-24 chars: letters, numbers, _ . -"))
        if (password.length < 4 || password.length > 128) throw CoinError("INVALID_PASSWORD")
        val salt = randHex(16); val h = hashPass(password, salt)
        return tx { db ->
            if (long1("SELECT COUNT(*) FROM users WHERE username IS NOT NULL") >= maxUsers) throw CoinError("TOO_MANY_REQUESTS", 429, JSONObject().put("message", "This network is full"))
            db.rawQuery("SELECT 1 FROM users WHERE username=? COLLATE NOCASE", arrayOf(username)).use { c -> if (c.moveToFirst()) throw CoinError("Username already taken", 409) }
            val id = newUserId(db)
            val v = ContentValues(); v.put("id", id); v.put("username", username); v.put("pass", h); v.put("salt", salt); v.put("sats", 0L); v.put("card", randHex(6)); v.put("created", System.currentTimeMillis())
            db.insertOrThrow("users", null, v)
            id
        }
    }

    fun checkLogin(username: String, password: String): User? {
        val u = userByName(username) ?: return null
        val p = u.pass ?: return null; val s = u.salt ?: return null
        return if (MessageDigest.isEqual(hashPass(password, s).toByteArray(), p.toByteArray())) u else null
    }

    fun changeCredentials(id: String, username: String?, password: String?) = tx { db ->
        val v = ContentValues()
        if (username == null && password == null) { v.putNull("username"); v.putNull("pass"); v.putNull("salt") }
        else {
            if (username != null) {
                if (!Regex("^[A-Za-z0-9_.-]{3,24}$").matches(username)) throw CoinError("INVALID_USERNAME")
                db.rawQuery("SELECT id FROM users WHERE username=? COLLATE NOCASE", arrayOf(username)).use { c -> if (c.moveToFirst() && c.getString(0) != id) throw CoinError("Username already taken", 409) }
                v.put("username", username)
            }
            if (password != null) { if (password.length < 4 || password.length > 128) throw CoinError("INVALID_PASSWORD"); val salt = randHex(16); v.put("salt", salt); v.put("pass", hashPass(password, salt)) }
        }
        db.update("users", v, "id=?", arrayOf(id))
        db.delete("sessions", "user_id=?", arrayOf(id))
    }

    // ───────────────────────── sessões (guarda só o sha256 do token) ─────────────────────────
    fun createSession(userId: String): String {
        val token = randHex(32)
        tx { db ->
            db.delete("sessions", "expires<?", arrayOf(System.currentTimeMillis().toString()))
            val v = ContentValues(); v.put("hash", sha256(token)); v.put("user_id", userId); v.put("expires", System.currentTimeMillis() + 24 * 3_600_000L)
            db.insertOrThrow("sessions", null, v)
            // no máximo 5 sessões por conta
            db.execSQL("DELETE FROM sessions WHERE user_id=? AND hash NOT IN (SELECT hash FROM sessions WHERE user_id=? ORDER BY expires DESC LIMIT 5)", arrayOf(userId, userId))
        }
        return token
    }

    fun sessionUser(token: String): String? {
        if (!Regex("^[a-fA-F0-9]{64}$").matches(token)) return null
        return q("SELECT user_id FROM sessions WHERE hash=? AND expires>?", arrayOf(sha256(token.lowercase()), System.currentTimeMillis().toString())) { it.getString(0) }.firstOrNull()
    }

    fun deleteSession(token: String) = tx { db -> db.delete("sessions", "hash=?", arrayOf(sha256(token.lowercase()))) }

    // ───────────────────────── dinheiro ─────────────────────────
    private fun bal(db: SQLiteDatabase, id: String): Long? = db.rawQuery("SELECT sats FROM users WHERE id=?", arrayOf(id)).use { c -> if (c.moveToFirst()) c.getLong(0) else null }

    private fun insertTx(db: SQLiteDatabase, id: String, from: String, to: String, sats: Long, now: Long) {
        val v = ContentValues(); v.put("id", id); v.put("ts", now); v.put("from_id", from); v.put("to_id", to); v.put("amount", sats)
        db.insertOrThrow("txs", null, v)
    }

    class TxOut(val id: String, val ts: Long, val from: String, val to: String, val sats: Long)

    private fun doTransfer(db: SQLiteDatabase, from: String, to: String, sats: Long, txId: String, now: Long): TxOut {
        if (sats <= 0) throw CoinError("INVALID_AMOUNT")
        if (from == to) throw CoinError("SELF_TRANSFER")
        val fb = bal(db, from) ?: throw CoinError("INSUFFICIENT_FUNDS", 402)
        if (bal(db, to) == null) throw CoinError("INVALID_TARGET")
        val lastTx = db.rawQuery("SELECT last_tx FROM users WHERE id=?", arrayOf(from)).use { c -> if (c.moveToFirst()) c.getLong(0) else 0L }
        if (now - lastTx < 1000) throw CoinError("TRANSFER_COOLDOWN", 429)
        if (fb < sats) throw CoinError("INSUFFICIENT_FUNDS", 402)
        db.execSQL("UPDATE users SET sats=sats-?, last_tx=? WHERE id=?", arrayOf<Any>(sats, now, from))
        db.execSQL("UPDATE users SET sats=sats+? WHERE id=?", arrayOf<Any>(sats, to))
        insertTx(db, txId, from, to, sats, now)
        return TxOut(txId, now, from, to, sats)
    }

    fun transfer(from: String, to: String, sats: Long): TxOut = tx { db -> doTransfer(db, from, to, sats, UUID.randomUUID().toString(), System.currentTimeMillis()) }

    fun claim(userId: String, claimSats: Long, cooldownMs: Long): TxOut = tx { db ->
        val now = System.currentTimeMillis()
        val last = db.rawQuery("SELECT last_claim FROM users WHERE id=?", arrayOf(userId)).use { c -> if (c.moveToFirst()) c.getLong(0) else throw CoinError("INVALID_TARGET") }
        if (last > 0 && now - last < cooldownMs) throw CoinError("COOLDOWN_ACTIVE", 429, JSONObject().put("nextClaimInMs", last + cooldownMs - now).put("lastClaimTs", last))
        db.execSQL("UPDATE users SET sats=sats+?, last_claim=? WHERE id=?", arrayOf<Any>(claimSats, now, userId))
        val id = UUID.randomUUID().toString()
        insertTx(db, id, SYSTEM_ID, userId, claimSats, now)
        TxOut(id, now, SYSTEM_ID, userId, claimSats)
    }

    fun setCard(userId: String): String = tx { db -> val c = randHex(6); db.execSQL("UPDATE users SET card=? WHERE id=?", arrayOf<Any>(c, userId)); c }

    // ───────────────────────── leituras ─────────────────────────
    fun txList(userId: String, limit: Int, offset: Int): List<TxOut> =
        q("SELECT id, ts, from_id, to_id, amount FROM txs WHERE from_id=? OR to_id=? ORDER BY ts DESC LIMIT $limit OFFSET $offset", arrayOf(userId, userId)) { TxOut(it.getString(0), it.getLong(1), it.getString(2), it.getString(3), it.getLong(4)) }

    fun txGet(id: String): TxOut? = q("SELECT id, ts, from_id, to_id, amount FROM txs WHERE id=?", arrayOf(id)) { TxOut(it.getString(0), it.getLong(1), it.getString(2), it.getString(3), it.getLong(4)) }.firstOrNull()

    fun txCount(userId: String): Long = long1("SELECT COUNT(*) FROM txs WHERE from_id=? OR to_id=?", userId, userId)

    fun stats(): JSONObject {
        val now = System.currentTimeMillis(); val day = (now - 86_400_000L).toString()
        return JSONObject()
            .put("totalUsers", long1("SELECT COUNT(*) FROM users WHERE username IS NOT NULL"))
            .put("newUsers24h", long1("SELECT COUNT(*) FROM users WHERE created>?", day))
            .put("holders", long1("SELECT COUNT(*) FROM users WHERE sats>0"))
            .put("totalSats", long1("SELECT COALESCE(SUM(sats),0) FROM users"))
            .put("totalTransactions", long1("SELECT COUNT(*) FROM txs"))
            .put("transactions24h", long1("SELECT COUNT(*) FROM txs WHERE ts>?", day))
            .put("volume24hSats", long1("SELECT COALESCE(SUM(amount),0) FROM txs WHERE ts>? AND from_id<>?", day, SYSTEM_ID))
            .put("totalClaims", long1("SELECT COUNT(*) FROM txs WHERE from_id=?", SYSTEM_ID))
            .put("claims24h", long1("SELECT COUNT(*) FROM txs WHERE from_id=? AND ts>?", SYSTEM_ID, day))
            .put("openBills", long1("SELECT COUNT(*) FROM bills"))
            .put("totalCards", long1("SELECT COUNT(*) FROM users WHERE card IS NOT NULL"))
    }

    fun history(days: Int): JSONArray {
        val out = JSONArray()
        val cal = java.util.Calendar.getInstance(TimeZone.getTimeZone("UTC"))
        cal.set(java.util.Calendar.HOUR_OF_DAY, 0); cal.set(java.util.Calendar.MINUTE, 0); cal.set(java.util.Calendar.SECOND, 0); cal.set(java.util.Calendar.MILLISECOND, 0)
        cal.add(java.util.Calendar.DAY_OF_YEAR, -(days - 1))
        val f = SimpleDateFormat("yyyy-MM-dd", Locale.US); f.timeZone = TimeZone.getTimeZone("UTC")
        for (i in 0 until days) {
            val a = cal.timeInMillis; val b = a + 86_400_000L
            val n = long1("SELECT COUNT(*) FROM txs WHERE ts>=? AND ts<? AND from_id<>?", a.toString(), b.toString(), SYSTEM_ID)
            val v = long1("SELECT COALESCE(SUM(amount),0) FROM txs WHERE ts>=? AND ts<? AND from_id<>?", a.toString(), b.toString(), SYSTEM_ID)
            val c = long1("SELECT COUNT(*) FROM txs WHERE ts>=? AND ts<? AND from_id=?", a.toString(), b.toString(), SYSTEM_ID)
            out.put(JSONObject().put("date", f.format(Date(a))).put("transactions", n).put("volume", Coin.api(v, HostConfig.get().optInt("decimals", 8))).put("volumeSats", v).put("claims", c))
            cal.add(java.util.Calendar.DAY_OF_YEAR, 1)
        }
        return out
    }

    /** posição no ranking (só quem tem saldo), como a rede principal */
    fun rankOf(sats: Long): Long? = if (sats <= 0) null else long1("SELECT COUNT(*) FROM users WHERE username IS NOT NULL AND sats>?", sats.toString()) + 1

    fun rank(limit: Int, offset: Int): List<User> = q("SELECT $USER_COLS FROM users WHERE username IS NOT NULL ORDER BY sats DESC LIMIT $limit OFFSET $offset", arrayOf()) { userOf(it) }

    // ───────────────────────── cobranças (bills) ─────────────────────────
    class Bill(val id: String, val from: String?, val to: String, val sats: Long, val ts: Long, val expires: Long?)
    private fun billOf(c: Cursor) = Bill(c.getString(0), if (c.isNull(1) || c.getString(1).isEmpty()) null else c.getString(1), c.getString(2), c.getLong(3), c.getLong(4), if (c.isNull(5)) null else c.getLong(5))

    fun billCreate(from: String?, to: String, sats: Long, expires: Long): Bill = tx { db ->
        if (sats <= 0) throw CoinError("INVALID_AMOUNT")
        if (bal(db, to) == null) throw CoinError("INVALID_TARGET")
        val id = UUID.randomUUID().toString(); val now = System.currentTimeMillis()
        val v = ContentValues(); v.put("id", id); v.put("from_id", from ?: ""); v.put("to_id", to); v.put("amount", sats); v.put("ts", now); v.put("expires", expires)
        db.insertOrThrow("bills", null, v)
        Bill(id, from, to, sats, now, expires)
    }

    fun billGet(id: String): Bill? = q("SELECT id, from_id, to_id, amount, ts, expires FROM bills WHERE id=?", arrayOf(id)) { billOf(it) }.firstOrNull()
    fun billsFrom(user: String, limit: Int, off: Int) = q("SELECT id, from_id, to_id, amount, ts, expires FROM bills WHERE from_id=? ORDER BY ts DESC LIMIT $limit OFFSET $off", arrayOf(user)) { billOf(it) }
    fun billsTo(user: String, limit: Int, off: Int) = q("SELECT id, from_id, to_id, amount, ts, expires FROM bills WHERE to_id=? ORDER BY ts DESC LIMIT $limit OFFSET $off", arrayOf(user)) { billOf(it) }

    class BillPaid(val bill: Bill, val tx: TxOut?, val self: Boolean)

    fun billPay(id: String, payer: String): BillPaid = tx { db ->
        val now = System.currentTimeMillis()
        val b = db.rawQuery("SELECT id, from_id, to_id, amount, ts, expires FROM bills WHERE id=?", arrayOf(id)).use { c -> if (c.moveToFirst()) billOf(c) else null } ?: throw CoinError("BILL_NOT_FOUND", 404)
        if (b.expires != null && b.expires < now) { db.delete("bills", "id=?", arrayOf(id)); throw CoinError("BILL_EXPIRED", 410) }
        val self = b.to == payer
        val t = if (self) null else doTransfer(db, payer, b.to, b.sats, b.id, now)
        db.delete("bills", "id=?", arrayOf(id))
        BillPaid(b, t, self)
    }

    // ───────────────────────── pedidos de pagamento (QR) ─────────────────────────
    class PayReq(val id: String, val to: String, val sats: Long?, val memo: String?, val reusable: Boolean, val status: String, val created: Long, val expires: Long, val paidCount: Int, val paidTotal: Long, val lastTx: String?, val lastPayer: String?, val paidAt: Long?)
    private fun prOf(c: Cursor) = PayReq(c.getString(0), c.getString(1), if (c.isNull(2)) null else c.getLong(2), if (c.isNull(3)) null else c.getString(3), c.getInt(4) != 0, c.getString(5), c.getLong(6), c.getLong(7), c.getInt(8), c.getLong(9), if (c.isNull(10)) null else c.getString(10), if (c.isNull(11)) null else c.getString(11), if (c.isNull(12)) null else c.getLong(12))
    private val PR_COLS = "id, to_id, amount, memo, reusable, status, created, expires, paid_count, paid_total, last_tx, last_payer, paid_at"

    fun prCreate(to: String, sats: Long?, memo: String?, reusable: Boolean, expires: Long): PayReq = tx { db ->
        val open = db.rawQuery("SELECT COUNT(*) FROM payreqs WHERE to_id=? AND status='open' AND expires>?", arrayOf(to, System.currentTimeMillis().toString())).use { c -> if (c.moveToFirst()) c.getLong(0) else 0L }
        if (open >= 100) throw CoinError("TOO_MANY_REQUESTS", 429)
        val id = randId(16); val now = System.currentTimeMillis()
        val v = ContentValues(); v.put("id", id); v.put("to_id", to); if (sats == null) v.putNull("amount") else v.put("amount", sats)
        if (memo == null) v.putNull("memo") else v.put("memo", memo)
        v.put("reusable", if (reusable) 1 else 0); v.put("status", "open"); v.put("created", now); v.put("expires", expires)
        db.insertOrThrow("payreqs", null, v)
        PayReq(id, to, sats, memo, reusable, "open", now, expires, 0, 0L, null, null, null)
    }

    fun prGet(id: String): PayReq? {
        val r = q("SELECT $PR_COLS FROM payreqs WHERE id=?", arrayOf(id)) { prOf(it) }.firstOrNull() ?: return null
        return if (r.status == "open" && r.expires < System.currentTimeMillis()) PayReq(r.id, r.to, r.sats, r.memo, r.reusable, "expired", r.created, r.expires, r.paidCount, r.paidTotal, r.lastTx, r.lastPayer, r.paidAt) else r
    }

    fun prList(to: String, status: String?, limit: Int, off: Int): List<PayReq> =
        if (status == null) q("SELECT $PR_COLS FROM payreqs WHERE to_id=? ORDER BY created DESC LIMIT $limit OFFSET $off", arrayOf(to)) { prOf(it) }
        else q("SELECT $PR_COLS FROM payreqs WHERE to_id=? AND status=? ORDER BY created DESC LIMIT $limit OFFSET $off", arrayOf(to, status)) { prOf(it) }

    fun prPay(id: String, payer: String, amount: Long?): Pair<TxOut, PayReq> = tx { db ->
        val now = System.currentTimeMillis()
        val r = db.rawQuery("SELECT $PR_COLS FROM payreqs WHERE id=?", arrayOf(id)).use { c -> if (c.moveToFirst()) prOf(c) else null } ?: throw CoinError("PAYREQ_NOT_FOUND", 404)
        when {
            r.status == "paid" -> throw CoinError("PAYREQ_PAID", 409)
            r.status == "cancelled" -> throw CoinError("PAYREQ_CANCELLED", 409)
            r.status == "expired" -> throw CoinError("PAYREQ_EXPIRED", 410)
            r.status != "open" -> throw CoinError("PAYREQ_CLOSED", 409)
            r.expires < now -> throw CoinError("PAYREQ_EXPIRED", 410)
        }
        val sats = r.sats ?: amount ?: throw CoinError("AMOUNT_REQUIRED")
        if (r.sats != null && amount != null && amount != r.sats) throw CoinError("INVALID_AMOUNT")
        val t = doTransfer(db, payer, r.to, sats, UUID.randomUUID().toString(), now)
        val status = if (r.reusable) "open" else "paid"
        db.execSQL("UPDATE payreqs SET status=?, paid_count=paid_count+1, paid_total=paid_total+?, last_tx=?, last_payer=?, paid_at=? WHERE id=?", arrayOf<Any>(status, sats, t.id, payer, now, id))
        val nr = db.rawQuery("SELECT $PR_COLS FROM payreqs WHERE id=?", arrayOf(id)).use { c -> c.moveToFirst(); prOf(c) }
        Pair(t, nr)
    }

    fun prCancel(id: String, user: String): PayReq = tx { db ->
        val r = db.rawQuery("SELECT $PR_COLS FROM payreqs WHERE id=?", arrayOf(id)).use { c -> if (c.moveToFirst()) prOf(c) else null } ?: throw CoinError("PAYREQ_NOT_FOUND", 404)
        if (r.to != user) throw CoinError("PAYREQ_NOT_FOUND", 404)
        when (r.status) {
            "open" -> db.execSQL("UPDATE payreqs SET status='cancelled' WHERE id=?", arrayOf<Any>(id))
            "paid" -> throw CoinError("PAYREQ_PAID", 409)
            "cancelled" -> throw CoinError("PAYREQ_CANCELLED", 409)
            else -> throw CoinError("PAYREQ_EXPIRED", 409)
        }
        db.rawQuery("SELECT $PR_COLS FROM payreqs WHERE id=?", arrayOf(id)).use { c -> c.moveToFirst(); prOf(c) }
    }

    // ───────────────────────── backups ─────────────────────────
    fun backups(user: String): List<String> = q("SELECT code FROM backups WHERE user_id=? ORDER BY rowid", arrayOf(user)) { it.getString(0) }

    fun backupCreate(user: String, n: Int): List<String> = tx { db ->
        val have = db.rawQuery("SELECT COUNT(*) FROM backups WHERE user_id=?", arrayOf(user)).use { c -> if (c.moveToFirst()) c.getInt(0) else 0 }
        if ((bal(db, user) ?: 0L) <= 0L) throw CoinError("EMPTY_WALLET")
        for (i in have until n) { val v = ContentValues(); v.put("code", randHex(12)); v.put("user_id", user); db.insertOrThrow("backups", null, v) }
        backups(user)
    }

    fun backupRestore(code: String, user: String): TxOut = tx { db ->
        val owner = db.rawQuery("SELECT user_id FROM backups WHERE code=?", arrayOf(code)).use { c -> if (c.moveToFirst()) c.getString(0) else null } ?: throw CoinError("BACKUP_NOT_FOUND", 404)
        if (owner == user) throw CoinError("BACKUP_SAME_ACCOUNT")
        val b = bal(db, owner) ?: 0L
        if (b <= 0L) throw CoinError("BACKUP_EMPTY")
        db.execSQL("UPDATE users SET last_tx=0 WHERE id=?", arrayOf<Any>(owner))
        val t = doTransfer(db, owner, user, b, UUID.randomUUID().toString(), System.currentTimeMillis())
        db.delete("backups", "code=?", arrayOf(code))
        t
    }

    // ───────────────────────── manutenção ─────────────────────────
    fun cleanup(retainTxDays: Int) = tx { db ->
        val now = System.currentTimeMillis()
        db.delete("sessions", "expires<?", arrayOf(now.toString()))
        db.delete("bills", "expires IS NOT NULL AND expires<?", arrayOf(now.toString()))
        db.execSQL("UPDATE payreqs SET status='expired' WHERE status='open' AND expires<?", arrayOf<Any>(now))
        db.delete("payreqs", "created<?", arrayOf((now - 60L * 86_400_000L).toString()))
        if (retainTxDays > 0) db.delete("txs", "ts<?", arrayOf((now - retainTxDays * 86_400_000L).toString()))
    }

    fun sizeBytes(ctx: Context): Long {
        var t = 0L
        for (n in listOf("hostcoin.db", "hostcoin.db-wal", "hostcoin.db-shm")) { val f = ctx.getDatabasePath(n); if (f.exists()) t += f.length() }
        return t
    }

    fun wipe() = tx { db -> for (tb in listOf("users", "sessions", "txs", "bills", "payreqs", "backups", "meta")) db.delete(tb, null, null) }
}
