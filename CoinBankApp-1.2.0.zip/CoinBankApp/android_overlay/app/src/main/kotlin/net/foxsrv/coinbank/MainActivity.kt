package net.foxsrv.coinbank

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.util.Base64
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.EventChannel
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.Executors

/**
 * Ponte Flutter ⇄ Android. Canal "coinbank/core": todo método devolve uma String JSON
 * {ok:true,...} ou {ok:false,error,status,...}. Canal "coinbank/events": eventos do Kotlin
 * {type:'net'|'route'|'refresh'|'notify'|'nearby'|'nearbyMsg'|'nfc'|'host'|'session'|'claimed'}.
 */
class MainActivity : FlutterActivity() {
    private val bg = Executors.newCachedThreadPool()
    private val main = Handler(Looper.getMainLooper())
    @Volatile private var launchRoute: String? = null
    @Volatile private var online = true
    private var netCb: ConnectivityManager.NetworkCallback? = null
    private var pendingPerm: MethodChannel.Result? = null
    @Volatile private var nfcReading = false

    companion object { const val REQ_PERM = 9103; const val REQ_ICON = 9104 }
    private var pendingIcon: MethodChannel.Result? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        Store.init(this); HostConfig.init(this)
        super.onCreate(savedInstanceState)
        Notifier.init(this)
        handleIntent(intent)
        CoinService.sync(this)
    }

    override fun onResume() {
        super.onResume()
        Events.foreground = true
        if (nfcReading) startNfcReader()
        Nearby.syncBackground(this)
    }

    override fun onPause() {
        Events.foreground = false
        PayNfc.stopReader(this)
        super.onPause()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "coinbank/core").setMethodCallHandler { call, result -> dispatch(call, result) }
        EventChannel(flutterEngine.dartExecutor.binaryMessenger, "coinbank/events").setStreamHandler(object : EventChannel.StreamHandler {
            override fun onListen(arguments: Any?, sink: EventChannel.EventSink?) {
                Events.sink = { s -> try { sink?.success(s) } catch (ignored: Exception) { } }
                Events.emit(JSONObject().put("type", "net").put("online", online))
            }
            override fun onCancel(arguments: Any?) { Events.sink = null }
        })
        watchNetwork()
    }

    override fun onDestroy() {
        try { netCb?.let { (getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager).unregisterNetworkCallback(it) } } catch (ignored: Exception) { }
        Events.sink = null
        Nearby.scanning = false
        if (!CoinService.running) Nearby.stop()
        PayNfc.set(null)
        super.onDestroy()
    }

    // ───────────── conexão ─────────────
    private fun watchNetwork() {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        fun now(): Boolean = try { val n = cm.activeNetwork; val cp = if (n != null) cm.getNetworkCapabilities(n) else null; cp != null && cp.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) } catch (e: Exception) { true }
        online = now()
        val cb = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) { main.postDelayed({ update(now()) }, 300) }
            override fun onLost(network: Network) { main.postDelayed({ update(now()) }, 300) }
            override fun onCapabilitiesChanged(network: Network, caps: NetworkCapabilities) { main.post { update(now()) } }
        }
        try { cm.registerDefaultNetworkCallback(cb); netCb = cb } catch (ignored: Exception) { }
    }

    private fun update(v: Boolean) {
        if (v == online) return
        online = v
        Events.emit(JSONObject().put("type", "net").put("online", v))
    }

    // ───────────── rotas: notificações e links ─────────────
    private fun handleIntent(i: Intent?) {
        if (i == null) return
        i.getStringExtra(Notifier.EXTRA_ROUTE)?.let { r -> launchRoute = r; i.removeExtra(Notifier.EXTRA_ROUTE); Events.emit(JSONObject().put("type", "route").put("route", r)) }
        if (i.action == Intent.ACTION_VIEW && i.data != null) {
            val r = "pay:" + i.data.toString()
            launchRoute = r; i.action = null; i.data = null
            Events.emit(JSONObject().put("type", "route").put("route", r))
        }
    }

    // ───────────── despacho ─────────────
    private fun ok(o: JSONObject = JSONObject()): String = o.put("ok", true).toString()
    private fun err(e: Throwable): String {
        val o = JSONObject().put("ok", false)
        when (e) {
            is ApiError -> { e.body?.let { b -> val it = b.keys(); while (it.hasNext()) { val k = it.next(); if (k != "ok") o.put(k, b.get(k)) } }; o.put("error", e.error).put("status", e.status) }
            is CoinError -> o.put("error", e.code).put("status", e.status)
            else -> o.put("error", e.message ?: e.javaClass.simpleName).put("status", 0)
        }
        return o.toString()
    }

    private fun reply(result: MethodChannel.Result, s: String) { main.post { try { result.success(s) } catch (ignored: Exception) { } } }

    private fun async(result: MethodChannel.Result, block: () -> String) {
        bg.submit {
            val s = try { block() } catch (e: Throwable) { err(e) }
            reply(result, s)
        }
    }

    private fun arg(call: MethodCall, k: String): String? = call.argument<Any>(k)?.toString()
    private fun argBool(call: MethodCall, k: String): Boolean = call.argument<Any>(k) == true
    private fun argJson(call: MethodCall, k: String): JSONObject = try { JSONObject(arg(call, k) ?: "{}") } catch (e: Exception) { JSONObject() }

    private fun state(): JSONObject = JSONObject().put("settings", Store.settings()).put("servers", Store.servers()).put("sessions", Store.publicSessions())
        .put("accounts", Store.publicAccounts()).put("active", Store.activeId()).put("netcfg", Store.netCfgAll())

    private fun dispatch(call: MethodCall, result: MethodChannel.Result) {
        when (call.method) {
            "init" -> async(result) {
                val r = launchRoute; launchRoute = null
                val v = try { packageManager.getPackageInfo(packageName, 0).versionName ?: "" } catch (e: Exception) { "" }
                ok(state().put("online", online).put("route", r ?: JSONObject.NULL).put("sdk", Build.VERSION.SDK_INT).put("version", v)
                    .put("device", Nearby.device(this)).put("bio", Bio.status(this)).put("nfc", PayNfc.state(this)))
            }
            "state" -> async(result) { ok(state()) }
            "settings.set" -> async(result) {
                val s = Store.setSettings(argJson(call, "patch"))
                CoinService.sync(this); Nearby.refresh(this)
                ok(JSONObject().put("settings", s))
            }

            // ── redes
            "servers.add" -> async(result) {
                val url = Store.cleanUrl(arg(call, "url") ?: "")
                if (url.isEmpty() || Store.origin(url) == null) throw ApiError("invalid_url", 0, null)
                val p = Api.ping(url)
                if (!p.optBoolean("ok") && !argBool(call, "force")) throw ApiError("network", 0, p)
                // redes hospedadas pelo app (e APIs compatíveis) contam nome, casas e ícone da moeda em /api/net/info
                val info = try { val r = Http.request(url + "/api/net/info", "GET", null, emptyMap(), 6_000); if (r.status in 200..299) Http.parse(r.body) else JSONObject() } catch (e: Exception) { JSONObject() }
                val name = (arg(call, "name") ?: "").trim().ifEmpty { info.optString("name").ifEmpty { p.optJSONObject("info")?.optString("network").orEmpty() } }
                val sv = Store.addServer(url, name)
                val id = sv.optString("id")
                if (id != Store.MAIN_ID && id != Store.HOST_ID) {
                    val patch = JSONObject()
                    val apiDec = call.argument<Any>("api") as? Number
                    if (apiDec != null) patch.put("api", apiDec.toInt()) else if (info.has("decimals")) patch.put("api", info.optInt("decimals", 8))
                    val disp = call.argument<Any>("disp") as? Number
                    if (disp != null) patch.put("disp", disp.toInt())
                    val icon = arg(call, "icon").orEmpty().ifEmpty { info.optString("icon") }
                    if (icon.isNotEmpty()) patch.put("icon", icon)
                    val coin = arg(call, "coin").orEmpty().ifEmpty { info.optString("coin") }
                    if (coin.isNotEmpty()) patch.put("coin", coin)
                    if (patch.length() > 0) Store.setNetCfg(id, patch)
                }
                ok(JSONObject().put("server", sv).put("ping", p).put("info", info).put("servers", Store.servers()).put("state", state()))
            }
            "netcfg.set" -> async(result) { Store.setNetCfg(arg(call, "id") ?: Store.activeId(), argJson(call, "patch")); HostRuntime.changed(); ok(state()) }
            "pickIcon" -> {
                pendingIcon?.let { reply(it, ok()) }
                pendingIcon = result
                try { @Suppress("DEPRECATION") startActivityForResult(Intent(Intent.ACTION_GET_CONTENT).setType("image/*").addCategory(Intent.CATEGORY_OPENABLE), REQ_ICON) }
                catch (e: Exception) { pendingIcon = null; reply(result, err(ApiError("no_app", 0, null))) }
            }
            "appIcon.get" -> reply(result, ok(JSONObject().put("icon", AppIcon.current(this))))
            "appIcon.set" -> { val n = arg(call, "icon") ?: "default"; try { AppIcon.set(this, n); reply(result, ok(JSONObject().put("icon", n))) } catch (e: Exception) { reply(result, err(e)) } }
            "servers.remove" -> async(result) { Store.removeServer(arg(call, "id") ?: ""); ok(state()) }
            "servers.rename" -> async(result) { Store.renameServer(arg(call, "id") ?: "", (arg(call, "name") ?: "").trim().take(40)); ok(state()) }
            "servers.active" -> async(result) {
                val id = arg(call, "id") ?: Store.MAIN_ID
                if (Store.server(id) == null) throw ApiError("server_not_found", 0, null)
                Store.setSettings(JSONObject().put("activeServer", id)); Nearby.refresh(this)
                ok(state())
            }
            "ping" -> async(result) { ok(Api.ping(arg(call, "url") ?: Store.mainUrl())) }

            // ── API genérica
            "api" -> async(result) {
                val sid = arg(call, "server") ?: Store.activeId()
                val method = (arg(call, "method") ?: "GET").uppercase()
                val body = arg(call, "body")
                val path = arg(call, "path") ?: "/"
                // long-poll (?wait=25) precisa de mais tempo de leitura que o padrão de 15 s
                val timeout = if (Regex("[?&]wait=[1-9]").containsMatchIn(path)) 40_000 else 15_000
                val r = Api.raw(sid, method, path, if (method == "GET") null else (body ?: "{}"), !argBool(call, "noAuth"), timeout)
                if (r.status >= 400 || r.status == 0) {
                    val o = Http.parse(r.body)
                    throw ApiError(Api.errCode(o, r.status), r.status, o)
                }
                ok(JSONObject().put("status", r.status).put("body", r.body).put("ms", r.ms))
            }
            "login" -> async(result) {
                val sid = arg(call, "server") ?: Store.activeId()
                val o = Api.login(sid, (arg(call, "username") ?: "").trim(), arg(call, "password") ?: "", argBool(call, "remember"), argBool(call, "bio"))
                CoinService.sync(this)
                ok(JSONObject().put("login", o).put("state", state()))
            }
            "register" -> async(result) {
                val sid = arg(call, "server") ?: Store.activeId()
                val o = Api.register(sid, (arg(call, "username") ?: "").trim(), arg(call, "password") ?: "", argBool(call, "remember"), argBool(call, "bio"))
                CoinService.sync(this)
                ok(JSONObject().put("register", o).put("state", state()))
            }
            "logout" -> async(result) {
                val sid = arg(call, "server") ?: Store.activeId()
                Api.logout(sid)
                Store.setKv("watch_$sid", "{}")
                CoinService.sync(this); Nearby.refresh(this)
                ok(state())
            }
            "accounts.remove" -> async(result) { Store.removeAccount(arg(call, "id") ?: ""); ok(state()) }
            "accounts.save" -> async(result) {
                val sid = arg(call, "server") ?: Store.activeId()
                val url = Store.serverUrl(sid) ?: throw ApiError("server_not_found", 0, null)
                val ses = Store.session(sid) ?: throw ApiError("Unauthorized", 401, null)
                // confere a senha antes de guardar
                Api.login(sid, ses.optString("username"), arg(call, "password") ?: "", true, true)
                ok(state().put("saved", url))
            }
            "accounts.login" -> {
                val acc = Store.account(arg(call, "id") ?: "")
                if (acc == null) { reply(result, err(ApiError("account_not_found", 0, null))); return }
                val go = {
                    async(result) {
                        val url = acc.optString("server")
                        val sv = Store.serverByUrl(url) ?: Store.addServer(url, "")
                        val sid = sv.optString("id")
                        val pw = Store.password(acc) ?: throw ApiError("vault_error", 0, null)
                        val o = Api.login(sid, acc.optString("username"), pw, false, false)
                        Store.setSettings(JSONObject().put("activeServer", sid))
                        CoinService.sync(this)
                        ok(JSONObject().put("login", o).put("server", sid).put("state", state()))
                    }
                }
                if (acc.optBoolean("bio", true) && !argBool(call, "skipBio")) {
                    Bio.authenticate(this, Store.t(this, "Entrar como ${acc.optString("username")}", "Sign in as ${acc.optString("username")}"),
                        Store.t(this, "Confirme com a digital, o rosto ou o bloqueio de tela", "Confirm with fingerprint, face or screen lock")) { okk, e ->
                        if (okk) go() else reply(result, err(ApiError(e ?: "cancelled", 0, null)))
                    }
                } else go()
            }
            "bio.status" -> async(result) { ok(Bio.status(this)) }
            "bio.check" -> Bio.authenticate(this, arg(call, "title") ?: "Coin Bank", arg(call, "subtitle") ?: "") { okk, e -> reply(result, if (okk) ok() else err(ApiError(e ?: "cancelled", 0, null))) }

            // ── QR
            "scan" -> QrScan.scan(this) { text, error ->
                reply(result, if (error != null) err(ApiError(error, 0, null)) else ok(JSONObject().put("text", text ?: JSONObject.NULL)))
            }
            "qr" -> async(result) { ok(JSONObject().put("rows", JSONArray(QrEncoder.toRows(QrEncoder.encode(arg(call, "text") ?: ""))))) }

            // ── NFC
            "nfc.state" -> reply(result, ok(JSONObject().put("state", PayNfc.state(this))))
            "nfc.charge" -> { PayNfc.set(arg(call, "text")); reply(result, ok(JSONObject().put("state", PayNfc.state(this)))) }
            "nfc.read" -> {
                nfcReading = argBool(call, "on")
                if (nfcReading) startNfcReader() else PayNfc.stopReader(this)
                reply(result, ok(JSONObject().put("state", PayNfc.state(this))))
            }
            "nfc.settings" -> { try { startActivity(Intent(Settings.ACTION_NFC_SETTINGS)) } catch (e: Exception) { try { startActivity(Intent(Settings.ACTION_WIRELESS_SETTINGS)) } catch (ignored: Exception) { } }; reply(result, ok()) }

            // ── por perto
            "nearby.scan" -> async(result) {
                Nearby.scanning = argBool(call, "on")
                if (Nearby.scanning) Nearby.start(this)
                Nearby.syncBackground(this)
                ok(JSONObject().put("status", Nearby.status(this)).put("peers", Nearby.list()))
            }
            "nearby.list" -> async(result) { ok(JSONObject().put("status", Nearby.status(this)).put("peers", Nearby.list())) }
            "nearby.send" -> async(result) {
                val sent = Nearby.message(this, arg(call, "device") ?: "", argJson(call, "msg"))
                if (!sent) throw ApiError("no_route", 0, null)
                ok()
            }

            // ── comprovantes e arquivos
            "receipt.png" -> async(result) { ok(JSONObject().put("b64", Base64.encodeToString(Receipt.png(this, fixTx(argJson(call, "tx"))), Base64.NO_WRAP))) }
            "receipt.save" -> async(result) {
                val tx = fixTx(argJson(call, "tx")); val pdf = arg(call, "format") == "pdf"
                val data = if (pdf) Receipt.pdf(this, tx) else Receipt.png(this, tx)
                val name = "comprovante-" + tx.optString("id").take(36) + if (pdf) ".pdf" else ".png"
                ok(JSONObject().put("path", Files.saveDownloads(this, name, if (pdf) "application/pdf" else "image/png", data)))
            }
            "receipt.share" -> async(result) {
                val tx = fixTx(argJson(call, "tx")); val pdf = arg(call, "format") == "pdf"
                val data = if (pdf) Receipt.pdf(this, tx) else Receipt.png(this, tx)
                val name = "comprovante-" + tx.optString("id").take(36) + if (pdf) ".pdf" else ".png"
                main.post { try { Files.share(this, name, if (pdf) "application/pdf" else "image/png", data, Store.t(this, "Compartilhar comprovante", "Share receipt")) } catch (ignored: Exception) { } }
                ok()
            }
            "saveText" -> async(result) { ok(JSONObject().put("path", Files.saveDownloads(this, arg(call, "name") ?: "coinbank.txt", "text/plain", (arg(call, "text") ?: "").toByteArray(Charsets.UTF_8)))) }
            "shareText" -> { try { Files.shareText(this, arg(call, "text") ?: "", arg(call, "title") ?: "Coin Bank") } catch (ignored: Exception) { }; reply(result, ok()) }
            "open" -> { try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(arg(call, "url") ?: "")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) ; reply(result, ok()) } catch (e: Exception) { reply(result, err(ApiError("no_app", 0, null))) } }
            "browser" -> { BrowserActivity.open(this, arg(call, "url") ?: Store.mainUrl(), arg(call, "title")); reply(result, ok()) }

            // ── rede hospedada
            "host.status" -> async(result) { ok(HostRuntime.status(this)) }
            "host.set" -> async(result) {
                HostConfig.set(argJson(call, "patch"))
                if (!HostConfig.get().optBoolean("enabled", false) && Store.activeId() == Store.HOST_ID) Store.setSettings(JSONObject().put("activeServer", Store.MAIN_ID))
                if (!HostConfig.get().optBoolean("enabled", false)) Store.clearSession(Store.HOST_ID)
                HostRuntime.sync(this); CoinService.sync(this); Nearby.refresh(this)
                ok(HostRuntime.status(this).put("state", state()))
            }
            "host.wipe" -> async(result) { HostRuntime.wipe(this); Store.clearSession(Store.HOST_ID); ok(HostRuntime.status(this).put("state", state())) }

            // ── sistema
            "service.sync" -> async(result) { CoinService.sync(this); ok(JSONObject().put("running", CoinService.running)) }
            "system" -> async(result) {
                val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
                ok(JSONObject().put("batteryIgnored", pm.isIgnoringBatteryOptimizations(packageName)).put("notifications", Notifier.enabled(this))
                    .put("service", CoinService.running).put("lastCheck", CoinService.lastCheck).put("nfc", PayNfc.state(this)).put("ble", Nearby.bleState(this))
                    .put("bio", Bio.status(this)).put("camera", hasPerm(Manifest.permission.CAMERA)))
            }
            "battery.request" -> {
                try {
                    @Suppress("BatteryLife")
                    val i = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))
                    startActivity(i)
                } catch (e: Exception) { try { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) } catch (ignored: Exception) { } }
                reply(result, ok())
            }
            "appSettings" -> { try { startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))) } catch (ignored: Exception) { }; reply(result, ok()) }
            "perm" -> {
                val kind = arg(call, "kind") ?: ""
                val perms = when (kind) {
                    "notifications" -> if (Build.VERSION.SDK_INT >= 33) arrayOf(Manifest.permission.POST_NOTIFICATIONS) else arrayOf()
                    "bluetooth" -> if (Build.VERSION.SDK_INT >= 31) arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_ADVERTISE, Manifest.permission.BLUETOOTH_CONNECT) else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
                    "nearby" -> if (Build.VERSION.SDK_INT >= 33) arrayOf(Manifest.permission.NEARBY_WIFI_DEVICES) else arrayOf()
                    "camera" -> arrayOf(Manifest.permission.CAMERA)
                    "storage" -> if (Build.VERSION.SDK_INT <= 28) arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE) else arrayOf()
                    else -> arrayOf()
                }
                val missing = perms.filter { !hasPerm(it) }
                if (missing.isEmpty()) { reply(result, ok(JSONObject().put("granted", true))); return }
                pendingPerm?.let { reply(it, ok(JSONObject().put("granted", false))) }
                pendingPerm = result
                requestPermissions(missing.toTypedArray(), REQ_PERM)
            }
            else -> result.notImplemented()
        }
    }

    /** comprovante da rede deste aparelho: o QR aponta para o endereço público (Cloudflare ou IP local), não 127.0.0.1 */
    private fun fixTx(tx: JSONObject): JSONObject {
        val sv = tx.optString("server")
        if (sv.startsWith("http://127.0.0.1") || sv.startsWith("http://localhost")) tx.put("server", HostRuntime.publicBase(HostConfig.get().optInt("port", HostConfig.DEFAULT_PORT)))
        return tx
    }

    private fun hasPerm(p: String) = checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

    private fun startNfcReader() {
        PayNfc.startReader(this, { p -> Events.emit(JSONObject().put("type", "nfc").put("payload", p)) }, { e -> Events.emit(JSONObject().put("type", "nfc").put("error", e)) })
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_PERM) {
            val granted = grantResults.isNotEmpty() && grantResults.all { it == PackageManager.PERMISSION_GRANTED }
            pendingPerm?.let { reply(it, ok(JSONObject().put("granted", granted))) }
            pendingPerm = null
            Nearby.refresh(this)
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == Bio.REQ_CONFIRM) { Bio.onLegacyResult(resultCode == RESULT_OK); return }
        if (requestCode == REQ_ICON) {
            val res = pendingIcon; pendingIcon = null
            val u = data?.data
            if (res == null) return
            if (resultCode != RESULT_OK || u == null) { reply(res, ok(JSONObject().put("icon", JSONObject.NULL))); return }
            bg.submit {
                val out = try { ok(JSONObject().put("icon", AppIcon.toBase64(this, u))) } catch (e: Exception) { err(ApiError("invalid_image", 0, null)) }
                reply(res, out)
            }
            return
        }
        @Suppress("DEPRECATION") super.onActivityResult(requestCode, resultCode, data)
    }
}
