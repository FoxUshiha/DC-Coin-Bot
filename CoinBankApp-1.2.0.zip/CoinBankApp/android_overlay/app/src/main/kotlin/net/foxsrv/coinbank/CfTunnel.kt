package net.foxsrv.coinbank

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.BufferedReader
import java.io.File
import java.io.InputStream
import java.io.InputStreamReader
import java.io.OutputStream
import java.net.HttpURLConnection
import java.net.Inet4Address
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.net.URL
import java.util.concurrent.ConcurrentHashMap

/**
 * Túnel Cloudflare grátis (trycloudflare.com) para a rede Coin hospedada neste celular.
 *
 * Com ele, o celular recebe conexões de qualquer lugar (sem abrir porta, mesmo atrás de CGNAT/4G):
 * o central testa o endereço https://xxxx.trycloudflare.com, marca o nó como "direto" e entrega esse
 * endereço aos apps (celular e PC), que baixam os pedaços direto deste celular.
 *
 * O binário oficial `cloudflared` (linux-arm64) vai no APK como `libcloudflared.so` (pasta de libs nativas,
 * a única de onde o Android deixa executar). Como binários Linux não acham DNS no Android, o app:
 *  - resolve os servidores de borda da Cloudflare em Kotlin e passa `--edge ip:7844`;
 *  - pede o túnel por uma ponte local (`--quick-service http://127.0.0.1:N`) que repassa para
 *    https://api.trycloudflare.com/tunnel usando a rede do Android.
 */
object CfTunnel {
    private const val API = "https://api.trycloudflare.com"
    private val EDGE_HOSTS = listOf("region1.v2.argotunnel.com", "region2.v2.argotunnel.com")
    private val URL_RX = Regex("https://[a-z0-9-]+\\.trycloudflare\\.com", RegexOption.IGNORE_CASE)

    class Tun(val key: String, val port: Int, val protocol: String, val onUrl: (String?) -> Unit) {
        @Volatile var proc: Process? = null
        @Volatile var url: String? = null
        @Volatile var pendingUrl: String? = null
        @Volatile var connected = false
        @Volatile var state = "starting"
        @Volatile var error: String? = null
        @Volatile var stopped = false
        @Volatile var startedAt = 0L
        @Volatile var restarts = 0
        @Volatile var conns = 0
        val log = ArrayDeque<String>()
        fun addLog(l: String) { synchronized(log) { log.addLast(l.take(300)); while (log.size > 40) log.removeFirst() } }
    }

    private val tuns = ConcurrentHashMap<String, Tun>()
    @Volatile private var app: Context? = null

    fun binary(ctx: Context): File? = try {
        File(ctx.applicationInfo.nativeLibraryDir ?: "", "libcloudflared.so").takeIf { it.isFile && it.length() > 1_000_000 }
    } catch (e: Throwable) { null }

    fun available(ctx: Context) = binary(ctx) != null

    /** liga o túnel apontando para http://127.0.0.1:port; onUrl recebe o endereço público (ou null quando cai) */
    @Synchronized
    fun start(ctx: Context, key: String, port: Int, protocol: String, onUrl: (String?) -> Unit): Boolean {
        app = ctx.applicationContext
        tuns[key]?.let { if (!it.stopped && it.port == port) return true; stop(key) }
        if (binary(ctx) == null) return false
        val t = Tun(key, port, protocol.ifEmpty { "auto" }, onUrl)
        tuns[key] = t
        Thread({ loop(t) }, "cf-tunnel-$key").also { it.isDaemon = true }.start()
        return true
    }

    @Synchronized
    fun stop(key: String) {
        val t = tuns.remove(key) ?: return
        t.stopped = true; t.state = "off"
        try { t.proc?.destroy() } catch (ignored: Exception) { }
        try { t.onUrl(null) } catch (ignored: Exception) { }
    }

    fun stopAll() { for (k in tuns.keys.toList()) stop(k) }

    fun url(key: String): String? = tuns[key]?.takeIf { it.connected }?.url

    fun status(key: String): JSONObject {
        val t = tuns[key]
        val o = JSONObject().put("available", app?.let { available(it) } ?: false)
        if (t == null) return o.put("on", false).put("state", "off")
        val lines = synchronized(t.log) { t.log.toList().takeLast(12) }
        return o.put("on", true).put("state", t.state).put("url", t.url ?: JSONObject.NULL).put("connected", t.connected).put("connections", t.conns)
            .put("protocol", t.protocol).put("restarts", t.restarts).put("error", t.error ?: JSONObject.NULL)
            .put("upSec", if (t.connected && t.startedAt > 0) (System.currentTimeMillis() - t.startedAt) / 1000 else JSONObject.NULL)
            .put("log", JSONArray(lines))
    }

    // ───────────────────────── processo ─────────────────────────
    private fun loop(t: Tun) {
        var backoff = 5_000L
        while (!t.stopped) {
            val ok = try { runOnce(t) } catch (e: Exception) { t.error = e.message ?: e.javaClass.simpleName; false }
            if (t.stopped) break
            if (t.connected || t.url != null) { t.connected = false; t.url = null; try { t.onUrl(null) } catch (ignored: Exception) { } }
            t.restarts++; t.state = "retrying"
            if (ok) backoff = 5_000L else backoff = minOf(backoff * 2, 5 * 60_000L)
            var waited = 0L
            while (!t.stopped && waited < backoff) { Thread.sleep(500); waited += 500 }
        }
    }

    /** true se chegou a conectar (o próximo reinício é rápido) */
    private fun runOnce(t: Tun): Boolean {
        val ctx = app ?: return false
        val bin = binary(ctx) ?: run { t.error = "cloudflared_missing"; return false }
        t.state = "starting"; t.error = null; t.pendingUrl = null; t.conns = 0
        val edges = edgeIps()
        if (edges.isEmpty()) { t.error = "edge_dns_failed"; t.addLog("não achou os servidores da Cloudflare (DNS)"); return false }
        val shim = Shim.ensure() ?: run { t.error = "shim_failed"; return false }
        val home = File(ctx.filesDir, "cloudflared").also { it.mkdirs() }
        val args = arrayListOf(bin.absolutePath, "tunnel", "--no-autoupdate", "--edge-ip-version", "4",
            "--protocol", if (t.protocol in setOf("auto", "http2", "quic")) t.protocol else "auto",
            "--quick-service", "http://127.0.0.1:$shim", "--metrics", "127.0.0.1:0", "--loglevel", "info")
        for (e in edges.take(4)) { args.add("--edge"); args.add("$e:7844") }
        args.add("--url"); args.add("http://127.0.0.1:${t.port}")
        val pb = ProcessBuilder(args).directory(home).redirectErrorStream(true)
        val env = pb.environment()
        env["HOME"] = home.absolutePath; env["TMPDIR"] = ctx.cacheDir.absolutePath
        env["SSL_CERT_DIR"] = "/system/etc/security/cacerts"
        env["TUNNEL_TRANSPORT_LOGLEVEL"] = "warn"
        val p = pb.start(); t.proc = p
        if (t.stopped) { p.destroy(); return false }
        t.addLog("cloudflared iniciado (${t.protocol}, borda ${edges.take(4).joinToString(",")})")
        // vigia: endereço recebido mas nenhuma conexão em 90 s → reinicia
        val watchdog = Thread {
            try {
                var n = 0
                while (!t.stopped && alive(p) && !t.connected && n < 180) { Thread.sleep(500); n++ }
                if (!t.stopped && alive(p) && !t.connected) { t.error = "connect_timeout"; t.addLog("sem conexão com a Cloudflare em 90 s — reiniciando"); p.destroy() }
            } catch (ignored: Exception) { }
        }.also { it.isDaemon = true }; watchdog.start()
        var everConnected = false
        try {
            BufferedReader(InputStreamReader(p.inputStream, Charsets.UTF_8)).use { r ->
                while (true) {
                    val line = r.readLine() ?: break
                    val clean = line.replace(Regex("\u001B\\[[0-9;]*m"), "").trim()
                    if (clean.isEmpty() || clean.all { it == '|' || it == '+' || it == '-' || it == ' ' }) continue
                    URL_RX.find(clean)?.let { m -> if (t.pendingUrl == null && !clean.contains("api.trycloudflare", true)) t.pendingUrl = m.value.lowercase() }
                    if (clean.contains("Registered tunnel connection", true)) {
                        t.conns++
                        if (!t.connected && t.pendingUrl != null && !t.stopped) {
                            t.connected = true; everConnected = true; t.url = t.pendingUrl; t.state = "on"; t.error = null; t.startedAt = System.currentTimeMillis()
                            t.addLog("túnel no ar: ${t.url}")
                            try { t.onUrl(t.url) } catch (ignored: Exception) { }
                        }
                    } else if (!clean.contains("|") && !clean.contains("precheck") && !clean.contains("features") && (clean.contains(" ERR ") || clean.contains("error=", true))) {
                        t.error = clean.substringAfter(" ERR ").take(160); t.addLog(clean.take(200))
                    } else if (clean.contains("INF") && (clean.contains("trycloudflare") || clean.contains("Starting") || clean.contains("Unregistered") || clean.contains("Retrying"))) {
                        t.addLog(clean.take(200))
                    }
                    if (clean.contains("Unregistered tunnel connection", true)) t.conns = maxOf(0, t.conns - 1)
                }
            }
        } catch (ignored: Exception) { }
        try { p.waitFor() } catch (ignored: Exception) { }
        t.addLog("cloudflared saiu (código ${try { p.exitValue() } catch (e: Exception) { -1 }})")
        t.proc = null
        return everConnected
    }

    private fun alive(p: Process): Boolean = try { p.exitValue(); false } catch (e: IllegalThreadStateException) { true }

    /** IPs da borda da Cloudflare (resolvidos pelo Android, porque o binário Linux não acha DNS aqui) */
    private fun edgeIps(): List<String> {
        val out = ArrayList<String>()
        for (h in EDGE_HOSTS) {
            try { InetAddress.getAllByName(h).filterIsInstance<Inet4Address>().mapNotNull { it.hostAddress }.shuffled().take(2).forEach { if (it !in out) out.add(it) } } catch (ignored: Exception) { }
        }
        return out
    }

    // ───────────────────────── ponte local para api.trycloudflare.com ─────────────────────────
    private object Shim {
        @Volatile private var server: ServerSocket? = null

        @Synchronized fun ensure(): Int? {
            server?.let { if (!it.isClosed) return it.localPort }
            return try {
                val s = ServerSocket(); s.reuseAddress = true; s.bind(InetSocketAddress(InetAddress.getByName("127.0.0.1"), 0), 16)
                server = s
                Thread({ accept(s) }, "cf-shim").also { it.isDaemon = true }.start()
                s.localPort
            } catch (e: Exception) { null }
        }

        private fun accept(s: ServerSocket) {
            while (!s.isClosed) {
                val c = try { s.accept() } catch (e: Exception) { break }
                Thread { handle(c) }.also { it.isDaemon = true }.start()
            }
        }

        private fun readLine(inp: InputStream): String? {
            val sb = StringBuilder()
            while (true) {
                val b = inp.read(); if (b < 0) return if (sb.isEmpty()) null else sb.toString()
                if (b == '\n'.code) return sb.toString().trimEnd('\r')
                sb.append(b.toChar()); if (sb.length > 8192) return null
            }
        }

        private fun handle(c: Socket) {
            c.use { sock ->
                try {
                    sock.soTimeout = 20000
                    val inp = BufferedInputStream(sock.getInputStream())
                    val first = readLine(inp) ?: return
                    val parts = first.split(' '); if (parts.size < 2) return
                    val method = parts[0].uppercase(); val path = parts[1]
                    val headers = HashMap<String, String>()
                    while (true) { val l = readLine(inp) ?: break; if (l.isEmpty()) break; val i = l.indexOf(':'); if (i > 0) headers[l.substring(0, i).trim().lowercase()] = l.substring(i + 1).trim() }
                    val len = (headers["content-length"] ?: "0").toIntOrNull()?.coerceIn(0, 65536) ?: 0
                    val body = ByteArray(len); var o = 0
                    while (o < len) { val n = inp.read(body, o, len - o); if (n < 0) break; o += n }
                    val out = sock.getOutputStream()
                    if (method != "POST" || !path.endsWith("/tunnel")) { reply(out, 404, "{\"success\":false}".toByteArray()); return }
                    val conn = URL("$API/tunnel").openConnection() as HttpURLConnection
                    conn.requestMethod = "POST"; conn.connectTimeout = 15000; conn.readTimeout = 20000; conn.doOutput = true; conn.useCaches = false
                    conn.setRequestProperty("Content-Type", headers["content-type"] ?: "application/json")
                    conn.setRequestProperty("User-Agent", headers["user-agent"] ?: "cloudflared")
                    conn.outputStream.use { it.write(body) }
                    val code = conn.responseCode
                    val rb = (if (code >= 400) conn.errorStream else conn.inputStream)?.use { it.readBytes() } ?: ByteArray(0)
                    conn.disconnect()
                    reply(out, code, rb)
                } catch (e: Exception) {
                    try { reply(sock.getOutputStream(), 502, "{\"success\":false,\"errors\":[{\"message\":\"${(e.message ?: "network").replace("\"", "'").take(120)}\"}]}".toByteArray()) } catch (ignored: Exception) { }
                }
            }
        }

        private fun reply(out: OutputStream, code: Int, body: ByteArray) {
            val head = "HTTP/1.1 $code X\r\nContent-Type: application/json\r\nContent-Length: ${body.size}\r\nConnection: close\r\n\r\n"
            out.write(head.toByteArray(Charsets.ISO_8859_1)); out.write(body); out.flush()
        }
    }
}
