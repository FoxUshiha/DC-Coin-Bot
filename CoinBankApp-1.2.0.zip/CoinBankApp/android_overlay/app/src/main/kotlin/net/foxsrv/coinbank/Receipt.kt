package net.foxsrv.coinbank

import android.content.ContentProvider
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.database.Cursor
import android.database.MatrixCursor
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.ParcelFileDescriptor
import android.provider.MediaStore
import android.provider.OpenableColumns
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileNotFoundException
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone

/**
 * Comprovante gerado na hora, no próprio aparelho (igual ao do site): imagem PNG ou PDF com QR Code de verificação
 * (link /tx/<id> da rede). Funciona também nas redes locais e hospedadas.
 */
object Receipt {
    private const val W = 1080

    private fun paint(color: Int, size: Float, bold: Boolean = false, mono: Boolean = false) = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        this.color = color; textSize = size
        typeface = when { mono -> Typeface.create(Typeface.MONOSPACE, if (bold) Typeface.BOLD else Typeface.NORMAL); bold -> Typeface.create(Typeface.DEFAULT, Typeface.BOLD); else -> Typeface.DEFAULT }
    }

    private fun date(iso: String, pt: Boolean): String = try {
        val inF = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.US); inF.timeZone = TimeZone.getTimeZone("UTC")
        val d = inF.parse(iso.take(19)) ?: throw IllegalArgumentException()
        SimpleDateFormat(if (pt) "dd/MM/yyyy 'às' HH:mm:ss" else "yyyy-MM-dd 'at' HH:mm:ss", Locale.getDefault()).format(d)
    } catch (e: Exception) { iso }

    /** desenha o comprovante; altura calculada pelo conteúdo */
    fun draw(ctx: Context, tx: JSONObject): Bitmap {
        val pt = when (tx.optString("lang")) { "pt" -> true; "en" -> false; else -> Store.pt(ctx) }
        fun t(a: String, b: String) = if (pt) a else b
        val dark = tx.optBoolean("dark", false)
        val bg = if (dark) Color.parseColor("#101113") else Color.parseColor("#ECEEF1")
        val card = if (dark) Color.parseColor("#191B1E") else Color.WHITE
        val fg = if (dark) Color.parseColor("#E8EAED") else Color.parseColor("#14161A")
        val fg2 = if (dark) Color.parseColor("#A1A7B0") else Color.parseColor("#5B616B")
        val line = if (dark) Color.parseColor("#2A2D33") else Color.parseColor("#DFE2E7")
        val gold = if (dark) Color.parseColor("#D6A94B") else Color.parseColor("#A9802A")
        val ok = if (dark) Color.parseColor("#2FBF80") else Color.parseColor("#0F8A5B")

        val id = tx.optString("id"); val from = tx.optString("from"); val to = tx.optString("to")
        val me = tx.optString("me")
        val sats = Coin.satsOf(tx, "amountSats", "amountCoins").let { if (it == 0L) Coin.satsOf(tx, "amountSats", "amount") else it }
        val claim = tx.optString("type") == "claim" || from == HostDb.SYSTEM_ID
        val dec = tx.optInt("decimals", 8)
        val net = tx.optString("network").ifEmpty { "Coin Bank" }
        val server = tx.optString("server")
        val verify = if (server.isNotEmpty()) "$server/tx/$id" else id
        val sign = when { me.isEmpty() -> ""; to == me && from != me -> "+"; from == me -> "−"; else -> "" }

        val rows = ArrayList<Pair<String, String>>()
        rows.add(t("Data", "Date") to date(tx.optString("date"), pt))
        rows.add(t("Tipo", "Type") to if (claim) t("Resgate (claim)", "Claim") else t("Transferência", "Transfer"))
        rows.add(t("De", "From") to if (claim) t("Sistema (emissão)", "System (mint)") else from)
        rows.add(t("Para", "To") to to)
        rows.add(t("Rede", "Network") to net)
        rows.add(t("ID da transação", "Transaction ID") to id)

        val qr = try { QrEncoder.encode(verify) } catch (e: Exception) { null }
        val qrSize = 360
        val H = 300 + 260 + rows.size * 118 + (if (qr != null) qrSize + 200 else 60) + 170
        val bmp = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        c.drawColor(bg)
        val m = 48f
        val cardR = RectF(m, m, W - m, H - m)
        c.drawRoundRect(cardR, 44f, 44f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = card })
        c.drawRoundRect(cardR, 44f, 44f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = line; style = Paint.Style.STROKE; strokeWidth = 2f })

        // cabeçalho dourado
        val head = RectF(m, m, W - m, m + 230f)
        val hp = Paint(Paint.ANTI_ALIAS_FLAG); hp.shader = LinearGradient(head.left, head.top, head.right, head.bottom, Color.parseColor("#2A2F38"), Color.parseColor("#0F1216"), Shader.TileMode.CLAMP)
        c.save(); c.clipRect(head); c.drawRoundRect(RectF(head.left, head.top, head.right, head.bottom + 60f), 44f, 44f, hp); c.restore()
        try {
            val ic = BitmapFactory.decodeResource(ctx.resources, R.drawable.ic_launcher_foreground)
            if (ic != null) c.drawBitmap(Bitmap.createScaledBitmap(ic, 190, 190, true), m + 24f, m + 20f, null)
        } catch (ignored: Exception) { }
        c.drawText("Coin Bank", m + 230f, m + 110f, paint(Color.WHITE, 56f, true))
        c.drawText(t("Comprovante", "Receipt") + " · " + net, m + 230f, m + 168f, paint(Color.parseColor("#D6A94B"), 34f))

        var y = m + 330f
        val title = if (claim) t("Resgate recebido", "Claim received") else t("Transferência concluída", "Transfer completed")
        c.drawText("✓  $title", m + 56f, y, paint(ok, 40f, true))
        y += 110f
        val amt = sign + Coin.format(sats, dec, pt)
        val ap = paint(gold, 96f, true)
        c.drawText(amt, m + 56f, y, ap)
        c.drawText(tx.optString("coin", "coins").ifEmpty { "coins" }, m + 56f + ap.measureText(amt) + 22f, y, paint(fg2, 44f))
        y += 70f
        c.drawLine(m + 56f, y, W - m - 56f, y, Paint().apply { color = line; strokeWidth = 2f })
        y += 70f
        val lp = paint(fg2, 32f); val vp = paint(fg, 38f, true); val mp = paint(fg, 34f, true, true)
        for ((k, v) in rows) {
            c.drawText(k.uppercase(Locale.getDefault()), m + 56f, y, lp)
            val isMono = k == t("De", "From") || k == t("Para", "To") || k == t("ID da transação", "Transaction ID")
            val p = if (isMono) mp else vp
            var text = v
            val maxW = W - 2 * m - 112f
            while (p.measureText(text) > maxW && text.length > 4) text = text.dropLast(2)
            if (text != v) text = text.dropLast(1) + "…"
            c.drawText(text, m + 56f, y + 50f, p)
            y += 118f
        }
        if (qr != null) {
            y += 10f
            val n = qr.size; val quiet = 4; val cell = qrSize.toFloat() / (n + quiet * 2)
            val qx = (W - qrSize) / 2f
            c.drawRoundRect(RectF(qx - 12f, y - 12f, qx + qrSize + 12f, y + qrSize + 12f), 24f, 24f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE })
            val qp = Paint().apply { color = Color.BLACK }
            for (r in 0 until n) for (col in 0 until n) if (qr[r][col]) c.drawRect(qx + (col + quiet) * cell, y + (r + quiet) * cell, qx + (col + quiet + 1) * cell + 0.6f, y + (r + quiet + 1) * cell + 0.6f, qp)
            y += qrSize + 60f
            val cp = paint(fg2, 28f); val cap = t("Escaneie para verificar", "Scan to verify")
            c.drawText(cap, (W - cp.measureText(cap)) / 2f, y, cp)
            y += 42f
            var u = verify; while (cp.measureText(u) > W - 2 * m - 80f && u.length > 10) u = u.dropLast(2)
            if (u != verify) u += "…"
            c.drawText(u, (W - cp.measureText(u)) / 2f, y, cp)
        }
        val foot = t("Coins não têm valor real. Nenhum dinheiro ou cartão real é utilizado.", "Coins have no real-world value. No real money or cards are involved.")
        val fp = paint(fg2, 26f)
        c.drawText(foot, (W - fp.measureText(foot)) / 2f, H - m - 48f, fp)
        return bmp
    }

    fun png(ctx: Context, tx: JSONObject): ByteArray {
        val b = draw(ctx, tx); val out = ByteArrayOutputStream()
        b.compress(Bitmap.CompressFormat.PNG, 100, out); b.recycle()
        return out.toByteArray()
    }

    fun pdf(ctx: Context, tx: JSONObject): ByteArray {
        val b = draw(ctx, tx)
        val pw = 595; val ph = (b.height * pw.toFloat() / b.width).toInt()
        val doc = PdfDocument()
        val page = doc.startPage(PdfDocument.PageInfo.Builder(pw, ph, 1).create())
        val c = page.canvas
        c.scale(pw.toFloat() / b.width, pw.toFloat() / b.width)
        c.drawBitmap(b, 0f, 0f, Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG))
        doc.finishPage(page)
        val out = ByteArrayOutputStream(); doc.writeTo(out); doc.close(); b.recycle()
        return out.toByteArray()
    }
}

/** Salvar no aparelho (pasta Download/CoinBank) e compartilhar com outros apps. */
object Files {
    /** devolve onde ficou (texto para mostrar) */
    fun saveDownloads(ctx: Context, name: String, mime: String, data: ByteArray): String {
        val clean = name.replace(Regex("[\\\\/:*?\"<>|]"), "_")
        if (Build.VERSION.SDK_INT >= 29) {
            val v = ContentValues()
            v.put(MediaStore.MediaColumns.DISPLAY_NAME, clean)
            v.put(MediaStore.MediaColumns.MIME_TYPE, mime)
            v.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/CoinBank")
            v.put(MediaStore.MediaColumns.IS_PENDING, 1)
            val uri = ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v) ?: throw IllegalStateException("save_failed")
            ctx.contentResolver.openOutputStream(uri)?.use { it.write(data) } ?: throw IllegalStateException("save_failed")
            val done = ContentValues(); done.put(MediaStore.MediaColumns.IS_PENDING, 0)
            ctx.contentResolver.update(uri, done, null, null)
            return "Download/CoinBank/$clean"
        }
        @Suppress("DEPRECATION")
        val pub = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "CoinBank")
        val canPublic = ctx.checkSelfPermission(android.Manifest.permission.WRITE_EXTERNAL_STORAGE) == android.content.pm.PackageManager.PERMISSION_GRANTED
        val dir = if (canPublic && (pub.exists() || pub.mkdirs())) pub else File(ctx.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: ctx.filesDir, "CoinBank").also { it.mkdirs() }
        val f = File(dir, clean)
        FileOutputStream(f).use { it.write(data) }
        return f.absolutePath
    }

    fun share(ctx: Context, name: String, mime: String, data: ByteArray, title: String) {
        val dir = File(ctx.filesDir, "share").also { it.mkdirs() }
        dir.listFiles()?.forEach { if (System.currentTimeMillis() - it.lastModified() > 3_600_000L) it.delete() }
        val f = File(dir, System.currentTimeMillis().toString())
        FileOutputStream(f).use { it.write(data) }
        val uri = FileShareProvider.uriFor(ctx, f, name)
        val i = Intent(Intent.ACTION_SEND).setType(mime).putExtra(Intent.EXTRA_STREAM, uri).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        val ch = Intent.createChooser(i, title).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(ch)
    }

    fun shareText(ctx: Context, text: String, title: String) {
        val i = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text)
        ctx.startActivity(Intent.createChooser(i, title).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}

/** Entrega arquivos privados do app (comprovantes para compartilhar) sem androidx. */
class FileShareProvider : ContentProvider() {
    companion object {
        fun authority(ctx: Context) = ctx.packageName + ".files"
        /** content://<pacote>.files/<pasta>/<arquivo>/<nome exibido> */
        fun uriFor(ctx: Context, file: File, displayName: String): Uri {
            val base = ctx.filesDir.canonicalFile
            val rel = file.canonicalFile.path.removePrefix(base.path).trimStart('/')
            return Uri.Builder().scheme("content").authority(authority(ctx)).appendEncodedPath(rel).appendPath(displayName).build()
        }
    }

    override fun onCreate(): Boolean = true

    private fun fileOf(uri: Uri): File {
        val segs = uri.pathSegments
        if (segs.size < 2) throw FileNotFoundException(uri.toString())
        val rel = segs.subList(0, segs.size - 1).joinToString("/")
        val base = context!!.filesDir.canonicalFile
        val f = File(base, rel).canonicalFile
        if (!f.path.startsWith(base.path + "/") || !f.exists()) throw FileNotFoundException(uri.toString())
        return f
    }

    override fun openFile(uri: Uri, mode: String): ParcelFileDescriptor = ParcelFileDescriptor.open(fileOf(uri), ParcelFileDescriptor.MODE_READ_ONLY)

    override fun query(uri: Uri, projection: Array<out String>?, selection: String?, selectionArgs: Array<out String>?, sortOrder: String?): Cursor {
        val f = fileOf(uri)
        val cols = projection ?: arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE)
        val c = MatrixCursor(cols)
        val row = arrayOfNulls<Any>(cols.size)
        for (k in cols.indices) row[k] = when (cols[k]) { OpenableColumns.DISPLAY_NAME -> uri.lastPathSegment; OpenableColumns.SIZE -> f.length(); else -> null }
        c.addRow(row)
        return c
    }

    override fun getType(uri: Uri): String {
        val n = (uri.lastPathSegment ?: "").lowercase()
        return when { n.endsWith(".png") -> "image/png"; n.endsWith(".pdf") -> "application/pdf"; n.endsWith(".txt") -> "text/plain"; else -> "application/octet-stream" }
    }
    override fun insert(uri: Uri, values: ContentValues?): Uri? = null
    override fun delete(uri: Uri, selection: String?, selectionArgs: Array<out String>?): Int = 0
    override fun update(uri: Uri, values: ContentValues?, selection: String?, selectionArgs: Array<out String>?): Int = 0
}
