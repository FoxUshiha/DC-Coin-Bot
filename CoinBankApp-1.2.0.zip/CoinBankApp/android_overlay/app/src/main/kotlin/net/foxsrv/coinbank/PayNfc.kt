package net.foxsrv.coinbank

import android.app.Activity
import android.nfc.NfcAdapter
import android.nfc.Tag
import android.nfc.cardemulation.HostApduService
import android.nfc.tech.IsoDep
import android.os.Bundle

/**
 * Cobrança por aproximação entre dois celulares (como PIX por aproximação), sem bibliotecas:
 *  • quem COBRA vira um "cartão" (HCE) que entrega o link da cobrança pelo AID F0434F494E504159 ("COINPAY");
 *  • quem PAGA liga o modo leitor e lê a cobrança ao encostar os aparelhos.
 * O dinheiro só se move no servidor da rede (POST /api/pay/request/:id/pay), depois da confirmação na tela.
 */
object PayNfc {
    val AID: ByteArray = byteArrayOf(0xF0.toByte(), 0x43, 0x4F, 0x49, 0x4E, 0x50, 0x41, 0x59)
    @Volatile var payload: ByteArray? = null; private set
    fun set(text: String?) { payload = text?.toByteArray(Charsets.UTF_8) }

    fun state(a: Activity?): String {
        val ad = try { NfcAdapter.getDefaultAdapter(a) } catch (e: Exception) { null } ?: return "unsupported"
        return if (ad.isEnabled) "on" else "off"
    }

    @Volatile private var reading = false
    /** liga o modo leitor; onRead recebe o texto da cobrança do outro celular */
    fun startReader(a: Activity, onRead: (String) -> Unit, onError: (String) -> Unit): Boolean {
        val ad = try { NfcAdapter.getDefaultAdapter(a) } catch (e: Exception) { null } ?: return false
        if (!ad.isEnabled) return false
        reading = true
        val cb = NfcAdapter.ReaderCallback { tag: Tag -> try { val s = readTag(tag); if (s != null) a.runOnUiThread { onRead(s) } } catch (e: Exception) { a.runOnUiThread { onError(e.message ?: "nfc_error") } } }
        val opts = Bundle(); opts.putInt(NfcAdapter.EXTRA_READER_PRESENCE_CHECK_DELAY, 250)
        ad.enableReaderMode(a, cb, NfcAdapter.FLAG_READER_NFC_A or NfcAdapter.FLAG_READER_NFC_B or NfcAdapter.FLAG_READER_SKIP_NDEF_CHECK, opts)
        return true
    }
    fun stopReader(a: Activity) { if (!reading) return; reading = false; try { NfcAdapter.getDefaultAdapter(a)?.disableReaderMode(a) } catch (ignored: Exception) { } }

    private fun ok(r: ByteArray) = r.size >= 2 && r[r.size - 2] == 0x90.toByte() && r[r.size - 1] == 0x00.toByte()

    private fun readTag(tag: Tag): String? {
        val iso = IsoDep.get(tag) ?: return null
        iso.use { d ->
            d.connect(); d.timeout = 3000
            val sel = byteArrayOf(0x00, 0xA4.toByte(), 0x04, 0x00, AID.size.toByte()) + AID + byteArrayOf(0x00)
            val r = d.transceive(sel); if (!ok(r) || r.size < 4) return null
            val len = ((r[0].toInt() and 0xff) shl 8) or (r[1].toInt() and 0xff)
            if (len <= 0 || len > 4096) return null
            val out = java.io.ByteArrayOutputStream(); var off = 0
            while (off < len) {
                val n = minOf(200, len - off)
                val cmd = byteArrayOf(0x80.toByte(), 0xCA.toByte(), (off shr 8).toByte(), (off and 0xff).toByte(), n.toByte())
                val x = d.transceive(cmd); if (!ok(x)) return null
                if (x.size <= 2) return null
                out.write(x, 0, x.size - 2); off += x.size - 2
            }
            return String(out.toByteArray(), Charsets.UTF_8)
        }
    }
}

/** o "cartão" virtual de quem está cobrando */
class PayHceService : HostApduService() {
    private val OK = byteArrayOf(0x90.toByte(), 0x00)
    private val NOT_FOUND = byteArrayOf(0x6A, 0x82.toByte())
    override fun processCommandApdu(cmd: ByteArray, extras: Bundle?): ByteArray {
        val p = PayNfc.payload ?: return NOT_FOUND
        if (cmd.size >= 4 && cmd[0] == 0x00.toByte() && cmd[1] == 0xA4.toByte()) {
            val n = p.size; return byteArrayOf((n shr 8).toByte(), (n and 0xff).toByte()) + OK
        }
        if (cmd.size >= 5 && cmd[0] == 0x80.toByte() && cmd[1] == 0xCA.toByte()) {
            val off = ((cmd[2].toInt() and 0xff) shl 8) or (cmd[3].toInt() and 0xff)
            val le = (cmd[4].toInt() and 0xff).let { if (it == 0) 256 else it }
            if (off >= p.size) return NOT_FOUND
            return p.copyOfRange(off, minOf(p.size, off + minOf(le, 240))) + OK
        }
        return NOT_FOUND
    }
    override fun onDeactivated(reason: Int) {}
}
