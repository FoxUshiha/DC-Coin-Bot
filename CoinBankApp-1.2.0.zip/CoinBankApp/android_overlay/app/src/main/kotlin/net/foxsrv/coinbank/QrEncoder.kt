package net.foxsrv.coinbank

/**
 * Gerador de QR Code (modo byte, correção M), sem bibliotecas — baseado no algoritmo de referência (Nayuki, domínio público/MIT).
 * Devolve a matriz de módulos (true = escuro). Versões 1–40.
 */
object QrEncoder {
    private val ECC_CODEWORDS_PER_BLOCK = arrayOf(
        intArrayOf(-1, 7, 10, 15, 20, 26, 18, 20, 24, 30, 18, 20, 24, 26, 30, 22, 24, 28, 30, 28, 28, 28, 28, 30, 30, 26, 28, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30),   // L
        intArrayOf(-1, 10, 16, 26, 18, 24, 16, 18, 22, 22, 26, 30, 22, 22, 24, 24, 28, 28, 26, 26, 26, 26, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28), // M
    )
    private val NUM_ERROR_CORRECTION_BLOCKS = arrayOf(
        intArrayOf(-1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 4, 4, 4, 4, 4, 6, 6, 6, 6, 7, 8, 8, 9, 9, 10, 12, 12, 12, 13, 14, 15, 16, 17, 18, 19, 19, 20, 21, 22, 24, 25),
        intArrayOf(-1, 1, 1, 1, 2, 2, 4, 4, 4, 5, 5, 5, 8, 9, 9, 10, 10, 11, 13, 14, 16, 17, 17, 18, 20, 21, 23, 25, 26, 28, 29, 31, 33, 35, 37, 38, 40, 43, 45, 47, 49),
    )
    private const val ECL = 1            // M
    private const val ECL_FORMAT_BITS = 0 // M → 00

    fun encode(text: String): Array<BooleanArray> = encodeBytes(text.toByteArray(Charsets.UTF_8))

    fun encodeBytes(data: ByteArray): Array<BooleanArray> {
        var version = 1; var dataCapBits: Int
        while (true) {
            dataCapBits = numDataCodewords(version) * 8
            val used = 4 + (if (version < 10) 8 else 16) + data.size * 8
            if (used <= dataCapBits) break
            version++; if (version > 40) throw IllegalArgumentException("data_too_long")
        }
        val bb = ArrayList<Boolean>()
        fun app(v: Int, n: Int) { for (i in n - 1 downTo 0) bb.add(((v ushr i) and 1) != 0) }
        app(4, 4); app(data.size, if (version < 10) 8 else 16); for (b in data) app(b.toInt() and 0xff, 8)
        app(0, minOf(4, dataCapBits - bb.size)); app(0, (8 - bb.size % 8) % 8)
        var pad = 0xEC; while (bb.size < dataCapBits) { app(pad, 8); pad = pad xor 0xEC xor 0x11 }
        val dataCw = IntArray(bb.size / 8); for (i in bb.indices) if (bb[i]) dataCw[i ushr 3] = dataCw[i ushr 3] or (1 shl (7 - (i and 7)))
        val all = addEccAndInterleave(dataCw, version)
        val size = version * 4 + 17
        val modules = Array(size) { BooleanArray(size) }; val isFn = Array(size) { BooleanArray(size) }
        drawFunctionPatterns(version, modules, isFn)
        drawCodewords(all, modules, isFn)
        var best = -1; var minPen = Int.MAX_VALUE
        for (m in 0 until 8) {
            applyMask(m, modules, isFn); drawFormatBits(m, modules, isFn)
            val p = penalty(modules); if (p < minPen) { minPen = p; best = m }
            applyMask(m, modules, isFn)
        }
        applyMask(best, modules, isFn); drawFormatBits(best, modules, isFn)
        return modules
    }

    private fun numRawDataModules(ver: Int): Int {
        var result = (16 * ver + 128) * ver + 64
        if (ver >= 2) { val numAlign = ver / 7 + 2; result -= (25 * numAlign - 10) * numAlign - 55; if (ver >= 7) result -= 36 }
        return result
    }
    private fun numDataCodewords(ver: Int) = numRawDataModules(ver) / 8 - ECC_CODEWORDS_PER_BLOCK[ECL][ver] * NUM_ERROR_CORRECTION_BLOCKS[ECL][ver]

    private fun addEccAndInterleave(data: IntArray, ver: Int): IntArray {
        val numBlocks = NUM_ERROR_CORRECTION_BLOCKS[ECL][ver]; val blockEccLen = ECC_CODEWORDS_PER_BLOCK[ECL][ver]
        val rawCodewords = numRawDataModules(ver) / 8; val numShortBlocks = numBlocks - rawCodewords % numBlocks; val shortBlockLen = rawCodewords / numBlocks
        val blocks = ArrayList<IntArray>(); val div = rsDivisor(blockEccLen); var k = 0
        for (i in 0 until numBlocks) {
            val datLen = shortBlockLen - blockEccLen + (if (i < numShortBlocks) 0 else 1)
            val dat = data.copyOfRange(k, k + datLen); k += datLen
            val ecc = rsRemainder(dat, div)
            val block = IntArray(shortBlockLen + 1)
            System.arraycopy(dat, 0, block, 0, dat.size)
            System.arraycopy(ecc, 0, block, shortBlockLen + 1 - blockEccLen, ecc.size)
            if (i < numShortBlocks) { /* posição shortBlockLen-blockEccLen fica de fora */ }
            blocks.add(block)
        }
        val result = ArrayList<Int>()
        for (i in 0 until shortBlockLen + 1) for (j in blocks.indices) if (i != shortBlockLen - blockEccLen || j >= numShortBlocks) result.add(blocks[j][i])
        return result.toIntArray()
    }
    private fun rsDivisor(degree: Int): IntArray {
        val r = IntArray(degree); r[degree - 1] = 1; var root = 1
        for (i in 0 until degree) { for (j in r.indices) { r[j] = mul(r[j], root); if (j + 1 < r.size) r[j] = r[j] xor r[j + 1] }; root = mul(root, 0x02) }
        return r
    }
    private fun rsRemainder(data: IntArray, div: IntArray): IntArray {
        val r = IntArray(div.size)
        for (b in data) { val f = b xor r[0]; System.arraycopy(r, 1, r, 0, r.size - 1); r[r.size - 1] = 0; for (i in r.indices) r[i] = r[i] xor mul(div[i], f) }
        return r
    }
    private fun mul(x: Int, y: Int): Int { var z = 0; for (i in 7 downTo 0) { z = (z shl 1) xor ((z ushr 7) * 0x11D); z = z xor (((y ushr i) and 1) * x) }; return z }

    private fun setFn(m: Array<BooleanArray>, f: Array<BooleanArray>, x: Int, y: Int, dark: Boolean) { m[y][x] = dark; f[y][x] = true }
    private fun drawFunctionPatterns(ver: Int, m: Array<BooleanArray>, f: Array<BooleanArray>) {
        val size = m.size
        for (i in 0 until size) { setFn(m, f, 6, i, i % 2 == 0); setFn(m, f, i, 6, i % 2 == 0) }
        fun finder(x: Int, y: Int) { for (dy in -4..4) for (dx in -4..4) { val d = maxOf(Math.abs(dx), Math.abs(dy)); val xx = x + dx; val yy = y + dy; if (xx in 0 until size && yy in 0 until size) setFn(m, f, xx, yy, d != 2 && d != 4) } }
        finder(3, 3); finder(size - 4, 3); finder(3, size - 4)
        val pos = alignPositions(ver); val n = pos.size
        for (i in 0 until n) for (j in 0 until n) { if ((i == 0 && j == 0) || (i == 0 && j == n - 1) || (i == n - 1 && j == 0)) continue; for (dy in -2..2) for (dx in -2..2) setFn(m, f, pos[i] + dx, pos[j] + dy, maxOf(Math.abs(dx), Math.abs(dy)) != 1) }
        drawFormatBits(0, m, f)
        if (ver >= 7) {
            var rem = ver; for (i in 0 until 12) rem = (rem shl 1) xor ((rem ushr 11) * 0x1F25)
            val bits = (ver shl 12) or rem
            for (i in 0 until 18) { val bit = ((bits ushr i) and 1) != 0; val a = size - 11 + i % 3; val b = i / 3; setFn(m, f, a, b, bit); setFn(m, f, b, a, bit) }
        }
    }
    private fun alignPositions(ver: Int): IntArray {
        if (ver == 1) return IntArray(0)
        val numAlign = ver / 7 + 2; val step = if (ver == 32) 26 else (ver * 4 + numAlign * 2 + 1) / (numAlign * 2 - 2) * 2
        val r = IntArray(numAlign); r[0] = 6; var pos = ver * 4 + 10
        for (i in numAlign - 1 downTo 1) { r[i] = pos; pos -= step }
        return r
    }
    private fun drawFormatBits(mask: Int, m: Array<BooleanArray>, f: Array<BooleanArray>) {
        val size = m.size
        val data = (ECL_FORMAT_BITS shl 3) or mask
        var rem = data; for (i in 0 until 10) rem = (rem shl 1) xor ((rem ushr 9) * 0x537)
        val bits = ((data shl 10) or rem) xor 0x5412
        fun bit(i: Int) = ((bits ushr i) and 1) != 0
        for (i in 0..5) setFn(m, f, 8, i, bit(i))
        setFn(m, f, 8, 7, bit(6)); setFn(m, f, 8, 8, bit(7)); setFn(m, f, 7, 8, bit(8))
        for (i in 9 until 15) setFn(m, f, 14 - i, 8, bit(i))
        for (i in 0 until 8) setFn(m, f, size - 1 - i, 8, bit(i))
        for (i in 8 until 15) setFn(m, f, 8, size - 15 + i, bit(i))
        setFn(m, f, 8, size - 8, true)
    }
    private fun drawCodewords(data: IntArray, m: Array<BooleanArray>, f: Array<BooleanArray>) {
        val size = m.size; var i = 0; var right = size - 1
        while (right >= 1) {
            if (right == 6) right = 5
            for (vert in 0 until size) for (j in 0 until 2) {
                val x = right - j; val upward = ((right + 1) and 2) == 0; val y = if (upward) size - 1 - vert else vert
                if (!f[y][x] && i < data.size * 8) { m[y][x] = ((data[i ushr 3] ushr (7 - (i and 7))) and 1) != 0; i++ }
            }
            right -= 2
        }
    }
    private fun applyMask(mask: Int, m: Array<BooleanArray>, f: Array<BooleanArray>) {
        val size = m.size
        for (y in 0 until size) for (x in 0 until size) {
            val inv = when (mask) { 0 -> (x + y) % 2 == 0; 1 -> y % 2 == 0; 2 -> x % 3 == 0; 3 -> (x + y) % 3 == 0; 4 -> (x / 3 + y / 2) % 2 == 0; 5 -> x * y % 2 + x * y % 3 == 0; 6 -> (x * y % 2 + x * y % 3) % 2 == 0; else -> ((x + y) % 2 + x * y % 3) % 2 == 0 }
            if (!f[y][x] && inv) m[y][x] = !m[y][x]
        }
    }
    private fun penalty(m: Array<BooleanArray>): Int {
        val size = m.size; var result = 0
        for (y in 0 until size) { var run = 1; for (x in 1 until size) { if (m[y][x] == m[y][x - 1]) { run++; if (run == 5) result += 3 else if (run > 5) result++ } else run = 1 } }
        for (x in 0 until size) { var run = 1; for (y in 1 until size) { if (m[y][x] == m[y - 1][x]) { run++; if (run == 5) result += 3 else if (run > 5) result++ } else run = 1 } }
        for (y in 0 until size - 1) for (x in 0 until size - 1) { val c = m[y][x]; if (c == m[y][x + 1] && c == m[y + 1][x] && c == m[y + 1][x + 1]) result += 3 }
        fun finderLike(get: (Int) -> Boolean, n: Int): Int {
            var p = 0
            for (i in 0..n - 11) {
                val a = get(i) && !get(i + 1) && get(i + 2) && get(i + 3) && get(i + 4) && !get(i + 5) && get(i + 6)
                if (a && ((i + 10 < n && !get(i + 7) && !get(i + 8) && !get(i + 9) && !get(i + 10)))) p += 40
                val b = !get(i) && !get(i + 1) && !get(i + 2) && !get(i + 3) && get(i + 4) && !get(i + 5) && get(i + 6) && get(i + 7) && get(i + 8) && !get(i + 9) && get(i + 10)
                if (b) p += 40
            }
            return p
        }
        for (y in 0 until size) result += finderLike({ m[y][it] }, size)
        for (x in 0 until size) result += finderLike({ m[it][x] }, size)
        var dark = 0; for (row in m) for (c in row) if (c) dark++
        val total = size * size; val k = (Math.abs(dark * 20 - total * 10) + total - 1) / total - 1
        result += maxOf(0, k) * 10
        return result
    }

    /** matriz como texto "0/1" por linha (para a tela desenhar) */
    fun toRows(m: Array<BooleanArray>): List<String> = m.map { r -> String(CharArray(r.size) { if (r[it]) '1' else '0' }) }
}
