package net.foxsrv.coinbank

import android.os.Handler
import android.os.Looper
import org.json.JSONObject
import java.math.BigDecimal
import java.math.RoundingMode

/**
 * Canal de eventos Kotlin → Flutter (o MainActivity liga o "sink" enquanto o app está aberto).
 * O serviço em segundo plano e o servidor hospedado também emitem por aqui.
 */
object Events {
    @Volatile var sink: ((String) -> Unit)? = null
    /** o app está na tela (avisos viram banner dentro do app em vez de notificação) */
    @Volatile var foreground = false
    private val main = Handler(Looper.getMainLooper())

    fun emit(o: JSONObject) {
        val s = o.toString()
        main.post { try { sink?.invoke(s) } catch (ignored: Exception) { } }
    }
}

/**
 * Valores: inteiros na menor unidade da moeda ("unidades"). Cada rede diz quantas casas a API usa
 * (`api`, 8 na rede principal) e o usuário escolhe quantas casas exibir (`disp`). Exibir só muda onde fica a
 * vírgula, contando da direita — nada é cortado: 12 unidades → 8 casas: 0,00000012 · 2: 0,12 · inteiro: 12.
 */
object Coin {
    const val SATS = 100_000_000L

    /** valor da API ("0.00000012", 1.5, 12) → unidades, com as casas da API da rede */
    fun parse(v: Any?, dec: Int = 8): Long? {
        if (v == null || v == JSONObject.NULL) return null
        return try {
            val s = (if (v is Number && v !is Int && v !is Long) BigDecimal(v.toString()) else BigDecimal(v.toString().trim().replace(",", ".")))
            s.movePointRight(dec).setScale(0, RoundingMode.DOWN).toLong()
        } catch (e: Exception) { null }
    }

    /** unidades de um objeto da API: prefere os campos inteiros (…Sats), senão converte o texto */
    fun satsOf(o: JSONObject, satsKey: String, coinKey: String, dec: Int = 8): Long {
        if (o.has(satsKey) && !o.isNull(satsKey)) { val x = o.opt(satsKey); if (x is Number) return x.toLong(); x?.toString()?.toLongOrNull()?.let { return it } }
        return parse(o.opt(coinKey), dec) ?: 0L
    }

    /** igual ao site: o modo só muda onde fica a vírgula (contando da direita); nada é cortado. */
    fun format(sats: Long, decimals: Int, pt: Boolean): String {
        val d = decimals.coerceIn(0, 18)
        var base = 1L; repeat(d) { base *= 10L }
        val neg = sats < 0; val v = Math.abs(sats)
        val ip = (v / base).toString()
        val sb = StringBuilder()
        for (i in ip.indices) { if (i > 0 && (ip.length - i) % 3 == 0) sb.append(if (pt) '.' else ','); sb.append(ip[i]) }
        if (d > 0) sb.append(if (pt) ',' else '.').append((v % base).toString().padStart(d, '0'))
        return (if (neg) "-" else "") + sb.toString()
    }

    /** formato da API (casas da API, ponto decimal) */
    fun api(sats: Long, dec: Int = 8): String = if (dec <= 0) sats.toString() else BigDecimal.valueOf(sats).movePointLeft(dec).setScale(dec, RoundingMode.DOWN).toPlainString()
}
