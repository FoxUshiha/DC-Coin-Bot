package net.foxsrv.coinbank

import android.app.Activity
import android.app.KeyguardManager
import android.content.Context
import android.content.DialogInterface
import android.hardware.biometrics.BiometricManager
import android.hardware.biometrics.BiometricPrompt
import android.os.Build
import android.os.CancellationSignal
import org.json.JSONObject

/**
 * Digital / rosto / bloqueio de tela do Android (sem androidx): BiometricPrompt no Android 9+,
 * tela de confirmação do bloqueio no Android 7–8. Usado para entrar com uma conta salva sem digitar a senha.
 */
object Bio {
    const val REQ_CONFIRM = 9211
    @Volatile private var pendingLegacy: ((Boolean, String?) -> Unit)? = null

    fun status(ctx: Context): JSONObject {
        val km = ctx.getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
        val secure = km.isDeviceSecure
        var bio = false
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                val bm = ctx.getSystemService(BiometricManager::class.java)
                bio = bm?.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG or BiometricManager.Authenticators.BIOMETRIC_WEAK) == BiometricManager.BIOMETRIC_SUCCESS
            } else if (Build.VERSION.SDK_INT >= 29) {
                @Suppress("DEPRECATION")
                bio = ctx.getSystemService(BiometricManager::class.java)?.canAuthenticate() == BiometricManager.BIOMETRIC_SUCCESS
            } else {
                bio = ctx.packageManager.hasSystemFeature("android.hardware.fingerprint")
            }
        } catch (ignored: Exception) { }
        return JSONObject().put("available", secure).put("biometric", bio).put("secure", secure)
    }

    fun authenticate(a: Activity, title: String, subtitle: String, done: (Boolean, String?) -> Unit) {
        val km = a.getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
        if (!km.isDeviceSecure) { done(false, "no_lock"); return }
        if (Build.VERSION.SDK_INT >= 28) {
            try {
                var finished = false
                val b = BiometricPrompt.Builder(a).setTitle(title).setSubtitle(subtitle)
                when {
                    Build.VERSION.SDK_INT >= 30 -> b.setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_STRONG or BiometricManager.Authenticators.BIOMETRIC_WEAK or BiometricManager.Authenticators.DEVICE_CREDENTIAL)
                    Build.VERSION.SDK_INT == 29 -> @Suppress("DEPRECATION") b.setDeviceCredentialAllowed(true)
                    else -> b.setNegativeButton(Store.t(a, "Cancelar", "Cancel"), a.mainExecutor, DialogInterface.OnClickListener { _, _ -> if (!finished) { finished = true; done(false, "cancelled") } })
                }
                val prompt = b.build()
                prompt.authenticate(CancellationSignal(), a.mainExecutor, object : BiometricPrompt.AuthenticationCallback() {
                    override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult?) { if (!finished) { finished = true; done(true, null) } }
                    override fun onAuthenticationError(errorCode: Int, errString: CharSequence?) { if (!finished) { finished = true; done(false, if (errorCode == BiometricPrompt.BIOMETRIC_ERROR_USER_CANCELED || errorCode == BiometricPrompt.BIOMETRIC_ERROR_CANCELED) "cancelled" else (errString?.toString() ?: "bio_error")) } }
                    override fun onAuthenticationFailed() {}
                })
                return
            } catch (e: Exception) { /* cai para a confirmação do bloqueio de tela */ }
        }
        try {
            @Suppress("DEPRECATION")
            val i = km.createConfirmDeviceCredentialIntent(title, subtitle)
            if (i == null) { done(true, null); return }
            pendingLegacy = done
            @Suppress("DEPRECATION")
            a.startActivityForResult(i, REQ_CONFIRM)
        } catch (e: Exception) { done(false, "bio_error") }
    }

    fun onLegacyResult(ok: Boolean) { val p = pendingLegacy; pendingLegacy = null; p?.invoke(ok, if (ok) null else "cancelled") }
}
