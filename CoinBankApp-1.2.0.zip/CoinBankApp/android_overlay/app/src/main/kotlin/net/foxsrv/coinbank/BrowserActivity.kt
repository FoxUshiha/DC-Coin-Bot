package net.foxsrv.coinbank

import android.annotation.SuppressLint
import android.app.Activity
import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.view.animation.DecelerateInterpolator
import android.webkit.URLUtil
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView

/**
 * Navegador do app em forma de modal (comprovante pelo link, termos do servidor, páginas de pagamento):
 * fundo escurecido, painel com cantos arredondados, fechar/voltar/recarregar/abrir fora. Segue o tema do app.
 */
class BrowserActivity : Activity() {
    companion object {
        const val EXTRA_URL = "url"; const val EXTRA_TITLE = "title"
        /** termos, privacidade e documentação embutidos no app (funcionam sem internet): https://docs.coinbank.local/terms/... */
        const val LOCAL_HOST = "docs.coinbank.local"
        private fun mime(p: String) = when {
            p.endsWith(".html") -> "text/html"; p.endsWith(".png") -> "image/png"; p.endsWith(".ico") -> "image/x-icon"
            p.endsWith(".css") -> "text/css"; p.endsWith(".js") -> "application/javascript"; p.endsWith(".svg") -> "image/svg+xml"; else -> "application/octet-stream"
        }
        fun open(ctx: Context, url: String, title: String?) {
            val i = Intent(ctx, BrowserActivity::class.java).putExtra(EXTRA_URL, url).putExtra(EXTRA_TITLE, title ?: "")
            if (ctx !is Activity) i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(i)
            if (ctx is Activity) @Suppress("DEPRECATION") ctx.overridePendingTransition(0, 0)
        }
    }

    private lateinit var web: WebView
    private lateinit var titleView: TextView
    private lateinit var progress: ProgressBar
    private lateinit var panel: LinearLayout

    private fun dp(v: Float) = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, resources.displayMetrics).toInt()
    private val dark get() = Store.dark(this)

    private fun btn(label: String, onClick: () -> Unit): TextView {
        val t = TextView(this); t.text = label; t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f); t.gravity = Gravity.CENTER
        t.setPadding(dp(13f), dp(7f), dp(13f), dp(7f)); t.setTextColor(if (dark) Color.parseColor("#E8C987") else Color.parseColor("#7A5A16"))
        val bg = GradientDrawable(); bg.cornerRadius = dp(18f).toFloat(); bg.setColor(if (dark) Color.parseColor("#2A2620") else Color.parseColor("#F4EBD8")); t.background = bg
        t.setOnClickListener { onClick() }; return t
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Store.init(this)
        val url = intent.getStringExtra(EXTRA_URL) ?: Store.mainUrl()
        val bgColor = if (dark) Color.parseColor("#191B1E") else Color.WHITE

        val root = FrameLayout(this); root.setBackgroundColor(Color.argb(150, 0, 0, 0))
        root.setOnClickListener { close() }
        panel = LinearLayout(this); panel.orientation = LinearLayout.VERTICAL; panel.isClickable = true
        val pbg = GradientDrawable(); pbg.setColor(bgColor); pbg.cornerRadii = floatArrayOf(dp(22f).toFloat(), dp(22f).toFloat(), dp(22f).toFloat(), dp(22f).toFloat(), 0f, 0f, 0f, 0f)
        panel.background = pbg; panel.clipToOutline = true
        val handle = View(this); val hb = GradientDrawable(); hb.cornerRadius = dp(3f).toFloat(); hb.setColor(if (dark) Color.parseColor("#3A3F47") else Color.parseColor("#D5D9E0")); handle.background = hb
        val hl = LinearLayout.LayoutParams(dp(40f), dp(5f)); hl.gravity = Gravity.CENTER_HORIZONTAL; hl.topMargin = dp(8f)
        panel.addView(handle, hl)
        val bar = LinearLayout(this); bar.orientation = LinearLayout.HORIZONTAL; bar.gravity = Gravity.CENTER_VERTICAL
        bar.setPadding(dp(12f), dp(6f), dp(12f), dp(8f))
        val close = btn("✕") { close() }
        titleView = TextView(this); titleView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f); titleView.maxLines = 1; titleView.ellipsize = android.text.TextUtils.TruncateAt.END
        titleView.setTextColor(if (dark) Color.parseColor("#E8EAED") else Color.parseColor("#14161A")); titleView.setPadding(dp(12f), 0, dp(8f), 0)
        titleView.text = intent.getStringExtra(EXTRA_TITLE)?.ifEmpty { null } ?: (Uri.parse(url).host ?: "")
        val back = btn("‹") { if (web.canGoBack()) web.goBack() }
        val reload = btn("↻") { web.reload() }
        val ext = btn("↗") {
            try {
                var target = web.url ?: url
                val pu = Uri.parse(target)
                if (pu.host == LOCAL_HOST) target = Store.mainUrl().trimEnd('/') + (pu.path ?: "/") + (pu.fragment?.let { "#$it" } ?: "")
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(target)))
            } catch (ignored: Exception) { }
        }
        bar.addView(close); bar.addView(titleView, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        bar.addView(back)
        val lp1 = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT); lp1.leftMargin = dp(6f); bar.addView(reload, lp1)
        val lp2 = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT); lp2.leftMargin = dp(6f); bar.addView(ext, lp2)
        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal); progress.max = 100
        web = WebView(this); web.setBackgroundColor(bgColor)
        panel.addView(bar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        panel.addView(progress, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(3f)))
        panel.addView(web, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        val plp = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        plp.topMargin = (resources.displayMetrics.heightPixels * 0.07f).toInt()
        root.addView(panel, plp)
        setContentView(root)
        root.setOnApplyWindowInsetsListener { v, ins ->
            if (Build.VERSION.SDK_INT >= 30) { val s = ins.getInsets(WindowInsets.Type.systemBars() or WindowInsets.Type.ime()); panel.setPadding(0, 0, 0, s.bottom); v.setPadding(s.left, s.top, s.right, 0) }
            else @Suppress("DEPRECATION") { panel.setPadding(0, 0, 0, ins.systemWindowInsetBottom); v.setPadding(ins.systemWindowInsetLeft, ins.systemWindowInsetTop, ins.systemWindowInsetRight, 0) }
            ins
        }
        // entra subindo
        panel.translationY = resources.displayMetrics.heightPixels.toFloat()
        panel.animate().translationY(0f).setDuration(280).setInterpolator(DecelerateInterpolator()).start()

        val s = web.settings
        s.javaScriptEnabled = true; s.domStorageEnabled = true; s.cacheMode = WebSettings.LOAD_DEFAULT
        s.loadWithOverviewMode = true; s.useWideViewPort = true; s.builtInZoomControls = true; s.displayZoomControls = false
        s.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        s.userAgentString = s.userAgentString + " CoinBankApp/1.0"
        // tema e idioma do app também no site (cookies coin_theme / coin_lang do site)
        try {
            val cm = android.webkit.CookieManager.getInstance(); cm.setAcceptCookie(true)
            val origin = Store.origin(url)
            if (origin != null) {
                cm.setCookie(origin, "coin_theme=" + (if (dark) "dark" else "light") + "; Path=/")
                cm.setCookie(origin, "coin_lang=" + (if (Store.pt(this)) "pt" else "en") + "; Path=/")
                cm.flush()
            }
        } catch (ignored: Exception) { }
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, req: WebResourceRequest): Boolean {
                val u = req.url; val sc = u.scheme ?: ""
                if (u.host == LOCAL_HOST && (u.path ?: "/").let { it == "/" || it.isEmpty() || it == "/index.html" }) { view.loadUrl(Store.mainUrl()); return true }
                if (sc == "http" || sc == "https") return false
                try { startActivity(Intent(Intent.ACTION_VIEW, u)) } catch (ignored: Exception) { }
                return true
            }
            override fun shouldInterceptRequest(view: WebView, req: WebResourceRequest): WebResourceResponse? {
                val u = req.url
                if (u.host != LOCAL_HOST) return null
                var p = u.path ?: "/"
                if (p == "/terms" || p == "/terms/") p = "/terms/terms.html"
                if (p.contains("..")) return null
                return try { WebResourceResponse(mime(p), "utf-8", assets.open("flutter_assets/assets/site$p")) }
                catch (e: Exception) { WebResourceResponse("text/plain", "utf-8", 404, "Not Found", null, "not found".byteInputStream()) }
            }
            override fun onPageStarted(view: WebView, url: String, favicon: Bitmap?) { progress.visibility = View.VISIBLE }
            override fun onPageFinished(view: WebView, url: String) { progress.visibility = View.GONE }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView, p: Int) { progress.progress = p }
            override fun onReceivedTitle(view: WebView, t: String?) { if (!t.isNullOrBlank() && !t.startsWith("http")) titleView.text = t }
        }
        web.setDownloadListener { dUrl, ua, cd, mime, _ ->
            try {
                val r = DownloadManager.Request(Uri.parse(dUrl)); val name = URLUtil.guessFileName(dUrl, cd, mime)
                r.addRequestHeader("User-Agent", ua)
                r.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED); r.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "CoinBank/$name")
                (getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).enqueue(r)
            } catch (ignored: Exception) { }
        }
        if (savedInstanceState != null) web.restoreState(savedInstanceState) else web.loadUrl(url)
    }

    private var closing = false
    private fun close() {
        if (closing) return
        closing = true
        panel.animate().translationY(panel.height.toFloat().coerceAtLeast(400f)).setDuration(220).withEndAction {
            finish(); @Suppress("DEPRECATION") overridePendingTransition(0, 0)
        }.start()
    }

    override fun onSaveInstanceState(out: Bundle) { super.onSaveInstanceState(out); web.saveState(out) }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { if (web.canGoBack()) web.goBack() else close() }

    override fun onDestroy() { try { (web.parent as? ViewGroup)?.removeView(web); web.destroy() } catch (ignored: Exception) { }; super.onDestroy() }
}
