package net.foxsrv.coinbank

import android.content.Context
import android.os.StatFs
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.InputStream
import java.io.OutputStream
import java.net.Inet4Address
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.net.ServerSocket
import java.net.Socket
import java.net.URLDecoder
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.ThreadPoolExecutor
import java.util.concurrent.atomic.AtomicInteger

/**
 * Servidor HTTP da moeda hospedada neste aparelho (sem bibliotecas): fala a mesma API da rede principal
 * (/api/login, /api/transfer, /api/claim, /api/bill/…, /api/pay/request/…), então o próprio app, outros celulares
 * na rede local e qualquer um pelo túnel Cloudflare usam do mesmo jeito.
 */
class HostServer(private val ctx: Context, val port: Int) {
    private val db = HostDb(ctx)
    @Volatile private var server: ServerSocket? = null
    private val pool = Executors.newFixedThreadPool(24) as ThreadPoolExecutor
    private val longPolls = AtomicInteger(0)
    private val buckets = ConcurrentHashMap<String, DoubleArray>()      // ip → [tokens, último]
    private val loginFails = ConcurrentHashMap<String, LongArray>()     // ip → [falhas, até]
    val startedAt = System.currentTimeMillis()
    @Volatile var requests = 0L; private set
    @Volatile var lastError: String? = null; private set

    fun start(): Boolean {
        if (server != null) return true
        return try {
            val s = ServerSocket(); s.reuseAddress = true
            s.bind(InetSocketAddress(InetAddress.getByName("0.0.0.0"), port), 64)
            server = s
            Thread({ accept(s) }, "coinbank-host").also { it.isDaemon = true }.start()
            try { db.cleanup(0) } catch (ignored: Exception) { }
            true
        } catch (e: Exception) { lastError = e.message ?: "bind_failed"; false }
    }

    fun stop() {
        try { server?.close() } catch (ignored: Exception) { }
        server = null
        try { pool.shutdownNow() } catch (ignored: Exception) { }
        try { db.close() } catch (ignored: Exception) { }
    }

    val running: Boolean get() = server?.isClosed == false

    fun users(): Long = try { db.stats().optLong("totalUsers") } catch (e: Exception) { 0L }
    fun stats(): JSONObject = db.stats()
    fun dbSize(): Long = db.sizeBytes(ctx)
    fun wipe() = db.wipe()

    private fun accept(s: ServerSocket) {
        var lastClean = System.currentTimeMillis()
        while (!s.isClosed) {
            val c = try { s.accept() } catch (e: Exception) { break }
            try { pool.execute { handle(c) } } catch (e: Exception) { try { c.close() } catch (ignored: Exception) { } }
            if (System.currentTimeMillis() - lastClean > 3_600_000L) { lastClean = System.currentTimeMillis(); try { db.cleanup(0) } catch (ignored: Exception) { } }
        }
    }

    // ───────────────────────── HTTP ─────────────────────────
    private class Req(val method: String, val path: String, val query: Map<String, String>, val headers: Map<String, String>, val body: JSONObject, val ip: String)
    private class Res(val status: Int, val body: ByteArray, val type: String)

    private fun readLine(inp: InputStream): String? {
        val sb = StringBuilder()
        while (true) {
            val b = inp.read(); if (b < 0) return if (sb.isEmpty()) null else sb.toString()
            if (b == '\n'.code) return sb.toString().trimEnd('\r')
            sb.append(b.toChar()); if (sb.length > 8192) return null
        }
    }

    private fun handle(c: Socket) {
        c.use { sock ->
            try {
                sock.soTimeout = 30_000
                val inp = BufferedInputStream(sock.getInputStream())
                val first = readLine(inp) ?: return
                val parts = first.split(' '); if (parts.size < 2) return
                val method = parts[0].uppercase()
                val headers = HashMap<String, String>()
                while (true) { val l = readLine(inp) ?: break; if (l.isEmpty()) break; val i = l.indexOf(':'); if (i > 0) headers[l.substring(0, i).trim().lowercase()] = l.substring(i + 1).trim() }
                var raw: ByteArray; var o = 0
                if (headers["transfer-encoding"]?.contains("chunked", true) == true) {
                    val acc = java.io.ByteArrayOutputStream()
                    while (acc.size() <= 32_768) {
                        val sz = readLine(inp)?.substringBefore(';')?.trim()?.toIntOrNull(16) ?: break
                        if (sz <= 0) { while (true) { val l = readLine(inp) ?: break; if (l.isEmpty()) break }; break }
                        val ch = ByteArray(sz); var k = 0
                        while (k < sz) { val n = inp.read(ch, k, sz - k); if (n < 0) break; k += n }
                        acc.write(ch, 0, k); if (k < sz) break
                        readLine(inp)
                    }
                    raw = acc.toByteArray(); o = raw.size
                } else {
                    val len = (headers["content-length"] ?: "0").toIntOrNull()?.coerceIn(0, 32_768) ?: 0
                    raw = ByteArray(len)
                    while (o < len) { val n = inp.read(raw, o, len - o); if (n < 0) break; o += n }
                }
                val target = parts[1]
                val qi = target.indexOf('?')
                val path = try { URLDecoder.decode(if (qi >= 0) target.substring(0, qi) else target, "UTF-8") } catch (e: Exception) { target }
                val query = HashMap<String, String>()
                if (qi >= 0) for (kv in target.substring(qi + 1).split('&')) { val e = kv.indexOf('='); if (e > 0) query[kv.substring(0, e)] = try { URLDecoder.decode(kv.substring(e + 1), "UTF-8") } catch (x: Exception) { kv.substring(e + 1) } }
                // IP real: atrás do túnel Cloudflare vem em CF-Connecting-IP (só confiável quando a conexão vem do próprio aparelho)
                val peer = sock.inetAddress?.hostAddress ?: "?"
                val ip = if (peer == "127.0.0.1" && headers["cf-connecting-ip"] != null) headers["cf-connecting-ip"]!! else peer
                val body = try { val t = String(raw, 0, o, Charsets.UTF_8).trim(); if (t.startsWith("{")) JSONObject(t) else JSONObject() } catch (e: Exception) { JSONObject() }
                requests++
                val res = if (method == "OPTIONS") Res(204, ByteArray(0), "text/plain")
                    else if (!allow(ip)) json(429, JSONObject().put("error", "TOO_MANY_REQUESTS"))
                    else try { route(Req(method, path, query, headers, body, ip)) }
                    catch (e: CoinError) { err(e) }
                    catch (e: Exception) { lastError = e.message; json(500, JSONObject().put("error", "Internal error")) }
                write(sock.getOutputStream(), res)
            } catch (ignored: Exception) { }
        }
    }

    private fun write(out: OutputStream, r: Res) {
        val reason = when (r.status) { 200 -> "OK"; 204 -> "No Content"; 400 -> "Bad Request"; 401 -> "Unauthorized"; 404 -> "Not Found"; 429 -> "Too Many Requests"; else -> "Status" }
        val head = "HTTP/1.1 ${r.status} $reason\r\nContent-Type: ${r.type}\r\nContent-Length: ${r.body.size}\r\nCache-Control: no-store\r\n" +
            "Access-Control-Allow-Origin: *\r\nAccess-Control-Allow-Headers: Authorization, Content-Type, Idempotency-Key\r\nAccess-Control-Allow-Methods: GET, POST, OPTIONS\r\n" +
            "X-Content-Type-Options: nosniff\r\nConnection: close\r\n\r\n"
        out.write(head.toByteArray(Charsets.ISO_8859_1)); out.write(r.body); out.flush()
    }

    /** 20 pedidos/s por IP (rajada de 60) */
    private fun allow(ip: String): Boolean {
        val now = System.currentTimeMillis().toDouble()
        val b = buckets.getOrPut(ip) { doubleArrayOf(60.0, now) }
        synchronized(b) {
            b[0] = minOf(60.0, b[0] + (now - b[1]) / 1000.0 * 20.0); b[1] = now
            if (b[0] < 1.0) return false
            b[0] -= 1.0; return true
        }
    }

    private fun json(status: Int, o: Any): Res = Res(status, o.toString().toByteArray(Charsets.UTF_8), "application/json; charset=utf-8")
    private fun html(status: Int, s: String): Res = Res(status, s.toByteArray(Charsets.UTF_8), "text/html; charset=utf-8")
    private fun err(e: CoinError): Res {
        val o = JSONObject().put("error", e.code)
        e.extra?.let { x -> val it = x.keys(); while (it.hasNext()) { val k = it.next(); o.put(k, x.get(k)) } }
        return json(e.status, o)
    }

    // ───────────────────────── regras / formatos ─────────────────────────
    private fun cfg() = HostConfig.get()
    private fun claimSats() = cfg().optLong("claimSats", 12L)
    private fun cooldown() = cfg().optLong("cooldownMs", 3_600_000L)

    private fun auth(r: Req): String {
        val h = r.headers["authorization"] ?: ""
        val m = Regex("^Bearer\\s+([A-Za-z0-9]{16,128})$", RegexOption.IGNORE_CASE).find(h) ?: throw CoinError("Unauthorized", 401)
        return db.sessionUser(m.groupValues[1]) ?: throw CoinError("Unauthorized", 401)
    }
    private fun token(r: Req): String = Regex("^Bearer\\s+([A-Za-z0-9]{16,128})$", RegexOption.IGNORE_CASE).find(r.headers["authorization"] ?: "")?.groupValues?.get(1) ?: ""

    private fun amount(v: Any?): Long {
        val s = Coin.parse(v, hdec()) ?: throw CoinError("Invalid parameters")
        if (s <= 0) throw CoinError("AMOUNT_TOO_SMALL")
        return s
    }
    private fun optAmount(v: Any?): Long? = if (v == null || v == JSONObject.NULL || v.toString().trim().isEmpty()) null else amount(v)
    private fun cleanId(v: Any?): String? { val s = v?.toString()?.trim()?.replace(Regex("[<@!>]"), "") ?: return null; return if (Regex("^\\d{1,32}$").matches(s)) s else null }

    private fun duration(v: Any?, def: Long, min: Long, max: Long): Long {
        if (v == null || v == JSONObject.NULL || v.toString().isEmpty()) return def
        val m = Regex("^(\\d+)\\s*([smhd]?)$").find(v.toString().trim().lowercase()) ?: throw CoinError("INVALID_TIME", 400, JSONObject().put("message", "Use 10m, 1h, 1d, 30d"))
        val n = m.groupValues[1].toLong()
        val ms = when (m.groupValues[2]) { "s", "" -> n * 1000; "m" -> n * 60_000; "h" -> n * 3_600_000; else -> n * 86_400_000 }
        return ms.coerceIn(min, max)
    }

    /** endereço público para links/QR: túnel Cloudflare > IP da rede local; quem acessou por outro endereço recebe o dele */
    private fun base(r: Req): String {
        val h = r.headers["host"] ?: ""
        val https = h.contains("trycloudflare.com") || r.headers["x-forwarded-proto"] == "https" || r.headers["cf-visitor"]?.contains("https") == true
        if (h.isNotEmpty() && !h.startsWith("127.0.0.1") && !h.startsWith("localhost")) return (if (https) "https://" else "http://") + h
        return HostRuntime.publicBase(port)
    }

    private fun txJson(t: HostDb.TxOut) = JSONObject().put("id", t.id).put("date", HostDb.iso(t.ts)).put("from", t.from).put("to", t.to).put("amountSats", t.sats).put("amountCoins", fmtA(t.sats)).put("type", if (t.from == HostDb.SYSTEM_ID) "claim" else "transfer")
    private fun billJson(b: HostDb.Bill) = JSONObject().put("id", b.id).put("from_id", b.from ?: JSONObject.NULL).put("to_id", b.to).put("amount", fmtA(b.sats)).put("amountSats", b.sats).put("date", HostDb.iso(b.ts)).put("expiresAt", b.expires ?: JSONObject.NULL)
    private fun claimStatus(u: HostDb.User): JSONObject {
        val rem = if (u.lastClaim > 0) maxOf(0L, u.lastClaim + cooldown() - System.currentTimeMillis()) else 0L
        return JSONObject().put("cooldownRemainingMs", rem).put("lastClaimTimestamp", u.lastClaim).put("cooldownMs", cooldown()).put("claimAmount", fmtA(claimSats())).put("claimAmountSats", claimSats())
    }
    private fun hdec(): Int = cfg().optInt("decimals", 8).coerceIn(0, 18)
    private fun fmtA(s: Long): String = Coin.api(s, hdec())
    private fun coins(s: Long): Double { var b = 1.0; repeat(hdec()) { b *= 10.0 }; return s.toDouble() / b }

    private fun prJson(r: Req, p: HostDb.PayReq): JSONObject {
        val u = db.user(p.to); val b = base(r)
        return JSONObject().put("id", p.id).put("to", p.to).put("toName", u?.username ?: JSONObject.NULL)
            .put("amount", if (p.sats == null) JSONObject.NULL else fmtA(p.sats)).put("amountSats", p.sats ?: JSONObject.NULL).put("open", p.sats == null)
            .put("memo", p.memo ?: JSONObject.NULL).put("reusable", p.reusable).put("status", p.status).put("createdAt", p.created).put("expiresAt", p.expires)
            .put("paidCount", p.paidCount).put("paidTotal", fmtA(p.paidTotal)).put("paidTotalSats", p.paidTotal)
            .put("lastTx", p.lastTx ?: JSONObject.NULL).put("lastPayer", p.lastPayer ?: JSONObject.NULL).put("paidAt", p.paidAt ?: JSONObject.NULL)
            .put("url", "$b/pay/${p.id}").put("uri", "coinbank://pay/${p.id}?net=" + java.net.URLEncoder.encode(b, "UTF-8"))
            .put("network", cfg().optString("name"))
    }

    private fun userPay(r: Req, id: String, amountV: Any?): JSONObject {
        val u = db.user(id) ?: throw CoinError("INVALID_TARGET")
        val sats = optAmount(amountV)
        val b = base(r)
        return JSONObject().put("type", "user").put("userId", id).put("name", u.username ?: JSONObject.NULL).put("amount", if (sats == null) JSONObject.NULL else fmtA(sats)).put("amountSats", sats ?: JSONObject.NULL)
            .put("url", "$b/pay/u/$id" + (if (sats != null) "?amount=" + fmtA(sats) else "")).put("uri", "coinbank://user/$id" + (if (sats != null) "?amount=" + fmtA(sats) else ""))
    }

    // ───────────────────────── rotas ─────────────────────────
    private fun route(r: Req): Res {
        val p = r.path.trimEnd('/').ifEmpty { "/" }
        val m = r.method
        fun seg(rx: String): MatchResult? = Regex(rx).matchEntire(p)
        when {
            p == "/health" || p == "/api/health" -> return json(200, JSONObject().put("ok", true).put("uptime", (System.currentTimeMillis() - startedAt) / 1000).put("version", 2).put("time", HostDb.iso(System.currentTimeMillis())).put("network", cfg().optString("name")).put("device", true))
            p == "/api/net/info" -> return json(200, JSONObject().put("name", cfg().optString("name")).put("claimAmount", fmtA(claimSats())).put("claimAmountSats", claimSats()).put("cooldownMs", cooldown()).put("users", users()).put("device", true).put("openRegister", cfg().optBoolean("openRegister", true))
                .put("decimals", hdec()).put("coin", cfg().optString("coin").ifEmpty { cfg().optString("name") }).put("icon", cfg().optString("icon")))

            m == "POST" && p == "/api/login" -> {
                val un = r.body.optString("username").trim(); val pw = r.body.optString("password")
                val lf = loginFails[r.ip]
                if (lf != null && lf[1] > System.currentTimeMillis()) return json(429, JSONObject().put("sessionCreated", false).put("passwordCorrect", false).put("error", "IP blocked. Try again in ${(lf[1] - System.currentTimeMillis()) / 1000 + 1} seconds."))
                if (un.isEmpty() || pw.isEmpty()) return json(400, JSONObject().put("sessionCreated", false).put("passwordCorrect", false))
                val u = db.checkLogin(un, pw)
                if (u == null) {
                    val f = loginFails.getOrPut(r.ip) { longArrayOf(0, 0) }
                    f[0]++; if (f[0] >= 10) { f[0] = 0; f[1] = System.currentTimeMillis() + 300_000L }
                    return json(200, JSONObject().put("sessionCreated", false).put("passwordCorrect", false))
                }
                loginFails.remove(r.ip)
                if (u.card == null) db.setCard(u.id)
                val st = claimStatus(u)
                return json(200, JSONObject().put("sessionCreated", true).put("passwordCorrect", true).put("userId", u.id).put("sessionId", db.createSession(u.id)).put("saldo", fmtA(u.sats)).put("sats", u.sats).put("cooldownRemainingMs", st.optLong("cooldownRemainingMs")))
            }
            m == "POST" && p == "/api/register" -> {
                if (!cfg().optBoolean("openRegister", true)) return json(403, JSONObject().put("success", false).put("error", "REGISTRATION_CLOSED"))
                val un = r.body.optString("username").trim(); val pw = r.body.optString("password")
                if (un.isEmpty() || pw.isEmpty()) return json(400, JSONObject().put("success", false).put("error", "Username and password required."))
                val id = db.register(un, pw, cfg().optInt("maxUsers", 1000))
                HostRuntime.changed()
                return json(200, JSONObject().put("success", true).put("userId", id).put("sessionId", db.createSession(id)))
            }
            m == "POST" && p == "/api/logout" -> { val t = token(r); if (t.isNotEmpty()) db.deleteSession(t); return json(200, JSONObject().put("success", true)) }
            m == "POST" && p == "/api/account/change" -> {
                val me = auth(r); val pw = r.body.optString("password")
                if (pw.isEmpty()) return json(400, JSONObject().put("error", "Missing password"))
                db.changeCredentials(me, r.body.optString("username").trim().ifEmpty { null }, pw)
                return json(200, JSONObject().put("success", true))
            }
            m == "POST" && p == "/api/account/unregister" -> { val me = auth(r); db.changeCredentials(me, null, null); return json(200, JSONObject().put("success", true)) }
            m == "GET" && p == "/api/me" -> {
                val me = auth(r); val u = db.user(me) ?: throw CoinError("Unauthorized", 401); val st = claimStatus(u)
                return json(200, JSONObject().put("userId", u.id).put("username", u.username ?: JSONObject.NULL).put("sats", u.sats).put("coins", coins(u.sats)).put("coinsStr", fmtA(u.sats))
                    .put("totalTransactions", db.txCount(me)).put("lastClaimTs", u.lastClaim).put("cooldownRemainingMs", st.optLong("cooldownRemainingMs")).put("cooldownMs", cooldown())
                    .put("registered", u.username != null).put("createdAt", HostDb.iso(u.created)).put("rank", db.rankOf(u.sats) ?: JSONObject.NULL).put("claim", st).put("network", cfg().optString("name")))
            }
            m == "GET" && seg("/api/user/(\\d{1,32})/balance") != null -> {
                auth(r); val id = seg("/api/user/(\\d{1,32})/balance")!!.groupValues[1]
                val s = db.user(id)?.sats ?: 0L
                return json(200, JSONObject().put("coins", coins(s)).put("sats", s).put("coinsStr", fmtA(s)).put("userId", id))
            }
            m == "POST" && p == "/api/transfer" -> {
                val me = auth(r); val to = cleanId(r.body.opt("toId")) ?: return json(400, JSONObject().put("error", "Invalid parameters"))
                val t = db.transfer(me, to, amount(r.body.opt("amount")))
                return json(200, JSONObject().put("success", true).put("txId", t.id).put("date", HostDb.iso(t.ts)).put("amount", fmtA(t.sats)).put("amountSats", t.sats))
            }
            m == "POST" && p == "/api/claim" -> {
                val me = auth(r)
                return try {
                    val t = db.claim(me, claimSats(), cooldown())
                    json(200, JSONObject().put("success", true).put("claimed", fmtA(t.sats)).put("claimedSats", t.sats).put("txId", t.id).put("date", HostDb.iso(t.ts)).put("nextClaimInMs", cooldown()))
                } catch (e: CoinError) {
                    if (e.code == "COOLDOWN_ACTIVE") json(429, JSONObject().put("error", "Cooldown active").put("nextClaimInMs", e.extra?.optLong("nextClaimInMs") ?: 0L).put("cooldownMs", cooldown()).put("lastClaimTs", e.extra?.optLong("lastClaimTs") ?: 0L)) else throw e
                }
            }
            m == "GET" && p == "/api/claim/status" -> { val me = auth(r); return json(200, claimStatus(db.user(me) ?: throw CoinError("Unauthorized", 401))) }
            m == "POST" && p == "/api/card" -> { val me = auth(r); val u = db.user(me) ?: throw CoinError("Unauthorized", 401); return json(200, JSONObject().put("cardCode", u.card ?: db.setCard(me))) }
            m == "POST" && p == "/api/card/reset" -> { val me = auth(r); return json(200, JSONObject().put("newCode", db.setCard(me))) }
            m == "POST" && p == "/api/card/info" -> {
                val u = db.userByCard(r.body.optString("cardCode").trim()) ?: return json(404, JSONObject().put("success", false).put("error", "Card not found"))
                val st = claimStatus(u)
                return json(200, JSONObject().put("success", true).put("userId", u.id).put("coins", fmtA(u.sats)).put("sats", u.sats).put("totalTransactions", db.txCount(u.id)).put("lastClaimTs", u.lastClaim).put("cooldownRemainingMs", st.optLong("cooldownRemainingMs")).put("cooldownMs", cooldown()))
            }

            // ── cobranças
            m == "POST" && p == "/api/bill/list" -> {
                val me = auth(r); val page = r.body.optInt("page", 1).coerceAtLeast(1); val off = (page - 1) * 10
                return json(200, JSONObject().put("toPay", JSONArray(db.billsFrom(me, 10, off).map { billJson(it) })).put("toReceive", JSONArray(db.billsTo(me, 10, off).map { billJson(it) })).put("page", page))
            }
            m == "POST" && p == "/api/bill/create" -> {
                auth(r)
                val to = cleanId(r.body.opt("toId")) ?: return json(400, JSONObject().put("error", "Invalid parameters"))
                val fromRaw = r.body.optString("fromId").trim()
                val from = if (fromRaw.isEmpty()) null else (cleanId(fromRaw) ?: return json(400, JSONObject().put("error", "Invalid parameters")))
                val sats = amount(r.body.opt("amount"))
                val exp = System.currentTimeMillis() + duration(r.body.opt("time"), 90L * 86_400_000L, 3_600_000L, 182L * 86_400_000L)
                val b = db.billCreate(from, to, sats, exp)
                return json(200, JSONObject().put("success", true).put("billId", b.id).put("from", b.from ?: JSONObject.NULL).put("to", b.to).put("amount", fmtA(b.sats)).put("amountSats", b.sats).put("expiresAt", exp))
            }
            m == "POST" && p == "/api/bill/pay" -> {
                val me = auth(r); val id = r.body.optString("billId").trim(); if (id.isEmpty()) return json(400, JSONObject().put("error", "Missing billId"))
                val x = db.billPay(id, me)
                return json(200, JSONObject().put("success", true).put("billId", x.bill.id).put("txId", x.tx?.id ?: JSONObject.NULL).put("toId", x.bill.to).put("amount", fmtA(x.bill.sats)).put("amountSats", x.bill.sats).put("date", HostDb.iso(x.tx?.ts ?: System.currentTimeMillis())).put("self", x.self))
            }
            m == "GET" && seg("/api/bill/([^/]{1,64})") != null -> {
                val b = db.billGet(seg("/api/bill/([^/]{1,64})")!!.groupValues[1]) ?: return json(404, JSONObject().put("success", false).put("error", "BILL_NOT_FOUND"))
                return json(200, JSONObject().put("success", true).put("bill", billJson(b)))
            }

            // ── backups
            m == "POST" && p == "/api/backup/create" -> { val me = auth(r); return json(200, JSONObject().put("success", true).put("count", db.backupCreate(me, 12).size)) }
            m == "POST" && p == "/api/backup/list" -> { val me = auth(r); return json(200, JSONObject().put("backups", JSONArray(db.backups(me)))) }
            m == "POST" && p == "/api/backup/restore" -> {
                val me = auth(r); val code = r.body.optString("backupId", r.body.optString("code")).trim()
                if (code.isEmpty()) return json(400, JSONObject().put("error", "Missing backupId"))
                val t = db.backupRestore(code, me)
                return json(200, JSONObject().put("success", true).put("txId", t.id).put("date", HostDb.iso(t.ts)).put("from", t.from).put("amount", fmtA(t.sats)).put("amountSats", t.sats))
            }

            // ── extrato
            m == "GET" && p == "/api/transactions" -> {
                val me = auth(r); val page = (r.query["page"]?.toIntOrNull() ?: 1).coerceAtLeast(1)
                val l = db.txList(me, 20, (page - 1) * 20).map { JSONObject().put("id", it.id).put("date", HostDb.iso(it.ts)).put("from_id", it.from).put("to_id", it.to).put("amount", fmtA(it.sats)).put("amountSats", it.sats) }
                return json(200, JSONObject().put("transactions", JSONArray(l)).put("page", page))
            }
            m == "GET" && seg("/api/tx/([^/]{1,64})/receipt(\\.png|\\.pdf)?") != null -> {
                val g = seg("/api/tx/([^/]{1,64})/receipt(\\.png|\\.pdf)?")!!.groupValues
                val t = db.txGet(g[1]) ?: return json(404, JSONObject().put("error", "INVALID_TRANSACTION"))
                val pdf = g[2] == ".pdf" || r.query["format"] == "pdf"
                val tx = receiptJson(r, t)
                return if (pdf) Res(200, Receipt.pdf(ctx, tx), "application/pdf") else Res(200, Receipt.png(ctx, tx), "image/png")
            }
            m == "GET" && seg("/api/tx/([^/]{1,64})/link") != null -> {
                val t = db.txGet(seg("/api/tx/([^/]{1,64})/link")!!.groupValues[1]) ?: return json(404, JSONObject().put("error", "INVALID_TRANSACTION"))
                val b = base(r)
                return json(200, JSONObject().put("success", true).put("id", t.id).put("url", "$b/tx/${t.id}").put("png", "$b/api/tx/${t.id}/receipt.png").put("pdf", "$b/api/tx/${t.id}/receipt.pdf").put("json", "$b/api/tx/${t.id}"))
            }
            m == "GET" && seg("/api/tx/([^/]{1,64})") != null -> {
                val t = db.txGet(seg("/api/tx/([^/]{1,64})")!!.groupValues[1]) ?: return json(404, JSONObject().put("error", "INVALID_TRANSACTION").put("message", "Transaction not found"))
                return json(200, JSONObject().put("success", true).put("tx", txJson(t)))
            }
            m == "GET" && p == "/api/user/graph" -> {
                val me = auth(r); val days = (r.query["days"]?.toIntOrNull() ?: 30).coerceIn(2, 365)
                return json(200, JSONObject().put("days", graph(me, days)))
            }

            // ── pagamentos por QR
            m == "POST" && p == "/api/pay/request" -> {
                val me = auth(r)
                val sats = optAmount(r.body.opt("amount"))
                val memo = r.body.optString("memo").replace(Regex("[\\u0000-\\u001f<>]"), "").trim().take(140).ifEmpty { null }
                val exp = System.currentTimeMillis() + duration(r.body.opt("expires"), 86_400_000L, 60_000L, 30L * 86_400_000L)
                val pr = db.prCreate(me, sats, memo, r.body.optBoolean("reusable", false), exp)
                return json(200, JSONObject().put("success", true).put("request", prJson(r, pr)))
            }
            m == "GET" && p == "/api/pay/requests" -> {
                val me = auth(r); val st = r.query["status"]?.takeIf { it in setOf("open", "paid", "cancelled", "expired") }
                val page = (r.query["page"]?.toIntOrNull() ?: 1).coerceAtLeast(1)
                return json(200, JSONObject().put("requests", JSONArray(db.prList(me, st, 20, (page - 1) * 20).map { prJson(r, it) })).put("page", page))
            }
            m == "GET" && seg("/api/pay/request/([A-Za-z0-9_-]{8,40})") != null -> {
                val id = seg("/api/pay/request/([A-Za-z0-9_-]{8,40})")!!.groupValues[1]
                var pr = db.prGet(id) ?: return json(404, JSONObject().put("success", false).put("error", "PAYREQ_NOT_FOUND"))
                val wait = (r.query["wait"]?.toIntOrNull() ?: 0).coerceIn(0, 25) * 1000L
                val since = r.query["since"]?.toIntOrNull()
                if (wait > 0 && since != null && longPolls.incrementAndGet() <= 12) {
                    try {
                        val until = System.currentTimeMillis() + wait
                        while (System.currentTimeMillis() < until && pr.paidCount == since && pr.status == "open") { Thread.sleep(400); pr = db.prGet(id) ?: break }
                    } finally { longPolls.decrementAndGet() }
                } else if (wait > 0 && since != null) longPolls.decrementAndGet()
                return json(200, JSONObject().put("success", true).put("request", prJson(r, pr)))
            }
            m == "POST" && seg("/api/pay/request/([A-Za-z0-9_-]{8,40})/pay") != null -> {
                val me = auth(r); val id = seg("/api/pay/request/([A-Za-z0-9_-]{8,40})/pay")!!.groupValues[1]
                val (t, pr) = db.prPay(id, me, optAmount(r.body.opt("amount")))
                return json(200, JSONObject().put("success", true).put("txId", t.id).put("date", HostDb.iso(t.ts)).put("from", me).put("to", t.to).put("amount", fmtA(t.sats)).put("amountSats", t.sats).put("request", prJson(r, pr)))
            }
            m == "POST" && seg("/api/pay/request/([A-Za-z0-9_-]{8,40})/cancel") != null -> {
                val me = auth(r); val id = seg("/api/pay/request/([A-Za-z0-9_-]{8,40})/cancel")!!.groupValues[1]
                return json(200, JSONObject().put("success", true).put("request", prJson(r, db.prCancel(id, me))))
            }
            m == "GET" && p == "/api/pay/me" -> { val me = auth(r); return json(200, userPay(r, me, r.query["amount"]).put("success", true)) }
            m == "GET" && seg("/api/pay/user/(\\d{1,32})") != null -> return json(200, userPay(r, seg("/api/pay/user/(\\d{1,32})")!!.groupValues[1], r.query["amount"]).put("success", true))
            m == "POST" && p == "/api/pay/scan" -> return json(200, scan(r, r.body.optString("data").take(600)).put("success", true))

            // ── estatísticas
            m == "GET" && p == "/api/totalusers" -> return json(200, JSONObject().put("totalUsers", users()))
            m == "GET" && p == "/api/stats" -> {
                val s = db.stats()
                return json(200, s.put("totalCoins", fmtA(s.optLong("totalSats"))).put("totalMinted", fmtA(s.optLong("totalSats"))).put("volume24h", fmtA(s.optLong("volume24hSats")))
                    .put("claimAmount", fmtA(claimSats())).put("claimCooldownMs", cooldown()).put("activeUsers24h", 0).put("maxSupply", JSONObject.NULL).put("updatedAt", HostDb.iso(System.currentTimeMillis())).put("network", cfg().optString("name")))
            }
            m == "GET" && p == "/api/stats/history" -> return json(200, JSONObject().put("days", db.history((r.query["days"]?.toIntOrNull() ?: 30).coerceIn(1, 365))))
            m == "GET" && p == "/api/rank" -> {
                auth(r); val page = (r.query["page"]?.toIntOrNull() ?: 1).coerceAtLeast(1); val size = (r.query["size"]?.toIntOrNull() ?: 25).coerceIn(1, 100)
                val l = db.rank(size, (page - 1) * size).mapIndexed { i, u -> JSONObject().put("position", (page - 1) * size + i + 1).put("id", u.id).put("username", u.username ?: "none").put("coins", fmtA(u.sats)).put("sats", u.sats) }
                val st = db.stats(); val holders = st.optLong("holders")
                return json(200, JSONObject().put("totalCoins", fmtA(st.optLong("totalSats"))).put("totalSats", st.optLong("totalSats")).put("totalHolders", holders)
                    .put("page", page).put("pages", maxOf(1L, (holders + size - 1) / size)).put("rankings", JSONArray(l)))
            }

            // ── páginas simples (quem abre o link no navegador)
            m == "GET" && (p == "/" || p == "/index.html") -> return html(200, page(cfg().optString("name"), Store.t(ctx,
                "Esta é uma rede Coin hospedada em um celular com o app Coin Bank. Instale o app e adicione este endereço em Hospedar › Servidores para usar.",
                "This is a Coin network hosted on a phone with the Coin Bank app. Install the app and add this address under Host › Servers to use it.") + "<p><code>${base(r)}</code></p>"))
            m == "GET" && (p == "/terms" || p.startsWith("/terms/")) -> return html(200, page(Store.t(ctx, "Termos", "Terms"), Store.t(ctx,
                "Os coins desta rede são unidades virtuais <b>sem valor monetário</b>, criadas por quem hospeda a rede neste aparelho. Não há dinheiro real nem cartão real envolvidos. A rede pode sair do ar a qualquer momento.",
                "The coins of this network are virtual units with <b>no monetary value</b>, created by whoever hosts it on this device. No real money or real cards are involved. The network may go offline at any time.")))
            m == "GET" && seg("/tx/([^/]{1,64})") != null -> {
                val t = db.txGet(seg("/tx/([^/]{1,64})")!!.groupValues[1]) ?: return html(404, page("404", Store.t(ctx, "Transação não encontrada.", "Transaction not found.")))
                return html(200, receiptPage(r, t))
            }
            m == "GET" && (seg("/pay/([A-Za-z0-9_-]{8,40})") != null || seg("/pay/u/(\\d{1,32})") != null) -> return html(200, page(Store.t(ctx, "Pagamento", "Payment"),
                Store.t(ctx, "Abra este QR Code no app Coin Bank (Escanear para pagar).", "Open this QR code in the Coin Bank app (Scan to pay).")))
        }
        return json(404, JSONObject().put("error", "Not found"))
    }

    private fun graph(me: String, days: Int): JSONArray {
        val now = System.currentTimeMillis(); val start = now - days * 86_400_000L
        val l = db.txList(me, 2000, 0)
        var bal = db.user(me)?.sats ?: 0L
        val pts = ArrayList<Pair<Long, Long>>()
        // anda para trás a partir do saldo atual
        val dayBal = LongArray(days)
        var idx = 0
        for (d in days - 1 downTo 0) {
            val dayEnd = start + (d + 1) * 86_400_000L
            while (idx < l.size && l[idx].ts >= dayEnd) { val t = l[idx]; bal += if (t.to == me) -t.sats else t.sats; idx++ }
            dayBal[d] = bal
        }
        val f = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US)
        val out = JSONArray()
        for (d in 0 until days) out.put(JSONObject().put("date", f.format(java.util.Date(start + d * 86_400_000L))).put("balance", fmtA(dayBal[d])).put("balanceSats", dayBal[d]))
        pts.clear()
        return out
    }

    private fun scan(r: Req, text: String): JSONObject {
        val s = text.trim()
        if (s.isEmpty()) return JSONObject().put("type", "unknown")
        val m = Regex("^(?:https?://[^/]+|coinbank:/)(/[^?#]*)(?:\\?([^#]*))?", RegexOption.IGNORE_CASE).find(s)
        val path = m?.groupValues?.get(1) ?: s
        val qAmount = m?.groupValues?.get(2)?.split('&')?.firstOrNull { it.startsWith("amount=") }?.substringAfter('=')?.let { try { URLDecoder.decode(it, "UTF-8") } catch (e: Exception) { it } }?.ifEmpty { null }
        Regex("^/pay/u/(\\d{1,32})/?$").find(path)?.let { x -> return try { userPay(r, x.groupValues[1], qAmount) } catch (e: CoinError) { JSONObject().put("type", "invalid").put("error", e.code) } }
        Regex("^/user/(\\d{1,32})/?$").find(path)?.let { x -> return try { userPay(r, x.groupValues[1], qAmount) } catch (e: CoinError) { JSONObject().put("type", "invalid").put("error", e.code) } }
        Regex("^/pay/([A-Za-z0-9_-]{8,40})/?$").find(path)?.let { x -> val pr = db.prGet(x.groupValues[1]); return if (pr != null) JSONObject().put("type", "request").put("request", prJson(r, pr)) else JSONObject().put("type", "invalid").put("error", "PAYREQ_NOT_FOUND") }
        Regex("^/tx/([^/]{1,64})/?$").find(path)?.let { x -> val t = db.txGet(x.groupValues[1]); return if (t != null) JSONObject().put("type", "transaction").put("tx", txJson(t)) else JSONObject().put("type", "invalid").put("error", "INVALID_TRANSACTION") }
        if (Regex("^\\d{5,32}$").matches(s)) return try { userPay(r, s, null) } catch (e: CoinError) { JSONObject().put("type", "invalid").put("error", e.code) }
        if (Regex("^[0-9a-fA-F-]{36}$").matches(s)) {
            db.billGet(s)?.let { return JSONObject().put("type", "bill").put("bill", billJson(it)) }
            db.txGet(s)?.let { return JSONObject().put("type", "transaction").put("tx", txJson(it)) }
        }
        db.prGet(s)?.let { return JSONObject().put("type", "request").put("request", prJson(r, it)) }
        return JSONObject().put("type", "unknown")
    }

    private fun receiptJson(r: Req, t: HostDb.TxOut): JSONObject {
        val lang = (r.query["lang"] ?: r.headers["accept-language"] ?: "").lowercase()
        return txJson(t).put("lang", if (lang.startsWith("pt")) "pt" else if (lang.startsWith("en")) "en" else "").put("dark", r.query["theme"] == "dark")
            .put("decimals", hdec()).put("server", base(r)).put("network", cfg().optString("name")).put("coin", cfg().optString("coin").ifEmpty { "coins" })
    }

    /** página pública do comprovante (link para mandar): imagem gerada na hora + baixar PNG/PDF + copiar link */
    private fun receiptPage(r: Req, t: HostDb.TxOut): String {
        val b = base(r); val id = esc(t.id)
        val pt = (r.headers["accept-language"] ?: "").lowercase().startsWith("pt")
        fun tr(a: String, e: String) = if (pt) a else e
        val body = """<img src="/api/tx/$id/receipt.png" alt="" style="width:100%;max-width:520px;border-radius:14px;display:block;margin:0 auto 14px">
<p style="text-align:center"><a class="b" href="/api/tx/$id/receipt.png" download>${tr("Baixar imagem", "Download image")}</a> <a class="b" href="/api/tx/$id/receipt.pdf" download>PDF</a>
<button class="b" onclick="navigator.clipboard&&navigator.clipboard.writeText(location.href);this.textContent='${tr("Link copiado", "Link copied")}'">${tr("Copiar link", "Copy link")}</button></p>
<p style="color:#a1a7b0;font-size:13px;text-align:center">${tr("Comprovante verificável", "Verifiable receipt")} · <code>$b/tx/$id</code></p>"""
        return page(tr("Comprovante", "Receipt"), body)
    }

    private fun page(title: String, body: String): String = """<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>${esc(title)} · Coin</title><style>body{margin:0;font:15px/1.6 system-ui,Roboto,sans-serif;background:#101113;color:#e8eaed}main{max-width:640px;margin:0 auto;padding:32px 18px}
h1{font-size:24px;margin:0 0 12px}.b{display:inline-block;margin:4px;padding:9px 14px;border-radius:10px;background:#e4e6e9;color:#111214;font-weight:700;text-decoration:none;border:0;font-size:14px;cursor:pointer}code{background:#212328;border:1px solid #2a2d33;border-radius:6px;padding:1px 6px}.c{background:#191b1e;border:1px solid #2a2d33;border-radius:14px;padding:16px 18px}b{color:#d6a94b}</style></head>
<body><main><h1>🪙 ${esc(title)}</h1><div class="c">$body</div><p style="color:#717883;font-size:13px">Coin Bank · ${esc(cfg().optString("name"))}</p></main></body></html>"""

    private fun esc(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;")
}

/** Liga/desliga a rede hospedada + túnel Cloudflare conforme a configuração, e informa o estado ao app. */
object HostRuntime {
    @Volatile private var srv: HostServer? = null
    @Volatile private var tunnelUrl: String? = null
    @Volatile private var lastChange = 0L

    fun changed() { lastChange = System.currentTimeMillis(); Events.emit(JSONObject().put("type", "host")) }

    @Synchronized fun sync(ctx: Context) {
        HostConfig.init(ctx)
        val c = HostConfig.get()
        if (!c.optBoolean("enabled", false)) { stop(ctx); return }
        val port = c.optInt("port", HostConfig.DEFAULT_PORT)
        val cur = srv
        if (cur == null || !cur.running || cur.port != port) {
            cur?.stop()
            val s = HostServer(ctx.applicationContext, port)
            srv = if (s.start()) s else { lastError = s.lastError; null }
            changed()
        }
        if (c.optBoolean("cloudflare", false) && srv != null) {
            CfTunnel.start(ctx, "host", port, "auto") { u -> tunnelUrl = u; changed() }
        } else if (tunnelUrl != null || CfTunnel.status("host").optBoolean("on")) {
            CfTunnel.stop("host"); tunnelUrl = null; changed()
        }
    }

    @Volatile var lastError: String? = null; private set

    @Synchronized fun stop(ctx: Context) {
        if (srv == null && tunnelUrl == null && !CfTunnel.status("host").optBoolean("on")) return
        CfTunnel.stop("host"); tunnelUrl = null
        srv?.stop(); srv = null
        changed()
    }

    fun running(): Boolean = srv?.running == true
    fun tunnel(): String? = tunnelUrl

    fun lanIp(): String? = try {
        NetworkInterface.getNetworkInterfaces()?.toList().orEmpty()
            .filter { it.isUp && !it.isLoopback && !it.isVirtual }
            .sortedBy { if (it.name.startsWith("wlan")) 0 else if (it.name.startsWith("ap") || it.name.startsWith("swlan")) 1 else 2 }
            .flatMap { it.inetAddresses.toList() }
            .firstOrNull { it is Inet4Address && !it.isLoopbackAddress && it.isSiteLocalAddress }?.hostAddress
    } catch (e: Exception) { null }

    /** endereço público da rede hospedada: Cloudflare quando ligado; senão o IP na rede local */
    fun publicBase(port: Int): String = tunnelUrl ?: ("http://" + (lanIp() ?: "127.0.0.1") + ":" + port)

    fun status(ctx: Context): JSONObject {
        val c = HostConfig.get(); val s = srv
        val port = c.optInt("port", HostConfig.DEFAULT_PORT)
        val o = JSONObject().put("config", c).put("running", s?.running == true).put("port", port)
            .put("local", "http://127.0.0.1:$port").put("lan", lanIp()?.let { "http://$it:$port" } ?: JSONObject.NULL)
            .put("public", publicBase(port)).put("error", lastError ?: JSONObject.NULL)
            .put("tunnel", CfTunnel.status("host")).put("cloudflaredAvailable", CfTunnel.available(ctx))
        if (s != null) {
            try {
                val st = s.stats()
                o.put("users", st.optLong("totalUsers")).put("transactions", st.optLong("totalTransactions")).put("supply", Coin.api(st.optLong("totalSats"), c.optInt("decimals", 8))).put("requests", s.requests).put("uptimeSec", (System.currentTimeMillis() - s.startedAt) / 1000)
            } catch (ignored: Exception) { }
        }
        try {
            val dbf = ctx.getDatabasePath("hostcoin.db")
            var size = 0L; for (n in listOf("hostcoin.db", "hostcoin.db-wal", "hostcoin.db-shm")) { val f = ctx.getDatabasePath(n); if (f.exists()) size += f.length() }
            val sf = StatFs((dbf.parentFile ?: ctx.filesDir).let { if (it.exists()) it.path else ctx.filesDir.path })
            o.put("storage", JSONObject().put("dbBytes", size).put("freeBytes", sf.availableBytes).put("totalBytes", sf.totalBytes))
        } catch (ignored: Exception) { }
        return o
    }

    /** apaga todos os dados da rede (contas, saldos, transações) */
    fun wipe(ctx: Context) {
        val s = srv
        if (s != null) s.wipe() else { val d = HostDb(ctx); try { d.wipe() } finally { d.close() } }
        changed()
    }
}
