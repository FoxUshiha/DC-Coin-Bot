package net.foxsrv.coinbank

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ImageFormat
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.SurfaceTexture
import android.graphics.Typeface
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraDevice
import android.hardware.camera2.CameraManager
import android.hardware.camera2.CaptureRequest
import android.media.ImageReader
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.HandlerThread
import android.os.Looper
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.provider.Settings
import android.util.Size
import android.util.TypedValue
import android.view.Gravity
import android.view.Surface
import android.view.TextureView
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import net.foxsrv.coinbank.zxing.BarcodeFormat
import net.foxsrv.coinbank.zxing.BinaryBitmap
import net.foxsrv.coinbank.zxing.DecodeHintType
import net.foxsrv.coinbank.zxing.LuminanceSource
import net.foxsrv.coinbank.zxing.PlanarYUVLuminanceSource
import net.foxsrv.coinbank.zxing.RGBLuminanceSource
import net.foxsrv.coinbank.zxing.common.GlobalHistogramBinarizer
import net.foxsrv.coinbank.zxing.common.HybridBinarizer
import net.foxsrv.coinbank.zxing.qrcode.QRCodeReader
import java.util.EnumMap
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Leitor de QR do próprio app (câmera dentro do Coin Bank, como em app de banco): Camera2 + ZXing, sem depender do
 * Google Play Services. Devolve o texto lido para quem pediu (a carteira manda o código para a API de pagamentos).
 */
object QrScan {
    @Volatile private var pending: ((String?, String?) -> Unit)? = null

    fun scan(a: Activity, done: (text: String?, error: String?) -> Unit) {
        // um pedido por vez: se havia outro esperando, ele é cancelado
        pending?.let { old -> pending = null; try { old(null, null) } catch (ignored: Exception) { } }
        pending = done
        try {
            a.startActivity(Intent(a, ScanActivity::class.java))
        } catch (e: Throwable) { deliver(null, "scanner_unavailable") }
    }

    fun deliver(text: String?, error: String?) {
        val p = pending ?: return
        pending = null
        Handler(Looper.getMainLooper()).post { try { p(text, error) } catch (ignored: Exception) { } }
    }

    private fun hints(): Map<DecodeHintType, Any> = EnumMap<DecodeHintType, Any>(DecodeHintType::class.java).apply {
        put(DecodeHintType.POSSIBLE_FORMATS, listOf(BarcodeFormat.QR_CODE))
        put(DecodeHintType.TRY_HARDER, true)
        put(DecodeHintType.CHARACTER_SET, "UTF-8")
    }

    /** decodifica a partir de uma fonte de luminância (tenta os dois binarizadores e a imagem invertida) */
    fun decode(src: LuminanceSource): String? {
        val reader = QRCodeReader(); val h = hints()
        for (s in listOf(src, src.invert())) {
            for (bin in listOf(HybridBinarizer(s), GlobalHistogramBinarizer(s))) {
                try { return reader.decode(BinaryBitmap(bin), h).text } catch (e: Exception) { reader.reset() }
            }
        }
        return null
    }

    /** lê um QR de uma imagem (galeria) */
    fun decodeImage(ctx: Context, uri: Uri): String? {
        val bytes = ctx.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: return null
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }; BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o)
        var sample = 1; while (o.outWidth / sample > 1600 || o.outHeight / sample > 1600) sample *= 2
        val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = sample }) ?: return null
        val px = IntArray(bmp.width * bmp.height); bmp.getPixels(px, 0, bmp.width, 0, 0, bmp.width, bmp.height)
        return decode(RGBLuminanceSource(bmp.width, bmp.height, px))
    }
}

/** Tela da câmera: visor central, lanterna, colar código e ler da galeria. */
class ScanActivity : Activity() {
    private lateinit var texture: TextureView
    private lateinit var frame: ScanFrameView
    private lateinit var hint: TextView
    private lateinit var torchBtn: TextView
    private var cam: CameraDevice? = null
    @Volatile private var opening = false
    private var session: CameraCaptureSession? = null
    private var reader: ImageReader? = null
    private var reqBuilder: CaptureRequest.Builder? = null
    private var bgThread: HandlerThread? = null
    private var bg: Handler? = null
    private var previewSize = Size(1280, 720)
    private var sensorOrientation = 90
    private var hasFlash = false
    private var torch = false
    private val busy = AtomicBoolean(false)
    private val done = AtomicBoolean(false)
    private var lastTry = 0L
    private var permAsked = false
    private var delivered = false

    companion object { const val REQ_CAM = 7401; const val REQ_IMG = 7402 }

    private fun t(pt: String, en: String) = AppUi.t(this, pt, en)
    private fun dp(v: Int) = AppUi.dp(this, v)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        if (Build.VERSION.SDK_INT >= 21) { window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS); bars() }
        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        texture = TextureView(this)
        root.addView(texture, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        frame = ScanFrameView(this)
        root.addView(frame, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        // barra de cima
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(8), dp(8), dp(8), dp(8)); fitsSystemWindows = true }
        top.addView(pill("✕") { finishCancel() }, LinearLayout.LayoutParams(dp(48), dp(48)))
        top.addView(TextView(this).apply { text = t("Escanear QR Code", "Scan QR code"); setTextColor(Color.WHITE); setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f); typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER },
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        torchBtn = pill("🔦") { setTorch(!torch) }
        top.addView(torchBtn, LinearLayout.LayoutParams(dp(48), dp(48)))
        root.addView(top, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP))
        // parte de baixo
        val bottom = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL; setPadding(dp(20), dp(12), dp(20), dp(24)); fitsSystemWindows = true }
        hint = TextView(this).apply {
            text = t("Aponte para o QR Code da cobrança ou da pessoa", "Point at the QR code of a request or a person")
            setTextColor(Color.WHITE); setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f); gravity = Gravity.CENTER
            setShadowLayer(6f, 0f, 1f, Color.BLACK)
        }
        bottom.addView(hint)
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        row.addView(wide(t("Colar código", "Paste code")) { paste() }, LinearLayout.LayoutParams(0, dp(48), 1f).apply { marginEnd = dp(6) })
        row.addView(wide(t("Da galeria", "From gallery")) { gallery() }, LinearLayout.LayoutParams(0, dp(48), 1f).apply { marginStart = dp(6) })
        bottom.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(16) })
        root.addView(bottom, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM))
        setContentView(root)
        texture.surfaceTextureListener = object : TextureView.SurfaceTextureListener {
            override fun onSurfaceTextureAvailable(st: SurfaceTexture, w: Int, h: Int) { startCamera() }
            override fun onSurfaceTextureSizeChanged(st: SurfaceTexture, w: Int, h: Int) { fitPreview() }
            override fun onSurfaceTextureDestroyed(st: SurfaceTexture): Boolean = true
            override fun onSurfaceTextureUpdated(st: SurfaceTexture) {}
        }
    }

    @Suppress("DEPRECATION")
    private fun bars() { window.statusBarColor = Color.TRANSPARENT; window.navigationBarColor = Color.BLACK }

    private fun pill(label: String, onClick: () -> Unit) = TextView(this).apply {
        text = label; setTextColor(Color.WHITE); setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f); gravity = Gravity.CENTER
        background = AppUi.round(Color.argb(110, 0, 0, 0), dp(24).toFloat()); isClickable = true; setOnClickListener { onClick() }
    }

    private fun wide(label: String, onClick: () -> Unit) = TextView(this).apply {
        text = label; setTextColor(Color.WHITE); setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f); typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
        background = AppUi.round(Color.argb(70, 255, 255, 255), dp(16).toFloat(), dp(1), Color.argb(150, 255, 255, 255))
        isClickable = true; setOnClickListener { onClick() }
    }

    override fun onResume() {
        super.onResume()
        bgThread = HandlerThread("coin-scan").also { it.start() }; bg = Handler(bgThread!!.looper)
        if (texture.isAvailable) startCamera()
    }

    override fun onPause() {
        closeCamera()
        bgThread?.quitSafely(); bgThread = null; bg = null
        super.onPause()
    }

    override fun onDestroy() {
        if (!delivered) { delivered = true; QrScan.deliver(null, null) }
        super.onDestroy()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { finishCancel() }

    private fun finishCancel() { if (!delivered) { delivered = true; QrScan.deliver(null, null) }; finish() }

    private fun finishWith(text: String) {
        if (!done.compareAndSet(false, true)) return
        runOnUiThread {
            try {
                val v = getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
                if (Build.VERSION.SDK_INT >= 26) v?.vibrate(VibrationEffect.createOneShot(60, VibrationEffect.DEFAULT_AMPLITUDE)) else @Suppress("DEPRECATION") v?.vibrate(60)
            } catch (ignored: Exception) { }
            frame.found = true; frame.invalidate()
            if (!delivered) { delivered = true; QrScan.deliver(text, null) }
            texture.postDelayed({ finish() }, 180)
        }
    }

    // ───────── câmera ─────────
    private fun hasCam() = Build.VERSION.SDK_INT < 23 || checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED

    @SuppressLint("MissingPermission")
    private fun startCamera() {
        if (cam != null || opening || bg == null) return
        if (!hasCam()) {
            if (!permAsked) { permAsked = true; requestPermissions(arrayOf(Manifest.permission.CAMERA), REQ_CAM) }
            else noPermission()
            return
        }
        val cm = getSystemService(Context.CAMERA_SERVICE) as CameraManager
        try {
            val id = cm.cameraIdList.firstOrNull { cm.getCameraCharacteristics(it).get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK } ?: cm.cameraIdList.firstOrNull()
            if (id == null) { hint.text = t("Este aparelho não tem câmera. Use \"Colar código\" ou \"Da galeria\".", "This device has no camera. Use \"Paste code\" or \"From gallery\"."); return }
            val ch = cm.getCameraCharacteristics(id)
            sensorOrientation = ch.get(CameraCharacteristics.SENSOR_ORIENTATION) ?: 90
            hasFlash = ch.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            torchBtn.visibility = if (hasFlash) View.VISIBLE else View.INVISIBLE
            val map = ch.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP) ?: return
            val yuv = map.getOutputSizes(ImageFormat.YUV_420_888)?.toList() ?: emptyList()
            // tamanho bom para ler QR sem pesar: ~1280×720 (ou o mais próximo abaixo de 1920×1080)
            previewSize = yuv.filter { it.width <= 1920 && it.height <= 1080 }.minByOrNull { Math.abs(it.width * it.height - 1280 * 720) } ?: yuv.firstOrNull() ?: Size(1280, 720)
            opening = true
            cm.openCamera(id, object : CameraDevice.StateCallback() {
                override fun onOpened(c: CameraDevice) { opening = false; if (bg == null || isFinishing) { c.close(); return }; cam = c; createSession() }
                override fun onDisconnected(c: CameraDevice) { opening = false; c.close(); cam = null }
                override fun onError(c: CameraDevice, error: Int) { opening = false; c.close(); cam = null; runOnUiThread { hint.text = t("Não foi possível abrir a câmera (erro $error). Feche outros apps que usam a câmera.", "Could not open the camera (error $error). Close other apps using the camera.") } }
            }, bg)
        } catch (e: SecurityException) { opening = false; noPermission()
        } catch (e: Exception) { opening = false; hint.text = t("Câmera indisponível: ", "Camera unavailable: ") + (e.message ?: "") }
    }

    private fun createSession() {
        val c = cam ?: return
        val st = texture.surfaceTexture ?: return
        st.setDefaultBufferSize(previewSize.width, previewSize.height)
        runOnUiThread { fitPreview() }
        val preview = Surface(st)
        val ir = ImageReader.newInstance(previewSize.width, previewSize.height, ImageFormat.YUV_420_888, 2); reader = ir
        ir.setOnImageAvailableListener({ r -> onFrame(r) }, bg)
        try {
            val b = c.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW)
            b.addTarget(preview); b.addTarget(ir.surface)
            b.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE)
            b.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_ON)
            b.set(CaptureRequest.FLASH_MODE, if (torch) CaptureRequest.FLASH_MODE_TORCH else CaptureRequest.FLASH_MODE_OFF)
            reqBuilder = b
            @Suppress("DEPRECATION")
            c.createCaptureSession(listOf(preview, ir.surface), object : CameraCaptureSession.StateCallback() {
                override fun onConfigured(s: CameraCaptureSession) {
                    if (cam == null) return
                    session = s
                    try { s.setRepeatingRequest(b.build(), null, bg) } catch (ignored: Exception) { }
                }
                override fun onConfigureFailed(s: CameraCaptureSession) { runOnUiThread { hint.text = t("A câmera não iniciou. Tente de novo.", "The camera did not start. Try again.") } }
            }, bg)
        } catch (e: Exception) { runOnUiThread { hint.text = t("Câmera indisponível: ", "Camera unavailable: ") + (e.message ?: "") } }
    }

    private fun setTorch(on: Boolean) {
        if (!hasFlash) return
        torch = on
        torchBtn.background = AppUi.round(if (on) Color.argb(220, 255, 214, 10) else Color.argb(110, 0, 0, 0), dp(24).toFloat())
        val b = reqBuilder ?: return; val s = session ?: return
        try { b.set(CaptureRequest.FLASH_MODE, if (on) CaptureRequest.FLASH_MODE_TORCH else CaptureRequest.FLASH_MODE_OFF); s.setRepeatingRequest(b.build(), null, bg) } catch (ignored: Exception) { }
    }

    /** imagem cheia na tela sem distorcer (corta as sobras); a tela é sempre em pé */
    private fun fitPreview() {
        val vw = texture.width.toFloat(); val vh = texture.height.toFloat()
        if (vw <= 0 || vh <= 0) return
        val sensorLandscape = sensorOrientation == 90 || sensorOrientation == 270
        val bw = if (sensorLandscape) previewSize.height.toFloat() else previewSize.width.toFloat()
        val bh = if (sensorLandscape) previewSize.width.toFloat() else previewSize.height.toFloat()
        val s = maxOf(vw / bw, vh / bh)
        val m = Matrix(); m.setScale(bw * s / vw, bh * s / vh, vw / 2f, vh / 2f)
        texture.setTransform(m)
    }

    private fun onFrame(r: ImageReader) {
        val img = try { r.acquireLatestImage() } catch (e: Exception) { null } ?: return
        try {
            if (done.get() || busy.get()) return
            val now = SystemClock.elapsedRealtime(); if (now - lastTry < 120) return
            lastTry = now; busy.set(true)
            val plane = img.planes[0]; val w = img.width; val h = img.height
            val buf = plane.buffer; val rs = plane.rowStride; val ps = plane.pixelStride
            val y = ByteArray(w * h)
            if (ps == 1 && rs == w) { buf.position(0); buf.get(y, 0, minOf(y.size, buf.remaining())) }
            else { val row = ByteArray(rs); for (j in 0 until h) { buf.position(j * rs); val n = minOf(rs, buf.remaining()); buf.get(row, 0, n); if (ps == 1) System.arraycopy(row, 0, y, j * w, minOf(w, n)) else for (i in 0 until w) y[j * w + i] = row[minOf(i * ps, n - 1)] } }
            img.close()
            // primeiro a região central (o visor), depois a imagem inteira
            val side = (minOf(w, h) * 0.8).toInt(); val left = (w - side) / 2; val top = (h - side) / 2
            val txt = try { QrScan.decode(PlanarYUVLuminanceSource(y, w, h, left, top, side, side, false)) } catch (e: Exception) { null }
                ?: try { QrScan.decode(PlanarYUVLuminanceSource(y, w, h, 0, 0, w, h, false)) } catch (e: Exception) { null }
            if (!txt.isNullOrBlank()) finishWith(txt.trim())
        } finally {
            try { img.close() } catch (ignored: Exception) { }
            busy.set(false)
        }
    }

    private fun closeCamera() {
        try { session?.close() } catch (ignored: Exception) { }; session = null
        try { cam?.close() } catch (ignored: Exception) { }; cam = null
        try { reader?.close() } catch (ignored: Exception) { }; reader = null
        torch = false; opening = false
    }

    private fun noPermission() {
        hint.text = t("O Coin Bank precisa da câmera para ler o QR Code. Toque aqui para permitir.", "Coin Bank needs the camera to read QR codes. Tap here to allow.")
        hint.setOnClickListener {
            if (Build.VERSION.SDK_INT >= 23 && shouldShowRequestPermissionRationale(Manifest.permission.CAMERA)) requestPermissions(arrayOf(Manifest.permission.CAMERA), REQ_CAM)
            else try { startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))) } catch (ignored: Exception) { }
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_CAM) { if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) { hint.setOnClickListener(null); startCamera() } else noPermission() }
    }

    // ───────── colar / galeria ─────────
    private fun paste() {
        val txt = try { (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).primaryClip?.let { c -> if (c.itemCount > 0) c.getItemAt(0).coerceToText(this)?.toString() else null } } catch (e: Exception) { null }
        if (txt.isNullOrBlank()) { hint.text = t("A área de transferência está vazia. Copie o código da cobrança e toque de novo.", "The clipboard is empty. Copy the request code and tap again."); return }
        finishWith(txt.trim())
    }

    private fun gallery() {
        try { startActivityForResult(Intent(Intent.ACTION_GET_CONTENT).setType("image/*").addCategory(Intent.CATEGORY_OPENABLE), REQ_IMG) }
        catch (e: Exception) { hint.text = t("Nenhum app de galeria disponível.", "No gallery app available.") }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        @Suppress("DEPRECATION") super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_IMG || resultCode != RESULT_OK) return
        val u = data?.data ?: return
        hint.text = t("Lendo a imagem…", "Reading the image…")
        Thread {
            val txt = try { QrScan.decodeImage(this, u) } catch (e: Exception) { null }
            runOnUiThread { if (txt.isNullOrBlank()) hint.text = t("Nenhum QR Code encontrado nesta imagem.", "No QR code found in this image.") else finishWith(txt.trim()) }
        }.start()
    }
}

/** Visor: escurece em volta, cantos arredondados e linha de leitura animada. */
class ScanFrameView(ctx: Context) : View(ctx) {
    private val dim = Paint().apply { color = Color.argb(140, 0, 0, 0) }
    private val corner = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; style = Paint.Style.STROKE; strokeWidth = AppUi.dp(ctx, 4).toFloat(); strokeCap = Paint.Cap.ROUND }
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#D6A94B"); strokeWidth = AppUi.dp(ctx, 2).toFloat() }
    private val okPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#22C55E"); style = Paint.Style.STROKE; strokeWidth = AppUi.dp(ctx, 5).toFloat() }
    var found = false
    private val start = SystemClock.uptimeMillis()

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val w = width.toFloat(); val h = height.toFloat()
        val side = minOf(w, h) * 0.68f
        val l = (w - side) / 2f; val t = (h - side) / 2f - h * 0.04f; val r = l + side; val b = t + side
        val rad = AppUi.dp(context, 22).toFloat()
        val hole = Path().apply { addRoundRect(RectF(l, t, r, b), rad, rad, Path.Direction.CW); fillType = Path.FillType.INVERSE_WINDING }
        c.drawPath(hole, dim)
        if (found) { c.drawRoundRect(RectF(l, t, r, b), rad, rad, okPaint); return }
        val len = side * 0.16f
        val p = Path()
        p.moveTo(l, t + len); p.lineTo(l, t + rad); p.quadTo(l, t, l + rad, t); p.lineTo(l + len, t)
        p.moveTo(r - len, t); p.lineTo(r - rad, t); p.quadTo(r, t, r, t + rad); p.lineTo(r, t + len)
        p.moveTo(r, b - len); p.lineTo(r, b - rad); p.quadTo(r, b, r - rad, b); p.lineTo(r - len, b)
        p.moveTo(l + len, b); p.lineTo(l + rad, b); p.quadTo(l, b, l, b - rad); p.lineTo(l, b - len)
        c.drawPath(p, corner)
        val f = ((SystemClock.uptimeMillis() - start) % 2200L) / 2200f
        val y = t + side * 0.08f + (side * 0.84f) * (if (f < 0.5f) f * 2f else (1f - f) * 2f)
        c.drawLine(l + side * 0.08f, y, r - side * 0.08f, y, line)
        postInvalidateOnAnimation()
    }
}
