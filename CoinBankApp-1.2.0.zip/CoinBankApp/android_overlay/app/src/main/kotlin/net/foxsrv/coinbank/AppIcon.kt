package net.foxsrv.coinbank

import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Rect
import android.net.Uri
import android.util.Base64
import java.io.ByteArrayOutputStream

/**
 * Ícones: do app na tela inicial (activity-alias: carteira com moedas, moeda, carteira) e das moedas de cada rede
 * (PNG 128×128 em base64 escolhido pelo usuário; padrão: carteira na rede principal, moedinha nas outras).
 */
object AppIcon {
    private val ALIASES = linkedMapOf("default" to ".LauncherDefault", "coin" to ".LauncherCoin", "wallet" to ".LauncherWallet")

    private fun cn(ctx: Context, alias: String) = ComponentName(ctx.packageName, ctx.packageName + alias)

    fun current(ctx: Context): String {
        val pm = ctx.packageManager
        for ((name, alias) in ALIASES) {
            val st = try { pm.getComponentEnabledSetting(cn(ctx, alias)) } catch (e: Exception) { PackageManager.COMPONENT_ENABLED_STATE_DEFAULT }
            if (st == PackageManager.COMPONENT_ENABLED_STATE_ENABLED) return name
        }
        return "default"
    }

    /** troca o ícone da tela inicial (o Android pode levar alguns segundos e alguns launchers fecham o app) */
    fun set(ctx: Context, name: String) {
        val pm = ctx.packageManager
        val want = ALIASES[name] ?: ALIASES.getValue("default")
        // liga o novo antes de desligar os outros, para o app nunca ficar sem ícone
        pm.setComponentEnabledSetting(cn(ctx, want), PackageManager.COMPONENT_ENABLED_STATE_ENABLED, PackageManager.DONT_KILL_APP)
        for ((_, alias) in ALIASES) {
            if (alias == want) continue
            val st = if (alias == ALIASES.getValue("default")) PackageManager.COMPONENT_ENABLED_STATE_DISABLED else PackageManager.COMPONENT_ENABLED_STATE_DEFAULT
            pm.setComponentEnabledSetting(cn(ctx, alias), st, PackageManager.DONT_KILL_APP)
        }
    }

    /** imagem escolhida na galeria → PNG quadrado 128×128 em base64 */
    fun toBase64(ctx: Context, uri: Uri): String {
        val bytes = ctx.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: throw IllegalStateException("read")
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }; BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o)
        var sample = 1; while (o.outWidth / sample > 1024 || o.outHeight / sample > 1024) sample *= 2
        val src = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = sample }) ?: throw IllegalStateException("decode")
        val side = minOf(src.width, src.height)
        val out = Bitmap.createBitmap(128, 128, Bitmap.Config.ARGB_8888)
        Canvas(out).drawBitmap(src, Rect((src.width - side) / 2, (src.height - side) / 2, (src.width + side) / 2, (src.height + side) / 2), Rect(0, 0, 128, 128), Paint(Paint.FILTER_BITMAP_FLAG))
        val bo = ByteArrayOutputStream(); out.compress(Bitmap.CompressFormat.PNG, 100, bo)
        return Base64.encodeToString(bo.toByteArray(), Base64.NO_WRAP)
    }

    fun decode(b64: String): Bitmap? = try { val b = Base64.decode(b64, Base64.DEFAULT); BitmapFactory.decodeByteArray(b, 0, b.size) } catch (e: Exception) { null }

    /** ícone grande da notificação de cada rede */
    fun large(ctx: Context, serverId: String): Bitmap? {
        val icon = Store.netCfg(serverId).optString("icon")
        if (icon.isNotEmpty()) decode(icon)?.let { return it }
        return try { BitmapFactory.decodeResource(ctx.resources, if (serverId == Store.MAIN_ID) R.drawable.large_wallet else R.drawable.large_coin) } catch (e: Exception) { null }
    }
}
