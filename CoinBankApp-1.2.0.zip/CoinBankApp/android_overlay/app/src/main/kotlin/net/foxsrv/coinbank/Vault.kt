package net.foxsrv.coinbank

import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * Cofre do aparelho: AES-256-GCM com chave gerada e guardada no Android Keystore (não sai do aparelho,
 * não vai para backup). Usado para a senha das contas salvas — entrar com a digital e renovar a sessão de 24 h.
 */
object Vault {
    private const val ALIAS = "coinbank_vault_v1"

    private fun key(): SecretKey? = try {
        val ks = KeyStore.getInstance("AndroidKeyStore"); ks.load(null)
        (ks.getKey(ALIAS, null) as? SecretKey) ?: run {
            val g = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
            g.init(KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256).build())
            g.generateKey()
        }
    } catch (e: Exception) { null }

    fun encrypt(plain: String): String? = try {
        val k = key() ?: throw IllegalStateException("keystore")
        val c = Cipher.getInstance("AES/GCM/NoPadding"); c.init(Cipher.ENCRYPT_MODE, k)
        val iv = c.iv; val ct = c.doFinal(plain.toByteArray(Charsets.UTF_8))
        Base64.encodeToString(iv + ct, Base64.NO_WRAP)
    } catch (e: Exception) { null }

    fun decrypt(enc: String): String? = try {
        val k = key() ?: throw IllegalStateException("keystore")
        val all = Base64.decode(enc, Base64.NO_WRAP)
        if (all.size < 13) throw IllegalArgumentException("short")
        val c = Cipher.getInstance("AES/GCM/NoPadding"); c.init(Cipher.DECRYPT_MODE, k, GCMParameterSpec(128, all.copyOfRange(0, 12)))
        String(c.doFinal(all.copyOfRange(12, all.size)), Charsets.UTF_8)
    } catch (e: Exception) { null }
}
