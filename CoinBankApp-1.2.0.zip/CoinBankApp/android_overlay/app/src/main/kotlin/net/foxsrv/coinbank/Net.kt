package net.foxsrv.coinbank

import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL

/** Erro da API ({error: CODE}) ou de rede (error = "network"). */
class ApiError(val error: String, val status: Int, val body: JSONObject?) : Exception(error)

/** HTTP simples (HttpURLConnection), sem bibliotecas. */
object Http {
    const val UA = "CoinBankApp/1.0 (Android)"

    class Resp(val status: Int, val body: String, val ms: Long)

    fun request(url: String, method: String, body: String?, headers: Map<String, String> = emptyMap(), timeoutMs: Int = 15_000): Resp {
        val t0 = System.currentTimeMillis()
        val c = try { URL(url).openConnection() as HttpURLConnection } catch (e: Exception) { throw ApiError("invalid_url", 0, null) }
        try {
            c.requestMethod = method
            c.connectTimeout = minOf(timeoutMs, 12_000); c.readTimeout = timeoutMs
            c.useCaches = false; c.instanceFollowRedirects = true
            c.setRequestProperty("User-Agent", UA)
            c.setRequestProperty("Accept", "application/json")
            for ((k, v) in headers) c.setRequestProperty(k, v)
            if (body != null && method != "GET") {
                val b = body.toByteArray(Charsets.UTF_8)
                c.doOutput = true
                c.setRequestProperty("Content-Type", "application/json; charset=utf-8")
                c.setFixedLengthStreamingMode(b.size)
                c.outputStream.use { it.write(b) }
            }
            val code = c.responseCode
            val stream: InputStream? = if (code >= 400) c.errorStream else c.inputStream
            val text = stream?.use { readAll(it) } ?: ""
            return Resp(code, text, System.currentTimeMillis() - t0)
        } catch (e: ApiError) { throw e
        } catch (e: Exception) { throw ApiError("network", 0, JSONObject().put("detail", e.javaClass.simpleName + ": " + (e.message ?: "")))
        } finally { try { c.disconnect() } catch (ignored: Exception) { } }
    }

    private fun readAll(i: InputStream): String {
        val out = ByteArrayOutputStream(); val buf = ByteArray(16384)
        var total = 0
        while (true) { val n = i.read(buf); if (n < 0) break; out.write(buf, 0, n); total += n; if (total > 8 * 1024 * 1024) break }
        return String(out.toByteArray(), Charsets.UTF_8)
    }

    fun parse(s: String): JSONObject = try {
        val t = s.trim()
        if (t.startsWith("{")) JSONObject(t) else if (t.startsWith("[")) JSONObject().put("items", org.json.JSONArray(t)) else JSONObject().put("text", t.take(400))
    } catch (e: Exception) { JSONObject().put("text", s.take(400)) }
}

/**
 * Chamadas à API de uma rede (principal, adicionada ou hospedada) com a sessão guardada.
 * Sessão expirada (401) + conta salva neste aparelho → entra de novo sozinho e repete o pedido.
 */
object Api {
    class Out(val status: Int, val body: String, val ms: Long)

    private fun base(serverId: String): String = Store.serverUrl(serverId) ?: throw ApiError("server_not_found", 0, null)

    fun raw(serverId: String, method: String, path: String, body: String?, auth: Boolean = true, timeoutMs: Int = 15_000): Out {
        val url = base(serverId) + (if (path.startsWith("/")) path else "/$path")
        val s = if (auth) Store.session(serverId) else null
        val h = HashMap<String, String>()
        if (s != null) h["Authorization"] = "Bearer " + s.optString("token")
        var r = Http.request(url, method, body, h, timeoutMs)
        // a API principal responde 403 {error:'operation failed'} para sessão inválida; a hospedada, 401
        if (s != null && (r.status == 401 || (r.status == 403 && r.body.contains("operation failed")))) {
            // sessão de 24 h venceu: renova com a conta salva (se houver) e tenta mais uma vez
            if (relogin(serverId)) {
                val s2 = Store.session(serverId)
                if (s2 != null) { h["Authorization"] = "Bearer " + s2.optString("token"); r = Http.request(url, method, body, h, timeoutMs) }
            } else {
                Store.clearSession(serverId)
                Events.emit(JSONObject().put("type", "session").put("server", serverId).put("expired", true))
            }
        }
        return Out(r.status, r.body, r.ms)
    }

    fun json(serverId: String, method: String, path: String, body: JSONObject? = null, auth: Boolean = true): JSONObject {
        val r = raw(serverId, method, path, body?.toString() ?: if (method == "GET") null else "{}", auth)
        val o = Http.parse(r.body)
        if (r.status >= 400 || r.status == 0) throw ApiError(errCode(o, r.status), r.status, o)
        return o
    }

    fun errCode(o: JSONObject, status: Int): String {
        val e = if (o.has("error") && !o.isNull("error")) o.optString("error") else ""
        return e.ifEmpty { "http_$status" }
    }

    /** login: guarda a sessão; remember = guarda a senha cifrada para entrar com a digital e renovar sozinho */
    fun login(serverId: String, username: String, password: String, remember: Boolean, bio: Boolean): JSONObject {
        val r = Http.request(base(serverId) + "/api/login", "POST", JSONObject().put("username", username).put("password", password).toString())
        val o = Http.parse(r.body)
        val token = o.optString("sessionId")
        if (r.status >= 400 && token.isEmpty()) throw ApiError(if (r.status == 429) "IP_LOCKED" else errCode(o, r.status), r.status, o)
        if (!o.optBoolean("sessionCreated", token.isNotEmpty()) || token.isEmpty()) throw ApiError("invalid_credentials", r.status, o)
        val uid = o.optString("userId")
        Store.setSession(serverId, token, uid, username)
        if (remember) Store.saveAccount(base(serverId), username, uid, password, bio)
        return o
    }

    fun register(serverId: String, username: String, password: String, remember: Boolean, bio: Boolean): JSONObject {
        val r = Http.request(base(serverId) + "/api/register", "POST", JSONObject().put("username", username).put("password", password).toString())
        val o = Http.parse(r.body)
        if (r.status >= 400 || !o.optBoolean("success", false)) throw ApiError(errCode(o, r.status), r.status, o)
        val token = o.optString("sessionId"); val uid = o.optString("userId")
        if (token.isNotEmpty()) Store.setSession(serverId, token, uid, username) else login(serverId, username, password, false, false)
        if (remember) Store.saveAccount(base(serverId), username, uid, password, bio)
        return o
    }

    fun logout(serverId: String) {
        try { if (Store.session(serverId) != null) raw(serverId, "POST", "/api/logout", "{}", true, 6_000) } catch (ignored: Exception) { }
        Store.clearSession(serverId)
    }

    @Synchronized
    fun relogin(serverId: String): Boolean {
        val s = Store.session(serverId) ?: return false
        val url = Store.serverUrl(serverId) ?: return false
        val acc = Store.accountFor(url, s.optString("userId")) ?: return false
        val pw = Store.password(acc) ?: return false
        return try { login(serverId, acc.optString("username"), pw, false, false); true } catch (e: Exception) { false }
    }

    /** ping: tempo de resposta do /health (ou /api/health) e se parece uma rede Coin */
    fun ping(url: String): JSONObject {
        val u = Store.cleanUrl(url)
        for (p in listOf("/health", "/api/health", "/api/totalusers")) {
            try {
                val r = Http.request(u + p, "GET", null, emptyMap(), 8_000)
                if (r.status in 200..299) {
                    val o = Http.parse(r.body)
                    return JSONObject().put("ok", true).put("ms", r.ms).put("url", u).put("info", o)
                }
            } catch (e: ApiError) { if (e.error == "invalid_url") return JSONObject().put("ok", false).put("error", "invalid_url") }
        }
        return JSONObject().put("ok", false).put("error", "network").put("url", u)
    }
}
