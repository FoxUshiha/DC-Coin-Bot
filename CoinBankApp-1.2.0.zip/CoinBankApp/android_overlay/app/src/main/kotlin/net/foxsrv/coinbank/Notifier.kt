package net.foxsrv.coinbank

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Build

/** Notificações (sem androidx): canais, aviso de pagamento/cobrança e a notificação fixa do serviço. */
object Notifier {
    const val CH_SERVICE = "coinbank_service"
    const val CH_MONEY = "coinbank_money"
    const val CH_BILLS = "coinbank_bills"
    const val NID_SERVICE = 7101
    const val EXTRA_ROUTE = "coinbank_route"
    @Volatile private var done = false

    fun init(ctx: Context) {
        if (done) return
        done = true
        if (Build.VERSION.SDK_INT < 26) return
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val pt = Store.pt(ctx)
        fun ch(id: String, pt1: String, en: String, imp: Int) {
            val c = NotificationChannel(id, if (pt) pt1 else en, imp)
            c.setShowBadge(imp >= NotificationManager.IMPORTANCE_DEFAULT)
            if (imp >= NotificationManager.IMPORTANCE_DEFAULT) { c.enableLights(true); c.lightColor = Color.parseColor("#D6A94B") }
            nm.createNotificationChannel(c)
        }
        ch(CH_SERVICE, "Coin Bank em segundo plano", "Coin Bank in background", NotificationManager.IMPORTANCE_LOW)
        ch(CH_MONEY, "Pagamentos recebidos", "Payments received", NotificationManager.IMPORTANCE_HIGH)
        ch(CH_BILLS, "Cobranças", "Bills", NotificationManager.IMPORTANCE_DEFAULT)
    }

    fun openIntent(ctx: Context, route: String?, req: Int): PendingIntent {
        val i = Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        if (route != null) i.putExtra(EXTRA_ROUTE, route)
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
        return PendingIntent.getActivity(ctx, req, i, flags)
    }

    @Suppress("DEPRECATION")
    private fun builder(ctx: Context, ch: String): Notification.Builder =
        if (Build.VERSION.SDK_INT >= 26) Notification.Builder(ctx, ch) else Notification.Builder(ctx)

    @Suppress("DEPRECATION")
    fun service(ctx: Context, title: String, text: String): Notification {
        init(ctx)
        val b = builder(ctx, CH_SERVICE).setContentTitle(title).setContentText(text).setSmallIcon(R.drawable.ic_stat_coin)
            .setContentIntent(openIntent(ctx, null, NID_SERVICE)).setOngoing(true).setOnlyAlertOnce(true).setShowWhen(false)
            .setColor(Color.parseColor("#D6A94B")).setStyle(Notification.BigTextStyle().bigText(text))
        if (Build.VERSION.SDK_INT >= 31) b.setForegroundServiceBehavior(Notification.FOREGROUND_SERVICE_IMMEDIATE)
        if (Build.VERSION.SDK_INT < 26) b.setPriority(Notification.PRIORITY_LOW)
        return b.build()
    }

    fun updateService(ctx: Context, title: String, text: String) {
        try { (ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(NID_SERVICE, service(ctx, title, text)) } catch (ignored: Exception) { }
    }

    @Suppress("DEPRECATION")
    fun alert(ctx: Context, id: Int, channel: String, title: String, text: String, route: String?, large: android.graphics.Bitmap? = null) {
        init(ctx)
        try {
            val b = builder(ctx, channel).setContentTitle(title).setContentText(text).setSmallIcon(R.drawable.ic_stat_coin)
                .setContentIntent(openIntent(ctx, route, id)).setAutoCancel(true).setColor(Color.parseColor("#D6A94B"))
                .setStyle(Notification.BigTextStyle().bigText(text))
            if (large != null) b.setLargeIcon(large)
            if (Build.VERSION.SDK_INT < 26) { b.setPriority(if (channel == CH_MONEY) Notification.PRIORITY_HIGH else Notification.PRIORITY_DEFAULT); b.setDefaults(Notification.DEFAULT_ALL) }
            (ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(id, b.build())
        } catch (ignored: Exception) { }
    }

    fun enabled(ctx: Context): Boolean = try {
        if (Build.VERSION.SDK_INT >= 24) (ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).areNotificationsEnabled() else true
    } catch (e: Exception) { true }
}
