package net.foxsrv.coinbank

import android.content.Context
import android.graphics.drawable.GradientDrawable
import android.util.TypedValue

/** Ajudas das telas nativas (leitor de QR, navegador): idioma do app e medidas. */
object AppUi {
    fun t(ctx: Context, pt: String, en: String): String { Store.init(ctx); return Store.t(ctx, pt, en) }
    fun dp(ctx: Context, v: Int): Int = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), ctx.resources.displayMetrics).toInt()
    fun round(color: Int, radius: Float, strokePx: Int = 0, strokeColor: Int = 0): GradientDrawable {
        val g = GradientDrawable(); g.cornerRadius = radius; g.setColor(color)
        if (strokePx > 0) g.setStroke(strokePx, strokeColor)
        return g
    }
}
