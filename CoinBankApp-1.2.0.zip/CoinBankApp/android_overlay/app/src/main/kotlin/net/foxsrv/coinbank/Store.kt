package net.foxsrv.coinbank

import android.content.Context
import android.content.SharedPreferences
import android.content.res.Configuration
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

/**
 * Tudo o que o app guarda no aparelho (SharedPreferences "coinbank"):
 *  • settings  — tema, idioma, casas decimais, notificações, segundo plano, URL da rede principal…
 *  • servers   — lista de redes (principal, adicionadas, a hospedada neste aparelho)
 *  • sessions  — sessão (token) de cada rede
 *  • accounts  — contas salvas (senha cifrada pelo Android Keystore, ver Vault)
 * O Flutter lê e grava pelas chamadas do MainActivity; o serviço em segundo plano lê daqui também.
 */
object Store {
    const val MAIN_ID = "main"
    const val HOST_ID = "host"
    const val DEFAULT_MAIN_URL = "https://bank.foxsrv.net"

    @Volatile private var sp: SharedPreferences? = null
    private val lock = Any()

    fun init(ctx: Context) { if (sp == null) sp = ctx.applicationContext.getSharedPreferences("coinbank", Context.MODE_PRIVATE) }
    private fun p(): SharedPreferences = sp ?: throw IllegalStateException("Store.init")

    private fun obj(key: String): JSONObject = try { JSONObject(p().getString(key, "{}") ?: "{}") } catch (e: Exception) { JSONObject() }
    private fun arr(key: String): JSONArray = try { JSONArray(p().getString(key, "[]") ?: "[]") } catch (e: Exception) { JSONArray() }
    private fun save(key: String, v: Any) { p().edit().putString(key, v.toString()).apply() }

    // ───────────────────────── configurações ─────────────────────────
    private fun defaults(): JSONObject = JSONObject()
        .put("theme", "system").put("lang", "auto").put("decimals", 8).put("hideCard", true)
        .put("notify", true).put("notifyOutgoing", true).put("notifyIncoming", true).put("notifyBills", true).put("notifyPaid", true)
        .put("autoClaim", false).put("background", true).put("battery", "balanced")
        .put("mainUrl", DEFAULT_MAIN_URL).put("visible", false).put("bluetooth", false)
        .put("activeServer", MAIN_ID).put("hideBalance", false).put("onboarded", false)

    fun settings(): JSONObject = synchronized(lock) {
        val d = defaults(); val s = obj("settings")
        val it = s.keys(); while (it.hasNext()) { val k = it.next(); d.put(k, s.get(k)) }
        d
    }

    fun setSettings(patch: JSONObject): JSONObject = synchronized(lock) {
        val s = obj("settings")
        val it = patch.keys(); while (it.hasNext()) { val k = it.next(); s.put(k, patch.get(k)) }
        // URL da rede principal sempre sem barra no fim; vazio volta ao padrão
        if (patch.has("mainUrl")) s.put("mainUrl", cleanUrl(patch.optString("mainUrl")).ifEmpty { DEFAULT_MAIN_URL })
        save("settings", s)
        settings()
    }

    fun bool(k: String): Boolean = settings().optBoolean(k, false)
    fun str(k: String): String = settings().optString(k, "")

    fun pt(ctx: Context): Boolean = when (str("lang")) {
        "pt" -> true
        "en" -> false
        else -> Locale.getDefault().language == "pt"
    }
    fun t(ctx: Context, pt: String, en: String) = if (pt(ctx)) pt else en
    fun dark(ctx: Context): Boolean = when (str("theme")) {
        "dark" -> true
        "light" -> false
        else -> (ctx.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
    }

    /** intervalo da conferência em segundo plano conforme o modo de bateria */
    fun pollMs(): Long = when (str("battery")) {
        "realtime" -> 5_000L
        "saver" -> 60_000L
        else -> 15_000L
    }

    fun cleanUrl(u: String): String {
        var s = u.trim()
        if (s.isEmpty()) return ""
        if (!s.startsWith("http://", true) && !s.startsWith("https://", true)) s = "https://$s"
        while (s.endsWith("/")) s = s.dropLast(1)
        return s
    }

    // ───────────────────────── redes ─────────────────────────
    fun mainUrl(): String = settings().optString("mainUrl", DEFAULT_MAIN_URL).ifEmpty { DEFAULT_MAIN_URL }

    /** principal (fixa) + as adicionadas + a hospedada neste aparelho (quando ligada) */
    fun servers(): JSONArray = synchronized(lock) {
        val out = JSONArray()
        out.put(JSONObject().put("id", MAIN_ID).put("name", "Coin Bank").put("url", mainUrl()).put("kind", "main"))
        val h = HostConfig.get()
        if (h.optBoolean("enabled", false)) {
            out.put(JSONObject().put("id", HOST_ID).put("name", h.optString("name", "Minha rede")).put("url", "http://127.0.0.1:" + h.optInt("port", HostConfig.DEFAULT_PORT)).put("kind", "host"))
        }
        val l = arr("servers")
        for (i in 0 until l.length()) { val o = l.optJSONObject(i) ?: continue; out.put(o) }
        out
    }

    fun server(id: String): JSONObject? {
        val l = servers()
        for (i in 0 until l.length()) { val o = l.getJSONObject(i); if (o.optString("id") == id) return o }
        return null
    }

    fun serverUrl(id: String): String? = server(id)?.optString("url")

    /** procura uma rede pela origem (https://host:porta) */
    fun serverByUrl(url: String): JSONObject? {
        val o = origin(url) ?: return null
        val l = servers()
        for (i in 0 until l.length()) { val s = l.getJSONObject(i); if (origin(s.optString("url")) == o) return s }
        // a rede hospedada neste aparelho também responde pelo IP da rede local e pelo túnel (links/QR que ela gera)
        val h = HostConfig.get()
        if (h.optBoolean("enabled", false)) {
            val port = h.optInt("port", HostConfig.DEFAULT_PORT)
            val alias = listOfNotNull(HostRuntime.tunnel(), HostRuntime.lanIp()?.let { "http://$it:$port" }, "http://localhost:$port")
            if (alias.any { origin(it) == o }) return server(HOST_ID)
        }
        return null
    }

    fun origin(url: String): String? = try {
        val u = java.net.URL(cleanUrl(url))
        val port = if (u.port == -1 || u.port == u.defaultPort) "" else ":" + u.port
        (u.protocol.lowercase() + "://" + u.host.lowercase() + port)
    } catch (e: Exception) { null }

    fun addServer(url: String, name: String): JSONObject = synchronized(lock) {
        val u = cleanUrl(url)
        serverByUrl(u)?.let { return it }
        val o = JSONObject().put("id", "s" + System.currentTimeMillis().toString(36)).put("name", name.ifEmpty { (try { java.net.URL(u).host } catch (e: Exception) { u }) }).put("url", u).put("kind", "custom")
        val l = arr("servers"); l.put(o); save("servers", l)
        o
    }

    fun removeServer(id: String) = synchronized(lock) {
        val l = arr("servers"); val n = JSONArray()
        for (i in 0 until l.length()) { val o = l.optJSONObject(i) ?: continue; if (o.optString("id") != id) n.put(o) }
        save("servers", n)
        clearSession(id)
        if (str("activeServer") == id) setSettings(JSONObject().put("activeServer", MAIN_ID))
    }

    fun renameServer(id: String, name: String) = synchronized(lock) {
        val l = arr("servers")
        for (i in 0 until l.length()) { val o = l.optJSONObject(i) ?: continue; if (o.optString("id") == id) o.put("name", name) }
        save("servers", l)
    }

    fun activeId(): String { val a = str("activeServer"); return if (server(a) != null) a else MAIN_ID }

    // ───────────────────────── moeda de cada rede (casas, nome, ícone) ─────────────────────────
    /**
     * disp = casas exibidas (0..18, escolha do usuário); api = casas que a API da rede usa (principal: sempre 8);
     * coin = nome da moeda; icon = PNG em base64 escolhido pelo usuário ("" = ícone padrão).
     */
    fun netCfg(id: String): JSONObject = synchronized(lock) {
        val all = obj("netcfg"); val c = all.optJSONObject(id) ?: JSONObject()
        val o = JSONObject()
        when (id) {
            MAIN_ID -> o.put("api", 8).put("disp", c.optInt("disp", settings().optInt("decimals", 8))).put("coin", "Coin").put("icon", "")
            HOST_ID -> { val h = HostConfig.get(); o.put("api", h.optInt("decimals", 8)).put("disp", c.optInt("disp", h.optInt("decimals", 8))).put("coin", h.optString("coin", h.optString("name"))).put("icon", h.optString("icon", "")) }
            else -> o.put("api", c.optInt("api", 8)).put("disp", c.optInt("disp", c.optInt("api", 8))).put("coin", c.optString("coin", server(id)?.optString("name") ?: "Coin")).put("icon", c.optString("icon", ""))
        }
        o
    }

    fun setNetCfg(id: String, patch: JSONObject) = synchronized(lock) {
        val all = obj("netcfg"); val c = all.optJSONObject(id) ?: JSONObject()
        if (patch.has("disp")) c.put("disp", patch.optInt("disp", 8).coerceIn(0, 18))
        if (id == HOST_ID) {
            val hp = JSONObject()
            if (patch.has("api")) hp.put("decimals", patch.optInt("api", 8).coerceIn(0, 18))
            if (patch.has("coin")) hp.put("coin", patch.optString("coin").trim().take(24))
            if (patch.has("icon")) hp.put("icon", patch.optString("icon"))
            if (hp.length() > 0) HostConfig.set(hp)
        } else if (id != MAIN_ID) {
            if (patch.has("api")) c.put("api", patch.optInt("api", 8).coerceIn(0, 18))
            if (patch.has("coin")) c.put("coin", patch.optString("coin").trim().take(24))
            if (patch.has("icon")) c.put("icon", patch.optString("icon"))
        }
        all.put(id, c); save("netcfg", all)
        if (id == MAIN_ID && patch.has("disp")) setSettings(JSONObject().put("decimals", c.optInt("disp", 8)))
    }

    fun netCfgAll(): JSONObject {
        val out = JSONObject(); val l = servers()
        for (i in 0 until l.length()) { val id = l.optJSONObject(i)?.optString("id") ?: continue; out.put(id, netCfg(id)) }
        return out
    }

    // ───────────────────────── sessões ─────────────────────────
    fun session(id: String): JSONObject? = obj("sessions").optJSONObject(id)?.takeIf { it.optString("token").isNotEmpty() }

    fun setSession(id: String, token: String, userId: String, username: String) = synchronized(lock) {
        val s = obj("sessions")
        s.put(id, JSONObject().put("token", token).put("userId", userId).put("username", username).put("at", System.currentTimeMillis()))
        save("sessions", s)
    }

    fun clearSession(id: String) = synchronized(lock) { val s = obj("sessions"); s.remove(id); save("sessions", s) }

    /** sessões sem o token (o Flutter só precisa saber quem está logado em cada rede) */
    fun publicSessions(): JSONObject {
        val s = obj("sessions"); val out = JSONObject()
        val it = s.keys(); while (it.hasNext()) { val k = it.next(); val o = s.optJSONObject(k) ?: continue; out.put(k, JSONObject().put("userId", o.optString("userId")).put("username", o.optString("username"))) }
        return out
    }

    // ───────────────────────── contas salvas (entrar com a digital) ─────────────────────────
    fun accounts(): JSONArray = arr("accounts")

    fun publicAccounts(): JSONArray {
        val l = accounts(); val out = JSONArray()
        for (i in 0 until l.length()) {
            val o = l.optJSONObject(i) ?: continue
            out.put(JSONObject().put("id", o.optString("id")).put("server", o.optString("server")).put("username", o.optString("username")).put("userId", o.optString("userId")).put("bio", o.optBoolean("bio", true)))
        }
        return out
    }

    fun account(id: String): JSONObject? {
        val l = accounts()
        for (i in 0 until l.length()) { val o = l.optJSONObject(i) ?: continue; if (o.optString("id") == id) return o }
        return null
    }

    /** conta salva desta rede e usuário (para renovar a sessão sozinho quando ela expira em 24 h) */
    fun accountFor(serverUrl: String, userId: String): JSONObject? {
        val o = origin(serverUrl) ?: return null
        val l = accounts()
        for (i in 0 until l.length()) { val a = l.optJSONObject(i) ?: continue; if (origin(a.optString("server")) == o && a.optString("userId") == userId) return a }
        return null
    }

    fun saveAccount(serverUrl: String, username: String, userId: String, password: String, bio: Boolean) = synchronized(lock) {
        val enc = Vault.encrypt(password) ?: return@synchronized
        val l = accounts(); val n = JSONArray()
        val o = origin(serverUrl) ?: serverUrl
        for (i in 0 until l.length()) {
            val a = l.optJSONObject(i) ?: continue
            if (origin(a.optString("server")) == o && a.optString("username").equals(username, true)) continue
            n.put(a)
        }
        n.put(JSONObject().put("id", "a" + System.currentTimeMillis().toString(36)).put("server", serverUrl).put("username", username).put("userId", userId).put("enc", enc).put("bio", bio))
        save("accounts", n)
    }

    fun removeAccount(id: String) = synchronized(lock) {
        val l = accounts(); val n = JSONArray()
        for (i in 0 until l.length()) { val a = l.optJSONObject(i) ?: continue; if (a.optString("id") != id) n.put(a) }
        save("accounts", n)
    }

    fun password(acc: JSONObject): String? = Vault.decrypt(acc.optString("enc"))

    // ───────────────────────── estado do vigia de notificações ─────────────────────────
    fun watch(): JSONObject = obj("watch")
    fun setWatch(o: JSONObject) = save("watch", o)

    fun kv(key: String, def: String = ""): String = p().getString("kv_$key", def) ?: def
    fun setKv(key: String, v: String) = p().edit().putString("kv_$key", v).apply()
}

/** Configuração da rede hospedada neste aparelho (moeda própria). */
object HostConfig {
    const val DEFAULT_PORT = 26450
    @Volatile private var sp: SharedPreferences? = null
    fun init(ctx: Context) { if (sp == null) sp = ctx.applicationContext.getSharedPreferences("coinbank_host", Context.MODE_PRIVATE) }

    private fun defaults(): JSONObject = JSONObject()
        .put("enabled", false).put("name", "Minha Coin").put("port", DEFAULT_PORT)
        .put("claimSats", 12L).put("cooldownMs", 3_600_000L).put("cloudflare", false)
        .put("openRegister", true).put("maxUsers", 1000).put("lan", true).put("wakeLock", false)
        .put("decimals", 8).put("coin", "").put("icon", "")

    fun get(): JSONObject {
        val d = defaults()
        val s = try { JSONObject(sp?.getString("cfg", "{}") ?: "{}") } catch (e: Exception) { JSONObject() }
        val it = s.keys(); while (it.hasNext()) { val k = it.next(); d.put(k, s.get(k)) }
        return d
    }

    fun set(patch: JSONObject): JSONObject {
        val s = try { JSONObject(sp?.getString("cfg", "{}") ?: "{}") } catch (e: Exception) { JSONObject() }
        val it = patch.keys(); while (it.hasNext()) { val k = it.next(); s.put(k, patch.get(k)) }
        // limites sãos
        if (s.has("port")) s.put("port", s.optInt("port", DEFAULT_PORT).coerceIn(1024, 65535))
        if (s.has("claimSats")) s.put("claimSats", s.optLong("claimSats", 12L).coerceIn(1L, 100_000_000_000L))
        if (s.has("cooldownMs")) s.put("cooldownMs", s.optLong("cooldownMs", 3_600_000L).coerceIn(60_000L, 7L * 86_400_000L))
        if (s.has("name")) s.put("name", s.optString("name").trim().take(40).ifEmpty { "Minha Coin" })
        sp?.edit()?.putString("cfg", s.toString())?.apply()
        return get()
    }
}
