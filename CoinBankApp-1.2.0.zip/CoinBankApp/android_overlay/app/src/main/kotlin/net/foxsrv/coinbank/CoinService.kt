package net.foxsrv.coinbank

import android.annotation.SuppressLint
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Serviço em primeiro plano (notificação fixa) que mantém o Coin Bank vivo em segundo plano:
 *  • confere a rede PRINCIPAL a cada N s (modo de bateria) e avisa pagamentos recebidos, cobranças novas e cobranças pagas;
 *  • resgate automático a cada hora (quando ligado);
 *  • mantém a rede hospedada neste aparelho (servidor local + túnel Cloudflare) e o anúncio para quem está perto.
 */
class CoinService : Service() {
    companion object {
        @Volatile var running = false
        @Volatile private var loopThread: Thread? = null
        @Volatile var lastCheck = 0L
        @Volatile var lastClaim = 0L

        /** precisa ficar ligado? (segundo plano + avisos/resgate, ou rede hospedada, ou visível para quem está perto) */
        fun wanted(ctx: Context): Boolean {
            val s = Store.settings()
            val anySession = Store.publicSessions().length() > 0
            val bg = s.optBoolean("background", true) && anySession && (s.optBoolean("notify", true) || s.optBoolean("autoClaim", false))
            return bg || HostConfig.get().optBoolean("enabled", false) || (s.optBoolean("visible", false) && s.optBoolean("background", true))
        }

        fun sync(ctx: Context) {
            Store.init(ctx); HostConfig.init(ctx)
            if (wanted(ctx)) start(ctx) else stop(ctx)
        }

        fun start(ctx: Context) {
            val i = Intent(ctx, CoinService::class.java)
            try { if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i) else ctx.startService(i) } catch (ignored: Exception) { }
        }

        fun stop(ctx: Context) {
            if (!running) return
            try { ctx.stopService(Intent(ctx, CoinService::class.java)) } catch (ignored: Exception) { }
        }
    }

    private var wake: PowerManager.WakeLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        Store.init(this); HostConfig.init(this); Notifier.init(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val n = Notifier.service(this, Store.t(this, "Coin Bank ativo", "Coin Bank active"), summary())
        try {
            when {
                Build.VERSION.SDK_INT >= 34 -> startForeground(Notifier.NID_SERVICE, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
                Build.VERSION.SDK_INT >= 29 -> startForeground(Notifier.NID_SERVICE, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
                else -> startForeground(Notifier.NID_SERVICE, n)
            }
        } catch (e: Exception) { stopSelf(); return START_NOT_STICKY }
        running = true
        if (loopThread?.isAlive != true) {
            loopThread = Thread({ loop() }, "coinbank-service").also { it.isDaemon = true; it.start() }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        running = false
        try { loopThread?.interrupt() } catch (ignored: Exception) { }
        loopThread = null
        HostRuntime.stop(this)
        if (!Events.foreground) Nearby.stop()
        releaseWake()
        super.onDestroy()
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        // o app foi tirado da lista de recentes: o serviço continua (é para isso que ele existe)
        super.onTaskRemoved(rootIntent)
    }

    private fun loop() {
        var lastSummary = ""
        while (running) {
            try {
                if (!wanted(this)) { running = false; stopSelf(); break }
                HostRuntime.sync(this)
                Nearby.syncBackground(this)
                holdWake(HostConfig.get().optBoolean("enabled", false) && HostConfig.get().optBoolean("wakeLock", false))
                val s = Store.settings()
                if (s.optBoolean("notify", true) && s.optBoolean("background", true)) {
                    try { Watcher.check(this); lastCheck = System.currentTimeMillis() } catch (ignored: Exception) { }
                }
                if (s.optBoolean("autoClaim", false)) AutoClaim.tick(this)
                val sm = summary()
                if (sm != lastSummary) { lastSummary = sm; Notifier.updateService(this, Store.t(this, "Coin Bank ativo", "Coin Bank active"), sm) }
            } catch (ignored: Exception) { }
            try { Thread.sleep(Store.pollMs()) } catch (e: InterruptedException) { break }
        }
    }

    private fun summary(): String {
        val parts = ArrayList<String>()
        val s = Store.settings()
        if (s.optBoolean("notify", true)) {
            parts.add(Store.t(this, "Avisos ligados (a cada ${Store.pollMs() / 1000} s)", "Alerts on (every ${Store.pollMs() / 1000} s)"))
        }
        if (s.optBoolean("autoClaim", false)) {
            val at = if (lastClaim > 0) SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(lastClaim)) else "—"
            parts.add(Store.t(this, "Resgate automático (último: $at)", "Auto-claim (last: $at)"))
        }
        val h = HostConfig.get()
        if (h.optBoolean("enabled", false)) {
            val st = HostRuntime.status(this)
            val pub = st.optJSONObject("tunnel")?.optString("url").orEmpty()
            parts.add(Store.t(this, "Hospedando \"${h.optString("name")}\" (${st.optInt("users")} usuários)", "Hosting \"${h.optString("name")}\" (${st.optInt("users")} users)") + if (pub.isNotEmpty()) " · Cloudflare" else "")
        }
        if (s.optBoolean("visible", false)) parts.add(Store.t(this, "Visível para quem está perto", "Visible to people nearby"))
        return if (parts.isEmpty()) Store.t(this, "Conectado", "Connected") else parts.joinToString(" · ")
    }

    @SuppressLint("WakelockTimeout")
    private fun holdWake(on: Boolean) {
        if (on) {
            if (wake?.isHeld == true) return
            try { wake = (getSystemService(Context.POWER_SERVICE) as PowerManager).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "coinbank:host").also { it.acquire() } } catch (ignored: Exception) { }
        } else releaseWake()
    }

    private fun releaseWake() { try { if (wake?.isHeld == true) wake?.release() } catch (ignored: Exception) { }; wake = null }
}

/** Liga o serviço de novo depois de reiniciar o celular ou atualizar o app. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val a = intent.action ?: return
        if (a == Intent.ACTION_BOOT_COMPLETED || a == Intent.ACTION_MY_PACKAGE_REPLACED) {
            try { CoinService.sync(ctx) } catch (ignored: Exception) { }
        }
    }
}

/**
 * Conferência de TODAS as redes em que há sessão (principal, adicionadas e a hospedada): avisa pagamentos recebidos,
 * transferências enviadas, cobranças novas e cobranças pagas. A notificação diz de qual rede é e usa o ícone da moeda.
 * Guarda o que já foi visto por rede: na primeira conferência de uma conta nada é avisado.
 */
object Watcher {
    private const val SYSTEM_ID = "000000000000"
    private val lock = Any()

    fun check(ctx: Context) = synchronized(lock) {
        val l = Store.servers()
        for (i in 0 until l.length()) {
            val sid = l.optJSONObject(i)?.optString("id") ?: continue
            if (Store.session(sid) == null) continue
            try { checkOne(ctx, sid) } catch (ignored: Exception) { }
        }
    }

    private fun checkOne(ctx: Context, sid: String) {
        val s = Store.session(sid) ?: return
        val me = s.optString("userId")
        if (me.isEmpty()) return
        val set = Store.settings()
        val nc = Store.netCfg(sid)
        val apiDec = nc.optInt("api", 8); val dec = nc.optInt("disp", 8); val pt = Store.pt(ctx)
        val coin = nc.optString("coin", "Coin").ifEmpty { "Coin" }.let { if (it.equals("coin", true)) "coins" else it }
        val net = Store.server(sid)?.optString("name").orEmpty().ifEmpty { "Coin" }
        val icon = AppIcon.large(ctx, sid)
        val txs = Api.json(sid, "GET", "/api/transactions?page=1").optJSONArray("transactions") ?: JSONArray()
        val bills = try { Api.json(sid, "POST", "/api/bill/list", JSONObject().put("page", 1)) } catch (e: Exception) { null }
        val w = try { JSONObject(Store.kv("watch_$sid", "{}")) } catch (e: Exception) { JSONObject() }
        val first = w.optString("user") != me
        val seen = HashSet<String>(); w.optJSONArray("tx")?.let { for (i in 0 until it.length()) seen.add(it.optString(i)) }
        val oldPay = HashSet<String>(); w.optJSONArray("pay")?.let { for (i in 0 until it.length()) oldPay.add(it.optString(i)) }
        val oldRecv = HashMap<String, Long>(); w.optJSONObject("recv")?.let { o -> val it = o.keys(); while (it.hasNext()) { val k = it.next(); oldRecv[k] = o.optLong(k) } }
        var changed = false
        val newSeen = JSONArray()
        val foot = Store.t(ctx, "Rede: $net", "Network: $net")
        for (i in 0 until txs.length()) {
            val t = txs.optJSONObject(i) ?: continue
            val id = t.optString("id"); if (id.isEmpty()) continue
            newSeen.put(id)
            if (first || seen.contains(id)) continue
            changed = true
            val to = t.optString("to_id"); val from = t.optString("from_id")
            if (from == SYSTEM_ID || from == to) continue
            val amt = Coin.format(Coin.satsOf(t, "amountSats", "amount", apiDec), dec, pt)
            val route = "tx:$id@$sid"
            if (to == me) {
                if (oldRecv.containsKey(id)) {
                    if (set.optBoolean("notifyPaid", true)) say(ctx, sid, "paid", (sid + id).hashCode(), Notifier.CH_MONEY,
                        Store.t(ctx, "Cobrança paga ✅", "Bill paid ✅"), Store.t(ctx, "$from pagou sua cobrança de $amt $coin.\n$foot", "$from paid your bill of $amt $coin.\n$foot"), route, icon)
                } else if (set.optBoolean("notifyIncoming", true)) {
                    say(ctx, sid, "incoming", (sid + id).hashCode(), Notifier.CH_MONEY,
                        Store.t(ctx, "Você recebeu $amt $coin", "You received $amt $coin"), Store.t(ctx, "De $from · toque para ver o comprovante\n$foot", "From $from · tap to see the receipt\n$foot"), route, icon)
                }
            } else if (from == me && set.optBoolean("notifyOutgoing", true)) {
                say(ctx, sid, "outgoing", (sid + id).hashCode(), Notifier.CH_MONEY,
                    Store.t(ctx, "Você enviou $amt $coin", "You sent $amt $coin"), Store.t(ctx, "Para $to · toque para ver o comprovante\n$foot", "To $to · tap to see the receipt\n$foot"), route, icon)
            }
        }
        for (x in seen) { if (newSeen.length() >= 200) break; var dup = false; for (j in 0 until newSeen.length()) if (newSeen.optString(j) == x) { dup = true; break }; if (!dup) newSeen.put(x) }
        val pay = JSONArray(); val recv = JSONObject()
        if (bills != null) {
            val tp = bills.optJSONArray("toPay") ?: JSONArray()
            for (i in 0 until tp.length()) {
                val b = tp.optJSONObject(i) ?: continue
                val id = b.optString("id"); if (id.isEmpty()) continue
                pay.put(id)
                if (!first && !oldPay.contains(id)) {
                    changed = true
                    if (set.optBoolean("notifyBills", true)) {
                        val amt = Coin.format(Coin.satsOf(b, "amountSats", "amount", apiDec), dec, pt)
                        say(ctx, sid, "bill", (sid + id).hashCode(), Notifier.CH_BILLS, Store.t(ctx, "Nova cobrança: $amt $coin", "New bill: $amt $coin"),
                            Store.t(ctx, "${b.optString("to_id")} está cobrando você. Toque para pagar.\n$foot", "${b.optString("to_id")} is billing you. Tap to pay.\n$foot"), "bill:$id@$sid", icon)
                    }
                }
            }
            val tr = bills.optJSONArray("toReceive") ?: JSONArray()
            for (i in 0 until tr.length()) { val b = tr.optJSONObject(i) ?: continue; val id = b.optString("id"); if (id.isNotEmpty()) recv.put(id, Coin.satsOf(b, "amountSats", "amount", apiDec)) }
            if (!first && recv.length() != oldRecv.size) changed = true
        } else {
            for (x in oldPay) pay.put(x)
            for ((k, v) in oldRecv) recv.put(k, v)
        }
        Store.setKv("watch_$sid", JSONObject().put("user", me).put("tx", newSeen).put("pay", pay).put("recv", recv).put("at", System.currentTimeMillis()).toString())
        if (changed) Events.emit(JSONObject().put("type", "refresh").put("server", sid))
    }

    /** app aberto → banner dentro do app; fechado → notificação do Android (com o ícone da moeda) */
    private fun say(ctx: Context, sid: String, kind: String, id: Int, ch: String, title: String, text: String, route: String, icon: android.graphics.Bitmap?) {
        if (Events.foreground) Events.emit(JSONObject().put("type", "notify").put("kind", kind).put("title", title).put("text", text).put("route", route).put("server", sid))
        else Notifier.alert(ctx, id, ch, title, text, route, icon)
    }
}

/** Resgate automático: tenta assim que o tempo de espera de cada rede termina (normalmente 1 h). */
object AutoClaim {
    fun tick(ctx: Context) {
        val l = Store.servers()
        for (i in 0 until l.length()) {
            val sv = l.optJSONObject(i) ?: continue
            val id = sv.optString("id")
            if (Store.session(id) == null) continue
            val next = Store.kv("claim_next_$id", "0").toLongOrNull() ?: 0L
            if (System.currentTimeMillis() < next) continue
            try {
                val r = Api.raw(id, "POST", "/api/claim", "{}")
                val o = Http.parse(r.body)
                if (r.status in 200..299) {
                    CoinService.lastClaim = System.currentTimeMillis()
                    val wait = o.optLong("nextClaimInMs", 3_600_000L).coerceAtLeast(60_000L)
                    Store.setKv("claim_next_$id", (System.currentTimeMillis() + wait + 2_000L).toString())
                    Events.emit(JSONObject().put("type", "claimed").put("server", id).put("auto", true).put("sats", Coin.satsOf(o, "claimedSats", "claimed")))
                } else if (r.status == 429) {
                    val wait = o.optLong("nextClaimInMs", 300_000L).coerceAtLeast(10_000L)
                    Store.setKv("claim_next_$id", (System.currentTimeMillis() + wait + 2_000L).toString())
                } else {
                    Store.setKv("claim_next_$id", (System.currentTimeMillis() + 300_000L).toString())
                }
            } catch (e: Exception) {
                Store.setKv("claim_next_$id", (System.currentTimeMillis() + 120_000L).toString())
            }
        }
    }
}
