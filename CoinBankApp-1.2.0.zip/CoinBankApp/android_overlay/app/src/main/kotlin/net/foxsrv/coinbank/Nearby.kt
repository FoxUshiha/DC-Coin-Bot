package net.foxsrv.coinbank

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothManager
import android.bluetooth.le.AdvertiseCallback
import android.bluetooth.le.AdvertiseData
import android.bluetooth.le.AdvertiseSettings
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanFilter
import android.bluetooth.le.ScanResult
import android.bluetooth.le.ScanSettings
import android.content.Context
import android.content.pm.PackageManager
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.net.wifi.WifiManager
import android.os.Build
import android.os.ParcelUuid
import org.json.JSONArray
import org.json.JSONObject
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.Inet4Address
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.nio.ByteBuffer
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

/**
 * Pessoas e redes por perto, sem servidor no meio:
 *  • rede local (Wi-Fi / hotspot): anúncio UDP (broadcast) a cada 3 s + NSD/mDNS (_coinbank._udp);
 *  • Bluetooth LE (opcional): anuncia o ID da conta + a rede (hash), para quem está perto mesmo sem Wi-Fi em comum;
 *  • mensagens diretas pela rede local: "te mandei uma cobrança", "cobrança por QR" — o outro app abre na hora.
 * Só aparece para os outros quem liga "Ficar visível". Quem hospeda uma rede anuncia a rede (Cloudflare tem prioridade).
 * O dinheiro sempre se move no servidor da rede (API), nunca por aqui.
 */
object Nearby {
    const val PORT = 26452
    private const val SERVICE = "_coinbank._udp."
    private val BLE_UUID: ParcelUuid = ParcelUuid(UUID.fromString("0000c01b-0000-1000-8000-00805f9b34fb"))

    @Volatile private var app: Context? = null
    @Volatile private var sock: DatagramSocket? = null
    @Volatile private var running = false
    @Volatile private var gen = 0            // geração: um start() novo encerra o beacon antigo
    @Volatile var scanning = false          // o app pediu para procurar (tela "Por perto" aberta)
    private var mlock: WifiManager.MulticastLock? = null
    private var nsd: NsdManager? = null
    private var regListener: NsdManager.RegistrationListener? = null
    private var regSig = ""
    private var discListener: NsdManager.DiscoveryListener? = null
    private var advCb: AdvertiseCallback? = null
    private var scanCb: ScanCallback? = null
    private var bleSig = ""
    val peers = ConcurrentHashMap<String, JSONObject>()
    @Volatile var lastError: String? = null; private set

    fun device(ctx: Context): String {
        Store.init(ctx)
        var d = Store.kv("device")
        if (d.isEmpty()) { d = HostDb.randHex(6); Store.setKv("device", d) }
        return d
    }

    /** o que este aparelho anuncia: a conta (se visível) e a rede hospedada (se houver) */
    private fun me(ctx: Context): JSONObject? {
        val s = Store.settings()
        if (!s.optBoolean("visible", false)) return null
        val id = Store.activeId()
        val ses = Store.session(id) ?: Store.session(Store.MAIN_ID) ?: return null
        val sid = if (Store.session(id) != null) id else Store.MAIN_ID
        val sv = Store.server(sid) ?: return null
        val net = if (sid == Store.HOST_ID) HostRuntime.publicBase(HostConfig.get().optInt("port", HostConfig.DEFAULT_PORT)) else sv.optString("url")
        return JSONObject().put("uid", ses.optString("userId")).put("name", ses.optString("username")).put("net", net).put("netName", sv.optString("name"))
    }

    private fun host(): JSONObject? {
        val c = HostConfig.get()
        if (!c.optBoolean("enabled", false) || !HostRuntime.running()) return null
        val port = c.optInt("port", HostConfig.DEFAULT_PORT)
        // com Cloudflare ligado, a rede aparece só pelo endereço do túnel
        val url = HostRuntime.tunnel() ?: (if (c.optBoolean("cloudflare", false)) null else HostRuntime.lanIp()?.let { "http://$it:$port" }) ?: return null
        return JSONObject().put("name", c.optString("name")).put("url", url).put("cf", HostRuntime.tunnel() != null)
    }

    fun syncBackground(ctx: Context) {
        val want = Store.bool("visible") || HostConfig.get().optBoolean("enabled", false) || scanning
        if (want) start(ctx) else if (!Events.foreground) stop()
        if (running) { refreshNsd(ctx); refreshBle(ctx) }
    }

    @Synchronized fun start(ctx0: Context) {
        val ctx = ctx0.applicationContext; app = ctx
        if (running) return
        running = true
        val g = ++gen
        try {
            val wm = ctx.getSystemService(Context.WIFI_SERVICE) as? WifiManager
            mlock = wm?.createMulticastLock("coinbank-nearby")?.also { it.setReferenceCounted(false); it.acquire() }
        } catch (ignored: Exception) { }
        try {
            val s = DatagramSocket(null); s.reuseAddress = true; s.broadcast = true
            s.bind(InetSocketAddress(PORT)); sock = s
            Thread({ listen(s) }, "coinbank-nearby-rx").also { it.isDaemon = true }.start()
        } catch (e: Exception) { lastError = "udp: ${e.message}" }
        Thread({ beacon(g) }, "coinbank-nearby-tx").also { it.isDaemon = true }.start()
        startNsdDiscovery(ctx)
        refreshNsd(ctx); refreshBle(ctx)
    }

    @Synchronized fun stop() {
        if (!running) return
        running = false
        try { sock?.close() } catch (ignored: Exception) { }
        sock = null
        try { mlock?.release() } catch (ignored: Exception) { }
        mlock = null
        try { regListener?.let { nsd?.unregisterService(it) } } catch (ignored: Exception) { }
        try { discListener?.let { nsd?.stopServiceDiscovery(it) } } catch (ignored: Exception) { }
        regListener = null; discListener = null; regSig = ""
        app?.let { stopBle(it) }
        bleSig = ""
    }

    // ───────────────────────── UDP ─────────────────────────
    private fun hello(ctx: Context): JSONObject? {
        val m = me(ctx); val h = host()
        if (m == null && h == null) return null
        return JSONObject().put("cb", 1).put("t", "hi").put("d", device(ctx)).put("me", m ?: JSONObject.NULL).put("host", h ?: JSONObject.NULL)
    }

    private fun broadcastAddrs(): List<InetAddress> {
        val out = ArrayList<InetAddress>()
        try {
            for (ni in NetworkInterface.getNetworkInterfaces()?.toList().orEmpty()) {
                if (!ni.isUp || ni.isLoopback) continue
                for (ia in ni.interfaceAddresses) { val b = ia.broadcast; if (b != null && !out.contains(b)) out.add(b) }
            }
        } catch (ignored: Exception) { }
        try { out.add(InetAddress.getByName("255.255.255.255")) } catch (ignored: Exception) { }
        return out
    }

    private fun beacon(g: Int) {
        var n = 0
        while (running && gen == g) {
            try {
                val ctx = app
                val s = sock
                if (ctx != null && s != null) {
                    val h = hello(ctx)
                    if (h != null) {
                        val b = h.toString().toByteArray(Charsets.UTF_8)
                        for (a in broadcastAddrs()) try { s.send(DatagramPacket(b, b.size, a, PORT)) } catch (ignored: Exception) { }
                    }
                    if (scanning && n % 2 == 0) {
                        // pede para quem estiver por perto se anunciar logo
                        val q = JSONObject().put("cb", 1).put("t", "who").put("d", device(ctx)).toString().toByteArray(Charsets.UTF_8)
                        for (a in broadcastAddrs()) try { s.send(DatagramPacket(q, q.size, a, PORT)) } catch (ignored: Exception) { }
                    }
                }
                prune()
            } catch (ignored: Exception) { }
            n++
            try { Thread.sleep(3000) } catch (e: InterruptedException) { break }
        }
    }

    private fun listen(s: DatagramSocket) {
        val buf = ByteArray(4096)
        while (running && !s.isClosed) {
            try {
                val pk = DatagramPacket(buf, buf.size)
                s.receive(pk)
                val o = JSONObject(String(pk.data, 0, pk.length, Charsets.UTF_8))
                if (o.optInt("cb") != 1) continue
                val ctx = app ?: continue
                val d = o.optString("d")
                if (d.isEmpty() || d == device(ctx)) continue
                val ip = pk.address?.hostAddress ?: continue
                when (o.optString("t")) {
                    "hi" -> offer(d, ip, "wifi", o.optJSONObject("me"), o.optJSONObject("host"))
                    "who" -> { val h = hello(ctx); if (h != null) send(ip, h) }
                    "msg" -> if (o.optString("to") == device(ctx)) onMessage(ctx, d, ip, o.optJSONObject("m") ?: JSONObject())
                }
            } catch (e: Exception) { if (!running) break }
        }
    }

    private fun send(ip: String, o: JSONObject): Boolean {
        val s = sock ?: return false
        return try { val b = o.toString().toByteArray(Charsets.UTF_8); s.send(DatagramPacket(b, b.size, InetAddress.getByName(ip), PORT)); true } catch (e: Exception) { false }
    }

    private fun offer(d: String, ip: String?, via: String, me: JSONObject?, host: JSONObject?) {
        val cur = peers[d] ?: JSONObject().put("id", d).put("via", JSONArray())
        if (ip != null) cur.put("ip", ip)
        if (me != null) cur.put("me", me)
        if (host != null) cur.put("host", host)
        val v = cur.optJSONArray("via") ?: JSONArray()
        var has = false; for (i in 0 until v.length()) if (v.optString(i) == via) has = true
        if (!has) v.put(via)
        cur.put("via", v).put("seen", System.currentTimeMillis())
        val isNew = !peers.containsKey(d)
        peers[d] = cur
        if (isNew) Events.emit(JSONObject().put("type", "nearby"))
    }

    private fun prune() {
        val now = System.currentTimeMillis(); var changed = false
        for ((k, v) in peers) if (now - v.optLong("seen") > 25_000L) { peers.remove(k); changed = true }
        if (changed) Events.emit(JSONObject().put("type", "nearby"))
    }

    fun list(): JSONArray = JSONArray(peers.values.sortedByDescending { it.optLong("seen") })

    /** mensagem direta para um aparelho por perto (cobrança criada, pedido por QR…) */
    fun message(ctx: Context, deviceId: String, m: JSONObject): Boolean {
        val p = peers[deviceId] ?: return false
        val ip = p.optString("ip"); if (ip.isEmpty()) return false
        // rede deste aparelho: o outro celular não alcança 127.0.0.1, manda o endereço público (LAN/Cloudflare)
        val net = m.optString("net")
        if (net.startsWith("http://127.0.0.1") || net.startsWith("http://localhost")) m.put("net", HostRuntime.publicBase(HostConfig.get().optInt("port", HostConfig.DEFAULT_PORT)))
        val o = JSONObject().put("cb", 1).put("t", "msg").put("d", device(ctx)).put("to", deviceId).put("m", m.put("fromMe", me(ctx) ?: JSONObject.NULL))
        var ok = false
        for (i in 0 until 2) ok = send(ip, o) || ok
        return ok
    }

    private fun onMessage(ctx: Context, from: String, ip: String, m: JSONObject) {
        Events.emit(JSONObject().put("type", "nearbyMsg").put("from", from).put("ip", ip).put("msg", m))
        if (Events.foreground) return
        // só a rede principal gera notificação
        val net = m.optString("net")
        if (net.isEmpty() || Store.origin(net) != Store.origin(Store.mainUrl()) || !Store.bool("notify")) return
        val who = m.optJSONObject("fromMe")?.optString("name").orEmpty().ifEmpty { Store.t(ctx, "Alguém por perto", "Someone nearby") }
        val amt = Coin.format(Coin.parse(m.opt("amount")) ?: 0L, Store.settings().optInt("decimals", 8), Store.pt(ctx))
        when (m.optString("kind")) {
            "bill" -> Notifier.alert(ctx, m.optString("billId").hashCode(), Notifier.CH_BILLS, Store.t(ctx, "$who te enviou uma cobrança", "$who sent you a bill"), "$amt coins", "bill:" + m.optString("billId"))
            "charge" -> Notifier.alert(ctx, m.optString("url").hashCode(), Notifier.CH_BILLS, Store.t(ctx, "$who está cobrando você", "$who is charging you"), "$amt coins", "pay:" + m.optString("url"))
        }
    }

    // ───────────────────────── NSD / mDNS ─────────────────────────
    private fun startNsdDiscovery(ctx: Context) {
        try {
            val m = nsd ?: (ctx.getSystemService(Context.NSD_SERVICE) as NsdManager).also { nsd = it }
            val dl = object : NsdManager.DiscoveryListener {
                override fun onDiscoveryStarted(t: String) {}
                override fun onDiscoveryStopped(t: String) {}
                override fun onStartDiscoveryFailed(t: String, err: Int) { lastError = "nsd_disc_$err" }
                override fun onStopDiscoveryFailed(t: String, err: Int) {}
                override fun onServiceLost(si: NsdServiceInfo) {}
                @Suppress("DEPRECATION")
                override fun onServiceFound(si: NsdServiceInfo) {
                    if (si.serviceName.endsWith(device(ctx))) return
                    try {
                        m.resolveService(si, object : NsdManager.ResolveListener {
                            override fun onResolveFailed(s: NsdServiceInfo, err: Int) {}
                            override fun onServiceResolved(s: NsdServiceInfo) {
                                val h = s.host ?: return
                                if (h !is Inet4Address) return
                                val a = s.attributes
                                fun at(k: String): String = a[k]?.let { String(it, Charsets.UTF_8) } ?: ""
                                val d = at("d").ifEmpty { s.serviceName.substringAfterLast('-') }
                                if (d == device(ctx)) return
                                val me = if (at("uid").isNotEmpty()) JSONObject().put("uid", at("uid")).put("name", at("n")).put("net", at("net")).put("netName", at("nn")) else null
                                val host = if (at("hu").isNotEmpty()) JSONObject().put("name", at("hn")).put("url", at("hu")) else null
                                offer(d, h.hostAddress, "nsd", me, host)
                                // pede o anúncio completo direto
                                send(h.hostAddress ?: return, JSONObject().put("cb", 1).put("t", "who").put("d", device(ctx)))
                            }
                        })
                    } catch (ignored: Exception) { }
                }
            }
            discListener = dl
            m.discoverServices(SERVICE, NsdManager.PROTOCOL_DNS_SD, dl)
        } catch (e: Exception) { lastError = "nsd: ${e.message}" }
    }

    @Synchronized private fun refreshNsd(ctx: Context) {
        val m = nsd ?: return
        val me = me(ctx); val h = host()
        val sig = (me?.toString() ?: "") + "|" + (h?.toString() ?: "")
        if (sig == regSig) return
        try { regListener?.let { m.unregisterService(it) } } catch (ignored: Exception) { }
        regListener = null; regSig = sig
        if (me == null && h == null) return
        try {
            val info = NsdServiceInfo(); info.serviceName = "CoinBank-" + device(ctx); info.serviceType = SERVICE; info.port = PORT
            fun put(k: String, v: String) { if (v.isNotEmpty()) try { info.setAttribute(k, v.take(200)) } catch (ignored: Exception) { } }
            put("d", device(ctx))
            if (me != null) { put("uid", me.optString("uid")); put("n", me.optString("name")); put("net", me.optString("net")); put("nn", me.optString("netName")) }
            if (h != null) { put("hn", h.optString("name")); put("hu", h.optString("url")) }
            val rl = object : NsdManager.RegistrationListener {
                override fun onServiceRegistered(si: NsdServiceInfo) {}
                override fun onRegistrationFailed(si: NsdServiceInfo, err: Int) { lastError = "nsd_reg_$err" }
                override fun onServiceUnregistered(si: NsdServiceInfo) {}
                override fun onUnregistrationFailed(si: NsdServiceInfo, err: Int) {}
            }
            regListener = rl
            m.registerService(info, NsdManager.PROTOCOL_DNS_SD, rl)
        } catch (e: Exception) { lastError = "nsd_reg: ${e.message}" }
    }

    // ───────────────────────── Bluetooth LE ─────────────────────────
    private fun has(ctx: Context, p: String) = Build.VERSION.SDK_INT < 23 || ctx.checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

    fun bleAllowed(ctx: Context): Boolean = if (Build.VERSION.SDK_INT >= 31) has(ctx, Manifest.permission.BLUETOOTH_ADVERTISE) && has(ctx, Manifest.permission.BLUETOOTH_SCAN)
        else has(ctx, Manifest.permission.ACCESS_FINE_LOCATION)

    fun bleState(ctx: Context): String = try {
        val ad = (ctx.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter
        when { ad == null -> "unsupported"; !ad.isEnabled -> "off"; !bleAllowed(ctx) -> "permission"; else -> "on" }
    } catch (e: Exception) { "unsupported" }

    /** hash curto da origem da rede (4 bytes) — o BLE só carrega 31 bytes */
    private fun netHash(url: String): Int = (Store.origin(url) ?: url).hashCode()

    private fun netByHash(h: Int): JSONObject? {
        val l = Store.servers()
        for (i in 0 until l.length()) { val s = l.optJSONObject(i) ?: continue; if (netHash(s.optString("url")) == h) return s }
        return null
    }

    @SuppressLint("MissingPermission")
    @Synchronized private fun refreshBle(ctx: Context) {
        val want = Store.bool("bluetooth") && bleState(ctx) == "on"
        val me = if (want) me(ctx) else null
        val sig = if (!want) "" else "on|" + (me?.optString("uid") ?: "") + "|" + (me?.optString("net") ?: "")
        if (sig == bleSig) return
        stopBle(ctx); bleSig = sig
        if (!want) return
        try {
            val ad = (ctx.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter ?: return
            val uid = me?.optString("uid")?.toLongOrNull()
            if (me != null && uid != null) {
                val payload = ByteBuffer.allocate(13).put(1.toByte()).putLong(uid).putInt(netHash(me.optString("net"))).array()
                val adv = ad.bluetoothLeAdvertiser
                if (adv != null) {
                    val cb = object : AdvertiseCallback() { override fun onStartFailure(errorCode: Int) { lastError = "ble_adv_$errorCode" } }
                    advCb = cb
                    adv.startAdvertising(AdvertiseSettings.Builder().setAdvertiseMode(AdvertiseSettings.ADVERTISE_MODE_BALANCED).setConnectable(false).setTxPowerLevel(AdvertiseSettings.ADVERTISE_TX_POWER_MEDIUM).build(),
                        AdvertiseData.Builder().setIncludeDeviceName(false).addServiceData(BLE_UUID, payload).build(), cb)
                }
            }
            val sc = ad.bluetoothLeScanner ?: return
            val cb = object : ScanCallback() {
                override fun onScanResult(callbackType: Int, result: ScanResult) {
                    val d = result.scanRecord?.getServiceData(BLE_UUID) ?: return
                    if (d.size < 13 || d[0].toInt() != 1) return
                    val b = ByteBuffer.wrap(d); b.get(); val id = b.long; val nh = b.int
                    val net = netByHash(nh)
                    if (me != null && id.toString() == me.optString("uid")) return
                    val key = "ble-" + id.toString(16)
                    val existing = peers.values.firstOrNull { it.optJSONObject("me")?.optString("uid") == id.toString() }
                    val m = JSONObject().put("uid", id.toString()).put("name", "").put("net", net?.optString("url") ?: "").put("netName", net?.optString("name") ?: "")
                    offer(existing?.optString("id") ?: key, null, "bluetooth", if (existing != null) null else m, null)
                    (existing ?: peers[key])?.put("rssi", result.rssi)
                }
            }
            scanCb = cb
            sc.startScan(listOf(ScanFilter.Builder().setServiceData(BLE_UUID, null).build()), ScanSettings.Builder().setScanMode(ScanSettings.SCAN_MODE_BALANCED).build(), cb)
        } catch (e: Exception) { lastError = "ble: ${e.message}" }
    }

    @SuppressLint("MissingPermission")
    private fun stopBle(ctx: Context) {
        try {
            val ad = (ctx.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter
            advCb?.let { ad?.bluetoothLeAdvertiser?.stopAdvertising(it) }
            scanCb?.let { ad?.bluetoothLeScanner?.stopScan(it) }
        } catch (ignored: Exception) { }
        advCb = null; scanCb = null
    }

    fun refresh(ctx: Context) { if (running) { refreshNsd(ctx); refreshBle(ctx) } }

    fun status(ctx: Context): JSONObject = JSONObject().put("running", running).put("scanning", scanning).put("device", device(ctx))
        .put("visible", Store.bool("visible")).put("bluetooth", Store.bool("bluetooth")).put("ble", bleState(ctx))
        .put("me", me(ctx) ?: JSONObject.NULL).put("host", host() ?: JSONObject.NULL).put("error", lastError ?: JSONObject.NULL)
}
