import 'i18n.dart';

/// Bloco de um documento embutido (funciona sem internet, no idioma e tema do app).
class DocBlock {
  const DocBlock.h(this.text) : kind = 'h', items = const <String>[];
  const DocBlock.p(this.text) : kind = 'p', items = const <String>[];
  const DocBlock.note(this.text) : kind = 'note', items = const <String>[];
  const DocBlock.code(this.text) : kind = 'code', items = const <String>[];
  const DocBlock.list(this.items) : kind = 'list', text = '';
  final String kind;
  final String text;
  final List<String> items;
}

class Doc {
  const Doc(this.title, this.updated, this.blocks);
  final String title;
  final String updated;
  final List<DocBlock> blocks;
}

class Docs {
  Docs._();

  static Doc terms() => L.pt ? _termsPt : _termsEn;
  static Doc privacy() => L.pt ? _privPt : _privEn;
  static Doc api() => L.pt ? _apiPt : _apiEn;
  static Doc howItWorks() => L.pt ? _howPt : _howEn;

  // ───────────────────────── Termos ─────────────────────────
  static const Doc _termsPt = Doc('Termos de Uso', 'Última atualização: outubro de 2026', <DocBlock>[
    DocBlock.note('O Coin Bank é um sistema de entretenimento / educativo. Os "coins" são unidades virtuais sem valor monetário, não podem ser comprados com dinheiro real nem trocados por ele, e não são produto financeiro, valor mobiliário ou moeda. Os "cartões" são códigos internos de pagamento deste sistema — não são cartões bancários ou de crédito.'),
    DocBlock.h('1. Aceitação'),
    DocBlock.p('Ao usar o app, o bot do Discord, o site ou a API você concorda com estes termos. Se não concordar, não use o serviço.'),
    DocBlock.h('2. Contas e segurança'),
    DocBlock.list(<String>[
      'Seu login (usuário + senha) ou sua conta do Discord identifica sua carteira.',
      'Mantenha sua senha, código do cartão e códigos de backup em segredo. Quem tiver o código do seu cartão pode movimentar seus coins pela API. Troque o código se ele vazar.',
      'Sessões expiram automaticamente após 24 horas. Contas salvas no app ficam cifradas pelo Android Keystore e só entram com a sua digital ou bloqueio de tela.',
    ]),
    DocBlock.h('3. Transações'),
    DocBlock.list(<String>[
      'Transferências são definitivas e não podem ser revertidas pelos operadores. Confira o ID de destino antes de enviar.',
      'Toda transação possui comprovante público verificável por QR em /tx/<id>.',
      'Registros antigos de transações podem ser apagados após o período de retenção configurado pelo operador (30 dias por padrão); os saldos nunca são afetados.',
    ]),
    DocBlock.h('4. Redes locais e hospedadas'),
    DocBlock.p('O app permite hospedar uma moeda própria no aparelho e entrar em outras redes. Cada rede é independente, criada e mantida por quem a hospeda, começa com saldo 0 para todos e pode sair do ar a qualquer momento. A rede principal (bank.foxsrv.net) não responde por redes de terceiros.'),
    DocBlock.h('5. Uso justo'),
    DocBlock.p('Abuso automatizado, exploração de falhas, ataques à API, criação de contas em massa ou tentativas de adivinhar códigos de cartão são proibidos e são limitados/bloqueados automaticamente. Contas envolvidas em abuso podem ser restringidas.'),
    DocBlock.h('6. Disponibilidade'),
    DocBlock.p('O serviço é fornecido "como está", sem garantias. Ele pode mudar, pausar ou terminar a qualquer momento. Como os coins não têm valor, nenhuma compensação é devida por coins perdidos, indisponibilidade ou perda de dados.'),
    DocBlock.h('7. Contato'),
    DocBlock.p('Servidor de suporte: discord.gg/C5cAfhcdRp'),
  ]);

  static const Doc _termsEn = Doc('Terms of Use', 'Last updated: October 2026', <DocBlock>[
    DocBlock.note('Coin Bank is an entertainment / educational system. "Coins" are virtual units with no monetary value, cannot be bought with or exchanged for real money, and are not a financial product, security or currency. "Cards" are internal payment codes of this system — they are not bank or credit cards.'),
    DocBlock.h('1. Acceptance'),
    DocBlock.p('By using the app, the Discord bot, the website or the API you agree to these terms. If you do not agree, do not use the service.'),
    DocBlock.h('2. Accounts and security'),
    DocBlock.list(<String>[
      'Your login (username + password) or your Discord account identifies your wallet.',
      'Keep your password, card code and backup codes secret. Anyone with your card code can move your coins through the API. Reset it if it leaks.',
      'Sessions expire automatically after 24 hours. Accounts saved in the app are encrypted by the Android Keystore and only sign in with your fingerprint or screen lock.',
    ]),
    DocBlock.h('3. Transactions'),
    DocBlock.list(<String>[
      'Transfers are final and cannot be reversed by the operators. Check the destination ID before sending.',
      'Every transaction has a public, QR-verifiable receipt at /tx/<id>.',
      'Old transaction records may be deleted after the retention period configured by the operator (30 days by default); balances are never affected.',
    ]),
    DocBlock.h('4. Local and hosted networks'),
    DocBlock.p('The app lets you host your own coin on the device and join other networks. Each network is independent, created and run by whoever hosts it, starts at 0 for everyone and may go offline at any time. The main network (bank.foxsrv.net) is not responsible for third-party networks.'),
    DocBlock.h('5. Fair use'),
    DocBlock.p('Automated abuse, exploiting bugs, attacking the API, mass account creation or attempts to guess card codes are forbidden and are rate-limited/blocked automatically. Accounts involved in abuse may be restricted.'),
    DocBlock.h('6. Availability'),
    DocBlock.p('The service is provided "as is", without warranties. It may change, pause or end at any time. Because coins have no value, no compensation is owed for lost coins, downtime or data loss.'),
    DocBlock.h('7. Contact'),
    DocBlock.p('Support server: discord.gg/C5cAfhcdRp'),
  ]);

  // ───────────────────────── Privacidade ─────────────────────────
  static const Doc _privPt = Doc('Política de Privacidade', 'Última atualização: outubro de 2026', <DocBlock>[
    DocBlock.note('Guardamos o mínimo necessário para operar uma moeda virtual. Não coletamos nomes reais, e-mails, telefones, documentos nem dados de pagamento reais.'),
    DocBlock.h('O que o servidor armazena'),
    DocBlock.list(<String>[
      'ID da conta e saldo — para manter sua carteira, enquanto a conta existir.',
      'Usuário + senha (somente hash com salt, nunca a senha em si) — para o login, até você remover.',
      'Transações (IDs, valor, data) — extratos e comprovantes públicos, pelo período de retenção (30 dias por padrão).',
      'Sessões de login (somente um SHA-256 do token) — por 24 h.',
      'Endereço IP — somente limites de uso e antiabuso: em memória por minutos; para o limite de criação de contas só um hash irreversível (HMAC) por até 24 h, nunca ligado à sua conta.',
      'Código do cartão e códigos de backup — até serem trocados/usados.',
    ]),
    DocBlock.h('O que o app guarda no aparelho'),
    DocBlock.list(<String>[
      'Configurações (tema, idioma, casas decimais, notificações) e a lista de redes.',
      'A sessão de cada rede (token de 24 h).',
      'Contas salvas: usuário e senha cifrados com AES-256-GCM por uma chave do Android Keystore, que não sai do aparelho e não vai para backup.',
      'Nada é enviado para terceiros. Não há rastreadores, anúncios nem analytics.',
    ]),
    DocBlock.h('Por perto, NFC e rede hospedada'),
    DocBlock.list(<String>[
      '"Ficar visível" (desligado por padrão) anuncia o ID e o nome de usuário da sua conta na rede local (Wi-Fi/hotspot) e, se você ligar, por Bluetooth. Desligue quando não quiser aparecer.',
      'A cobrança por aproximação (NFC) só entrega o link da cobrança enquanto a tela de cobrar está aberta.',
      'Se você hospedar uma rede, os dados dela (contas, saldos, transações) ficam somente no seu aparelho. Com o túnel Cloudflare ligado, a Cloudflare processa a conexão conforme a política dela.',
    ]),
    DocBlock.h('Informação pública'),
    DocBlock.p('Como no Bitcoin, o livro-razão é transparente: comprovantes (IDs, valores, datas) são públicos pelo ID, e o ranking mostra IDs/usuários e saldos.'),
    DocBlock.h('Suas escolhas'),
    DocBlock.p('Você pode remover seu login a qualquer momento (Conta › Excluir login), trocar seu cartão, apagar as contas salvas no app e pedir aos operadores no servidor de suporte a exclusão dos seus dados.'),
  ]);

  static const Doc _privEn = Doc('Privacy Policy', 'Last updated: October 2026', <DocBlock>[
    DocBlock.note('We store the minimum needed to run a virtual coin. No real names, e-mails, phone numbers, documents or real payment data are collected.'),
    DocBlock.h('What the server stores'),
    DocBlock.list(<String>[
      'Account ID and balance — to keep your wallet, while the account exists.',
      'Username + password (salted hash only, never the password itself) — for login, until you remove it.',
      'Transactions (IDs, amount, date) — statements and public receipts, for the retention period (30 days by default).',
      'Login sessions (only a SHA-256 of the token) — for 24 h.',
      'IP address — rate limits and anti-abuse only: in memory for minutes; for account-creation limits only an irreversible keyed hash (HMAC) for up to 24 h, never linked to your account.',
      'Card code and backup codes — until reset/used.',
    ]),
    DocBlock.h('What the app keeps on the device'),
    DocBlock.list(<String>[
      'Settings (theme, language, decimal places, notifications) and the list of networks.',
      'The session of each network (24 h token).',
      'Saved accounts: username and password encrypted with AES-256-GCM by an Android Keystore key that never leaves the device and is not backed up.',
      'Nothing is sent to third parties. No trackers, ads or analytics.',
    ]),
    DocBlock.h('Nearby, NFC and hosted network'),
    DocBlock.list(<String>[
      '"Be visible" (off by default) announces your account ID and username on the local network (Wi-Fi/hotspot) and, if you turn it on, over Bluetooth. Turn it off when you do not want to appear.',
      'Tap-to-charge (NFC) only hands out the request link while the charge screen is open.',
      'If you host a network, its data (accounts, balances, transactions) stays only on your device. With the Cloudflare tunnel on, Cloudflare processes the connection as described in its own policy.',
    ]),
    DocBlock.h('Public information'),
    DocBlock.p('Like Bitcoin, the ledger is transparent: transaction receipts (IDs, amounts, dates) are public by ID, and the ranking shows account IDs/usernames and balances.'),
    DocBlock.h('Your choices'),
    DocBlock.p('You can remove your login at any time (Account › Delete login), reset your card, delete the accounts saved in the app and ask the operators on the support server to delete your data.'),
  ]);

  // ───────────────────────── Documentação da API ─────────────────────────
  static const Doc _apiPt = Doc('Documentação da API', 'Base: https://bank.foxsrv.net · JSON', <DocBlock>[
    DocBlock.p('Valores são inteiros em sats (1 coin = 100 000 000 sats) e aparecem com 8 casas decimais. Rotas com sessão usam o cabeçalho Authorization: Bearer <sessionId> (vale 24 h). Erros vêm como {"error": "CÓDIGO"} com o status HTTP certo (ex.: INSUFFICIENT_FUNDS 402, TRANSFER_COOLDOWN 429).'),
    DocBlock.h('Conta'),
    DocBlock.code('POST /api/register {username, password}\nPOST /api/login {username, password} → {sessionId, userId, sats}\nPOST /api/logout\nGET  /api/me\nPOST /api/account/change {username?, password}\nPOST /api/account/unregister'),
    DocBlock.h('Saldo, transferências e resgate'),
    DocBlock.code('GET  /api/user/:id/balance → {coins, sats, coinsStr}\nPOST /api/transfer {toId, amount}  (Idempotency-Key opcional)\nPOST /api/claim → {claimedSats, txId, nextClaimInMs}\nGET  /api/claim/status\nGET  /api/transactions?page=1  (20 por página)\nGET  /api/tx/:id · /api/tx/:id/receipt.png|pdf'),
    DocBlock.h('Cartão'),
    DocBlock.code('POST /api/card → {cardCode}\nPOST /api/card/reset → {newCode}\nPOST /api/card/info {cardCode}\nPOST /api/transfer/card {cardCode, toId, amount}'),
    DocBlock.h('Cobranças (bills)'),
    DocBlock.code('POST /api/bill/create {fromId?, toId, amount, time}\nPOST /api/bill/list {page} → {toPay, toReceive}\nPOST /api/bill/pay {billId}\nGET  /api/bill/:id'),
    DocBlock.h('Pagamentos por QR (app)'),
    DocBlock.code('POST /api/pay/request {amount?, memo?, expires?, reusable?}\nGET  /api/pay/request/:id?wait=25&since=N  (espera o pagamento)\nPOST /api/pay/request/:id/pay {amount?}\nPOST /api/pay/request/:id/cancel\nGET  /api/pay/requests · /api/pay/me · /api/pay/user/:id\nPOST /api/pay/scan {data} → request | user | bill | transaction'),
    DocBlock.h('Backups e estatísticas'),
    DocBlock.code('POST /api/backup/create · /api/backup/list · /api/backup/restore {backupId}\nGET  /api/stats · /api/stats/history?days=30 · /api/totalusers · /api/rank'),
    DocBlock.note('As redes hospedadas pelo app falam esta mesma API, então qualquer cliente compatível funciona nelas.'),
  ]);

  static const Doc _apiEn = Doc('API documentation', 'Base: https://bank.foxsrv.net · JSON', <DocBlock>[
    DocBlock.p('Amounts are integers in sats (1 coin = 100,000,000 sats) shown with 8 decimal places. Session routes use the header Authorization: Bearer <sessionId> (valid 24 h). Errors come as {"error": "CODE"} with the right HTTP status (e.g. INSUFFICIENT_FUNDS 402, TRANSFER_COOLDOWN 429).'),
    DocBlock.h('Account'),
    DocBlock.code('POST /api/register {username, password}\nPOST /api/login {username, password} → {sessionId, userId, sats}\nPOST /api/logout\nGET  /api/me\nPOST /api/account/change {username?, password}\nPOST /api/account/unregister'),
    DocBlock.h('Balance, transfers and claim'),
    DocBlock.code('GET  /api/user/:id/balance → {coins, sats, coinsStr}\nPOST /api/transfer {toId, amount}  (optional Idempotency-Key)\nPOST /api/claim → {claimedSats, txId, nextClaimInMs}\nGET  /api/claim/status\nGET  /api/transactions?page=1  (20 per page)\nGET  /api/tx/:id · /api/tx/:id/receipt.png|pdf'),
    DocBlock.h('Card'),
    DocBlock.code('POST /api/card → {cardCode}\nPOST /api/card/reset → {newCode}\nPOST /api/card/info {cardCode}\nPOST /api/transfer/card {cardCode, toId, amount}'),
    DocBlock.h('Bills'),
    DocBlock.code('POST /api/bill/create {fromId?, toId, amount, time}\nPOST /api/bill/list {page} → {toPay, toReceive}\nPOST /api/bill/pay {billId}\nGET  /api/bill/:id'),
    DocBlock.h('QR payments (app)'),
    DocBlock.code('POST /api/pay/request {amount?, memo?, expires?, reusable?}\nGET  /api/pay/request/:id?wait=25&since=N  (waits for payment)\nPOST /api/pay/request/:id/pay {amount?}\nPOST /api/pay/request/:id/cancel\nGET  /api/pay/requests · /api/pay/me · /api/pay/user/:id\nPOST /api/pay/scan {data} → request | user | bill | transaction'),
    DocBlock.h('Backups and statistics'),
    DocBlock.code('POST /api/backup/create · /api/backup/list · /api/backup/restore {backupId}\nGET  /api/stats · /api/stats/history?days=30 · /api/totalusers · /api/rank'),
    DocBlock.note('Networks hosted by the app speak this same API, so any compatible client works with them.'),
  ]);

  // ───────────────────────── Como funciona ─────────────────────────
  static const Doc _howPt = Doc('Como funciona o Coin Bank', 'Moeda virtual, sem dinheiro real', <DocBlock>[
    DocBlock.note('O Coin Bank é uma moeda digital parecida com o Bitcoin, mas sem vínculo com dinheiro real: os coins não se compram nem se vendem. É para brincar, aprender e trocar entre amigos e comunidades.'),
    DocBlock.h('1. Crie sua conta'),
    DocBlock.p('Escolha um usuário e uma senha. Você recebe um ID de conta (seu "número de carteira") e um cartão virtual com um código secreto para pagamentos pela API.'),
    DocBlock.h('2. Ganhe coins'),
    DocBlock.p('Toque no presente 🎁 no topo: a cada hora você resgata uma pequena quantia (claim). Ligue o resgate automático para o app fazer isso sozinho.'),
    DocBlock.h('3. Envie, cobre e pague'),
    DocBlock.list(<String>[
      'Enviar: digite o ID da pessoa (ou escolha alguém por perto) e o valor.',
      'Cobrar: gere um QR Code; quem paga escaneia, aproxima o celular (NFC) ou recebe a cobrança direto no app se estiver por perto.',
      'Escanear para pagar: a câmera do app lê QR de cobranças, de pessoas e de cobranças (bills).',
      'Contas: crie cobranças com vencimento para alguém pagar depois e pague as que chegarem para você.',
    ]),
    DocBlock.h('4. Comprovantes'),
    DocBlock.p('Toda transação tem comprovante: abra pelo extrato, salve como imagem ou PDF, ou abra o link verificável na web.'),
    DocBlock.h('5. Outras redes'),
    DocBlock.p('Além da rede principal você pode entrar em outras redes Coin ou hospedar a sua própria no celular (menu › Hospedar), com túnel Cloudflare para acesso de qualquer lugar. Cada rede tem seus próprios saldos; só a principal envia notificações.'),
  ]);

  static const Doc _howEn = Doc('How Coin Bank works', 'Virtual coin, no real money', <DocBlock>[
    DocBlock.note('Coin Bank is a digital coin similar to Bitcoin, but with no link to real money: coins cannot be bought or sold. It is for fun, learning and trading among friends and communities.'),
    DocBlock.h('1. Create your account'),
    DocBlock.p('Pick a username and password. You get an account ID (your "wallet number") and a virtual card with a secret code for API payments.'),
    DocBlock.h('2. Earn coins'),
    DocBlock.p('Tap the gift 🎁 at the top: every hour you can claim a small amount. Turn on auto-claim to let the app do it for you.'),
    DocBlock.h('3. Send, charge and pay'),
    DocBlock.list(<String>[
      'Send: type the person\'s ID (or pick someone nearby) and the amount.',
      'Charge: create a QR code; the payer scans it, taps phones (NFC) or gets the request directly in the app when nearby.',
      'Scan to pay: the in-app camera reads QR codes of requests, people and bills.',
      'Bills: create bills with a due date for someone to pay later and pay the ones you receive.',
    ]),
    DocBlock.h('4. Receipts'),
    DocBlock.p('Every transaction has a receipt: open it from the statement, save it as an image or PDF, or open the verifiable web link.'),
    DocBlock.h('5. Other networks'),
    DocBlock.p('Besides the main network you can join other Coin networks or host your own on the phone (menu › Host), with a Cloudflare tunnel for access from anywhere. Each network has its own balances; only the main one sends notifications.'),
  ]);
}
