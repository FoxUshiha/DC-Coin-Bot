import 'dart:ui' as ui;

/// Idioma do app: segue o aparelho (pt / en) ou a escolha nas configurações.
class L {
  L._();
  static String lang = _device();

  static String _device() {
    try {
      return ui.PlatformDispatcher.instance.locale.languageCode == 'pt' ? 'pt' : 'en';
    } catch (_) {
      return 'pt';
    }
  }

  static void apply(String choice) {
    lang = choice == 'pt' || choice == 'en' ? choice : _device();
  }

  static bool get pt => lang == 'pt';

  /// Texto em português ou inglês conforme o idioma ativo.
  static String t(String pt, String en) => lang == 'pt' ? pt : en;

  static const Map<String, List<String>> _errors = <String, List<String>>{
    'network': <String>['Sem conexão com o servidor.', 'No connection to the server.'],
    'invalid_url': <String>['Endereço inválido.', 'Invalid address.'],
    'server_not_found': <String>['Rede não encontrada.', 'Network not found.'],
    'Unauthorized': <String>['Sua sessão expirou. Entre novamente.', 'Your session expired. Sign in again.'],
    'operation failed': <String>['Sua sessão expirou. Entre novamente.', 'Your session expired. Sign in again.'],
    'RATE_LIMIT_EXCEEDED': <String>['Muitos pedidos. Aguarde um instante.', 'Too many requests. Wait a moment.'],
    'NOT_FOUND': <String>['Recurso não disponível nesta rede (atualize o servidor).', 'Not available on this network (update the server).'],
    'http_401': <String>['Sua sessão expirou. Entre novamente.', 'Your session expired. Sign in again.'],
    'invalid_credentials': <String>['Usuário ou senha incorretos.', 'Wrong username or password.'],
    'IP_LOCKED': <String>['Muitas tentativas. Aguarde alguns minutos.', 'Too many attempts. Wait a few minutes.'],
    'INVALID_USERNAME': <String>['Usuário inválido: 3 a 24 caracteres (letras, números, _ . -).', 'Invalid username: 3-24 characters (letters, numbers, _ . -).'],
    'INVALID_PASSWORD': <String>['Senha inválida: de 4 a 128 caracteres.', 'Invalid password: 4 to 128 characters.'],
    'Username already taken': <String>['Este usuário já existe.', 'This username is taken.'],
    'INVALID_AMOUNT': <String>['Valor inválido.', 'Invalid amount.'],
    'AMOUNT_TOO_SMALL': <String>['Valor muito pequeno.', 'Amount too small.'],
    'AMOUNT_REQUIRED': <String>['Informe o valor.', 'Enter the amount.'],
    'INVALID_TARGET': <String>['Conta de destino inválida.', 'Invalid destination account.'],
    'SELF_TRANSFER': <String>['Você não pode enviar para você mesmo.', 'You cannot send to yourself.'],
    'INSUFFICIENT_FUNDS': <String>['Saldo insuficiente.', 'Insufficient balance.'],
    'TRANSFER_COOLDOWN': <String>['Aguarde um segundo entre transferências.', 'Wait a second between transfers.'],
    'COOLDOWN_ACTIVE': <String>['O resgate ainda não está disponível.', 'The claim is not available yet.'],
    'Cooldown active': <String>['O resgate ainda não está disponível.', 'The claim is not available yet.'],
    'MAX_SUPPLY_REACHED': <String>['A emissão máxima da moeda foi atingida.', 'The maximum supply was reached.'],
    'BILL_NOT_FOUND': <String>['Cobrança não encontrada (talvez já paga).', 'Bill not found (maybe already paid).'],
    'BILL_EXPIRED': <String>['Esta cobrança expirou.', 'This bill expired.'],
    'CARD_NOT_FOUND': <String>['Cartão não encontrado.', 'Card not found.'],
    'BACKUP_NOT_FOUND': <String>['Código de backup não encontrado.', 'Backup code not found.'],
    'BACKUP_SAME_ACCOUNT': <String>['Este código é desta mesma conta.', 'This code belongs to this same account.'],
    'BACKUP_EMPTY': <String>['A carteira deste backup está vazia.', 'The wallet of this backup is empty.'],
    'EMPTY_WALLET': <String>['Sua carteira está vazia: não há o que guardar em backup.', 'Your wallet is empty: nothing to back up.'],
    'INVALID_TRANSACTION': <String>['Transação não encontrada.', 'Transaction not found.'],
    'PAYREQ_NOT_FOUND': <String>['Cobrança não encontrada.', 'Request not found.'],
    'PAYREQ_PAID': <String>['Esta cobrança já foi paga.', 'This request was already paid.'],
    'PAYREQ_CANCELLED': <String>['Esta cobrança foi cancelada.', 'This request was cancelled.'],
    'PAYREQ_CLOSED': <String>['Esta cobrança está encerrada.', 'This request is closed.'],
    'PAYREQ_EXPIRED': <String>['Esta cobrança expirou.', 'This request expired.'],
    'INVALID_TIME': <String>['Prazo inválido.', 'Invalid time.'],
    'TOO_MANY_REQUESTS': <String>['Muitos pedidos. Aguarde um pouco.', 'Too many requests. Please wait.'],
    'QUEUE_FULL': <String>['Servidor ocupado. Tente de novo.', 'Server busy. Try again.'],
    'QUEUE_TIMEOUT': <String>['O servidor demorou para responder.', 'The server took too long to respond.'],
    'REGISTRATION_CLOSED': <String>['Esta rede não aceita novas contas.', 'This network does not accept new accounts.'],
    'Internal error': <String>['Erro interno do servidor.', 'Internal server error.'],
    'cancelled': <String>['Cancelado.', 'Cancelled.'],
    'no_lock': <String>['Configure um bloqueio de tela (digital, PIN ou padrão) no Android para usar isto.', 'Set up a screen lock (fingerprint, PIN or pattern) on Android to use this.'],
    'account_not_found': <String>['Conta salva não encontrada.', 'Saved account not found.'],
    'vault_error': <String>['Não foi possível ler a conta salva. Entre com a senha.', 'Could not read the saved account. Sign in with your password.'],
    'scanner_unavailable': <String>['Leitor de QR indisponível neste aparelho.', 'QR scanner unavailable on this device.'],
    'no_route': <String>['Essa pessoa não está na mesma rede local agora.', 'This person is not on the same local network right now.'],
    'no_app': <String>['Nenhum app para abrir isto.', 'No app to open this.'],
    'unsupported': <String>['Recurso indisponível neste aparelho.', 'Feature unavailable on this device.'],
    'save_failed': <String>['Não foi possível salvar o arquivo.', 'Could not save the file.'],
  };

  /// Mensagem amigável para um código de erro da API
  static String err(String code, [Map<String, dynamic>? data]) {
    final List<String>? m = _errors[code];
    if (m != null) return pt ? m[0] : m[1];
    if (code.startsWith('Block:')) return t('Limite de contas por IP/aparelho atingido. Tente mais tarde.', 'Account limit per IP/device reached. Try later.');
    if (code.startsWith('IP blocked')) return t('Muitas tentativas. Aguarde alguns minutos.', 'Too many attempts. Wait a few minutes.');
    if (code.startsWith('http_5')) return t('O servidor está com problemas agora.', 'The server is having trouble right now.');
    if (code.startsWith('http_404')) return t('Recurso não disponível nesta rede.', 'Not available on this network.');
    final dynamic msg = data == null ? null : data['message'];
    if (msg is String && msg.isNotEmpty) return msg;
    return code;
  }
}
