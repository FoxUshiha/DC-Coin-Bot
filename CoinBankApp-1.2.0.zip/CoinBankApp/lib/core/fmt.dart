import 'i18n.dart';

/// Formatação: valores (inteiros em sats → 8, 2 ou 0 casas), datas e tempos, no padrão do idioma ativo.
/// Moeda de uma rede: casas da API, casas exibidas, nome e ícone (base64).
class NetCfg {
  const NetCfg(this.api, this.disp, this.coin, this.icon);
  final int api;
  final int disp;
  final String coin;
  final String icon;
}

/// Formatação: valores inteiros na menor unidade da moeda; cada rede tem as casas da API e as casas exibidas.
/// Exibir só muda ONDE fica a vírgula, contando da direita — nada é cortado:
/// 12 unidades → 8 casas: 0,00000012 · 2 casas: 0,12 · inteiro: 12. O que se digita usa as mesmas casas exibidas.
class F {
  F._();

  static const int sats = 100000000;

  /// configuração por rede (vem do Android) e a rede ativa
  static Map<String, NetCfg> nets = <String, NetCfg>{};
  static String active = 'main';

  static NetCfg cfg([String? net]) => nets[net ?? active] ?? const NetCfg(8, 8, 'Coin', '');

  /// casas exibidas da rede ativa
  static int get decimals => cfg().disp;

  /// nome da unidade ("coins" na rede principal)
  static String unit([String? net]) {
    final String c = cfg(net).coin.trim();
    return c.isEmpty || c.toLowerCase() == 'coin' ? 'coins' : c;
  }

  static int _pow10(int d) {
    int b = 1;
    for (int i = 0; i < d; i++) {
      b *= 10;
    }
    return b;
  }

  static String _group(String intPart) {
    final StringBuffer b = StringBuffer();
    final String sep = L.pt ? '.' : ',';
    for (int i = 0; i < intPart.length; i++) {
      if (i > 0 && (intPart.length - i) % 3 == 0) b.write(sep);
      b.write(intPart[i]);
    }
    return b.toString();
  }

  /// unidades → texto com as casas exibidas da rede (ou `dec`)
  static String coins(int value, {int? dec, bool sign = false, String? net}) {
    final int d = (dec ?? cfg(net).disp).clamp(0, 18);
    final bool neg = value < 0;
    final int v = value.abs();
    final int base = _pow10(d);
    final String ip = (v ~/ base).toString();
    final String frac = d == 0 ? '' : (v % base).toString().padLeft(d, '0');
    final String out = _group(ip) + (frac.isEmpty ? '' : (L.pt ? ',' : '.') + frac);
    if (neg) return '−$out';
    return sign && v > 0 ? '+$out' : out;
  }

  /// unidades → valor no formato da API da rede (ponto decimal, casas da API)
  static String api(int value, [String? net]) {
    final int d = cfg(net).api.clamp(0, 18);
    if (d == 0) return value.toString();
    final int base = _pow10(d);
    return '${value ~/ base}.${(value % base).toString().padLeft(d, '0')}';
  }

  static int? _parseDec(String input, int d, {bool strict = true}) {
    String s = input.trim().replaceAll(' ', '');
    if (s.isEmpty) return null;
    if (s.contains(',') && s.contains('.')) {
      if (s.lastIndexOf(',') > s.lastIndexOf('.')) {
        s = s.replaceAll('.', '').replaceAll(',', '.');
      } else {
        s = s.replaceAll(',', '');
      }
    } else {
      s = s.replaceAll(',', '.');
    }
    if (!RegExp(r'^\d+(\.\d+)?$').hasMatch(s) && !RegExp(r'^\.\d+$').hasMatch(s)) return null;
    final List<String> p = s.split('.');
    final String ip = p[0].isEmpty ? '0' : p[0];
    String fr = p.length > 1 ? p[1] : '';
    if (fr.length > d) {
      if (strict) return null;
      fr = fr.substring(0, d); // trunca, nunca arredonda
    }
    fr = fr.padRight(d, '0');
    final int? a = int.tryParse(ip);
    final int? b = d == 0 ? 0 : int.tryParse(fr);
    if (a == null || b == null) return null;
    return a * _pow10(d) + b;
  }

  /// o que o usuário digita (nas casas exibidas da rede) → unidades. null se inválido ou com casas demais.
  static int? parse(String input, [String? net]) => _parseDec(input, cfg(net).disp.clamp(0, 18));

  /// valor vindo da API (texto/número, casas da API da rede) → unidades
  static int? parseApi(dynamic v, [String? net]) {
    if (v == null) return null;
    final int d = cfg(net).api.clamp(0, 18);
    if (v is int) return v * _pow10(d);
    final String s = v is num ? _numStr(v) : v.toString();
    return _parseDec(s, d, strict: false);
  }

  static String _numStr(num v) {
    final String s = v.toString();
    if (!s.contains('e') && !s.contains('E')) return s;
    return v.toStringAsFixed(18).replaceFirst(RegExp(r'0+$'), '');
  }

  /// unidades de um objeto da API: prefere os campos inteiros (…Sats), senão converte o texto/número da API
  static int satsOf(dynamic m, String satsKey, String coinKey, [String? net]) {
    if (m is Map) {
      final dynamic s = m[satsKey];
      if (s is int) return s;
      if (s is num) return s.round();
      if (s is String && int.tryParse(s) != null) return int.parse(s);
      return parseApi(m[coinKey], net) ?? 0;
    }
    return 0;
  }

  static String _two(int v) => v < 10 ? '0$v' : '$v';

  static DateTime? parseDate(dynamic v) {
    if (v == null) return null;
    if (v is int) return DateTime.fromMillisecondsSinceEpoch(v);
    if (v is num) return DateTime.fromMillisecondsSinceEpoch(v.toInt());
    final String s = v.toString();
    final int? n = int.tryParse(s);
    if (n != null) return DateTime.fromMillisecondsSinceEpoch(n);
    final DateTime? d = DateTime.tryParse(s);
    return d?.toLocal();
  }

  static String date(DateTime d) => L.pt ? '${_two(d.day)}/${_two(d.month)}/${d.year}' : '${d.year}-${_two(d.month)}-${_two(d.day)}';
  static String time(DateTime d) => '${_two(d.hour)}:${_two(d.minute)}';
  static String dateTime(DateTime d) => '${date(d)} ${time(d)}';

  static const List<String> _mPt = <String>['jan', 'fev', 'mar', 'abr', 'mai', 'jun', 'jul', 'ago', 'set', 'out', 'nov', 'dez'];
  static const List<String> _mEn = <String>['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

  static String dayLabel(DateTime d) {
    final DateTime now = DateTime.now();
    final DateTime a = DateTime(now.year, now.month, now.day);
    final DateTime b = DateTime(d.year, d.month, d.day);
    final int diff = a.difference(b).inDays;
    if (diff == 0) return L.t('Hoje', 'Today');
    if (diff == 1) return L.t('Ontem', 'Yesterday');
    final String m = L.pt ? _mPt[d.month - 1] : _mEn[d.month - 1];
    final String y = d.year == now.year ? '' : ' ${d.year}';
    return L.pt ? '${d.day} de $m$y' : '$m ${d.day}$y';
  }

  static String shortDay(DateTime d) => L.pt ? '${_two(d.day)}/${_two(d.month)}' : '${_two(d.month)}/${_two(d.day)}';

  static String ago(DateTime d) {
    final int s = DateTime.now().difference(d).inSeconds;
    if (s < 45) return L.t('agora', 'now');
    if (s < 3600) return L.t('há ${s ~/ 60} min', '${s ~/ 60} min ago');
    if (s < 86400) return L.t('há ${s ~/ 3600} h', '${s ~/ 3600} h ago');
    if (s < 86400 * 7) return L.t('há ${s ~/ 86400} d', '${s ~/ 86400} d ago');
    return date(d);
  }

  /// contagem regressiva: 59:07 · 1:02:33 · 2d 03h
  static String countdown(int ms) {
    if (ms <= 0) return '0:00';
    final int s = (ms / 1000).ceil();
    final int d = s ~/ 86400, h = (s % 86400) ~/ 3600, m = (s % 3600) ~/ 60, sec = s % 60;
    if (d > 0) return '${d}d ${_two(h)}h';
    if (h > 0) return '$h:${_two(m)}:${_two(sec)}';
    return '$m:${_two(sec)}';
  }

  static String duration(int ms) {
    final int s = ms ~/ 1000;
    if (s < 60) return '${s}s';
    if (s < 3600) return '${s ~/ 60} min';
    if (s < 86400) return '${s ~/ 3600} h${s % 3600 >= 60 ? ' ${(s % 3600) ~/ 60} min' : ''}';
    return '${s ~/ 86400} d';
  }

  static String bytes(num b) {
    final double v = b.toDouble();
    String d(double x, int n) => L.pt ? x.toStringAsFixed(n).replaceAll('.', ',') : x.toStringAsFixed(n);
    if (v < 1024) return '${v.toStringAsFixed(0)} B';
    if (v < 1048576) return '${d(v / 1024, 1)} KB';
    if (v < 1073741824) return '${d(v / 1048576, 1)} MB';
    return '${d(v / 1073741824, 2)} GB';
  }

  static String integer(num v) => _group(v.round().abs().toString());

  /// encurta ids longos: 1234…7890
  static String short(String id, [int keep = 6]) => id.length <= keep * 2 + 1 ? id : '${id.substring(0, keep)}…${id.substring(id.length - keep)}';
}
