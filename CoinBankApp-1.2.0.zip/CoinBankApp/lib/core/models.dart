import 'fmt.dart';
import 'native.dart';

const String kSystemId = '000000000000';

/// Uma rede Coin (principal, adicionada ou hospedada neste aparelho).
class Server {
  Server(this.id, this.name, this.url, this.kind);
  factory Server.fromJson(J m) => Server(js(m, 'id'), js(m, 'name', 'Coin'), js(m, 'url'), js(m, 'kind', 'custom'));
  final String id;
  final String name;
  final String url;
  final String kind; // main | custom | host

  bool get isMain => kind == 'main';
  bool get isHost => kind == 'host';
  String get host {
    final Uri? u = Uri.tryParse(url);
    if (u == null || u.host.isEmpty) return url;
    return u.hasPort && u.port != 80 && u.port != 443 ? '${u.host}:${u.port}' : u.host;
  }
}

/// Transação do extrato (aceita o formato da lista e o de /api/tx/:id).
class Tx {
  Tx({required this.id, required this.date, required this.from, required this.to, required this.sats, required this.type});

  factory Tx.fromJson(J m) {
    final String from = m.containsKey('from_id') ? js(m, 'from_id') : js(m, 'from');
    final String to = m.containsKey('to_id') ? js(m, 'to_id') : js(m, 'to');
    int s = F.satsOf(m, 'amountSats', 'amountCoins');
    if (s == 0) s = F.satsOf(m, 'amountSats', 'amount');
    return Tx(
      id: js(m, 'id'),
      date: F.parseDate(m['date']) ?? DateTime.now(),
      from: from,
      to: to,
      sats: s,
      type: js(m, 'type', from == kSystemId ? 'claim' : 'transfer'),
    );
  }

  final String id;
  final DateTime date;
  final String from;
  final String to;
  final int sats;
  final String type;

  bool get isClaim => type == 'claim' || from == kSystemId;
  bool incoming(String me) => to == me && from != me;
  String other(String me) => incoming(me) ? from : to;

  J toJson() => <String, dynamic>{'id': id, 'date': date.toUtc().toIso8601String(), 'from': from, 'to': to, 'amountSats': sats, 'type': isClaim ? 'claim' : 'transfer'};
}

/// Cobrança (bill): `from` = quem deve pagar (pode ser vazio = qualquer um), `to` = quem recebe.
class Bill {
  Bill({required this.id, required this.from, required this.to, required this.sats, required this.date, this.expiresAt});
  factory Bill.fromJson(J m) => Bill(
        id: js(m, 'id', js(m, 'billId')),
        from: js(m, 'from_id', js(m, 'from')),
        to: js(m, 'to_id', js(m, 'to')),
        sats: F.satsOf(m, 'amountSats', 'amount'),
        date: F.parseDate(m['date']) ?? DateTime.now(),
        expiresAt: F.parseDate(m['expiresAt']),
      );
  final String id;
  final String from;
  final String to;
  final int sats;
  final DateTime date;
  final DateTime? expiresAt;
}

/// Pedido de pagamento por QR (cobrança tipo PIX).
class PayReq {
  PayReq(this.raw);
  final J raw;
  String get id => js(raw, 'id');
  String get to => js(raw, 'to');
  String get toName => js(raw, 'toName');
  int? get sats => raw['amountSats'] == null && raw['amount'] == null ? null : F.satsOf(raw, 'amountSats', 'amount');
  bool get open => jb(raw, 'open', sats == null);
  String get memo => js(raw, 'memo');
  bool get reusable => jb(raw, 'reusable');
  String get status => js(raw, 'status', 'open');
  int get paidCount => ji(raw, 'paidCount');
  int get paidTotal => F.satsOf(raw, 'paidTotalSats', 'paidTotal');
  String get lastTx => js(raw, 'lastTx');
  String get lastPayer => js(raw, 'lastPayer');
  String get url => js(raw, 'url');
  DateTime? get expiresAt => F.parseDate(raw['expiresAt']);
  bool get isOpen => status == 'open';
}

/// Alguém (ou uma rede) por perto.
class Peer {
  Peer(this.raw);
  final J raw;
  String get device => js(raw, 'id');
  J get me => jm(raw, 'me');
  J get host => jm(raw, 'host');
  bool get hasMe => js(me, 'uid').isNotEmpty;
  bool get hasHost => js(host, 'url').isNotEmpty;
  String get uid => js(me, 'uid');
  String get name => js(me, 'name');
  String get net => js(me, 'net');
  String get netName => js(me, 'netName');
  String get ip => js(raw, 'ip');
  List<String> get via => jsl(raw, 'via');
  bool get reachable => ip.isNotEmpty;
}
