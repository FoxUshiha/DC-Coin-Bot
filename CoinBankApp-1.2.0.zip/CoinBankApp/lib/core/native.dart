import 'dart:async';
import 'dart:convert';

import 'package:flutter/services.dart';

import 'i18n.dart';

typedef J = Map<String, dynamic>;

/// Erro vindo da API ({error: CODE}) ou da parte nativa.
class ApiException implements Exception {
  ApiException(this.code, this.status, this.data);
  final String code;
  final int status;
  final J data;

  bool get isNetwork => code == 'network' || status == 0 && code == 'network';
  String get message => L.err(code, data);

  @override
  String toString() => message;
}

// ───────── leitura segura de JSON ─────────
String js(dynamic m, String k, [String d = '']) {
  if (m is Map) {
    final dynamic v = m[k];
    if (v == null) return d;
    return v is String ? v : v.toString();
  }
  return d;
}

double jn(dynamic m, String k, [double d = 0]) {
  if (m is Map) {
    final dynamic v = m[k];
    if (v is num) return v.toDouble();
    if (v is String) return double.tryParse(v) ?? d;
  }
  return d;
}

int ji(dynamic m, String k, [int d = 0]) {
  if (m is Map) {
    final dynamic v = m[k];
    if (v is int) return v;
    if (v is num) return v.toInt();
    if (v is String) return int.tryParse(v) ?? d;
  }
  return d;
}

bool jb(dynamic m, String k, [bool d = false]) {
  if (m is Map) {
    final dynamic v = m[k];
    if (v is bool) return v;
    if (v is num) return v != 0;
    if (v is String) return v == 'true' || v == '1';
  }
  return d;
}

J jm(dynamic m, String k) {
  if (m is Map) {
    final dynamic v = m[k];
    if (v is Map) return v.cast<String, dynamic>();
  }
  return <String, dynamic>{};
}

List<J> jl(dynamic m, String k) {
  if (m is Map) {
    final dynamic v = m[k];
    if (v is List) {
      return v.whereType<Map<dynamic, dynamic>>().map((Map<dynamic, dynamic> e) => e.cast<String, dynamic>()).toList();
    }
  }
  return <J>[];
}

List<String> jsl(dynamic m, String k) {
  if (m is Map) {
    final dynamic v = m[k];
    if (v is List) return v.map((dynamic e) => e.toString()).toList();
  }
  return <String>[];
}

bool jnull(dynamic m, String k) => !(m is Map) || m[k] == null;

J decodeJ(String? s) {
  if (s == null || s.isEmpty) return <String, dynamic>{};
  try {
    final dynamic d = jsonDecode(s);
    if (d is Map) return d.cast<String, dynamic>();
    if (d is List) return <String, dynamic>{'items': d};
  } catch (_) {}
  return <String, dynamic>{'text': s};
}

/// Ponte com o código Android (Kotlin): API das redes, sessão, QR, NFC, por perto, comprovantes, rede hospedada…
class Native {
  Native._();
  static const MethodChannel _ch = MethodChannel('coinbank/core');
  static const EventChannel _ev = EventChannel('coinbank/events');
  static Stream<J>? _events;

  static Future<J> call(String method, [Map<String, dynamic>? args]) async {
    String? s;
    try {
      s = await _ch.invokeMethod<String>(method, args);
    } on PlatformException catch (e) {
      throw ApiException(e.code, 0, <String, dynamic>{'detail': e.message ?? ''});
    } on MissingPluginException {
      throw ApiException('unsupported', 0, <String, dynamic>{});
    }
    final J j = decodeJ(s);
    if (j['ok'] == false) {
      throw ApiException(js(j, 'error', 'error'), ji(j, 'status'), j);
    }
    return j;
  }

  /// Chamada JSON a qualquer endpoint de uma rede (com a sessão dela). Devolve o corpo já decodificado.
  static Future<J> api(String server, String method, String path, {Object? body, bool noAuth = false}) async {
    final J r = await call('api', <String, dynamic>{
      'server': server,
      'method': method,
      'path': path,
      'body': body == null ? null : jsonEncode(body),
      'noAuth': noAuth,
    });
    final J b = decodeJ(js(r, 'body'));
    b['_ms'] = ji(r, 'ms');
    return b;
  }

  static Stream<J> events() {
    _events ??= _ev.receiveBroadcastStream().map((dynamic e) => decodeJ(e is String ? e : '{}')).asBroadcastStream();
    return _events!;
  }
}

String jsonString(Object? o) => jsonEncode(o);
