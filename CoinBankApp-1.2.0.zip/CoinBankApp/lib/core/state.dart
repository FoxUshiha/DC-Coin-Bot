import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';

import 'fmt.dart';
import 'i18n.dart';
import 'models.dart';
import 'native.dart';

/// Aviso mostrado como banner dentro do app (pagamento recebido, cobrança nova…).
class Notice {
  Notice(this.title, this.text, {this.route, this.kind = 'info'});
  final String title;
  final String text;
  final String? route;
  final String kind;
}

/// Estado global: configurações, redes, sessões, carteira da rede ativa e eventos vindos do Android.
/// A tela atualiza a cada 2 s (contagens, "há x min") e a API é consultada a cada 5 s (saldo, extrato, cobranças).
class AppState extends ChangeNotifier {
  AppState._();
  static final AppState I = AppState._();

  bool ready = false;
  bool online = true;
  String version = '';
  String device = '';
  J bio = <String, dynamic>{};
  String nfc = 'unsupported';

  J settings = <String, dynamic>{};
  List<Server> servers = <Server>[];
  Map<String, J> sessions = <String, J>{};
  List<J> accounts = <J>[];
  String activeId = 'main';

  // ── carteira da rede ativa
  int? balance;
  J me = <String, dynamic>{};
  List<Tx> txs = <Tx>[];
  int txPage = 1;
  bool txMore = true;
  bool txLoading = false;
  List<Bill> toPay = <Bill>[];
  List<Bill> toReceive = <Bill>[];
  int claimRemainingMs = -1;
  DateTime claimFetchedAt = DateTime.now();
  int claimAmountSats = 12;
  int claimCooldownMs = 3600000;
  String? cardCode;
  bool reachable = true;
  DateTime? lastSync;
  String? lastError;
  bool _meSupported = true;
  bool _syncing = false;

  final ValueNotifier<int> tick = ValueNotifier<int>(0);
  final ValueNotifier<int> nearbyTick = ValueNotifier<int>(0);
  final ValueNotifier<int> hostTick = ValueNotifier<int>(0);
  final ValueNotifier<String?> routeRequest = ValueNotifier<String?>(null);
  final ValueNotifier<Notice?> notice = ValueNotifier<Notice?>(null);
  final StreamController<J> nearbyMessages = StreamController<J>.broadcast();
  final StreamController<String> nfcPayloads = StreamController<String>.broadcast();

  StreamSubscription<J>? _sub;
  Timer? _ui;
  Timer? _poll;
  String? pendingRoute;

  // ───────────────────────── leitura rápida ─────────────────────────
  Server get active => servers.firstWhere((Server s) => s.id == activeId, orElse: () => servers.isNotEmpty ? servers.first : Server('main', 'Coin Bank', 'https://bank.foxsrv.net', 'main'));
  Server? serverById(String id) {
    for (final Server s in servers) {
      if (s.id == id) return s;
    }
    return null;
  }

  J? sessionOf(String id) => sessions[id];
  bool get loggedIn => sessions[activeId] != null;
  String get userId => js(sessions[activeId], 'userId');
  String get username => js(sessions[activeId], 'username', js(me, 'username'));
  int get decimals => F.cfg(activeId).disp;
  bool get hideCardDefault => jb(settings, 'hideCard', true);
  bool get hideBalance => jb(settings, 'hideBalance');
  bool get autoClaim => jb(settings, 'autoClaim');
  String get mainUrl => js(settings, 'mainUrl', 'https://bank.foxsrv.net');
  ThemeMode get themeMode {
    final String t = js(settings, 'theme', 'system');
    return t == 'light' ? ThemeMode.light : (t == 'dark' ? ThemeMode.dark : ThemeMode.system);
  }

  String get langChoice => js(settings, 'lang', 'auto');

  /// tempo restante do resgate, descontando o tempo desde a última consulta
  int get claimLeft {
    if (claimRemainingMs < 0) return -1;
    final int left = claimRemainingMs - DateTime.now().difference(claimFetchedAt).inMilliseconds;
    return left < 0 ? 0 : left;
  }

  bool get claimReady => claimLeft == 0;

  /// sem internet ou rede fora do ar: o app abre normalmente, só não mostra saldos
  bool get canShowMoney => online && reachable && balance != null;

  // ───────────────────────── início ─────────────────────────
  Future<void> boot() async {
    try {
      final J r = await Native.call('init');
      _applyState(r);
      online = jb(r, 'online', true);
      version = js(r, 'version');
      device = js(r, 'device');
      bio = jm(r, 'bio');
      nfc = js(r, 'nfc', 'unsupported');
      final String route = js(r, 'route');
      if (route.isNotEmpty) pendingRoute = route;
    } catch (_) {
      servers = <Server>[Server('main', 'Coin Bank', 'https://bank.foxsrv.net', 'main')];
    }
    _sub ??= Native.events().listen(_onEvent);
    ready = true;
    notifyListeners();
    _ui ??= Timer.periodic(const Duration(seconds: 2), (_) => tick.value++);
    _poll ??= Timer.periodic(const Duration(seconds: 5), (_) => sync());
    if (loggedIn) unawaited(refreshAll());
  }

  void _applyState(J r) {
    final J st = r.containsKey('settings') ? r : jm(r, 'state');
    if (st.isEmpty) return;
    settings = jm(st, 'settings');
    servers = jl(st, 'servers').map(Server.fromJson).toList();
    final J ses = jm(st, 'sessions');
    sessions = <String, J>{};
    for (final String k in ses.keys) {
      sessions[k] = jm(ses, k);
    }
    accounts = jl(st, 'accounts');
    final String a = js(st, 'active', activeId);
    if (a != activeId) _resetWallet();
    activeId = a;
    L.apply(langChoice);
    final J nc = jm(st, 'netcfg');
    if (nc.isNotEmpty) {
      final Map<String, NetCfg> m = <String, NetCfg>{};
      for (final String k in nc.keys) {
        final J c = jm(nc, k);
        m[k] = NetCfg(ji(c, 'api', 8), ji(c, 'disp', 8), js(c, 'coin', 'Coin'), js(c, 'icon'));
      }
      F.nets = m;
    }
    F.active = activeId;
  }

  /// casas exibidas, casas da API, nome e ícone da moeda de uma rede (salvo por rede no aparelho)
  Future<void> setNetCfg(String id, J patch) async {
    final NetCfg o = F.cfg(id);
    F.nets = <String, NetCfg>{
      ...F.nets,
      id: NetCfg(ji(patch, 'api', o.api), ji(patch, 'disp', o.disp), patch.containsKey('coin') ? js(patch, 'coin') : o.coin, patch.containsKey('icon') ? js(patch, 'icon') : o.icon),
    };
    notifyListeners();
    try {
      _applyState(await Native.call('netcfg.set', <String, dynamic>{'id': id, 'patch': jsonEncode(patch)}));
      notifyListeners();
    } catch (_) {}
  }

  void _resetWallet() {
    balance = null;
    me = <String, dynamic>{};
    txs = <Tx>[];
    txPage = 1;
    txMore = true;
    toPay = <Bill>[];
    toReceive = <Bill>[];
    claimRemainingMs = -1;
    cardCode = null;
    lastSync = null;
    reachable = true;
    _meSupported = true;
  }

  Future<void> reloadState() async {
    try {
      _applyState(await Native.call('state'));
      notifyListeners();
    } catch (_) {}
  }

  void _onEvent(J e) {
    switch (js(e, 'type')) {
      case 'net':
        final bool v = jb(e, 'online', true);
        if (v != online) {
          online = v;
          if (!v) balance = null;
          notifyListeners();
          if (v && loggedIn) unawaited(refreshAll());
        }
        break;
      case 'route':
        final String r = js(e, 'route');
        if (r.isNotEmpty) {
          pendingRoute = r;
          routeRequest.value = r;
        }
        break;
      case 'refresh':
        if (js(e, 'server') == activeId) unawaited(refreshAll());
        break;
      case 'claimed':
        if (js(e, 'server') == activeId) unawaited(refreshAll());
        break;
      case 'notify':
        notice.value = Notice(js(e, 'title'), js(e, 'text'), route: js(e, 'route'), kind: js(e, 'kind'));
        unawaited(refreshAll());
        break;
      case 'nearby':
        nearbyTick.value++;
        break;
      case 'nearbyMsg':
        nearbyMessages.add(e);
        break;
      case 'nfc':
        final String p = js(e, 'payload');
        if (p.isNotEmpty) nfcPayloads.add(p);
        break;
      case 'host':
        hostTick.value++;
        break;
      case 'session':
        unawaited(reloadState().then((_) {
          if (js(e, 'server') == activeId && !loggedIn) _resetWallet();
          notifyListeners();
        }));
        break;
    }
  }

  // ───────────────────────── API da rede ativa ─────────────────────────
  Future<J> api(String method, String path, [Object? body]) => Native.api(activeId, method, path, body: body);
  Future<J> apiOn(String server, String method, String path, [Object? body]) => Native.api(server, method, path, body: body);

  /// consulta periódica (5 s) — leve: saldo/resgate e a primeira página do extrato e das cobranças
  Future<void> sync() async {
    if (!ready || !loggedIn || !online || _syncing) return;
    await refreshAll(quiet: true);
  }

  Future<void> refreshAll({bool quiet = false}) async {
    if (!loggedIn) return;
    if (_syncing && quiet) return;
    _syncing = true;
    final String sid = activeId;
    try {
      await _refreshMe(sid);
      if (sid != activeId) return;
      await Future.wait(<Future<void>>[_refreshTx(sid), _refreshBills(sid)]);
      if (cardCode == null) unawaited(loadCard());
      reachable = true;
      lastError = null;
      lastSync = DateTime.now();
    } on ApiException catch (e) {
      if (e.isNetwork || e.status == 0) {
        reachable = false;
        balance = null;
      }
      lastError = e.message;
    } catch (e) {
      lastError = e.toString();
    } finally {
      _syncing = false;
      notifyListeners();
    }
  }

  Future<void> _refreshMe(String sid) async {
    if (_meSupported) {
      try {
        final J r = await apiOn(sid, 'GET', '/api/me');
        if (sid != activeId) return;
        me = r;
        balance = F.satsOf(r, 'sats', 'coins');
        final J c = jm(r, 'claim');
        _applyClaim(c.isNotEmpty ? c : r);
        return;
      } on ApiException catch (e) {
        if (e.status == 404) {
          _meSupported = false;
        } else {
          rethrow;
        }
      }
    }
    final J b = await apiOn(sid, 'GET', '/api/user/$userId/balance');
    if (sid != activeId) return;
    balance = F.satsOf(b, 'sats', 'coins');
    try {
      _applyClaim(await apiOn(sid, 'GET', '/api/claim/status'));
    } catch (_) {}
  }

  void _applyClaim(J c) {
    if (c.containsKey('cooldownRemainingMs')) {
      claimRemainingMs = ji(c, 'cooldownRemainingMs');
      claimFetchedAt = DateTime.now();
    }
    if (c.containsKey('cooldownMs')) claimCooldownMs = ji(c, 'cooldownMs', claimCooldownMs);
    if (c.containsKey('claimAmountSats') || c.containsKey('claimAmount')) {
      final int s = F.satsOf(c, 'claimAmountSats', 'claimAmount');
      if (s > 0) claimAmountSats = s;
    }
  }

  Future<void> _refreshTx(String sid) async {
    final J r = await apiOn(sid, 'GET', '/api/transactions?page=1');
    if (sid != activeId) return;
    final List<Tx> first = jl(r, 'transactions').map(Tx.fromJson).toList();
    if (txs.isEmpty || txPage <= 1) {
      txs = first;
      txMore = first.length >= 20;
      txPage = 1;
    } else {
      // junta as novas no topo sem perder as páginas já carregadas
      final Set<String> have = txs.map((Tx t) => t.id).toSet();
      final List<Tx> fresh = first.where((Tx t) => !have.contains(t.id)).toList();
      if (fresh.isNotEmpty) txs = <Tx>[...fresh, ...txs];
    }
  }

  Future<void> loadMoreTx() async {
    if (txLoading || !txMore || !loggedIn) return;
    txLoading = true;
    notifyListeners();
    final String sid = activeId;
    try {
      final J r = await apiOn(sid, 'GET', '/api/transactions?page=${txPage + 1}');
      if (sid != activeId) return;
      final List<Tx> more = jl(r, 'transactions').map(Tx.fromJson).toList();
      final Set<String> have = txs.map((Tx t) => t.id).toSet();
      txs = <Tx>[...txs, ...more.where((Tx t) => !have.contains(t.id))];
      txPage++;
      txMore = more.length >= 20;
    } catch (_) {
    } finally {
      txLoading = false;
      notifyListeners();
    }
  }

  Future<void> _refreshBills(String sid) async {
    try {
      final J r = await apiOn(sid, 'POST', '/api/bill/list', <String, dynamic>{'page': 1});
      if (sid != activeId) return;
      toPay = jl(r, 'toPay').map(Bill.fromJson).toList();
      toReceive = jl(r, 'toReceive').map(Bill.fromJson).toList();
    } on ApiException catch (e) {
      if (e.isNetwork) rethrow;
    }
  }

  Future<void> loadCard() async {
    try {
      final J r = await api('POST', '/api/card');
      final String c = js(r, 'cardCode');
      if (c.isNotEmpty) {
        cardCode = c;
        notifyListeners();
      }
    } catch (_) {}
  }

  Future<String> resetCard() async {
    final J r = await api('POST', '/api/card/reset');
    cardCode = js(r, 'newCode', cardCode ?? '');
    notifyListeners();
    return cardCode ?? '';
  }

  /// resgate (claim): devolve os sats recebidos
  Future<int> claim() async {
    try {
      final J r = await api('POST', '/api/claim');
      final int got = F.satsOf(r, 'claimedSats', 'claimed');
      claimRemainingMs = ji(r, 'nextClaimInMs', claimCooldownMs);
      claimFetchedAt = DateTime.now();
      notifyListeners();
      unawaited(refreshAll());
      return got;
    } on ApiException catch (e) {
      if (e.data.containsKey('nextClaimInMs')) {
        claimRemainingMs = ji(e.data, 'nextClaimInMs');
        claimFetchedAt = DateTime.now();
        notifyListeners();
      }
      rethrow;
    }
  }

  // ───────────────────────── configurações / redes ─────────────────────────
  Future<void> setSettings(J patch) async {
    settings = <String, dynamic>{...settings, ...patch};
    if (patch.containsKey('lang')) L.apply(langChoice);
    notifyListeners();
    try {
      final J r = await Native.call('settings.set', <String, dynamic>{'patch': jsonEncode(patch)});
      settings = jm(r, 'settings');
      L.apply(langChoice);
      notifyListeners();
    } catch (_) {}
  }

  Future<void> setActive(String id) async {
    if (id == activeId) return;
    final J r = await Native.call('servers.active', <String, dynamic>{'id': id});
    _resetWallet();
    _applyState(r);
    activeId = js(r, 'active', id);
    F.active = activeId;
    notifyListeners();
    if (loggedIn) unawaited(refreshAll());
  }

  Future<void> afterAuth(J r) async {
    _resetWallet();
    _applyState(jm(r, 'state'));
    final String s = js(r, 'server');
    if (s.isNotEmpty) {
      activeId = s;
      F.active = s;
    }
    notifyListeners();
    await refreshAll();
  }

  Future<void> login(String server, String user, String pass, {bool remember = false, bool useBio = false}) async {
    final J r = await Native.call('login', <String, dynamic>{'server': server, 'username': user, 'password': pass, 'remember': remember, 'bio': useBio});
    await afterAuth(r);
  }

  Future<void> register(String server, String user, String pass, {bool remember = false, bool useBio = false}) async {
    final J r = await Native.call('register', <String, dynamic>{'server': server, 'username': user, 'password': pass, 'remember': remember, 'bio': useBio});
    await afterAuth(r);
  }

  Future<void> loginSaved(String accountId) async {
    final J r = await Native.call('accounts.login', <String, dynamic>{'id': accountId});
    await afterAuth(r);
  }

  Future<void> logout() async {
    try {
      final J r = await Native.call('logout', <String, dynamic>{'server': activeId});
      _applyState(r);
    } catch (_) {
      sessions.remove(activeId);
    }
    _resetWallet();
    notifyListeners();
  }

  bool hasSavedAccount() {
    final String o = _origin(active.url);
    for (final J a in accounts) {
      if (_origin(js(a, 'server')) == o && js(a, 'userId') == userId) return true;
    }
    return false;
  }

  static String _origin(String u) {
    final Uri? x = Uri.tryParse(u);
    if (x == null) return u;
    return '${x.scheme}://${x.host}${x.hasPort && x.port != 80 && x.port != 443 ? ':${x.port}' : ''}'.toLowerCase();
  }

  Server? serverByUrl(String url) {
    final String o = _origin(url);
    for (final Server s in servers) {
      if (_origin(s.url) == o) return s;
    }
    return null;
  }
}
