import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter/services.dart';

import '../core/fmt.dart';
import '../core/i18n.dart';
import '../core/native.dart';
import '../core/state.dart';
import 'common.dart';
import 'theme.dart';

/// Abre o resgate em tela cheia. Só fecha pelo X ou pelo voltar do celular (as moedas têm física e podem ser
/// arrastadas pela tela toda, então tocar fora não fecha).
Future<void> openClaim(BuildContext context) {
  return showGeneralDialog<void>(
    context: context,
    barrierDismissible: false,
    barrierLabel: 'claim',
    barrierColor: Colors.black54,
    transitionDuration: const Duration(milliseconds: 260),
    pageBuilder: (BuildContext c, Animation<double> a, Animation<double> b) => const ClaimScreen(),
    transitionBuilder: (BuildContext c, Animation<double> a, Animation<double> b, Widget child) =>
        FadeTransition(opacity: a, child: ScaleTransition(scale: Tween<double>(begin: 0.96, end: 1).animate(CurvedAnimation(parent: a, curve: Curves.easeOutCubic)), child: child)),
  );
}

// ───────────────────────── física ─────────────────────────

const String _kCoin = 'assets/coin.png';
const String _kBack = 'assets/wallet_back.png';
const String _kFront = 'assets/wallet_front.png';

/// Medidas dos PNGs da carteira (350×350): corpo da frente x 34…316, topo da frente y 124, fundo y 313, topo do fundo y 106.
const double _png = 350;
const double _bodyL = 34, _bodyR = 316, _frontTop = 124, _bodyB = 313, _backTop = 106;

/// a moeda colorida ocupa um círculo de raio 0,474 do PNG
const double _coinFill = 0.474;

class _Box {
  const _Box(this.l, this.t, this.r, this.b);
  final double l, t, r, b;
  bool contains(Offset p) => p.dx >= l && p.dx <= r && p.dy >= t && p.dy <= b;
}

/// Geometria da carteira em coordenadas da tela.
class _Geo {
  _Geo(this.img) {
    final double k = img.width / _png;
    left = img.left + _bodyL * k;
    right = img.left + _bodyR * k;
    top = img.top + _frontTop * k;
    bottom = img.top + _bodyB * k;
    backTop = img.top + _backTop * k;
    rim = 12 * k;
    r = (right - left) * 0.135;
    final double baseTop = top + r * 2.25;
    boxes = <_Box>[
      _Box(left, top, left + rim, bottom), // parede esquerda
      _Box(right - rim, top, right, bottom), // parede direita
      _Box(left, baseTop, right, bottom), // corpo (fundo do bolso)
    ];
  }
  final Rect img;
  late final double left, right, top, bottom, backTop, rim, r;
  late final List<_Box> boxes;

  double get cx => (left + right) / 2;
  double get mouthL => left + rim;
  double get mouthR => right - rim;
  Offset get pivot => Offset(cx, bottom);
  Rect get body => Rect.fromLTRB(left, backTop, right, bottom);
  double get coinPx => r * 2 / (_coinFill * 2);
}

class _Coin {
  _Coin(this.p, {this.v = Offset.zero, this.g = 1, this.spin = 0, this.fromWallet = false});
  Offset p;
  Offset v;
  double g; // 1 = cai para baixo · -1 = dinheiro saindo (cai para cima)
  double a = 0;
  double spin;
  bool fromWallet; // saiu da carteira (conta no limite de moedinhas da carteira)
  bool front = false; // passa por cima de tudo, sem bater na carteira
  // segurada pelo dedo
  int? pointer;
  Offset finger = Offset.zero;
  final List<_Sample> hist = <_Sample>[];
  // meio para fora da boca da carteira
  bool peek = false;
  int slot = 0;
  double peekT = 0;
  bool peekBack = false; // voltando para dentro
  bool get held => pointer != null;
}

class _Sample {
  _Sample(this.t, this.p);
  final double t;
  final Offset p;
}

class _Pending {
  _Pending(this.at, this.coin);
  final double at;
  final _Coin coin;
}

class ClaimScreen extends StatefulWidget {
  const ClaimScreen({super.key});

  @override
  State<ClaimScreen> createState() => _ClaimScreenState();
}

class _ClaimScreenState extends State<ClaimScreen> with SingleTickerProviderStateMixin {
  static const double _gravity = 1450; // px/s²
  static const int _maxWalletCoins = 12;
  static const int _maxPeek = 6;

  final GlobalKey _slotKey = GlobalKey();
  final math.Random _rnd = math.Random();
  late final Ticker _ticker;
  Duration _last = Duration.zero;
  double _now = 0;

  _Geo? _geo;
  Size _screen = Size.zero;
  final List<_Coin> _coins = <_Coin>[];
  final List<_Pending> _pending = <_Pending>[];

  // carteira: chacoalhar, inclinar, tremidinha ao receber moeda
  double _shakeStart = -10;
  double _shakeDur = 0.5;
  double _shakeAmp = 0.07;
  double _shakeFreq = 4;
  double _tilt = 0;
  double _tiltTarget = 0;
  double _tiltHoldUntil = 0;
  double _bumpStart = -10;
  double _lastTap = -10;
  double _lastInteraction = 0;
  double _lastHaptic = 0;

  // resgate
  bool _busy = false;
  bool _claiming = false;
  int _got = 0;
  double _gotUntil = 0;

  // saldo observado (transferências recebidas/enviadas com o resgate aberto)
  int? _lastBal;
  String _lastNet = '';

  @override
  void initState() {
    super.initState();
    final AppState s = AppState.I;
    _lastNet = s.activeId;
    _lastBal = s.canShowMoney ? s.balance : null;
    s.addListener(_onState);
    _ticker = createTicker(_tick)..start();
    unawaited(s.refreshAll());
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    for (final String a in <String>[_kCoin, _kBack, _kFront]) {
      precacheImage(AssetImage(a), context);
    }
  }

  @override
  void dispose() {
    AppState.I.removeListener(_onState);
    _ticker.dispose();
    super.dispose();
  }

  // ───────────────────────── regras ─────────────────────────

  /// quantas moedinhas representam um valor: 1 moedinha = 1 unidade da última casa exibida (máx. 12, mín. 1)
  int _unitsOf(int amount) {
    if (amount <= 0) return 0;
    final NetCfg c = F.cfg();
    final int shift = math.max(0, c.api - c.disp);
    int div = 1;
    for (int i = 0; i < shift; i++) {
      div *= 10;
    }
    return (amount ~/ div).clamp(1, _maxWalletCoins);
  }

  int get _balanceUnits => AppState.I.canShowMoney ? _unitsOf(AppState.I.balance ?? 0) : 0;
  int get _walletOut => _coins.where((_Coin c) => c.fromWallet).length;

  void _onState() {
    final AppState s = AppState.I;
    final int? b = s.canShowMoney ? s.balance : null;
    if (s.activeId != _lastNet) {
      _lastNet = s.activeId;
      _lastBal = b;
      _coins.removeWhere((_Coin c) => c.fromWallet);
      return;
    }
    if (_claiming || b == null) return;
    final int? old = _lastBal;
    _lastBal = b;
    if (old == null || old == b) return;
    if (b > old) {
      _rain(_unitsOf(b - old));
    } else {
      _outgoing(_unitsOf(old - b));
    }
  }

  // ───────────────────────── animações ─────────────────────────

  void _shake({bool fast = false, double strength = 1}) {
    _shakeStart = _now;
    _shakeDur = fast ? 0.42 : 0.55;
    _shakeAmp = (fast ? 0.095 : 0.06) * strength;
    _shakeFreq = fast ? 6.5 : 4;
    if (strength >= 1) HapticFeedback.selectionClick();
  }

  double get _walletAngle {
    double a = _tilt;
    final double st = _now - _shakeStart;
    if (st >= 0 && st < _shakeDur) {
      final double k = st / _shakeDur;
      a += math.sin(k * _shakeFreq * 2 * math.pi) * _shakeAmp * (1 - k);
    }
    final double bt = _now - _bumpStart;
    if (bt >= 0 && bt < 0.25) a += math.sin(bt / 0.25 * math.pi * 2) * 0.025 * (1 - bt / 0.25);
    return a;
  }

  double get _walletDip {
    final double bt = _now - _bumpStart;
    return bt >= 0 && bt < 0.22 ? math.sin(bt / 0.22 * math.pi) * 3.5 : 0;
  }

  /// moedas do servidor caindo de fora da tela para dentro da carteira
  void _rain(int n) {
    final _Geo? g = _geo;
    if (n <= 0 || g == null) return;
    final double half = (g.mouthR - g.mouthL) / 2 - g.r;
    for (int i = 0; i < n; i++) {
      final _Coin c = _Coin(
        Offset(g.cx + (_rnd.nextDouble() * 2 - 1) * half * 0.75, -g.r - 8 - _rnd.nextDouble() * 24),
        v: Offset((_rnd.nextDouble() - 0.5) * 30, 60 + _rnd.nextDouble() * 40),
        spin: (_rnd.nextDouble() - 0.5) * 5,
      );
      c.a = _rnd.nextDouble() * math.pi;
      _pending.add(_Pending(_now + i * 0.15 + _rnd.nextDouble() * 0.05, c));
    }
  }

  /// dinheiro saindo: a carteira chacoalha sozinha e as moedinhas voam para cima até sumir
  void _outgoing(int n) {
    final _Geo? g = _geo;
    if (n <= 0 || g == null) return;
    _shake(fast: true);
    HapticFeedback.mediumImpact();
    final double half = (g.mouthR - g.mouthL) / 2 - g.r;
    for (int i = 0; i < n; i++) {
      final _Coin c = _Coin(
        Offset(g.cx + (_rnd.nextDouble() * 2 - 1) * half, g.top + g.r * 0.9),
        g: -1,
        v: Offset((_rnd.nextDouble() - 0.5) * 220, -(260 + _rnd.nextDouble() * 240)),
        spin: (_rnd.nextDouble() - 0.5) * 9,
      );
      _pending.add(_Pending(_now + 0.08 + i * 0.11, c));
    }
  }

  Offset _slotOffset(int slot) {
    final _Geo g = _geo!;
    final double maxOff = (g.mouthR - g.mouthL) / 2 - g.r * 1.02;
    final double step = _maxPeek > 1 ? (maxOff * 2) / (_maxPeek - 1) : 0;
    return Offset(-maxOff + step * slot, (slot.isEven ? 0 : 3.0));
  }

  int? _freeSlot() {
    final Set<int> used = _coins.where((_Coin c) => c.peek).map((_Coin c) => c.slot).toSet();
    final List<int> free = <int>[for (int i = 0; i < _maxPeek; i++) if (!used.contains(i)) i];
    if (free.isEmpty) return null;
    // perto do centro primeiro, com um pouco de acaso
    final Map<int, double> key = <int, double>{for (final int i in free) i: (i - (_maxPeek - 1) / 2).abs() + _rnd.nextDouble() * 1.6};
    free.sort((int a, int b) => key[a]!.compareTo(key[b]!));
    return free.first;
  }

  bool _spawnPeek({double delay = 0}) {
    if (_geo == null) return false;
    if (_walletOut >= math.min(_balanceUnits, _maxWalletCoins)) return false;
    if (_coins.where((_Coin c) => c.peek).length >= math.min(_balanceUnits, _maxPeek)) return false;
    final int? slot = _freeSlot();
    if (slot == null) return false;
    final _Coin c = _Coin(Offset.zero, fromWallet: true);
    c.peek = true;
    c.slot = slot;
    c.peekT = -delay / 0.4;
    c.a = (_rnd.nextDouble() - 0.5) * 0.5;
    _coins.add(c);
    _place(c);
    return true;
  }

  /// posição da moedinha meio para fora (gira junto com a carteira)
  void _place(_Coin c) {
    final _Geo g = _geo!;
    final double t = c.peekT.clamp(0.0, 1.0);
    final double e = c.peekBack ? Curves.easeIn.transform(t) : Curves.easeOutBack.transform(t);
    final Offset o = _slotOffset(c.slot);
    final double st = _now - _shakeStart;
    final double jig = st >= 0 && st < _shakeDur ? -math.sin(st / _shakeDur * math.pi) * 6 * (1 - st / _shakeDur) * (c.slot.isEven ? 1 : 0.6) : 0;
    final Offset local = Offset(g.cx + o.dx, g.top + g.r * 1.1 - e * g.r * 1.1 + o.dy + jig + _walletDip);
    c.p = _rotate(local, g.pivot, _walletAngle);
  }

  Offset _rotate(Offset p, Offset o, double a) {
    if (a == 0) return p;
    final double s = math.sin(a), co = math.cos(a);
    final Offset d = p - o;
    return o + Offset(d.dx * co - d.dy * s, d.dx * s + d.dy * co);
  }

  void _popPeek(_Coin c) {
    final _Geo g = _geo!;
    c.peek = false;
    final double side = (c.p.dx - g.cx).abs() < 4 ? (_rnd.nextBool() ? 1 : -1) : (c.p.dx - g.cx).sign;
    final double dir = _rnd.nextDouble() < 0.8 ? side : -side;
    c.v = Offset(dir * (130 + _rnd.nextDouble() * 220), -(520 + _rnd.nextDouble() * 260));
    c.spin = dir * (5 + _rnd.nextDouble() * 6);
  }

  // ───────────────────────── loop ─────────────────────────

  void _tick(Duration d) {
    final double dt = _last == Duration.zero ? 0 : ((d - _last).inMicroseconds / 1e6).clamp(0.0, 1 / 30);
    _last = d;
    _now = d.inMicroseconds / 1e6;
    _updateGeo();
    final _Geo? g = _geo;
    if (g != null) {
      // nascimentos agendados
      for (final _Pending p in List<_Pending>.of(_pending)) {
        if (_now >= p.at) {
          _pending.remove(p);
          _coins.add(p.coin);
        }
      }
      // inclinação da carteira (moeda empurrando por baixo)
      if (_now > _tiltHoldUntil) _tiltTarget = 0;
      _tilt += (_tiltTarget - _tilt) * (1 - math.exp(-dt * 7));
      // moedinhas meio para fora: sobem, ficam, e voltam para dentro depois de um tempo parado
      final bool idle = _now - _lastInteraction > 15;
      for (final _Coin c in List<_Coin>.of(_coins)) {
        if (!c.peek || c.held) continue;
        if (idle && !c.peekBack) {
          c.peekBack = true;
          c.peekT = 1;
        }
        c.peekT += (c.peekBack ? -dt : dt) / 0.4;
        if (c.peekBack && c.peekT <= 0) {
          _coins.remove(c);
          continue;
        }
        _place(c);
      }
      const int steps = 3;
      for (int i = 0; i < steps; i++) {
        _step(dt / steps, g);
      }
    }
    if (mounted) setState(() {});
  }

  void _updateGeo() {
    final RenderBox? box = _slotKey.currentContext?.findRenderObject() as RenderBox?;
    final RenderBox? stack = context.findRenderObject() as RenderBox?;
    if (box == null || stack == null || !box.hasSize || !stack.hasSize) return;
    final Offset o = stack.globalToLocal(box.localToGlobal(Offset.zero));
    final double s = box.size.width;
    final Rect img = Rect.fromLTWH(o.dx, o.dy - s * 0.17, s, s);
    if (_geo == null || _geo!.img != img) _geo = _Geo(img);
  }

  void _step(double dt, _Geo g) {
    final double r = g.r;
    final List<_Coin> gone = <_Coin>[];
    for (final _Coin c in _coins) {
      if (c.peek) continue;
      if (c.held) {
        // a moeda se centraliza no dedo
        final double k = 1 - math.exp(-dt * 28);
        final Offset np = Offset.lerp(c.p, c.finger, k)!;
        if (dt > 0) c.v = (np - c.p) / dt;
        c.p = np;
        c.a += c.spin * dt;
        c.spin *= math.exp(-dt * 5);
        continue;
      }
      c.v = Offset(c.v.dx, c.v.dy + _gravity * c.g * dt);
      final double drag = math.exp(-dt * 0.35);
      c.v = c.v * drag;
      final double sp = c.v.distance;
      if (sp > 2600) c.v = c.v * (2600 / sp);
      c.p += c.v * dt;
      c.a += c.spin * dt;
      if (!c.front) {
        for (final _Box b in g.boxes) {
          _collide(c, b, r, g);
        }
        // entrou pela boca: afunda atrás da frente da carteira e some
        if (c.g > 0 && c.p.dy > g.top + r * 0.95 && c.p.dx > g.mouthL && c.p.dx < g.mouthR) {
          gone.add(c);
          _bumpStart = _now;
          if (_now - _lastHaptic > 0.06) {
            _lastHaptic = _now;
            HapticFeedback.lightImpact();
          }
          continue;
        }
      }
      // saiu da tela
      final Size s = _screen;
      if (c.p.dx + r < -30 || c.p.dx - r > s.width + 30 || c.p.dy - r > s.height + 20 || (c.g < 0 && c.p.dy + r < -20) || c.p.dy < -4000) {
        gone.add(c);
      }
    }
    _coins.removeWhere(gone.contains);
    _separate(r);
  }

  /// círculo × retângulo: empurra para fora, quica, atrito e rolamento
  void _collide(_Coin c, _Box b, double r, _Geo g) {
    final double qx = c.p.dx.clamp(b.l, b.r);
    final double qy = c.p.dy.clamp(b.t, b.b);
    double dx = c.p.dx - qx, dy = c.p.dy - qy;
    final double d2 = dx * dx + dy * dy;
    if (d2 >= r * r) return;
    double nx, ny, pen;
    if (d2 > 1e-6) {
      final double d = math.sqrt(d2);
      nx = dx / d;
      ny = dy / d;
      pen = r - d;
    } else {
      // centro dentro do retângulo: sai pela face mais próxima
      final double toL = c.p.dx - b.l, toR = b.r - c.p.dx, toT = c.p.dy - b.t, toB = b.b - c.p.dy;
      final double m = math.min(math.min(toL, toR), math.min(toT, toB));
      if (m == toT) {
        nx = 0;
        ny = -1;
      } else if (m == toB) {
        nx = 0;
        ny = 1;
      } else if (m == toL) {
        nx = -1;
        ny = 0;
      } else {
        nx = 1;
        ny = 0;
      }
      pen = m + r;
    }
    c.p += Offset(nx, ny) * pen;
    final double vn = c.v.dx * nx + c.v.dy * ny;
    if (vn < 0) {
      final double bounce = vn < -260 ? 0.38 : 0.08;
      c.v -= Offset(nx, ny) * (vn * (1 + bounce));
      // atrito tangencial e rolamento
      final double tx = -ny, ty = nx;
      final double vt = c.v.dx * tx + c.v.dy * ty;
      c.v -= Offset(tx, ty) * (vt * 0.035);
      c.spin += (vt / r - c.spin) * 0.35;
      if (vn < -380 && _now - _lastHaptic > 0.08) {
        _lastHaptic = _now;
        HapticFeedback.selectionClick();
      }
    }
    // dinheiro saindo empurrado contra a parte de baixo: a carteira inclina e a moeda rola para o lado
    if (c.g < 0 && ny > 0.6) {
      final double side = (c.p.dx - g.cx).abs() < 3 ? (_rnd.nextBool() ? 1.0 : -1.0) : (c.p.dx - g.cx).sign;
      _tiltTarget = -side * 0.075;
      _tiltHoldUntil = _now + 0.18;
      c.v = Offset(c.v.dx + side * 22, c.v.dy);
      c.spin += side * 0.4;
    }
  }

  /// moedas soltas não se atravessam
  void _separate(double r) {
    final List<_Coin> f = _coins.where((_Coin c) => !c.peek && !c.held && !c.front).toList();
    for (int i = 0; i < f.length; i++) {
      for (int j = i + 1; j < f.length; j++) {
        final _Coin a = f[i], b = f[j];
        final Offset d = b.p - a.p;
        final double dist = d.distance;
        final double min = r * 1.9;
        if (dist >= min || dist < 1e-4) continue;
        final Offset n = d / dist;
        final Offset corr = n * ((min - dist) / 2);
        a.p -= corr;
        b.p += corr;
        final double rel = (b.v - a.v).dx * n.dx + (b.v - a.v).dy * n.dy;
        if (rel < 0) {
          final Offset imp = n * (rel * 0.65);
          a.v += imp;
          b.v -= imp;
        }
      }
    }
  }

  // ───────────────────────── toque ─────────────────────────

  _Coin? _coinAt(Offset pos) {
    final _Geo? g = _geo;
    if (g == null) return null;
    final double r = g.r;
    // de cima para baixo: segura primeiro a que está desenhada na frente
    final List<_Coin> order = <_Coin>[..._coins.where((_Coin c) => c.front || c.held), ..._coins.where((_Coin c) => !c.front && !c.held)].reversed.toList();
    for (final _Coin c in order) {
      if (c.held) continue;
      if (c.peek && c.peekT < 0.5) continue;
      if ((c.p - pos).distance <= r) return c;
    }
    return null;
  }

  bool _hits(Offset pos) {
    if (_coinAt(pos) != null) return true;
    final _Geo? g = _geo;
    return g != null && g.body.contains(pos);
  }

  void _down(PointerDownEvent e) {
    _lastInteraction = _now;
    final _Coin? c = _coinAt(e.localPosition);
    if (c != null) {
      c.peek = false;
      c.pointer = e.pointer;
      c.finger = e.localPosition;
      c.hist
        ..clear()
        ..add(_Sample(_now, e.localPosition));
      HapticFeedback.selectionClick();
      return;
    }
    final _Geo? g = _geo;
    if (g != null && g.body.contains(e.localPosition)) _tapWallet();
  }

  void _move(PointerMoveEvent e) {
    for (final _Coin c in _coins) {
      if (c.pointer != e.pointer) continue;
      c.finger = e.localPosition;
      c.hist.add(_Sample(_now, e.localPosition));
      c.hist.removeWhere((_Sample s) => _now - s.t > 0.09);
      _lastInteraction = _now;
    }
  }

  void _up(PointerEvent e) {
    final _Geo? g = _geo;
    for (final _Coin c in _coins) {
      if (c.pointer != e.pointer) continue;
      c.pointer = null;
      _lastInteraction = _now;
      Offset vel = Offset.zero;
      if (c.hist.length >= 2) {
        final _Sample a = c.hist.first, b = c.hist.last;
        final double t = b.t - a.t;
        if (t > 0.004) vel = (b.p - a.p) / t;
      }
      if (vel.distance > 3000) vel = vel * (3000 / vel.distance);
      c.v = vel;
      c.spin = (vel.dx / (g?.r ?? 24)) * 0.4;
      if (g == null || c.front) continue;
      final Rect front = Rect.fromLTRB(g.left, g.top, g.right, g.bottom);
      if (front.contains(c.p)) {
        if (c.g > 0) {
          // soltou em cima da carteira: entra pela boca
          c.p = Offset(c.p.dx.clamp(g.mouthL + g.r, g.mouthR - g.r), g.top + g.r * 0.4);
          c.v = Offset(0, 260);
        } else {
          // dinheiro saindo colocado por baixo: encosta embaixo, a carteira inclina e ela rola para fora
          c.p = Offset(c.p.dx, g.bottom + g.r + 1);
          c.v = Offset(c.v.dx, math.min(c.v.dy, -40));
        }
      }
    }
  }

  /// toque na carteira: balança · 2 toques rápidos: moedinhas sobem meio para fora · tocando de novo: elas pulam para fora
  void _tapWallet() {
    final bool quick = _now - _lastTap < 0.36;
    _lastTap = _now;
    // dinheiro saindo preso embaixo: a carteira chacoalha e as moedas passam pela frente, para cima
    final List<_Coin> leaving = _coins.where((_Coin c) => c.g < 0 && !c.front).toList();
    if (leaving.isNotEmpty) {
      _shake(fast: true);
      for (final _Coin c in leaving) {
        c.front = true;
        c.v = Offset(c.v.dx * 0.5, math.min(c.v.dy, -520));
      }
      return;
    }
    final int units = _balanceUnits;
    if (units <= 0) {
      _shake(fast: quick);
      return;
    }
    final List<_Coin> peeks = _coins.where((_Coin c) => c.peek && !c.peekBack).toList();
    if (peeks.isEmpty) {
      _shake(fast: quick);
      if (quick) {
        final int n = math.min(units, _maxPeek);
        for (int i = 0; i < n; i++) {
          if (!_spawnPeek(delay: i * 0.06)) break;
        }
      }
      return;
    }
    _shake(fast: true, strength: quick ? 1 : 0.8);
    final List<_Coin> ready = peeks.where((_Coin c) => c.peekT >= 0.6).toList();
    if (ready.isEmpty) return;
    final _Coin c = ready[_rnd.nextInt(ready.length)];
    _popPeek(c);
    _spawnPeek(delay: 0.12);
  }

  // ───────────────────────── resgate ─────────────────────────

  Future<void> _claim() async {
    if (_busy) return;
    setState(() => _busy = true);
    _claiming = true;
    try {
      final int got = await AppState.I.claim();
      _got = got > 0 ? got : AppState.I.claimAmountSats;
      _gotUntil = _now + 3.5;
      HapticFeedback.mediumImpact();
      await AppState.I.refreshAll();
      final AppState s = AppState.I;
      if (s.canShowMoney && s.balance != null) _lastBal = s.balance;
      _rain(_unitsOf(_got));
    } catch (e) {
      toast(errText(e), error: true);
    } finally {
      _claiming = false;
      if (mounted) setState(() => _busy = false);
    }
  }

  // ───────────────────────── tela ─────────────────────────

  @override
  Widget build(BuildContext context) {
    final Pal p = Pal.of(context);
    final AppState s = AppState.I;
    final int left = s.claimLeft;
    final bool online = s.canShowMoney;
    final bool ready = left == 0 && online;
    return LayoutBuilder(builder: (BuildContext c, BoxConstraints bc) {
      _screen = Size(bc.maxWidth, bc.maxHeight);
      final double cardW = math.min(380.0, bc.maxWidth - 32);
      final double side = math.min(250.0, cardW - 60);
      final _Geo? g = _geo;
      final double angle = _walletAngle;
      final double coinPx = g?.coinPx ?? 50;
      Widget coinW(_Coin k) {
        final double sc = k.held ? 1.12 : 1;
        return Positioned(
          left: k.p.dx - coinPx / 2,
          top: k.p.dy - coinPx / 2,
          width: coinPx,
          height: coinPx,
          child: Transform.rotate(
            angle: k.a + (k.peek ? angle : 0),
            child: Transform.scale(scale: sc, child: Image.asset(_kCoin, filterQuality: FilterQuality.none, gaplessPlayback: true)),
          ),
        );
      }

      Widget walletImg(String asset) => Positioned.fromRect(
            rect: g!.img.shift(Offset(0, _walletDip)),
            child: Transform.rotate(
              angle: angle,
              alignment: const Alignment(0, (_bodyB / _png) * 2 - 1),
              child: Image.asset(asset, fit: BoxFit.contain, filterQuality: FilterQuality.none, gaplessPlayback: true),
            ),
          );

      final bool calm = _coins.isEmpty && _pending.isEmpty;
      return Stack(children: <Widget>[
        // fundo: não fecha ao tocar fora
        const Positioned.fill(child: AbsorbPointer(child: SizedBox.expand())),
        Center(
          child: Material(
            color: p.card,
            borderRadius: BorderRadius.circular(26),
            elevation: 12,
            child: SizedBox(
              width: cardW,
              child: Padding(
                padding: const EdgeInsets.fromLTRB(20, 8, 20, 16),
                child: Column(mainAxisSize: MainAxisSize.min, children: <Widget>[
                  Row(children: <Widget>[
                    const SizedBox(width: 40),
                    Expanded(child: Text(L.t('Resgate', 'Claim'), textAlign: TextAlign.center, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800))),
                    IconButton(onPressed: () => Navigator.of(context).maybePop(), icon: Icon(Icons.close_rounded, color: p.fg2)),
                  ]),
                  const SizedBox(height: 18),
                  // lugar da carteira (ela é desenhada por cima, em camadas, para as moedas passarem entre o fundo e a frente)
                  SizedBox(key: _slotKey, width: side, height: side * 0.74),
                  const SizedBox(height: 8),
                  AnimatedSwitcher(
                    duration: const Duration(milliseconds: 250),
                    child: !online
                        ? Text(L.t('Sem conexão com a rede', 'No connection to the network'), key: const ValueKey<String>('off'), style: TextStyle(color: p.bad, fontWeight: FontWeight.w700))
                        : _now < _gotUntil
                            ? Text('+${F.coins(_got)} ${F.unit()}', key: const ValueKey<String>('got'), style: TextStyle(color: p.ok, fontSize: 22, fontWeight: FontWeight.w900))
                            : ready
                                ? Text(L.t('Disponível agora', 'Available now'), key: const ValueKey<String>('ready'), style: TextStyle(color: p.ok, fontSize: 22, fontWeight: FontWeight.w900))
                                : Column(key: const ValueKey<String>('wait'), children: <Widget>[
                                    Text(L.t('Próximo resgate em', 'Next claim in'), style: TextStyle(color: p.fg2, fontSize: 13)),
                                    Text(left < 0 ? '—' : F.countdown(left), style: TextStyle(fontSize: 30, fontWeight: FontWeight.w800, color: p.fg, fontFeatures: const <FontFeature>[FontFeature.tabularFigures()])),
                                  ]),
                  ),
                  const SizedBox(height: 2),
                  Text(L.t('${F.coins(s.claimAmountSats)} ${F.unit()} a cada ${F.duration(s.claimCooldownMs)}', '${F.coins(s.claimAmountSats)} ${F.unit()} every ${F.duration(s.claimCooldownMs)}'),
                      style: TextStyle(color: p.fg3, fontSize: 12.5)),
                  const SizedBox(height: 14),
                  SizedBox(
                    width: double.infinity,
                    child: FilledButton(
                      style: FilledButton.styleFrom(padding: const EdgeInsets.symmetric(vertical: 15)),
                      onPressed: ready && !_busy ? _claim : null,
                      child: _busy ? SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2.4, color: p.prifg)) : Text(L.t('Resgatar', 'Claim'), style: const TextStyle(fontSize: 16)),
                    ),
                  ),
                  SwitchListTile(
                    contentPadding: EdgeInsets.zero,
                    dense: true,
                    value: s.autoClaim,
                    onChanged: (bool v) async {
                      await s.setSettings(<String, dynamic>{'autoClaim': v, if (v) 'background': true});
                      if (v) {
                        try {
                          await Native.call('perm', <String, dynamic>{'kind': 'notifications'});
                        } catch (_) {}
                      }
                    },
                    title: Text(L.t('Resgate automático', 'Auto-claim'), style: const TextStyle(fontWeight: FontWeight.w700)),
                    subtitle: Text(L.t('A cada hora, com a notificação fixa ativa', 'Every hour, with the persistent notification on'), style: TextStyle(color: p.fg3, fontSize: 12)),
                  ),
                ]),
              ),
            ),
          ),
        ),
        if (g != null) ...<Widget>[
          // camada 1: fundo da carteira
          IgnorePointer(child: Stack(children: <Widget>[walletImg(_kBack)])),
          // camada 2: moedas entre o fundo e a frente
          Positioned.fill(child: IgnorePointer(child: Stack(clipBehavior: Clip.none, children: <Widget>[for (final _Coin k in _coins) if (!k.front && !k.held) coinW(k)]))),
          // camada 3: frente da carteira
          IgnorePointer(child: Stack(children: <Widget>[walletImg(_kFront)])),
          // moedinha flutuando quando o resgate está disponível
          if (ready && calm && !_busy)
            Positioned(
              left: g.cx - coinPx * 0.42,
              top: g.backTop - coinPx * 1.05 + math.sin(_now * 3) * 4,
              width: coinPx * 0.84,
              height: coinPx * 0.84,
              child: IgnorePointer(child: Image.asset(_kCoin, filterQuality: FilterQuality.none)),
            ),
          // camada 4: moedas por cima de tudo (seguradas no dedo ou passando pela frente)
          Positioned.fill(child: IgnorePointer(child: Stack(clipBehavior: Clip.none, children: <Widget>[for (final _Coin k in _coins) if (k.front || k.held) coinW(k)]))),
          // toque: só onde há moeda ou carteira (o resto passa para os botões do cartão)
          Positioned.fill(
            child: Listener(
              behavior: HitTestBehavior.deferToChild,
              onPointerDown: _down,
              onPointerMove: _move,
              onPointerUp: _up,
              onPointerCancel: _up,
              child: CustomPaint(painter: _HitArea(_hits), size: Size.infinite),
            ),
          ),
        ],
      ]);
    });
  }
}

/// área de toque personalizada: o círculo exato das moedas e o corpo da carteira
class _HitArea extends CustomPainter {
  _HitArea(this.test);
  final bool Function(Offset) test;

  @override
  void paint(Canvas canvas, Size size) {}

  @override
  bool? hitTest(Offset position) => test(position);

  @override
  bool shouldRepaint(covariant _HitArea oldDelegate) => false;
}
