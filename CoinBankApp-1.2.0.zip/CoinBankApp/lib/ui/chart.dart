import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../core/fmt.dart';
import '../core/models.dart';
import 'theme.dart';

class ChartPoint {
  const ChartPoint(this.t, this.v);
  final DateTime t;
  final int v;
}

/// Série do saldo ao longo do tempo, calculada do extrato (anda para trás a partir do saldo atual).
List<ChartPoint> balanceSeries(List<Tx> txs, int balance, String me, {Duration? range}) {
  final DateTime now = DateTime.now();
  final DateTime? from = range == null ? null : now.subtract(range);
  final List<Tx> l = List<Tx>.of(txs)..sort((Tx a, Tx b) => b.date.compareTo(a.date));
  final List<ChartPoint> out = <ChartPoint>[ChartPoint(now, balance)];
  int bal = balance;
  for (final Tx t in l) {
    if (from != null && t.date.isBefore(from)) {
      break;
    }
    out.add(ChartPoint(t.date, bal));
    // saldo antes desta transação
    if (t.to == me && t.from != me) {
      bal -= t.sats;
    } else if (t.from == me && t.to != me) {
      bal += t.sats;
    }
    out.add(ChartPoint(t.date.subtract(const Duration(milliseconds: 1)), bal));
  }
  if (from != null) out.add(ChartPoint(from, bal));
  if (out.length == 1) out.add(ChartPoint(now.subtract(range ?? const Duration(days: 1)), balance));
  return out.reversed.toList();
}

class BalanceChart extends StatelessWidget {
  const BalanceChart({super.key, required this.points, this.height = 170});
  final List<ChartPoint> points;
  final double height;

  @override
  Widget build(BuildContext context) {
    final Pal p = Pal.of(context);
    return SizedBox(
      height: height,
      child: TweenAnimationBuilder<double>(
        key: ValueKey<int>(points.length * 31 + (points.isEmpty ? 0 : points.last.v.hashCode)),
        tween: Tween<double>(begin: 0, end: 1),
        duration: const Duration(milliseconds: 900),
        curve: Curves.easeOutCubic,
        builder: (BuildContext c, double prog, Widget? _) => CustomPaint(
          size: Size.infinite,
          painter: _ChartPainter(points, prog, p),
        ),
      ),
    );
  }
}

class _ChartPainter extends CustomPainter {
  _ChartPainter(this.pts, this.prog, this.p);
  final List<ChartPoint> pts;
  final double prog;
  final Pal p;

  @override
  void paint(Canvas canvas, Size size) {
    if (pts.length < 2) return;
    const double padTop = 18, padBottom = 22;
    final double h = size.height - padTop - padBottom;
    final int t0 = pts.first.t.millisecondsSinceEpoch;
    final int t1 = math.max(t0 + 1, pts.last.t.millisecondsSinceEpoch);
    int vmin = pts.first.v, vmax = pts.first.v;
    for (final ChartPoint q in pts) {
      vmin = math.min(vmin, q.v);
      vmax = math.max(vmax, q.v);
    }
    if (vmax == vmin) {
      vmax += 1;
      vmin = math.max(0, vmin - 1);
    }
    Offset at(ChartPoint q) {
      final double x = (q.t.millisecondsSinceEpoch - t0) / (t1 - t0) * size.width;
      final double y = padTop + h - (q.v - vmin) / (vmax - vmin) * h;
      return Offset(x, y);
    }

    // grade
    final Paint grid = Paint()
      ..color = p.line
      ..strokeWidth = 1;
    for (int i = 0; i <= 3; i++) {
      final double y = padTop + h * i / 3;
      canvas.drawLine(Offset(0, y), Offset(size.width, y), grid);
    }

    final Path line = Path();
    final List<Offset> o = pts.map(at).toList();
    final double clipX = size.width * prog;
    line.moveTo(o.first.dx, o.first.dy);
    for (int i = 1; i < o.length; i++) {
      line.lineTo(o[i].dx, o[i].dy);
    }
    canvas.save();
    canvas.clipRect(Rect.fromLTWH(0, 0, clipX + 2, size.height));
    final Path fill = Path.from(line)
      ..lineTo(o.last.dx, padTop + h)
      ..lineTo(o.first.dx, padTop + h)
      ..close();
    canvas.drawPath(
      fill,
      Paint()
        ..shader = LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: <Color>[p.gold.withValues(alpha: 0.32), p.gold.withValues(alpha: 0.0)])
            .createShader(Rect.fromLTWH(0, padTop, size.width, h)),
    );
    canvas.drawPath(
      line,
      Paint()
        ..color = p.gold
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2.6
        ..strokeJoin = StrokeJoin.round
        ..strokeCap = StrokeCap.round,
    );
    canvas.restore();
    if (prog > 0.98) {
      canvas.drawCircle(o.last, 6, Paint()..color = p.gold.withValues(alpha: 0.25));
      canvas.drawCircle(o.last, 3.6, Paint()..color = p.gold);
    }
    // rótulos: máximo / mínimo e datas das pontas
    void label(String s, Offset pos, {TextAlign align = TextAlign.left}) {
      final TextPainter tp = TextPainter(text: TextSpan(text: s, style: TextStyle(color: p.fg3, fontSize: 10.5, fontWeight: FontWeight.w600)), textDirection: TextDirection.ltr)..layout();
      double x = pos.dx;
      if (align == TextAlign.right) x -= tp.width;
      tp.paint(canvas, Offset(math.max(0.0, math.min(x, size.width - tp.width)), pos.dy));
    }

    label(F.coins(vmax), const Offset(0, 0));
    label(F.coins(vmin), Offset(0, padTop + h - 14));
    label(F.shortDay(pts.first.t), Offset(0, size.height - 14));
    label(F.shortDay(pts.last.t), Offset(size.width, size.height - 14), align: TextAlign.right);
  }

  @override
  bool shouldRepaint(covariant _ChartPainter old) => old.prog != prog || old.pts != pts || old.p.dark != p.dark;
}

/// barras simples (atividade da rede por dia)
class BarsChart extends StatelessWidget {
  const BarsChart({super.key, required this.values, required this.labels, this.height = 120});
  final List<double> values;
  final List<String> labels;
  final double height;

  @override
  Widget build(BuildContext context) {
    final Pal p = Pal.of(context);
    double mx = 1.0;
    for (final double v in values) {
      if (v > mx) mx = v;
    }
    return SizedBox(
      height: height,
      child: Row(crossAxisAlignment: CrossAxisAlignment.end, children: <Widget>[
        for (int i = 0; i < values.length; i++)
          Expanded(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 2),
              child: Column(mainAxisAlignment: MainAxisAlignment.end, children: <Widget>[
                TweenAnimationBuilder<double>(
                  tween: Tween<double>(begin: 0, end: values[i] / mx),
                  duration: Duration(milliseconds: 500 + i * 25),
                  curve: Curves.easeOutCubic,
                  builder: (BuildContext c, double v, Widget? _) => Container(
                    height: math.max(3.0, (height - 18) * v),
                    decoration: BoxDecoration(color: i == values.length - 1 ? p.gold : p.gold.withValues(alpha: 0.45), borderRadius: BorderRadius.circular(5)),
                  ),
                ),
                const SizedBox(height: 4),
                Text(i == 0 || i == values.length - 1 || i == values.length ~/ 2 ? labels[i] : '', style: TextStyle(fontSize: 9.5, color: p.fg3), maxLines: 1),
              ]),
            ),
          ),
      ]),
    );
  }
}
