import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../core/fmt.dart';
import '../core/i18n.dart';
import '../core/models.dart';
import '../core/native.dart';
import '../core/state.dart';
import 'common.dart';
import 'theme.dart';

AppState get _s => AppState.I;

String serverUrl(String id) => _s.serverById(id)?.url ?? _s.active.url;
String serverName(String id) => _s.serverById(id)?.name ?? 'Coin';
String myIdOn(String server) => js(_s.sessionOf(server), 'userId');

// ═══════════════════════════════ COMPROVANTE ═══════════════════════════════

/// abre o comprovante de uma transação (gerado na hora no aparelho)
Future<void> openReceipt(BuildContext context, {required String server, Tx? tx, String? txId}) {
  return showSheet<void>(context, (BuildContext c) => ReceiptSheet(server: server, tx: tx, txId: txId ?? tx?.id ?? ''));
}

class ReceiptSheet extends StatefulWidget {
  const ReceiptSheet({super.key, required this.server, required this.txId, this.tx});
  final String server;
  final String txId;
  final Tx? tx;

  @override
  State<ReceiptSheet> createState() => _ReceiptSheetState();
}

class _ReceiptSheetState extends State<ReceiptSheet> {
  Tx? _tx;
  Uint8List? _png;
  String? _err;

  @override
  void initState() {
    super.initState();
    _tx = widget.tx;
    _load();
  }

  J _payload(Tx t, bool dark) => <String, dynamic>{
        ...t.toJson(),
        'lang': L.lang,
        'dark': dark,
        'decimals': F.cfg(widget.server).disp,
        'coin': F.unit(widget.server),
        'server': serverUrl(widget.server),
        'network': serverName(widget.server),
        'me': myIdOn(widget.server),
      };

  Future<void> _load() async {
    try {
      if (_tx == null) {
        final J r = await Native.api(widget.server, 'GET', '/api/tx/${Uri.encodeComponent(widget.txId)}', noAuth: true);
        _tx = Tx.fromJson(jm(r, 'tx'));
      }
      if (!mounted) return;
      final bool dark = Theme.of(context).brightness == Brightness.dark;
      final J r = await Native.call('receipt.png', <String, dynamic>{'tx': jsonEncode(_payload(_tx!, dark))});
      if (!mounted) return;
      setState(() => _png = base64Decode(js(r, 'b64')));
    } catch (e) {
      if (mounted) setState(() => _err = errText(e));
    }
  }

  Future<void> _save(String format) async {
    final Tx? t = _tx;
    if (t == null) return;
    final J r = await Native.call('receipt.save', <String, dynamic>{'tx': jsonEncode(_payload(t, false)), 'format': format});
    toast(L.t('Salvo em ${js(r, 'path')}', 'Saved to ${js(r, 'path')}'), ok: true);
  }

  Future<void> _share() async {
    final Tx? t = _tx;
    if (t == null) return;
    await Native.call('receipt.share', <String, dynamic>{'tx': jsonEncode(_payload(t, false)), 'format': 'png'});
  }

  @override
  Widget build(BuildContext context) {
    final Pal p = Pal.of(context);
    final String link = '${serverUrl(widget.server)}/tx/${widget.txId}';
    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(18, 0, 18, 22),
      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: <Widget>[
        Row(children: <Widget>[
          Icon(Icons.receipt_long_rounded, color: p.gold),
          const SizedBox(width: 10),
          Expanded(child: Text(L.t('Comprovante', 'Receipt'), style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900))),
          IconButton(onPressed: () => copyText(widget.txId, 'ID'), icon: const Icon(Icons.copy_rounded), tooltip: L.t('Copiar ID', 'Copy ID')),
        ]),
        const SizedBox(height: 10),
        AnimatedSwitcher(
          duration: const Duration(milliseconds: 350),
          child: _err != null
              ? EmptyState(key: const ValueKey<String>('e'), icon: Icons.error_outline_rounded, title: L.t('Não foi possível abrir', 'Could not open'), text: _err)
              : _png == null
                  ? const SizedBox(key: ValueKey<String>('l'), height: 320, child: Center(child: CircularProgressIndicator()))
                  : ClipRRect(
                      key: const ValueKey<String>('i'),
                      borderRadius: BorderRadius.circular(18),
                      child: Image.memory(_png!, fit: BoxFit.contain, gaplessPlayback: true),
                    ),
        ),
        const SizedBox(height: 14),
        Row(children: <Widget>[
          Expanded(child: _Action(icon: Icons.image_outlined, label: L.t('Imagem', 'Image'), onTap: _tx == null ? null : () => _save('png'))),
          Expanded(child: _Action(icon: Icons.picture_as_pdf_outlined, label: 'PDF', onTap: _tx == null ? null : () => _save('pdf'))),
          Expanded(child: _Action(icon: Icons.share_rounded, label: L.t('Enviar', 'Share'), onTap: _tx == null ? null : _share)),
          Expanded(
              child: _Action(
                  icon: Icons.language_rounded,
                  label: L.t('Link web', 'Web link'),
                  onTap: () async => Native.call('browser', <String, dynamic>{'url': link, 'title': L.t('Comprovante', 'Receipt')}))),
        ]),
        const SizedBox(height: 4),
        OutlinedButton.icon(
          onPressed: () async {
            // a API informa o link público do comprovante; redes antigas: /tx/<id>
            String url = link;
            try {
              final J r = await Native.api(widget.server, 'GET', '/api/tx/${Uri.encodeComponent(widget.txId)}/link', noAuth: true);
              if (js(r, 'url').isNotEmpty) url = js(r, 'url');
            } catch (_) {}
            await copyText(url, 'Link');
          },
          icon: const Icon(Icons.link_rounded, size: 18),
          label: Text(L.t('Copiar link do comprovante', 'Copy receipt link')),
        ),
        const SizedBox(height: 6),
        Center(child: Text(L.t('Gerado no aparelho · verificável pelo QR Code', 'Generated on the device · verifiable by QR code'), style: TextStyle(color: p.fg3, fontSize: 12))),
      ]),
    );
  }
}

class _Action extends StatefulWidget {
  const _Action({required this.icon, required this.label, required this.onTap});
  final IconData icon;
  final String label;
  final Future<void> Function()? onTap;

  @override
  State<_Action> createState() => _ActionState();
}

class _ActionState extends State<_Action> {
  bool _busy = false;

  @override
  Widget build(BuildContext context) {
    final Pal p = Pal.of(context);
    final Future<void> Function()? f = widget.onTap;
    return InkWell(
      borderRadius: BorderRadius.circular(16),
      onTap: f == null || _busy
          ? null
          : () async {
              setState(() => _busy = true);
              try {
                await f();
              } catch (e) {
                toast(errText(e), error: true);
              } finally {
                if (mounted) setState(() => _busy = false);
              }
            },
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 10),
        child: Column(children: <Widget>[
          Container(
            width: 50,
            height: 50,
            decoration: BoxDecoration(color: p.goldSoft, borderRadius: BorderRadius.circular(16)),
            child: _busy ? Padding(padding: const EdgeInsets.all(14), child: CircularProgressIndicator(strokeWidth: 2.4, color: p.gold)) : Icon(widget.icon, color: f == null ? p.fg3 : p.gold),
          ),
          const SizedBox(height: 6),
          Text(widget.label, style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: p.fg2)),
        ]),
      ),
    );
  }
}

// ═══════════════════════════════ SUCESSO ═══════════════════════════════

/// ✓ animado + valor + botão de comprovante
class SuccessView extends StatelessWidget {
  const SuccessView({super.key, required this.title, required this.sats, this.subtitle, this.server, this.txId, this.onDone});
  final String title;
  final int sats;
  final String? subtitle;
  final String? server;
  final String? txId;
  final VoidCallback? onDone;

  @override
  Widget build(BuildContext context) {
    final Pal p = Pal.of(context);
    return Padding(
      padding: const EdgeInsets.fromLTRB(22, 4, 22, 24),
      child: Column(mainAxisSize: MainAxisSize.min, children: <Widget>[
        TweenAnimationBuilder<double>(
          tween: Tween<double>(begin: 0, end: 1),
          duration: const Duration(milliseconds: 700),
          curve: Curves.elasticOut,
          builder: (BuildContext c, double v, Widget? ch) => Transform.scale(scale: v, child: ch),
          child: Container(width: 92, height: 92, decoration: BoxDecoration(color: p.okSoft, shape: BoxShape.circle), child: Icon(Icons.check_rounded, color: p.ok, size: 58)),
        ),
        const SizedBox(height: 16),
        Text(title, textAlign: TextAlign.center, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
        const SizedBox(height: 8),
        CoinText(sats, size: 30, color: p.gold),
        if (subtitle != null) Padding(padding: const EdgeInsets.only(top: 6), child: Text(subtitle!, textAlign: TextAlign.center, style: TextStyle(color: p.fg2))),
        const SizedBox(height: 20),
        if (txId != null && txId!.isNotEmpty && server != null)
          SizedBox(
            width: double.infinity,
            child: OutlinedButton.icon(
              onPressed: () => openReceipt(context, server: server!, txId: txId),
              icon: const Icon(Icons.receipt_long_rounded),
              label: Text(L.t('Abrir comprovante', 'Open receipt')),
            ),
          ),
        const SizedBox(height: 10),
        SizedBox(width: double.infinity, child: FilledButton(onPressed: onDone ?? () => Navigator.of(context).maybePop(), child: Text(L.t('Concluir', 'Done')))),
      ]),
    );
  }
}

Widget sheetTitle(BuildContext context, IconData icon, String title, {String? subtitle}) {
  final Pal p = Pal.of(context);
  return Padding(
    padding: const EdgeInsets.only(bottom: 14),
    child: Row(children: <Widget>[
      Container(width: 44, height: 44, decoration: BoxDecoration(color: p.goldSoft, borderRadius: BorderRadius.circular(14)), child: Icon(icon, color: p.gold)),
      const SizedBox(width: 12),
      Expanded(
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: <Widget>[
          Text(title, style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w900)),
          if (subtitle != null) Text(subtitle, style: TextStyle(color: p.fg2, fontSize: 13)),
        ]),
      ),
    ]),
  );
}

// ═══════════════════════════════ ENVIAR ═══════════════════════════════

Future<void> openSend(BuildContext context, {String? server, String? toId, int? amount, String? name}) {
  return showSheet<void>(context, (BuildContext c) => SendSheet(server: server ?? _s.activeId, toId: toId, amount: amount, name: name));
}

class SendSheet extends StatefulWidget {
  const SendSheet({super.key, required this.server, this.toId, this.amount, this.name});
  final String server;
  final String? toId;
  final int? amount;
  final String? name;

  @override
  State<SendSheet> createState() => _SendSheetState();
}

class _SendSheetState extends State<SendSheet> {
  final TextEditingController _to = TextEditingController();
  final TextEditingController _amt = TextEditingController();
  J? _done;
  String _name = '';

  @override
  void initState() {
    super.initState();
    _to.text = widget.toId ?? '';
    if (widget.amount != null && widget.amount! > 0) _amt.text = F.coins(widget.amount!, net: widget.server);
    _name = widget.name ?? '';
    if (_to.text.isNotEmpty && _name.isEmpty) _lookup();
  }

  @override
  void dispose() {
    _to.dispose();
    _amt.dispose();
    super.dispose();
  }

  Future<void> _lookup() async {
    try {
      final J r = await Native.api(widget.server, 'GET', '/api/pay/user/${_to.text.trim()}', noAuth: true);
      if (mounted) setState(() => _name = js(r, 'name'));
    } catch (_) {}
  }

  Future<void> _send() async {
    final String to = _to.text.trim();
    final int? sats = F.parse(_amt.text, widget.server);
    if (to.isEmpty) throw ApiException('INVALID_TARGET', 400, <String, dynamic>{});
    if (sats == null || sats <= 0) throw ApiException('INVALID_AMOUNT', 400, <String, dynamic>{});
    if (to == myIdOn(widget.server)) throw ApiException('SELF_TRANSFER', 400, <String, dynamic>{});
    final bool ok = await confirm(context,
        icon: Icons.send_rounded,
        title: L.t('Confirmar envio', 'Confirm transfer'),
        text: L.t('Enviar ${F.coins(sats)} coins para ${_name.isNotEmpty ? '$_name ' : ''}($to) na rede ${serverName(widget.server)}?\n\nTransferências não podem ser desfeitas.',
            'Send ${F.coins(sats)} coins to ${_name.isNotEmpty ? '$_name ' : ''}($to) on ${serverName(widget.server)}?\n\nTransfers cannot be undone.'),
        ok: L.t('Enviar', 'Send'));
    if (!ok) return;
    final J r = await Native.api(widget.server, 'POST', '/api/transfer', body: <String, dynamic>{'toId': to, 'amount': F.api(sats, widget.server)});
    HapticFeedback.mediumImpact();
    if (mounted) setState(() => _done = r);
    if (widget.server == _s.activeId) unawaited(_s.refreshAll());
  }

  Future<void> _pickNearby() async {
    final Peer? peer = await pickNearby(context, server: widget.server);
    if (peer == null) return;
    setState(() {
      _to.text = peer.uid;
      _name = peer.name;
    });
    if (_name.isEmpty) unawaited(_lookup());
  }

  @override
  Widget build(BuildContext context) {
    final Pal p = Pal.of(context);
    final J? d = _done;
    if (d != null) {
      return SuccessView(
        title: L.t('Enviado!', 'Sent!'),
        sats: F.satsOf(d, 'amountSats', 'amount'),
        subtitle: L.t('para ${_name.isNotEmpty ? _name : _to.text}', 'to ${_name.isNotEmpty ? _name : _to.text}'),
        server: widget.server,
        txId: js(d, 'txId'),
      );
    }
    final int? bal = widget.server == _s.activeId ? _s.balance : null;
    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(20, 0, 20, 22),
      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: <Widget>[
        sheetTitle(context, Icons.send_rounded, L.t('Enviar coins', 'Send coins'), subtitle: serverName(widget.server)),
        IdField(
          controller: _to,
          label: L.t('Para (ID da conta)', 'To (account ID)'),
          trailing: Row(mainAxisSize: MainAxisSize.min, children: <Widget>[
            IconButton(
              tooltip: L.t('Colar', 'Paste'),
              icon: const Icon(Icons.content_paste_rounded),
              onPressed: () async {
                final ClipboardData? c = await Clipboard.getData(Clipboard.kTextPlain);
                final String t = (c?.text ?? '').replaceAll(RegExp(r'\D'), '');
                if (t.isNotEmpty) {
                  _to.text = t;
                  unawaited(_lookup());
                }
              },
            ),
            IconButton(tooltip: L.t('Por perto', 'Nearby'), icon: const Icon(Icons.wifi_tethering_rounded), onPressed: _pickNearby),
          ]),
        ),
        AnimatedSize(
          duration: const Duration(milliseconds: 250),
          child: _name.isEmpty
              ? const SizedBox(height: 12)
              : Padding(
                  padding: const EdgeInsets.fromLTRB(6, 8, 6, 10),
                  child: Row(children: <Widget>[Avatar(_name, size: 26), const SizedBox(width: 8), Text(_name, style: const TextStyle(fontWeight: FontWeight.w800))]),
                ),
        ),
        AmountField(controller: _amt),
        if (bal != null)
          Padding(
            padding: const EdgeInsets.fromLTRB(6, 8, 6, 0),
            child: Row(children: <Widget>[
              Text(L.t('Disponível: ', 'Available: '), style: TextStyle(color: p.fg2)),
              Text('${F.coins(bal)} coins', style: const TextStyle(fontWeight: FontWeight.w800)),
              const Spacer(),
              TextButton(onPressed: () => _amt.text = F.coins(bal, net: widget.server), child: Text(L.t('Tudo', 'Max'))),
            ]),
          ),
        const SizedBox(height: 16),
        BusyButton(label: L.t('Continuar', 'Continue'), icon: Icons.arrow_forward_rounded, onPressed: _send),
      ]),
    );
  }
}

// ═══════════════════════════════ COBRAR (QR / NFC / por perto) ═══════════════════════════════

Future<void> openCharge(BuildContext context, {String? server}) {
  return showSheet<void>(context, (BuildContext c) => ChargeSheet(server: server ?? _s.activeId));
}

class ChargeSheet extends StatefulWidget {
  const ChargeSheet({super.key, required this.server});
  final String server;

  @override
  State<ChargeSheet> createState() => _ChargeSheetState();
}

class _ChargeSheetState extends State<ChargeSheet> {
  final TextEditingController _amt = TextEditingController();
  final TextEditingController _memo = TextEditingController();
  bool _reusable = false;
  PayReq? _req;
  bool _paid = false;
  bool _closed = false;
  String _nfc = 'unsupported';
  // modo local: redes sem /api/pay/request (API antiga) — QR de pagamento direto para a conta,
  // e o pagamento é confirmado pelo extrato
  bool _local = false;
  final Set<String> _seen = <String>{};

  @override
  void dispose() {
    _closed = true;
    _amt.dispose();
    _memo.dispose();
    unawaited(Native.call('nfc.charge', <String, dynamic>{'text': null}).catchError((Object _) => <String, dynamic>{}));
    super.dispose();
  }

  Future<void> _create() async {
    final String t = _amt.text.trim();
    final int? sats = t.isEmpty ? null : F.parse(t, widget.server);
    if (t.isNotEmpty && (sats == null || sats <= 0)) throw ApiException('INVALID_AMOUNT', 400, <String, dynamic>{});
    final J body = <String, dynamic>{'reusable': _reusable};
    if (sats != null) body['amount'] = F.api(sats, widget.server);
    if (_memo.text.trim().isNotEmpty) body['memo'] = _memo.text.trim();
    PayReq q;
    try {
      final J r = await Native.api(widget.server, 'POST', '/api/pay/request', body: body);
      q = PayReq(jm(r, 'request'));
      if (q.id.isEmpty || q.url.isEmpty) throw ApiException('http_404', 404, <String, dynamic>{});
    } on ApiException catch (e) {
      if (!_unsupported(e)) rethrow;
      q = await _localRequest(sats);
    }
    try {
      final J n = await Native.call('nfc.charge', <String, dynamic>{'text': q.url});
      _nfc = js(n, 'state', 'unsupported');
    } catch (_) {}
    if (!mounted) return;
    setState(() => _req = q);
    unawaited(_local ? _watchLocal() : _watch());
  }

  static bool _unsupported(ApiException e) =>
      e.status == 404 || e.status == 405 || e.status == 501 || e.code == 'NOT_FOUND' || e.code == 'Not found' || e.code.startsWith('http_404') || e.code.startsWith('http_405');

  /// cobrança local (sem pedido no servidor): QR com o link de pagamento direto para esta conta
  Future<PayReq> _localRequest(int? sats) async {
    final String me = myIdOn(widget.server);
    try {
      final J r = await Native.api(widget.server, 'GET', '/api/transactions?page=1');
      for (final J t in jl(r, 'transactions')) {
        _seen.add(js(t, 'id'));
      }
    } catch (_) {}
    _local = true;
    final String url = '${serverUrl(widget.server)}/pay/u/$me${sats == null ? '' : '?amount=${F.api(sats, widget.server)}'}';
    return PayReq(<String, dynamic>{
      'id': 'local-${DateTime.now().millisecondsSinceEpoch}',
      'to': me,
      'toName': _s.username,
      'amountSats': sats,
      'amount': sats == null ? null : F.api(sats, widget.server),
      'open': sats == null,
      'memo': _memo.text.trim(),
      'reusable': _reusable,
      'status': 'open',
      'paidCount': 0,
      'paidTotalSats': 0,
      'url': url,
    });
  }

  /// confirma pelo extrato (a cada 3 s) quando a rede não tem pedidos de pagamento
  Future<void> _watchLocal() async {
    final String me = myIdOn(widget.server);
    while (!_closed && mounted) {
      await Future<void>.delayed(const Duration(seconds: 3));
      if (_closed || !mounted) return;
      final PayReq? q = _req;
      if (q == null || !q.isOpen) return;
      try {
        final J r = await Native.api(widget.server, 'GET', '/api/transactions?page=1');
        for (final J m in jl(r, 'transactions')) {
          final Tx t = Tx.fromJson(m);
          if (_seen.contains(t.id)) continue;
          _seen.add(t.id);
          if (t.to != me || t.from == me || t.isClaim) continue;
          if (q.sats != null && t.sats != q.sats) continue;
          final J raw = <String, dynamic>{...q.raw};
          raw['paidCount'] = q.paidCount + 1;
          raw['paidTotalSats'] = q.paidTotal + t.sats;
          raw['lastTx'] = t.id;
          raw['lastPayer'] = t.from;
          if (!q.reusable) raw['status'] = 'paid';
          HapticFeedback.heavyImpact();
          if (!mounted) return;
          setState(() {
            _req = PayReq(raw);
            _paid = true;
          });
          if (widget.server == _s.activeId) unawaited(_s.refreshAll());
          if (!q.reusable) return;
          break;
        }
      } catch (_) {}
    }
  }

  /// espera o pagamento (long-poll de até 25 s por vez)
  Future<void> _watch() async {
    int fails = 0;
    while (!_closed && mounted) {
      final PayReq? q = _req;
      if (q == null || !q.isOpen) break;
      try {
        final J r = await Native.api(widget.server, 'GET', '/api/pay/request/${q.id}?wait=25&since=${q.paidCount}', noAuth: true);
        if (_closed || !mounted) return;
        final PayReq n = PayReq(jm(r, 'request'));
        final bool newPay = n.paidCount > q.paidCount;
        setState(() {
          _req = n;
          if (newPay) _paid = true;
        });
        if (newPay) {
          HapticFeedback.heavyImpact();
          if (widget.server == _s.activeId) unawaited(_s.refreshAll());
          if (!n.reusable) break;
        }
        fails = 0;
      } catch (_) {
        fails++;
        await Future<void>.delayed(Duration(seconds: fails > 5 ? 10 : 3));
      }
    }
  }

  Future<void> _cancel() async {
    final PayReq? q = _req;
    if (q == null) return;
    if (!_local) await Native.api(widget.server, 'POST', '/api/pay/request/${q.id}/cancel');
    if (mounted) Navigator.of(context).maybePop();
  }

  Future<void> _sendNearby() async {
    final PayReq? q = _req;
    if (q == null) return;
    final Peer? peer = await pickNearby(context, server: widget.server);
    if (peer == null) return;
    await Native.call('nearby.send', <String, dynamic>{
      'device': peer.device,
      'msg': jsonEncode(<String, dynamic>{'kind': 'charge', 'url': q.url, 'amount': q.sats == null ? null : F.api(q.sats!, widget.server), 'memo': q.memo, 'net': serverUrl(widget.server), 'netName': serverName(widget.server)}),
    });
    toast(L.t('Cobrança enviada para ${peer.name.isEmpty ? peer.uid : peer.name}', 'Request sent to ${peer.name.isEmpty ? peer.uid : peer.name}'), ok: true);
  }

  @override
  Widget build(BuildContext context) {
    final Pal p = Pal.of(context);
    final PayReq? q = _req;
    if (q == null) {
      return SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(20, 0, 20, 22),
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: <Widget>[
          sheetTitle(context, Icons.qr_code_2_rounded, L.t('Cobrar', 'Charge'), subtitle: L.t('QR Code, aproximação (NFC) ou quem está perto', 'QR code, tap (NFC) or people nearby')),
          AmountField(controller: _amt, hint: L.t('Deixe vazio para valor livre', 'Leave empty for any amount')),
          const SizedBox(height: 12),
          TextField(
            controller: _memo,
            maxLength: 140,
            decoration: InputDecoration(labelText: L.t('Descrição (opcional)', 'Description (optional)'), prefixIcon: const Icon(Icons.notes_rounded)),
          ),
          SwitchListTile(
            contentPadding: const EdgeInsets.symmetric(horizontal: 4),
            value: _reusable,
            onChanged: (bool v) => setState(() => _reusable = v),
            title: Text(L.t('Aceitar vários pagamentos', 'Accept multiple payments'), style: const TextStyle(fontWeight: FontWeight.w700)),
            subtitle: Text(L.t('Ex.: QR fixo de uma loja', 'E.g. a shop\'s fixed QR'), style: TextStyle(color: p.fg2)),
          ),
          const SizedBox(height: 8),
          BusyButton(label: L.t('Gerar cobrança', 'Create request'), icon: Icons.qr_code_rounded, onPressed: _create),
        ]),
      );
    }
    if (_paid && !q.reusable) {
      return SuccessView(title: L.t('Pagamento recebido!', 'Payment received!'), sats: q.paidTotal, subtitle: L.t('de ${q.lastPayer}', 'from ${q.lastPayer}'), server: widget.server, txId: q.lastTx);
    }
    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(20, 0, 20, 22),
      child: Column(children: <Widget>[
        sheetTitle(context, Icons.qr_code_2_rounded, L.t('Cobrança criada', 'Request created'), subtitle: serverName(widget.server)),
        AnimatedSwitcher(
          duration: const Duration(milliseconds: 300),
          child: _paid
              ? Container(
                  key: ValueKey<int>(q.paidCount),
                  margin: const EdgeInsets.only(bottom: 12),
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(color: p.okSoft, borderRadius: BorderRadius.circular(14)),
                  child: Row(children: <Widget>[
                    Icon(Icons.check_circle_rounded, color: p.ok),
                    const SizedBox(width: 8),
                    Expanded(child: Text(L.t('${q.paidCount} pagamento(s) · total ${F.coins(q.paidTotal)} coins', '${q.paidCount} payment(s) · total ${F.coins(q.paidTotal)} coins'), style: TextStyle(color: p.ok, fontWeight: FontWeight.w800))),
                  ]),
                )
              : const SizedBox.shrink(),
        ),
        FadeSlide(child: QrView(q.url, size: 250)),
        const SizedBox(height: 14),
        if (q.sats != null) CoinText(q.sats!, size: 28, color: p.gold) else Text(L.t('Valor livre', 'Any amount'), style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: p.gold)),
        if (q.memo.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 4), child: Text(q.memo, style: TextStyle(color: p.fg2))),
        const SizedBox(height: 10),
        Row(mainAxisAlignment: MainAxisAlignment.center, children: <Widget>[
          SizedBox(width: 14, height: 14, child: CircularProgressIndicator(strokeWidth: 2, color: p.gold)),
          const SizedBox(width: 8),
          Text(L.t('Aguardando pagamento…', 'Waiting for payment…'), style: TextStyle(color: p.fg2, fontWeight: FontWeight.w600)),
        ]),
        const SizedBox(height: 14),
        if (_nfc == 'on')
          AppCard(
            padding: const EdgeInsets.all(12),
            color: p.goldSoft,
            child: Row(children: <Widget>[
              Icon(Icons.contactless_rounded, color: p.gold, size: 30),
              const SizedBox(width: 10),
              Expanded(child: Text(L.t('Aproxime o celular de quem vai pagar (NFC) — ele abre esta cobrança na hora.', 'Hold the payer\'s phone near this one (NFC) — it opens this request instantly.'), style: TextStyle(color: p.fg, fontWeight: FontWeight.w600))),
            ]),
          ),
        const SizedBox(height: 12),
        Row(children: <Widget>[
          Expanded(child: OutlinedButton.icon(onPressed: () => copyText(q.url, 'Link'), icon: const Icon(Icons.copy_rounded, size: 18), label: Text(L.t('Copiar', 'Copy')))),
          const SizedBox(width: 10),
          Expanded(
              child: OutlinedButton.icon(
                  onPressed: () => Native.call('shareText', <String, dynamic>{'text': q.url, 'title': L.t('Cobrança', 'Request')}), icon: const Icon(Icons.share_rounded, size: 18), label: Text(L.t('Enviar', 'Share')))),
        ]),
        const SizedBox(height: 10),
        SizedBox(width: double.infinity, child: OutlinedButton.icon(onPressed: _sendNearby, icon: const Icon(Icons.wifi_tethering_rounded, size: 18), label: Text(L.t('Mandar para quem está perto', 'Send to someone nearby')))),
        const SizedBox(height: 6),
        TextButton(onPressed: () => _cancel().catchError((Object e) => toast(errText(e), error: true)), child: Text(L.t('Cancelar cobrança', 'Cancel request'), style: TextStyle(color: p.bad))),
      ]),
    );
  }
}

// ═══════════════════════════════ PAGAR COBRANÇA POR QR ═══════════════════════════════

class PayRequestSheet extends StatefulWidget {
  const PayRequestSheet({super.key, required this.server, required this.req});
  final String server;
  final PayReq req;

  @override
  State<PayRequestSheet> createState() => _PayRequestSheetState();
}

class _PayRequestSheetState extends State<PayRequestSheet> {
  final TextEditingController _amt = TextEditingController();
  J? _done;

  @override
  void dispose() {
    _amt.dispose();
    super.dispose();
  }

  Future<void> _pay() async {
    final PayReq q = widget.req;
    final int? sats = q.sats ?? F.parse(_amt.text, widget.server);
    if (sats == null || sats <= 0) throw ApiException('AMOUNT_REQUIRED', 400, <String, dynamic>{});
    final bool ok = await confirm(context,
        icon: Icons.payments_rounded,
        title: L.t('Confirmar pagamento', 'Confirm payment'),
        text: L.t('Pagar ${F.coins(sats)} coins para ${q.toName.isNotEmpty ? q.toName : q.to}?', 'Pay ${F.coins(sats)} coins to ${q.toName.isNotEmpty ? q.toName : q.to}?'),
        ok: L.t('Pagar', 'Pay'));
    if (!ok) return;
    final J body = <String, dynamic>{};
    if (q.sats == null) body['amount'] = F.api(sats, widget.server);
    final J r = await Native.api(widget.server, 'POST', '/api/pay/request/${q.id}/pay', body: body);
    HapticFeedback.mediumImpact();
    if (mounted) setState(() => _done = r);
    if (widget.server == _s.activeId) unawaited(_s.refreshAll());
  }

  @override
  Widget build(BuildContext context) {
    final Pal p = Pal.of(context);
    final PayReq q = widget.req;
    final J? d = _done;
    if (d != null) {
      return SuccessView(title: L.t('Pago!', 'Paid!'), sats: F.satsOf(d, 'amountSats', 'amount'), subtitle: q.toName.isNotEmpty ? q.toName : q.to, server: widget.server, txId: js(d, 'txId'));
    }
    final bool mine = q.to == myIdOn(widget.server);
    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(20, 0, 20, 22),
      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: <Widget>[
        sheetTitle(context, Icons.payments_rounded, L.t('Pagar cobrança', 'Pay request'), subtitle: serverName(widget.server)),
        AppCard(
          child: Column(children: <Widget>[
            Avatar(q.toName.isNotEmpty ? q.toName : '#', size: 56),
            const SizedBox(height: 8),
            Text(q.toName.isNotEmpty ? q.toName : L.t('Conta', 'Account'), style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 18)),
            Text(q.to, style: TextStyle(color: p.fg2, fontFamily: 'monospace')),
            const SizedBox(height: 12),
            if (q.sats != null) CoinText(q.sats!, size: 30, color: p.gold),
            if (q.memo.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 6), child: Text('“${q.memo}”', style: TextStyle(color: p.fg2, fontStyle: FontStyle.italic))),
            const SizedBox(height: 6),
            Pill(q.isOpen ? L.t('Aberta', 'Open') : q.status.toUpperCase(), color: q.isOpen ? p.ok : p.bad),
          ]),
        ),
        const SizedBox(height: 14),
        if (q.sats == null && q.isOpen && !mine) AmountField(controller: _amt, autofocus: true),
        if (mine)
          Text(L.t('Esta cobrança é sua.', 'This request is yours.'), textAlign: TextAlign.center, style: TextStyle(color: p.fg2))
        else if (!q.isOpen)
          Text(L.err(q.status == 'paid' ? 'PAYREQ_PAID' : (q.status == 'cancelled' ? 'PAYREQ_CANCELLED' : 'PAYREQ_EXPIRED')), textAlign: TextAlign.center, style: TextStyle(color: p.bad))
        else ...<Widget>[
          const SizedBox(height: 12),
          BusyButton(label: L.t('Pagar agora', 'Pay now'), icon: Icons.lock_rounded, onPressed: _pay),
        ],
      ]),
    );
  }
}

// ═══════════════════════════════ COBRANÇAS (BILLS) ═══════════════════════════════

Future<void> openBill(BuildContext context, {required String server, required Bill bill}) {
  return showSheet<void>(context, (BuildContext c) => BillSheet(server: server, bill: bill));
}

class BillSheet extends StatefulWidget {
  const BillSheet({super.key, required this.server, required this.bill});
  final String server;
  final Bill bill;

  @override
  State<BillSheet> createState() => _BillSheetState();
}

class _BillSheetState extends State<BillSheet> {
  J? _done;

  Future<void> _pay(bool cancel) async {
    final Bill b = widget.bill;
    final bool ok = await confirm(context,
        icon: cancel ? Icons.cancel_outlined : Icons.payments_rounded,
        danger: cancel,
        title: cancel ? L.t('Cancelar cobrança?', 'Cancel bill?') : L.t('Pagar cobrança?', 'Pay bill?'),
        text: cancel
            ? L.t('A cobrança de ${F.coins(b.sats)} coins será encerrada. Nenhum coin é movido.', 'The bill of ${F.coins(b.sats)} coins will be closed. No coins move.')
            : L.t('Pagar ${F.coins(b.sats)} coins para ${b.to}?', 'Pay ${F.coins(b.sats)} coins to ${b.to}?'),
        ok: cancel ? L.t('Encerrar', 'Close it') : L.t('Pagar', 'Pay'));
    if (!ok) return;
    final J r = await Native.api(widget.server, 'POST', '/api/bill/pay', body: <String, dynamic>{'billId': b.id});
    HapticFeedback.mediumImpact();
    if (widget.server == _s.activeId) unawaited(_s.refreshAll());
    if (!mounted) return;
    if (cancel) {
      toast(L.t('Cobrança encerrada', 'Bill closed'), ok: true);
      Navigator.of(context).maybePop();
    } else {
      setState(() => _done = r);
    }
  }

  @override
  Widget build(BuildContext context) {
    final Pal p = Pal.of(context);
    final Bill b = widget.bill;
    final J? d = _done;
    if (d != null) return SuccessView(title: L.t('Cobrança paga!', 'Bill paid!'), sats: b.sats, subtitle: b.to, server: widget.server, txId: js(d, 'txId'));
    final String me = myIdOn(widget.server);
    final bool mine = b.to == me;
    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(20, 0, 20, 22),
      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: <Widget>[
        sheetTitle(context, Icons.request_quote_rounded, mine ? L.t('Cobrança que você criou', 'Bill you created') : L.t('Cobrança para pagar', 'Bill to pay'), subtitle: serverName(widget.server)),
        Center(child: CoinText(b.sats, size: 32, color: p.gold)),
        const SizedBox(height: 12),
        AppCard(
          child: Column(children: <Widget>[
            InfoRow(L.t('Quem recebe', 'Receiver'), b.to, mono: true, copy: true),
            InfoRow(L.t('Quem paga', 'Payer'), b.from.isEmpty ? L.t('Qualquer pessoa', 'Anyone') : b.from, mono: b.from.isNotEmpty),
            InfoRow(L.t('Criada', 'Created'), F.dateTime(b.date)),
            if (b.expiresAt != null) InfoRow(L.t('Vence', 'Expires'), F.dateTime(b.expiresAt!)),
            InfoRow('ID', F.short(b.id, 8), mono: true),
          ]),
        ),
        if (mine) ...<Widget>[
          const SizedBox(height: 16),
          Center(child: QrView(b.id, size: 200)),
          const SizedBox(height: 8),
          Center(child: Text(L.t('Quem paga escaneia este QR no app', 'The payer scans this QR in the app'), style: TextStyle(color: p.fg2, fontSize: 12.5))),
          const SizedBox(height: 12),
          Row(children: <Widget>[
            Expanded(child: OutlinedButton.icon(onPressed: () => copyText(b.id, 'ID'), icon: const Icon(Icons.copy_rounded, size: 18), label: Text(L.t('Copiar ID', 'Copy ID')))),
            const SizedBox(width: 10),
            Expanded(child: OutlinedButton.icon(onPressed: () => sendBillNearby(context, widget.server, b), icon: const Icon(Icons.wifi_tethering_rounded, size: 18), label: Text(L.t('Por perto', 'Nearby')))),
          ]),
          const SizedBox(height: 8),
          TextButton(onPressed: () => _pay(true).catchError((Object e) => toast(errText(e), error: true)), child: Text(L.t('Encerrar cobrança', 'Close bill'), style: TextStyle(color: p.bad))),
        ] else ...<Widget>[
          const SizedBox(height: 16),
          BusyButton(label: L.t('Pagar cobrança', 'Pay bill'), icon: Icons.lock_rounded, onPressed: () => _pay(false)),
        ],
      ]),
    );
  }
}

Future<void> sendBillNearby(BuildContext context, String server, Bill b, {Peer? peer}) async {
  final Peer? target = peer ?? await pickNearby(context, server: server);
  if (target == null) return;
  try {
    await Native.call('nearby.send', <String, dynamic>{
      'device': target.device,
      'msg': jsonEncode(<String, dynamic>{'kind': 'bill', 'billId': b.id, 'amount': F.api(b.sats, server), 'to': b.to, 'net': serverUrl(server), 'netName': serverName(server)}),
    });
    toast(L.t('Cobrança enviada para ${target.name.isEmpty ? target.uid : target.name}', 'Bill sent to ${target.name.isEmpty ? target.uid : target.name}'), ok: true);
  } catch (e) {
    toast(errText(e), error: true);
  }
}

Future<void> openCreateBill(BuildContext context, {String? server, String? payerId, Peer? peer}) {
  return showSheet<void>(context, (BuildContext c) => CreateBillSheet(server: server ?? _s.activeId, payerId: payerId, peer: peer));
}

class CreateBillSheet extends StatefulWidget {
  const CreateBillSheet({super.key, required this.server, this.payerId, this.peer});
  final String server;
  final String? payerId;
  final Peer? peer;

  @override
  State<CreateBillSheet> createState() => _CreateBillSheetState();
}

class _CreateBillSheetState extends State<CreateBillSheet> {
  final TextEditingController _payer = TextEditingController();
  final TextEditingController _amt = TextEditingController();
  String _time = '7d';
  Peer? _peer;

  @override
  void initState() {
    super.initState();
    _peer = widget.peer;
    _payer.text = widget.payerId ?? widget.peer?.uid ?? '';
  }

  @override
  void dispose() {
    _payer.dispose();
    _amt.dispose();
    super.dispose();
  }

  Future<void> _create() async {
    final int? sats = F.parse(_amt.text, widget.server);
    if (sats == null || sats <= 0) throw ApiException('INVALID_AMOUNT', 400, <String, dynamic>{});
    final String me = myIdOn(widget.server);
    final J r = await Native.api(widget.server, 'POST', '/api/bill/create', body: <String, dynamic>{'fromId': _payer.text.trim(), 'toId': me, 'amount': F.api(sats, widget.server), 'time': _time});
    final Bill b = Bill(id: js(r, 'billId'), from: _payer.text.trim(), to: me, sats: sats, date: DateTime.now(), expiresAt: F.parseDate(r['expiresAt']));
    HapticFeedback.mediumImpact();
    if (widget.server == _s.activeId) unawaited(_s.refreshAll());
    final Peer? peer = _peer;
    if (peer != null && peer.uid == _payer.text.trim() && mounted) await sendBillNearby(context, widget.server, b, peer: peer);
    if (!mounted) return;
    final NavigatorState nav = Navigator.of(context);
    await nav.maybePop();
    final BuildContext? c = navKey.currentContext;
    if (c != null && c.mounted) unawaited(openBill(c, server: widget.server, bill: b));
  }

  @override
  Widget build(BuildContext context) {
    final Map<String, String> times = <String, String>{'1h': '1 h', '1d': L.t('1 dia', '1 day'), '7d': L.t('7 dias', '7 days'), '30d': L.t('30 dias', '30 days'), '90d': L.t('90 dias', '90 days')};
    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(20, 0, 20, 22),
      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: <Widget>[
        sheetTitle(context, Icons.request_quote_rounded, L.t('Gerar cobrança', 'Create bill'), subtitle: L.t('A pessoa recebe e paga pelo app', 'The person gets it and pays in the app')),
        IdField(
          controller: _payer,
          label: L.t('Quem vai pagar (ID, opcional)', 'Who pays (ID, optional)'),
          trailing: IconButton(
            icon: const Icon(Icons.wifi_tethering_rounded),
            tooltip: L.t('Por perto', 'Nearby'),
            onPressed: () async {
              final Peer? pe = await pickNearby(context, server: widget.server);
              if (pe != null) {
                setState(() {
                  _peer = pe;
                  _payer.text = pe.uid;
                });
              }
            },
          ),
        ),
        const SizedBox(height: 12),
        AmountField(controller: _amt),
        const SizedBox(height: 14),
        Text(L.t('Vencimento', 'Expires in'), style: const TextStyle(fontWeight: FontWeight.w800)),
        const SizedBox(height: 8),
        Wrap(spacing: 8, runSpacing: 8, children: <Widget>[
          for (final MapEntry<String, String> e in times.entries)
            ChoiceChip(label: Text(e.value), selected: _time == e.key, onSelected: (bool _) => setState(() => _time = e.key)),
        ]),
        const SizedBox(height: 18),
        BusyButton(label: L.t('Criar cobrança', 'Create bill'), icon: Icons.add_rounded, onPressed: _create),
      ]),
    );
  }
}

/// pagar uma cobrança digitando/colando o ID
Future<void> payBillById(BuildContext context, {String? server}) async {
  final String sid = server ?? _s.activeId;
  final String? id = await askText(context, title: L.t('Pagar cobrança', 'Pay bill'), hint: L.t('ID da cobrança', 'Bill ID'), ok: L.t('Buscar', 'Find'));
  if (id == null || id.trim().isEmpty) return;
  try {
    final J r = await Native.api(sid, 'GET', '/api/bill/${Uri.encodeComponent(id.trim())}', noAuth: true);
    final BuildContext? c = navKey.currentContext;
    if (c != null && c.mounted) await openBill(c, server: sid, bill: Bill.fromJson(jm(r, 'bill')));
  } catch (e) {
    toast(errText(e), error: true);
  }
}

// ═══════════════════════════════ ESCANEAR / APROXIMAR ═══════════════════════════════

Future<void> scanToPay(BuildContext context) async {
  try {
    final J r = await Native.call('scan');
    final String t = js(r, 'text');
    if (t.isEmpty) return;
    final BuildContext? c = navKey.currentContext;
    if (c != null && c.mounted) await handleScanned(c, t);
  } catch (e) {
    toast(errText(e), error: true);
  }
}

/// interpreta o que foi lido (QR, NFC, link) e abre a tela certa
Future<void> handleScanned(BuildContext context, String raw) async {
  final String text = raw.trim();
  if (text.isEmpty) return;
  String server = _s.activeId;
  String path = text;
  Map<String, String> query = <String, String>{};
  final Uri? u = Uri.tryParse(text);
  Future<String?> ensureServer(String url) async {
    final Server? sv = _s.serverByUrl(url);
    if (sv != null) return sv.id;
    final Uri? x = Uri.tryParse(url);
    final String origin = x == null ? url : '${x.scheme}://${x.authority}';
    final BuildContext? c0 = navKey.currentContext;
    if (c0 == null || !c0.mounted) return null;
    final bool ok = await confirm(c0,
        icon: Icons.hub_rounded,
        title: L.t('Outra rede', 'Another network'),
        text: L.t('Este código é da rede $origin, que ainda não está no app. Adicionar e continuar?', 'This code belongs to $origin, which is not in the app yet. Add it and continue?'),
        ok: L.t('Adicionar', 'Add'));
    if (!ok) return null;
    final J r = await Native.call('servers.add', <String, dynamic>{'url': origin});
    await _s.reloadState();
    return js(jm(r, 'server'), 'id');
  }

  try {
    if (u != null && (u.scheme == 'http' || u.scheme == 'https') && u.host.isNotEmpty) {
      final String? id = await ensureServer(text);
      if (id == null) return;
      server = id;
      path = u.path;
      query = u.queryParameters;
    } else if (u != null && u.scheme == 'coinbank') {
      final String net = u.queryParameters['net'] ?? '';
      if (net.isNotEmpty) {
        final String? id = await ensureServer(net);
        if (id == null) return;
        server = id;
      }
      path = '/${u.host}${u.path}';
      query = u.queryParameters;
    }
    final BuildContext? c = navKey.currentContext;
    if (c == null || !c.mounted) return;
    if (_s.sessionOf(server) == null) {
      final bool go = await confirm(c,
          icon: Icons.login_rounded,
          title: L.t('Entre na rede', 'Sign in to the network'),
          text: L.t('Para pagar na rede ${serverName(server)} você precisa entrar nela. Trocar para essa rede agora?', 'To pay on ${serverName(server)} you need to sign in there. Switch to that network now?'),
          ok: L.t('Trocar', 'Switch'));
      if (go) await _s.setActive(server);
      return;
    }
    RegExpMatch? m;
    if ((m = RegExp(r'^/pay/u/(\d{1,32})/?$').firstMatch(path)) != null || (m = RegExp(r'^/user/(\d{1,32})/?$').firstMatch(path)) != null) {
      final String? a = query['amount'];
      await openSend(c, server: server, toId: m!.group(1), amount: a == null ? null : F.parseApi(a, server));
      return;
    }
    if ((m = RegExp(r'^/pay/([A-Za-z0-9_-]{8,40})/?$').firstMatch(path)) != null) {
      final J r = await Native.api(server, 'GET', '/api/pay/request/${m!.group(1)}', noAuth: true);
      final BuildContext? c2 = navKey.currentContext;
      if (c2 != null && c2.mounted) await showSheet<void>(c2, (BuildContext x) => PayRequestSheet(server: server, req: PayReq(jm(r, 'request'))));
      return;
    }
    if ((m = RegExp(r'^/tx/([^/]{1,64})/?$').firstMatch(path)) != null) {
      await openReceipt(c, server: server, txId: m!.group(1));
      return;
    }
    if (RegExp(r'^[0-9a-fA-F-]{36}$').hasMatch(text)) {
      try {
        final J r = await Native.api(server, 'GET', '/api/bill/$text', noAuth: true);
        final BuildContext? c2 = navKey.currentContext;
        if (c2 != null && c2.mounted) await openBill(c2, server: server, bill: Bill.fromJson(jm(r, 'bill')));
        return;
      } catch (_) {}
      final BuildContext? c3 = navKey.currentContext;
      if (c3 != null && c3.mounted) await openReceipt(c3, server: server, txId: text);
      return;
    }
    if (RegExp(r'^\d{5,32}$').hasMatch(text)) {
      await openSend(c, server: server, toId: text);
      return;
    }
    // último recurso: o servidor interpreta
    final J r = await Native.api(server, 'POST', '/api/pay/scan', body: <String, dynamic>{'data': text}, noAuth: true);
    final BuildContext? c4 = navKey.currentContext;
    if (c4 == null || !c4.mounted) return;
    switch (js(r, 'type')) {
      case 'user':
        await openSend(c4, server: server, toId: js(r, 'userId'), name: js(r, 'name'), amount: r['amountSats'] == null ? null : F.satsOf(r, 'amountSats', 'amount'));
        break;
      case 'request':
        await showSheet<void>(c4, (BuildContext x) => PayRequestSheet(server: server, req: PayReq(jm(r, 'request'))));
        break;
      case 'bill':
        await openBill(c4, server: server, bill: Bill.fromJson(jm(r, 'bill')));
        break;
      case 'transaction':
        await openReceipt(c4, server: server, tx: Tx.fromJson(jm(r, 'tx')));
        break;
      default:
        toast(L.t('Código não reconhecido.', 'Code not recognized.'), error: true);
    }
  } catch (e) {
    toast(errText(e), error: true);
  }
}

/// pagar por aproximação: liga o leitor NFC e espera o celular de quem cobra
Future<void> nfcPay(BuildContext context) async {
  final J st = await Native.call('nfc.state');
  final String state = js(st, 'state');
  final BuildContext? c = navKey.currentContext;
  if (c == null || !c.mounted) return;
  if (state != 'on') {
    final bool go = await confirm(c,
        icon: Icons.contactless_rounded,
        title: state == 'unsupported' ? L.t('Sem NFC', 'No NFC') : L.t('NFC desligado', 'NFC is off'),
        text: state == 'unsupported'
            ? L.t('Este aparelho não tem NFC. Use o QR Code.', 'This device has no NFC. Use the QR code.')
            : L.t('Ligue o NFC nas configurações do Android para pagar por aproximação.', 'Turn on NFC in Android settings to pay by tapping.'),
        ok: state == 'unsupported' ? 'OK' : L.t('Abrir configurações', 'Open settings'));
    if (go && state != 'unsupported') await Native.call('nfc.settings');
    return;
  }
  await showSheet<void>(c, (BuildContext x) => const _NfcWait());
}

class _NfcWait extends StatefulWidget {
  const _NfcWait();

  @override
  State<_NfcWait> createState() => _NfcWaitState();
}

class _NfcWaitState extends State<_NfcWait> with SingleTickerProviderStateMixin {
  StreamSubscription<String>? _sub;
  late final AnimationController _a = AnimationController(vsync: this, duration: const Duration(milliseconds: 1600))..repeat();

  @override
  void initState() {
    super.initState();
    unawaited(Native.call('nfc.read', <String, dynamic>{'on': true}).catchError((Object _) => <String, dynamic>{}));
    _sub = AppState.I.nfcPayloads.stream.listen((String p) async {
      HapticFeedback.heavyImpact();
      final NavigatorState nav = Navigator.of(context);
      await nav.maybePop();
      final BuildContext? c = navKey.currentContext;
      if (c != null && c.mounted) await handleScanned(c, p);
    });
  }

  @override
  void dispose() {
    _sub?.cancel();
    _a.dispose();
    unawaited(Native.call('nfc.read', <String, dynamic>{'on': false}).catchError((Object _) => <String, dynamic>{}));
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final Pal p = Pal.of(context);
    return Padding(
      padding: const EdgeInsets.fromLTRB(24, 0, 24, 30),
      child: Column(mainAxisSize: MainAxisSize.min, children: <Widget>[
        Text(L.t('Pagar por aproximação', 'Tap to pay'), style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
        const SizedBox(height: 24),
        SizedBox(
          width: 170,
          height: 170,
          child: AnimatedBuilder(
            animation: _a,
            builder: (BuildContext c, Widget? ch) => Stack(alignment: Alignment.center, children: <Widget>[
              for (int i = 0; i < 3; i++)
                Opacity(
                  opacity: (1 - ((_a.value + i / 3) % 1)).clamp(0.0, 1.0),
                  child: Container(
                    width: 70 + 100 * ((_a.value + i / 3) % 1),
                    height: 70 + 100 * ((_a.value + i / 3) % 1),
                    decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: p.gold, width: 2)),
                  ),
                ),
              ch!,
            ]),
            child: Container(width: 74, height: 74, decoration: BoxDecoration(color: p.gold, shape: BoxShape.circle), child: const Icon(Icons.contactless_rounded, color: Colors.white, size: 40)),
          ),
        ),
        const SizedBox(height: 22),
        Text(L.t('Encoste no celular de quem está cobrando.\nA cobrança abre aqui para você confirmar.', 'Hold near the phone that is charging.\nThe request opens here for you to confirm.'),
            textAlign: TextAlign.center, style: TextStyle(color: p.fg2, height: 1.4)),
      ]),
    );
  }
}

// ═══════════════════════════════ ESCOLHER ALGUÉM POR PERTO ═══════════════════════════════

Future<Peer?> pickNearby(BuildContext context, {String? server}) {
  return showSheet<Peer>(context, (BuildContext c) => _NearbyPicker(server: server));
}

class _NearbyPicker extends StatefulWidget {
  const _NearbyPicker({this.server});
  final String? server;

  @override
  State<_NearbyPicker> createState() => _NearbyPickerState();
}

class _NearbyPickerState extends State<_NearbyPicker> {
  List<Peer> _peers = <Peer>[];
  Timer? _t;

  @override
  void initState() {
    super.initState();
    _load(true);
    _t = Timer.periodic(const Duration(seconds: 2), (_) => _load(false));
  }

  @override
  void dispose() {
    _t?.cancel();
    unawaited(Native.call('nearby.scan', <String, dynamic>{'on': false}).catchError((Object _) => <String, dynamic>{}));
    super.dispose();
  }

  Future<void> _load(bool start) async {
    try {
      final J r = await Native.call(start ? 'nearby.scan' : 'nearby.list', start ? <String, dynamic>{'on': true} : null);
      if (!mounted) return;
      final String? sid = widget.server;
      final String? url = sid == null ? null : serverUrl(sid);
      setState(() {
        _peers = jl(r, 'peers').map((J m) => Peer(m)).where((Peer p) {
          if (!p.hasMe) return false;
          if (url == null || p.net.isEmpty) return true;
          final Server? a = _s.serverByUrl(p.net);
          return a == null || a.id == sid || AppState.I.serverByUrl(url)?.id == a.id;
        }).toList();
      });
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    final Pal p = Pal.of(context);
    return SizedBox(
      height: MediaQuery.of(context).size.height * 0.55,
      child: Column(children: <Widget>[
        Padding(padding: const EdgeInsets.fromLTRB(20, 0, 20, 8), child: sheetTitle(context, Icons.wifi_tethering_rounded, L.t('Pessoas por perto', 'People nearby'), subtitle: L.t('Wi-Fi, hotspot e Bluetooth', 'Wi-Fi, hotspot and Bluetooth'))),
        Expanded(
          child: _peers.isEmpty
              ? Center(
                  child: Column(mainAxisSize: MainAxisSize.min, children: <Widget>[
                    SizedBox(width: 30, height: 30, child: CircularProgressIndicator(strokeWidth: 2.6, color: p.gold)),
                    const SizedBox(height: 14),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 30),
                      child: Text(L.t('Procurando… A outra pessoa precisa estar com o app aberto e "Ficar visível" ligado.', 'Searching… The other person needs the app open with "Be visible" on.'),
                          textAlign: TextAlign.center, style: TextStyle(color: p.fg2)),
                    ),
                  ]),
                )
              : ListView(padding: const EdgeInsets.symmetric(horizontal: 12), children: <Widget>[
                  for (final Peer pe in _peers)
                    FadeSlide(
                      child: ListTile(
                        leading: Avatar(pe.name.isEmpty ? '#' : pe.name),
                        title: Text(pe.name.isEmpty ? L.t('Conta ${F.short(pe.uid, 4)}', 'Account ${F.short(pe.uid, 4)}') : pe.name, style: const TextStyle(fontWeight: FontWeight.w800)),
                        subtitle: Text('${pe.uid} · ${pe.via.join(', ')}', style: TextStyle(color: p.fg2, fontSize: 12)),
                        trailing: Icon(Icons.chevron_right_rounded, color: p.fg3),
                        onTap: () => Navigator.of(context).pop(pe),
                      ),
                    ),
                ]),
        ),
      ]),
    );
  }
}
