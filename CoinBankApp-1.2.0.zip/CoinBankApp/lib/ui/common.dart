import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../core/fmt.dart';
import '../core/i18n.dart';
import '../core/models.dart';
import '../core/native.dart';
import '../core/state.dart';
import 'theme.dart';

final GlobalKey<NavigatorState> navKey = GlobalKey<NavigatorState>();
final GlobalKey<ScaffoldMessengerState> messengerKey = GlobalKey<ScaffoldMessengerState>();

/// mensagem amigável de qualquer erro
String errText(Object e) => e is ApiException ? e.message : e.toString();

void toast(String msg, {bool error = false, bool ok = false}) {
  final ScaffoldMessengerState? m = messengerKey.currentState;
  if (m == null) return;
  m.hideCurrentSnackBar();
  m.showSnackBar(SnackBar(
    content: Row(children: <Widget>[
      Icon(error ? Icons.error_outline_rounded : (ok ? Icons.check_circle_rounded : Icons.info_outline_rounded), color: Colors.white, size: 20),
      const SizedBox(width: 10),
      Expanded(child: Text(msg, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600))),
    ]),
    backgroundColor: error ? const Color(0xFFC6383E) : (ok ? const Color(0xFF13885A) : const Color(0xFF2A2D33)),
    duration: Duration(milliseconds: error ? 3800 : 2400),
  ));
}

Future<void> copyText(String text, [String? what]) async {
  await Clipboard.setData(ClipboardData(text: text));
  toast(what == null ? L.t('Copiado', 'Copied') : L.t('$what copiado', '$what copied'), ok: true);
}

Future<bool> confirm(BuildContext context, {required String title, required String text, String? ok, bool danger = false, IconData? icon}) async {
  final Pal p = Pal.of(context);
  final bool? r = await showDialog<bool>(
    context: context,
    builder: (BuildContext c) => AlertDialog(
      icon: icon == null ? null : Icon(icon, color: danger ? p.bad : p.gold, size: 34),
      title: Text(title, textAlign: icon == null ? TextAlign.start : TextAlign.center),
      content: Text(text, style: TextStyle(color: p.fg2, height: 1.4)),
      actions: <Widget>[
        TextButton(onPressed: () => Navigator.of(c).pop(false), child: Text(L.t('Cancelar', 'Cancel'), style: TextStyle(color: p.fg2))),
        FilledButton(
          style: FilledButton.styleFrom(backgroundColor: danger ? p.bad : p.gold, foregroundColor: Colors.white),
          onPressed: () => Navigator.of(c).pop(true),
          child: Text(ok ?? L.t('Confirmar', 'Confirm')),
        ),
      ],
    ),
  );
  return r == true;
}

/// folha que sobe de baixo, com rolagem e respeitando teclado/barras
Future<T?> showSheet<T>(BuildContext context, WidgetBuilder builder) {
  return showModalBottomSheet<T>(
    context: context,
    isScrollControlled: true,
    useSafeArea: true,
    showDragHandle: true,
    builder: (BuildContext c) => Padding(
      padding: EdgeInsets.only(bottom: MediaQuery.of(c).viewInsets.bottom),
      child: builder(c),
    ),
  );
}

/// pede um texto (dialog simples)
Future<String?> askText(BuildContext context, {required String title, String? hint, String initial = '', bool obscure = false, TextInputType? keyboard, String? ok}) async {
  final TextEditingController ctl = TextEditingController(text: initial);
  final String? r = await showDialog<String>(
    context: context,
    builder: (BuildContext c) => AlertDialog(
      title: Text(title),
      content: TextField(
        controller: ctl,
        autofocus: true,
        obscureText: obscure,
        keyboardType: keyboard,
        decoration: InputDecoration(hintText: hint),
        onSubmitted: (String v) => Navigator.of(c).pop(v),
      ),
      actions: <Widget>[
        TextButton(onPressed: () => Navigator.of(c).pop(), child: Text(L.t('Cancelar', 'Cancel'))),
        FilledButton(onPressed: () => Navigator.of(c).pop(ctl.text), child: Text(ok ?? 'OK')),
      ],
    ),
  );
  ctl.dispose();
  return r;
}

class AppCard extends StatelessWidget {
  const AppCard({super.key, required this.child, this.padding = const EdgeInsets.all(16), this.onTap, this.color, this.margin = EdgeInsets.zero, this.radius = 20});
  final Widget child;
  final EdgeInsetsGeometry padding;
  final EdgeInsetsGeometry margin;
  final VoidCallback? onTap;
  final Color? color;
  final double radius;

  @override
  Widget build(BuildContext context) {
    final Pal p = Pal.of(context);
    return Padding(
      padding: margin,
      child: Material(
        color: color ?? p.card,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(radius), side: BorderSide(color: p.line)),
        clipBehavior: Clip.antiAlias,
        child: InkWell(onTap: onTap, child: Padding(padding: padding, child: child)),
      ),
    );
  }
}

class SectionTitle extends StatelessWidget {
  const SectionTitle(this.text, {super.key, this.action, this.onAction, this.padding = const EdgeInsets.fromLTRB(4, 18, 4, 8)});
  final String text;
  final String? action;
  final VoidCallback? onAction;
  final EdgeInsetsGeometry padding;

  @override
  Widget build(BuildContext context) {
    final Pal p = Pal.of(context);
    return Padding(
      padding: padding,
      child: Row(children: <Widget>[
        Expanded(child: Text(text.toUpperCase(), style: TextStyle(fontSize: 12, letterSpacing: 0.8, fontWeight: FontWeight.w800, color: p.fg3))),
        if (action != null) GestureDetector(onTap: onAction, child: Text(action!, style: TextStyle(color: p.gold, fontWeight: FontWeight.w800, fontSize: 13))),
      ]),
    );
  }
}

/// aparece deslizando de leve (usado nas listas e cartões)
class FadeSlide extends StatelessWidget {
  const FadeSlide({super.key, required this.child, this.delay = 0, this.dy = 14});
  final Widget child;
  final int delay;
  final double dy;

  @override
  Widget build(BuildContext context) {
    return TweenAnimationBuilder<double>(
      tween: Tween<double>(begin: 0, end: 1),
      duration: Duration(milliseconds: 380 + delay),
      curve: Curves.easeOutCubic,
      builder: (BuildContext c, double v, Widget? ch) => Opacity(opacity: v.clamp(0.0, 1.0), child: Transform.translate(offset: Offset(0, (1 - v) * dy), child: ch)),
      child: child,
    );
  }
}

class InfoRow extends StatelessWidget {
  const InfoRow(this.label, this.value, {super.key, this.mono = false, this.copy = false, this.valueColor});
  final String label;
  final String value;
  final bool mono;
  final bool copy;
  final Color? valueColor;

  @override
  Widget build(BuildContext context) {
    final Pal p = Pal.of(context);
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 7),
      child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: <Widget>[
        SizedBox(width: 118, child: Text(label, style: TextStyle(color: p.fg2, fontSize: 13.5))),
        Expanded(
          child: GestureDetector(
            onTap: copy ? () => copyText(value, label) : null,
            child: Text(value,
                style: TextStyle(fontWeight: FontWeight.w700, fontSize: 14, color: valueColor ?? p.fg, fontFamily: mono ? 'monospace' : null), textAlign: TextAlign.right),
          ),
        ),
        if (copy) Padding(padding: const EdgeInsets.only(left: 6), child: Icon(Icons.copy_rounded, size: 15, color: p.fg3)),
      ]),
    );
  }
}

class EmptyState extends StatelessWidget {
  const EmptyState({super.key, required this.icon, required this.title, this.text, this.action, this.onAction});
  final IconData icon;
  final String title;
  final String? text;
  final String? action;
  final VoidCallback? onAction;

  @override
  Widget build(BuildContext context) {
    final Pal p = Pal.of(context);
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 34, horizontal: 24),
      child: Column(mainAxisSize: MainAxisSize.min, children: <Widget>[
        Container(width: 64, height: 64, decoration: BoxDecoration(color: p.goldSoft, shape: BoxShape.circle), child: Icon(icon, color: p.gold, size: 30)),
        const SizedBox(height: 14),
        Text(title, textAlign: TextAlign.center, style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16, color: p.fg)),
        if (text != null) Padding(padding: const EdgeInsets.only(top: 6), child: Text(text!, textAlign: TextAlign.center, style: TextStyle(color: p.fg2, height: 1.35))),
        if (action != null) Padding(padding: const EdgeInsets.only(top: 14), child: FilledButton.tonal(onPressed: onAction, child: Text(action!))),
      ]),
    );
  }
}

/// botão que mostra "carregando" enquanto a ação assíncrona roda
class BusyButton extends StatefulWidget {
  const BusyButton({super.key, required this.label, required this.onPressed, this.icon, this.tonal = false, this.danger = false, this.expand = true});
  final String label;
  final Future<void> Function()? onPressed;
  final IconData? icon;
  final bool tonal;
  final bool danger;
  final bool expand;

  @override
  State<BusyButton> createState() => _BusyButtonState();
}

class _BusyButtonState extends State<BusyButton> {
  bool _busy = false;

  Future<void> _run() async {
    final Future<void> Function()? f = widget.onPressed;
    if (f == null || _busy) return;
    setState(() => _busy = true);
    try {
      await f();
    } catch (e) {
      toast(errText(e), error: true);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final Pal p = Pal.of(context);
    final Widget label = AnimatedSwitcher(
      duration: const Duration(milliseconds: 200),
      child: _busy
          ? const SizedBox(key: ValueKey<String>('busy'), width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2.4, color: Colors.white))
          : Row(key: const ValueKey<String>('idle'), mainAxisSize: MainAxisSize.min, children: <Widget>[
              if (widget.icon != null) Padding(padding: const EdgeInsets.only(right: 8), child: Icon(widget.icon, size: 20)),
              Flexible(child: Text(widget.label, overflow: TextOverflow.ellipsis)),
            ]),
    );
    final VoidCallback? cb = widget.onPressed == null ? null : _run;
    final Widget b = widget.tonal
        ? FilledButton.tonal(onPressed: cb, child: label)
        : FilledButton(
            style: FilledButton.styleFrom(backgroundColor: widget.danger ? p.bad : p.pri, foregroundColor: widget.danger ? Colors.white : p.prifg),
            onPressed: cb,
            child: label,
          );
    return widget.expand ? SizedBox(width: double.infinity, child: b) : b;
  }
}

/// valor em coins (respeita as casas decimais escolhidas)
class CoinText extends StatelessWidget {
  const CoinText(this.sats, {super.key, this.size = 16, this.color, this.sign = false, this.weight = FontWeight.w800, this.suffix = true});
  final int sats;
  final double size;
  final Color? color;
  final bool sign;
  final FontWeight weight;
  final bool suffix;

  @override
  Widget build(BuildContext context) {
    final Pal p = Pal.of(context);
    return Text.rich(
      TextSpan(children: <InlineSpan>[
        TextSpan(text: F.coins(sats, sign: sign), style: TextStyle(fontSize: size, fontWeight: weight, color: color ?? p.fg, fontFeatures: const <FontFeature>[FontFeature.tabularFigures()])),
        if (suffix) TextSpan(text: ' ${F.unit()}', style: TextStyle(fontSize: size * 0.62, fontWeight: FontWeight.w600, color: p.fg2)),
      ]),
      maxLines: 1,
      overflow: TextOverflow.ellipsis,
    );
  }
}

/// círculo com a inicial
class Avatar extends StatelessWidget {
  const Avatar(this.name, {super.key, this.size = 42, this.icon});
  final String name;
  final double size;
  final IconData? icon;

  @override
  Widget build(BuildContext context) {
    final Pal p = Pal.of(context);
    final String n = name.trim();
    return Container(
      width: size,
      height: size,
      alignment: Alignment.center,
      decoration: BoxDecoration(shape: BoxShape.circle, gradient: LinearGradient(colors: <Color>[p.gold, p.gold.withValues(alpha: 0.65)], begin: Alignment.topLeft, end: Alignment.bottomRight)),
      child: icon != null
          ? Icon(icon, color: Colors.white, size: size * 0.5)
          : Text(n.isEmpty ? '?' : n.substring(0, 1).toUpperCase(), style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: size * 0.42)),
    );
  }
}

/// QR Code gerado no aparelho (sem internet)
class QrView extends StatefulWidget {
  const QrView(this.text, {super.key, this.size = 220});
  final String text;
  final double size;

  @override
  State<QrView> createState() => _QrViewState();
}

class _QrViewState extends State<QrView> {
  List<String> _rows = <String>[];
  String _for = '';

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void didUpdateWidget(covariant QrView old) {
    super.didUpdateWidget(old);
    if (old.text != widget.text) _load();
  }

  Future<void> _load() async {
    final String t = widget.text;
    if (t.isEmpty || t == _for) return;
    try {
      final J r = await Native.call('qr', <String, dynamic>{'text': t});
      if (!mounted) return;
      setState(() {
        _rows = jsl(r, 'rows');
        _for = t;
      });
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: widget.size,
      height: widget.size,
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18)),
      child: AnimatedSwitcher(
        duration: const Duration(milliseconds: 300),
        child: _rows.isEmpty
            ? const Center(key: ValueKey<String>('l'), child: SizedBox(width: 26, height: 26, child: CircularProgressIndicator(strokeWidth: 2.6)))
            : CustomPaint(key: ValueKey<String>(_for), painter: _QrPainter(_rows), size: Size.infinite),
      ),
    );
  }
}

class _QrPainter extends CustomPainter {
  _QrPainter(this.rows);
  final List<String> rows;

  @override
  void paint(Canvas canvas, Size size) {
    final int n = rows.length;
    if (n == 0) return;
    final double cell = size.shortestSide / n;
    final Paint paint = Paint()..color = Colors.black;
    for (int y = 0; y < n; y++) {
      final String r = rows[y];
      for (int x = 0; x < r.length; x++) {
        if (r.codeUnitAt(x) == 49) canvas.drawRect(Rect.fromLTWH(x * cell, y * cell, cell + 0.4, cell + 0.4), paint);
      }
    }
  }

  @override
  bool shouldRepaint(covariant _QrPainter old) => old.rows != rows;
}

/// linha do extrato
class TxTile extends StatelessWidget {
  const TxTile({super.key, required this.tx, required this.me, this.onTap});
  final Tx tx;
  final String me;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final Pal p = Pal.of(context);
    final bool inc = tx.incoming(me);
    final Color c = tx.isClaim ? p.gold : (inc ? p.ok : p.fg);
    final IconData ic = tx.isClaim ? Icons.redeem_rounded : (inc ? Icons.south_west_rounded : Icons.north_east_rounded);
    final String title = tx.isClaim ? L.t('Resgate', 'Claim') : (inc ? L.t('Recebido', 'Received') : L.t('Enviado', 'Sent'));
    final String who = tx.isClaim ? L.t('Recompensa da rede', 'Network reward') : (inc ? L.t('de ', 'from ') : L.t('para ', 'to ')) + F.short(tx.other(me), 5);
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(14),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
        child: Row(children: <Widget>[
          Container(
            width: 42,
            height: 42,
            decoration: BoxDecoration(color: tx.isClaim ? p.goldSoft : (inc ? p.okSoft : p.card2), borderRadius: BorderRadius.circular(13)),
            child: Icon(ic, color: c, size: 21),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: <Widget>[
              Text(title, style: TextStyle(fontWeight: FontWeight.w800, color: p.fg, fontSize: 14.5)),
              const SizedBox(height: 2),
              Text('$who · ${F.time(tx.date)}', maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: p.fg2, fontSize: 12.5)),
            ]),
          ),
          const SizedBox(width: 8),
          Text(inc || tx.isClaim ? F.coins(tx.sats, sign: true) : '−${F.coins(tx.sats)}',
              style: TextStyle(fontWeight: FontWeight.w800, color: c, fontSize: 14.5, fontFeatures: const <FontFeature>[FontFeature.tabularFigures()])),
        ]),
      ),
    );
  }
}

/// selo pequeno (status)
class Pill extends StatelessWidget {
  const Pill(this.text, {super.key, this.color, this.icon});
  final String text;
  final Color? color;
  final IconData? icon;

  @override
  Widget build(BuildContext context) {
    final Pal p = Pal.of(context);
    final Color c = color ?? p.gold;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4),
      decoration: BoxDecoration(color: c.withValues(alpha: 0.14), borderRadius: BorderRadius.circular(99)),
      child: Row(mainAxisSize: MainAxisSize.min, children: <Widget>[
        if (icon != null) Padding(padding: const EdgeInsets.only(right: 4), child: Icon(icon, size: 13, color: c)),
        Text(text, style: TextStyle(color: c, fontWeight: FontWeight.w800, fontSize: 11.5)),
      ]),
    );
  }
}

/// ouve o relógio de 2 s do app (contagens, "há x min")
class TickBuilder extends StatelessWidget {
  const TickBuilder({super.key, required this.builder});
  final WidgetBuilder builder;

  @override
  Widget build(BuildContext context) => ValueListenableBuilder<int>(valueListenable: AppState.I.tick, builder: (BuildContext c, int _, Widget? __) => builder(c));
}

/// relógio de 1 s para contagens regressivas dentro de modais
class SecondTicker extends StatefulWidget {
  const SecondTicker({super.key, required this.builder});
  final WidgetBuilder builder;

  @override
  State<SecondTicker> createState() => _SecondTickerState();
}

class _SecondTickerState extends State<SecondTicker> {
  Timer? _t;

  @override
  void initState() {
    super.initState();
    _t = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted) setState(() {});
    });
  }

  @override
  void dispose() {
    _t?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => widget.builder(context);
}

/// campo de valor em coins
class AmountField extends StatelessWidget {
  const AmountField({super.key, required this.controller, this.label, this.hint, this.autofocus = false, this.onChanged});
  final TextEditingController controller;
  final String? label;
  final String? hint;
  final bool autofocus;
  final ValueChanged<String>? onChanged;

  @override
  Widget build(BuildContext context) {
    final Pal p = Pal.of(context);
    return TextField(
      controller: controller,
      autofocus: autofocus,
      keyboardType: const TextInputType.numberWithOptions(decimal: true),
      inputFormatters: <TextInputFormatter>[FilteringTextInputFormatter.allow(RegExp(r'[0-9.,]'))],
      style: TextStyle(fontSize: 26, fontWeight: FontWeight.w800, color: p.fg),
      onChanged: onChanged,
      decoration: InputDecoration(
        labelText: label ?? L.t('Valor', 'Amount'),
        hintText: hint ?? F.coins(0),
        suffixText: F.unit(),
        prefixIcon: Icon(Icons.toll_rounded, color: p.gold),
      ),
    );
  }
}

/// campo de ID de conta (só números)
class IdField extends StatelessWidget {
  const IdField({super.key, required this.controller, this.label, this.trailing});
  final TextEditingController controller;
  final String? label;
  final Widget? trailing;

  @override
  Widget build(BuildContext context) {
    return TextField(
      controller: controller,
      keyboardType: TextInputType.number,
      inputFormatters: <TextInputFormatter>[FilteringTextInputFormatter.digitsOnly],
      style: const TextStyle(fontWeight: FontWeight.w700, fontFamily: 'monospace'),
      decoration: InputDecoration(labelText: label ?? L.t('ID da conta', 'Account ID'), prefixIcon: const Icon(Icons.person_outline_rounded), suffixIcon: trailing),
    );
  }
}

/// reconstrói quando o estado global muda (saldo, extrato, configurações…)
class Watch extends StatelessWidget {
  const Watch({super.key, required this.builder});
  final WidgetBuilder builder;

  @override
  Widget build(BuildContext context) => ListenableBuilder(listenable: AppState.I, builder: (BuildContext c, Widget? _) => builder(c));
}
