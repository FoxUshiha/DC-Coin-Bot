import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

/// Cores iguais às do site do Coin Bank (claro/escuro), com o dourado como destaque.
class Pal {
  Pal(this.dark);
  final bool dark;

  static Pal of(BuildContext c) => Pal(Theme.of(c).brightness == Brightness.dark);

  Color get bg => dark ? const Color(0xFF101113) : const Color(0xFFECEEF1);
  Color get card => dark ? const Color(0xFF191B1E) : Colors.white;
  Color get card2 => dark ? const Color(0xFF212328) : const Color(0xFFF4F5F7);
  Color get fg => dark ? const Color(0xFFE8EAED) : const Color(0xFF14161A);
  Color get fg2 => dark ? const Color(0xFFA1A7B0) : const Color(0xFF5B616B);
  Color get fg3 => dark ? const Color(0xFF717883) : const Color(0xFF8B919B);
  Color get line => dark ? const Color(0xFF2A2D33) : const Color(0xFFDFE2E7);
  Color get gold => dark ? const Color(0xFFD6A94B) : const Color(0xFFA9802A);
  Color get goldSoft => dark ? const Color(0xFF2E2717) : const Color(0xFFF6EDD9);
  Color get ok => dark ? const Color(0xFF2FBF80) : const Color(0xFF0F8A5B);
  Color get okSoft => dark ? const Color(0xFF12301F) : const Color(0xFFDDF3E8);
  Color get bad => dark ? const Color(0xFFF05A60) : const Color(0xFFD0353B);
  Color get badSoft => dark ? const Color(0xFF3A1A1C) : const Color(0xFFFBE1E2);
  /// botão principal igual ao site (grafite no claro, quase branco no escuro)
  Color get pri => dark ? const Color(0xFFE4E6E9) : const Color(0xFF23272D);
  Color get prifg => dark ? const Color(0xFF111214) : Colors.white;
  Color get blue => dark ? const Color(0xFF6AA5FF) : const Color(0xFF2F6FE4);
}

const Color kGold = Color(0xFFD6A94B);

ThemeData buildTheme(Brightness b) {
  final bool dark = b == Brightness.dark;
  final Pal p = Pal(dark);
  final ColorScheme cs = ColorScheme.fromSeed(
    seedColor: kGold,
    brightness: b,
    primary: p.gold,
    onPrimary: dark ? const Color(0xFF1B1405) : Colors.white,
    surface: p.card,
    onSurface: p.fg,
    error: p.bad,
  );
  return ThemeData(
    useMaterial3: true,
    colorScheme: cs,
    brightness: b,
    scaffoldBackgroundColor: p.bg,
    canvasColor: p.bg,
    dividerColor: p.line,
    appBarTheme: AppBarTheme(
      centerTitle: false,
      elevation: 0,
      scrolledUnderElevation: 0,
      backgroundColor: p.bg,
      surfaceTintColor: Colors.transparent,
      foregroundColor: p.fg,
      titleTextStyle: TextStyle(fontSize: 20, fontWeight: FontWeight.w800, color: p.fg, letterSpacing: -0.2),
      systemOverlayStyle: dark ? SystemUiOverlayStyle.light : SystemUiOverlayStyle.dark,
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: p.card2,
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide(color: p.line)),
      enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide(color: p.line)),
      focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide(color: p.gold, width: 1.6)),
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
    ),
    filledButtonTheme: FilledButtonThemeData(
      style: FilledButton.styleFrom(
        backgroundColor: p.pri,
        foregroundColor: p.prifg,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 14),
        textStyle: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15),
      ),
    ),
    outlinedButtonTheme: OutlinedButtonThemeData(
      style: OutlinedButton.styleFrom(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 14),
        side: BorderSide(color: p.line),
        foregroundColor: p.fg,
        textStyle: const TextStyle(fontWeight: FontWeight.w700, fontSize: 15),
      ),
    ),
    textButtonTheme: TextButtonThemeData(style: TextButton.styleFrom(foregroundColor: p.gold, textStyle: const TextStyle(fontWeight: FontWeight.w700))),
    navigationBarTheme: NavigationBarThemeData(
      height: 68,
      backgroundColor: p.card,
      surfaceTintColor: Colors.transparent,
      indicatorColor: p.goldSoft,
      labelTextStyle: WidgetStateProperty.resolveWith((Set<WidgetState> s) =>
          TextStyle(fontSize: 12, fontWeight: s.contains(WidgetState.selected) ? FontWeight.w800 : FontWeight.w600, color: s.contains(WidgetState.selected) ? p.gold : p.fg2)),
      iconTheme: WidgetStateProperty.resolveWith((Set<WidgetState> s) => IconThemeData(color: s.contains(WidgetState.selected) ? p.gold : p.fg2)),
    ),
    drawerTheme: DrawerThemeData(backgroundColor: p.bg, surfaceTintColor: Colors.transparent),
    bottomSheetTheme: BottomSheetThemeData(
      backgroundColor: p.card,
      surfaceTintColor: Colors.transparent,
      showDragHandle: true,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(26))),
    ),
    dialogTheme: DialogThemeData(backgroundColor: p.card, surfaceTintColor: Colors.transparent, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24))),
    listTileTheme: ListTileThemeData(contentPadding: const EdgeInsets.symmetric(horizontal: 16), iconColor: p.fg2),
    snackBarTheme: SnackBarThemeData(behavior: SnackBarBehavior.floating, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))),
    chipTheme: ChipThemeData(shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)), side: BorderSide(color: p.line)),
    switchTheme: SwitchThemeData(
      thumbColor: WidgetStateProperty.resolveWith((Set<WidgetState> s) => s.contains(WidgetState.selected) ? Colors.white : null),
      trackColor: WidgetStateProperty.resolveWith((Set<WidgetState> s) => s.contains(WidgetState.selected) ? p.gold : null),
    ),
    progressIndicatorTheme: ProgressIndicatorThemeData(color: p.gold),
  );
}
