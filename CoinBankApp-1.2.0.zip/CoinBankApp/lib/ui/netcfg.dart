import 'dart:convert';
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../core/fmt.dart';
import '../core/i18n.dart';
import '../core/native.dart';
import '../core/state.dart';
import 'common.dart';
import 'theme.dart';

final Map<String, Uint8List> _iconCache = <String, Uint8List>{};

Uint8List? _iconBytes(String b64) {
  if (b64.isEmpty) return null;
  final Uint8List? c = _iconCache[b64];
  if (c != null) return c;
  try {
    final Uint8List b = base64Decode(b64);
    if (_iconCache.length > 32) _iconCache.clear();
    _iconCache[b64] = b;
    return b;
  } catch (_) {
    return null;
  }
}

/// Ícone da moeda de uma rede: o escolhido pelo usuário; senão a carteira (principal) ou a moedinha (outras).
class NetIcon extends StatelessWidget {
  const NetIcon(this.server, {super.key, this.size = 32});
  final String server;
  final double size;

  @override
  Widget build(BuildContext context) {
    final Uint8List? b = _iconBytes(F.cfg(server).icon);
    final Widget img = b != null
        ? Image.memory(b, width: size, height: size, fit: BoxFit.cover, gaplessPlayback: true)
        : Image.asset(server == 'main' ? 'assets/icon_small.png' : 'assets/coin.png', width: size, height: size, fit: BoxFit.contain, filterQuality: FilterQuality.none);
    return ClipRRect(borderRadius: BorderRadius.circular(size * 0.28), child: SizedBox(width: size, height: size, child: img));
  }
}

/// Configuração da moeda de uma rede: casas exibidas (8 · 2 · inteiro · personalizado), casas da API, nome e ícone.
/// A rede principal só permite trocar as casas exibidas (a API dela é sempre de 8 casas).
class CoinConfigCard extends StatefulWidget {
  const CoinConfigCard({super.key, required this.server});
  final String server;

  @override
  State<CoinConfigCard> createState() => _CoinConfigCardState();
}

class _CoinConfigCardState extends State<CoinConfigCard> {
  late final TextEditingController _name = TextEditingController(text: F.cfg(widget.server).coin);
  late final TextEditingController _custom = TextEditingController(text: '${F.cfg(widget.server).disp}');
  late final TextEditingController _api = TextEditingController(text: '${F.cfg(widget.server).api}');
  late bool _isCustom = !<int>[0, 2, 8].contains(F.cfg(widget.server).disp);

  bool get _main => widget.server == 'main';

  @override
  void dispose() {
    _name.dispose();
    _custom.dispose();
    _api.dispose();
    super.dispose();
  }

  Future<void> _set(J patch) => AppState.I.setNetCfg(widget.server, patch);

  Future<void> _pickIcon() async {
    try {
      final J r = await Native.call('pickIcon');
      final String icon = js(r, 'icon');
      if (icon.isNotEmpty) await _set(<String, dynamic>{'icon': icon});
    } catch (e) {
      toast(errText(e), error: true);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Watch(builder: (BuildContext context) {
      final Pal p = Pal.of(context);
      final NetCfg c = F.cfg(widget.server);
      final String netName = AppState.I.serverById(widget.server)?.name ?? 'Coin';
      Widget chip(String label, bool on, VoidCallback tap) => ChoiceChip(label: Text(label), selected: on, onSelected: (bool _) => tap());
      return AppCard(
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: <Widget>[
          Row(children: <Widget>[
            NetIcon(widget.server, size: 46),
            const SizedBox(width: 12),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: <Widget>[
                Text(netName, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16)),
                Text(L.t('Moeda: ${F.unit(widget.server)} · API com ${c.api} casas', 'Coin: ${F.unit(widget.server)} · API with ${c.api} decimals'), style: TextStyle(color: p.fg2, fontSize: 12)),
              ]),
            ),
            if (!_main)
              PopupMenuButton<String>(
                icon: Icon(Icons.image_outlined, color: p.gold),
                tooltip: L.t('Ícone da moeda', 'Coin icon'),
                onSelected: (String v) {
                  if (v == 'pick') _pickIcon();
                  if (v == 'reset') _set(<String, dynamic>{'icon': ''});
                },
                itemBuilder: (BuildContext x) => <PopupMenuEntry<String>>[
                  PopupMenuItem<String>(value: 'pick', child: Text(L.t('Escolher imagem', 'Choose image'))),
                  PopupMenuItem<String>(value: 'reset', child: Text(L.t('Usar ícone padrão', 'Use default icon'))),
                ],
              ),
          ]),
          const SizedBox(height: 14),
          Text(L.t('Casas decimais exibidas', 'Displayed decimal places'), style: const TextStyle(fontWeight: FontWeight.w800)),
          const SizedBox(height: 8),
          Wrap(spacing: 8, runSpacing: 8, children: <Widget>[
            chip(L.t('8 casas', '8 decimals'), !_isCustom && c.disp == 8, () => setState(() { _isCustom = false; _set(<String, dynamic>{'disp': 8}); })),
            chip(L.t('2 casas', '2 decimals'), !_isCustom && c.disp == 2, () => setState(() { _isCustom = false; _set(<String, dynamic>{'disp': 2}); })),
            chip(L.t('Inteiro', 'Integer'), !_isCustom && c.disp == 0, () => setState(() { _isCustom = false; _set(<String, dynamic>{'disp': 0}); })),
            chip(L.t('Personalizado', 'Custom'), _isCustom, () => setState(() => _isCustom = true)),
          ]),
          if (_isCustom) ...<Widget>[
            const SizedBox(height: 10),
            TextField(
              controller: _custom,
              keyboardType: TextInputType.number,
              inputFormatters: <TextInputFormatter>[FilteringTextInputFormatter.digitsOnly, LengthLimitingTextInputFormatter(2)],
              decoration: InputDecoration(labelText: L.t('Casas (0 a 18)', 'Places (0 to 18)'), prefixIcon: const Icon(Icons.pin_outlined)),
              onSubmitted: (String v) => _set(<String, dynamic>{'disp': (int.tryParse(v) ?? c.disp).clamp(0, 18)}),
              onChanged: (String v) {
                final int? n = int.tryParse(v);
                if (n != null && n >= 0 && n <= 18) _set(<String, dynamic>{'disp': n});
              },
            ),
          ],
          if (!_main) ...<Widget>[
            const SizedBox(height: 14),
            TextField(
              controller: _api,
              keyboardType: TextInputType.number,
              inputFormatters: <TextInputFormatter>[FilteringTextInputFormatter.digitsOnly, LengthLimitingTextInputFormatter(2)],
              decoration: InputDecoration(
                labelText: L.t('Casas que a API usa (onde começa o corte)', 'Decimals the API uses (where truncation starts)'),
                helperText: L.t('Ex.: 8 → "0.00000012" vira 12 unidades', 'E.g. 8 → "0.00000012" becomes 12 units'),
                prefixIcon: const Icon(Icons.api_rounded),
              ),
              onChanged: (String v) {
                final int? n = int.tryParse(v);
                if (n != null && n >= 0 && n <= 18) _set(<String, dynamic>{'api': n});
              },
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _name,
              maxLength: 24,
              decoration: InputDecoration(labelText: L.t('Nome da moeda', 'Coin name'), prefixIcon: const Icon(Icons.badge_outlined)),
              onSubmitted: (String v) => _set(<String, dynamic>{'coin': v.trim()}),
              onEditingComplete: () => _set(<String, dynamic>{'coin': _name.text.trim()}),
            ),
          ],
          const SizedBox(height: 8),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(color: p.card2, borderRadius: BorderRadius.circular(12)),
            child: Text(
              L.t('Exemplo: 12 unidades → ${F.coins(12, net: widget.server)} · 500.000 → ${F.coins(500000, net: widget.server)} ${F.unit(widget.server)}',
                  'Example: 12 units → ${F.coins(12, net: widget.server)} · 500,000 → ${F.coins(500000, net: widget.server)} ${F.unit(widget.server)}'),
              style: TextStyle(color: p.fg2, fontSize: 12.5, fontWeight: FontWeight.w600),
            ),
          ),
        ]),
      );
    });
  }
}

/// ícone do app na tela inicial (Android troca o atalho; alguns launchers demoram alguns segundos)
class AppIconPicker extends StatefulWidget {
  const AppIconPicker({super.key});

  @override
  State<AppIconPicker> createState() => _AppIconPickerState();
}

class _AppIconPickerState extends State<AppIconPicker> {
  String _cur = 'default';

  @override
  void initState() {
    super.initState();
    Native.call('appIcon.get').then((J r) {
      if (mounted) setState(() => _cur = js(r, 'icon', 'default'));
    }).catchError((Object _) => null);
  }

  Future<void> _set(String v) async {
    try {
      await Native.call('appIcon.set', <String, dynamic>{'icon': v});
      setState(() => _cur = v);
      toast(L.t('Ícone alterado. O Android pode levar alguns segundos para atualizar.', 'Icon changed. Android may take a few seconds to update.'), ok: true);
    } catch (e) {
      toast(errText(e), error: true);
    }
  }

  @override
  Widget build(BuildContext context) {
    final Pal p = Pal.of(context);
    Widget opt(String v, String asset, String label) => Expanded(
          child: GestureDetector(
            onTap: () => _set(v),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              padding: const EdgeInsets.all(10),
              margin: const EdgeInsets.symmetric(horizontal: 4),
              decoration: BoxDecoration(color: _cur == v ? p.goldSoft : p.card2, borderRadius: BorderRadius.circular(16), border: Border.all(color: _cur == v ? p.gold : p.line, width: _cur == v ? 1.6 : 1)),
              child: Column(children: <Widget>[
                Container(
                  width: 56,
                  height: 56,
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(borderRadius: BorderRadius.circular(14), gradient: const LinearGradient(colors: <Color>[Color(0xFF2A303C), Color(0xFF0C0F14)], begin: Alignment.topCenter, end: Alignment.bottomCenter)),
                  child: Image.asset(asset, filterQuality: FilterQuality.none),
                ),
                const SizedBox(height: 6),
                Text(label, style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: _cur == v ? p.gold : p.fg2)),
              ]),
            ),
          ),
        );
    return AppCard(
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: <Widget>[
        Text(L.t('Ícone do app', 'App icon'), style: const TextStyle(fontWeight: FontWeight.w800)),
        const SizedBox(height: 10),
        Row(children: <Widget>[
          opt('default', 'assets/wallet.png', L.t('Padrão', 'Default')),
          opt('coin', 'assets/coin.png', L.t('Moeda', 'Coin')),
          opt('wallet', 'assets/wallet_front.png', L.t('Carteira', 'Wallet')),
        ]),
      ]),
    );
  }
}
