import 'package:flutter/material.dart';

import '../core/docs.dart';
import '../core/i18n.dart';
import '../core/models.dart';
import '../core/native.dart';
import '../core/state.dart';
import '../ui/common.dart';
import '../ui/theme.dart';
import 'about_screen.dart';
import 'host_screen.dart';

/// Tela antes de entrar: logo, rede, contas salvas (digital), entrar / criar conta, termos e "como funciona".
class LoginScreen extends StatelessWidget {
  const LoginScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final Pal p = Pal.of(context);
    final AppState s = AppState.I;
    final Server sv = s.active;
    final List<J> saved = s.accounts;
    return Scaffold(
      body: SafeArea(
        child: Stack(children: <Widget>[
          Positioned.fill(
            child: DecoratedBox(
              decoration: BoxDecoration(
                gradient: RadialGradient(center: const Alignment(0, -0.75), radius: 1.0, colors: <Color>[p.gold.withValues(alpha: p.dark ? 0.16 : 0.18), p.bg]),
              ),
            ),
          ),
          ListView(padding: const EdgeInsets.fromLTRB(22, 56, 22, 24), children: <Widget>[
            FadeSlide(
              child: Center(
                child: Container(
                  decoration: BoxDecoration(borderRadius: BorderRadius.circular(30), boxShadow: <BoxShadow>[BoxShadow(color: p.gold.withValues(alpha: 0.35), blurRadius: 40, spreadRadius: 2)]),
                  child: ClipRRect(borderRadius: BorderRadius.circular(30), child: Image.asset('assets/icon.png', width: 112, height: 112)),
                ),
              ),
            ),
            const SizedBox(height: 22),
            FadeSlide(delay: 80, child: Text('Coin Bank', textAlign: TextAlign.center, style: TextStyle(fontSize: 34, fontWeight: FontWeight.w900, color: p.fg, letterSpacing: -0.8))),
            const SizedBox(height: 6),
            FadeSlide(
                delay: 120,
                child: Text(L.t('Sua carteira de moeda virtual.\nEnvie, cobre e pague em segundos.', 'Your virtual coin wallet.\nSend, charge and pay in seconds.'),
                    textAlign: TextAlign.center, style: TextStyle(color: p.fg2, fontSize: 15.5, height: 1.4))),
            const SizedBox(height: 22),
            FadeSlide(
              delay: 160,
              child: Center(
                child: ActionChip(
                  avatar: Icon(sv.isMain ? Icons.public_rounded : (sv.isHost ? Icons.dns_rounded : Icons.hub_rounded), size: 18, color: p.gold),
                  label: Text('${sv.name} · ${sv.host}', style: const TextStyle(fontWeight: FontWeight.w700)),
                  onPressed: () => pickNetwork(context),
                ),
              ),
            ),
            if (!s.online)
              Padding(
                padding: const EdgeInsets.only(top: 14),
                child: AppCard(
                  color: p.badSoft,
                  padding: const EdgeInsets.all(12),
                  child: Row(children: <Widget>[
                    Icon(Icons.wifi_off_rounded, color: p.bad),
                    const SizedBox(width: 10),
                    Expanded(child: Text(L.t('Sem internet. Você pode entrar quando a conexão voltar.', 'No internet. You can sign in when the connection is back.'), style: TextStyle(color: p.bad, fontWeight: FontWeight.w700))),
                  ]),
                ),
              ),
            if (saved.isNotEmpty) ...<Widget>[
              SectionTitle(L.t('Contas salvas', 'Saved accounts')),
              for (int i = 0; i < saved.length; i++)
                FadeSlide(
                  delay: 40 * i,
                  child: AppCard(
                    margin: const EdgeInsets.only(bottom: 8),
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                    onTap: () => _savedLogin(context, js(saved[i], 'id')),
                    child: Row(children: <Widget>[
                      Avatar(js(saved[i], 'username')),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: <Widget>[
                          Text(js(saved[i], 'username'), style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15.5)),
                          Text(Uri.tryParse(js(saved[i], 'server'))?.host ?? js(saved[i], 'server'), style: TextStyle(color: p.fg2, fontSize: 12.5)),
                        ]),
                      ),
                      Icon(Icons.fingerprint_rounded, color: p.gold, size: 30),
                      PopupMenuButton<String>(
                        icon: Icon(Icons.more_vert_rounded, color: p.fg3),
                        onSelected: (String v) async {
                          if (v == 'rm') {
                            await Native.call('accounts.remove', <String, dynamic>{'id': js(saved[i], 'id')});
                            await s.reloadState();
                          }
                        },
                        itemBuilder: (BuildContext c) => <PopupMenuEntry<String>>[PopupMenuItem<String>(value: 'rm', child: Text(L.t('Remover deste aparelho', 'Remove from this device')))],
                      ),
                    ]),
                  ),
                ),
            ],
            const SizedBox(height: 22),
            FadeSlide(
              delay: 200,
              child: SizedBox(
                height: 54,
                child: FilledButton.icon(
                  style: FilledButton.styleFrom(backgroundColor: p.pri, foregroundColor: p.prifg),
                  onPressed: () => showSheet<void>(context, (BuildContext c) => const AuthSheet(register: false)),
                  icon: const Icon(Icons.login_rounded),
                  label: Text(L.t('Entrar', 'Sign in')),
                ),
              ),
            ),
            const SizedBox(height: 10),
            FadeSlide(
              delay: 240,
              child: SizedBox(
                height: 54,
                child: OutlinedButton.icon(
                  onPressed: () => showSheet<void>(context, (BuildContext c) => const AuthSheet(register: true)),
                  icon: const Icon(Icons.person_add_alt_1_rounded),
                  label: Text(L.t('Criar conta grátis', 'Create a free account')),
                ),
              ),
            ),
            const SizedBox(height: 12),
            Center(
              child: TextButton.icon(
                onPressed: () => Navigator.of(context).push(MaterialPageRoute<void>(builder: (BuildContext c) => DocScreen(doc: Docs.howItWorks()))),
                icon: const Icon(Icons.lightbulb_outline_rounded),
                label: Text(L.t('Como funciona o app?', 'How does the app work?')),
              ),
            ),
            const SizedBox(height: 20),
            GestureDetector(
              onTap: () => openLocalDoc('/terms/', L.t('Termos de Uso', 'Terms of Use')),
              child: Text.rich(
                TextSpan(style: TextStyle(color: p.fg3, fontSize: 12.5, height: 1.4), children: <InlineSpan>[
                  TextSpan(text: L.t('Ao continuar você concorda com os ', 'By continuing you agree to the ')),
                  TextSpan(text: L.t('Termos de Uso', 'Terms of Use'), style: TextStyle(color: p.gold, fontWeight: FontWeight.w700, decoration: TextDecoration.underline)),
                  TextSpan(text: L.t(' de ${sv.host}. Coins não têm valor real.', ' of ${sv.host}. Coins have no real value.')),
                ]),
                textAlign: TextAlign.center,
              ),
            ),
          ]),
          Positioned(
            top: 4,
            right: 6,
            child: IconButton(
              tooltip: L.t('Sobre e termos', 'About and terms'),
              icon: Icon(Icons.info_outline_rounded, color: p.fg2),
              onPressed: () => Navigator.of(context).push(MaterialPageRoute<void>(builder: (BuildContext c) => const AboutScreen())),
            ),
          ),
          Positioned(
            top: 4,
            left: 6,
            child: IconButton(
              tooltip: L.t('Redes', 'Networks'),
              icon: Icon(Icons.dns_outlined, color: p.fg2),
              onPressed: () => Navigator.of(context).push(MaterialPageRoute<void>(builder: (BuildContext c) => const HostScreen())),
            ),
          ),
        ]),
      ),
    );
  }

  Future<void> _savedLogin(BuildContext context, String id) async {
    try {
      await AppState.I.loginSaved(id);
    } catch (e) {
      if (e is ApiException && e.code == 'cancelled') return;
      toast(errText(e), error: true);
    }
  }
}

/// escolher a rede (principal, adicionadas, a hospedada aqui) ou adicionar uma
Future<void> pickNetwork(BuildContext context) {
  return showSheet<void>(context, (BuildContext c) {
    final Pal p = Pal.of(c);
    final AppState s = AppState.I;
    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 20),
      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: <Widget>[
        Padding(padding: const EdgeInsets.fromLTRB(6, 0, 6, 10), child: Text(L.t('Escolha a rede', 'Choose the network'), style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w900))),
        for (final Server sv in s.servers)
          ListTile(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
            leading: Icon(sv.isMain ? Icons.public_rounded : (sv.isHost ? Icons.dns_rounded : Icons.hub_rounded), color: p.gold),
            title: Text(sv.name, style: const TextStyle(fontWeight: FontWeight.w800)),
            subtitle: Text(sv.host + (s.sessionOf(sv.id) != null ? L.t(' · conectado', ' · signed in') : ''), style: TextStyle(color: p.fg2)),
            trailing: sv.id == s.activeId ? Icon(Icons.check_circle_rounded, color: p.ok) : null,
            onTap: () async {
              Navigator.of(c).pop();
              try {
                await s.setActive(sv.id);
              } catch (e) {
                toast(errText(e), error: true);
              }
            },
          ),
        const SizedBox(height: 8),
        OutlinedButton.icon(
          onPressed: () {
            Navigator.of(c).pop();
            addNetworkDialog(context);
          },
          icon: const Icon(Icons.add_link_rounded),
          label: Text(L.t('Adicionar rede pelo endereço', 'Add network by address')),
        ),
      ]),
    );
  });
}

/// entrar / criar conta na rede ativa
class AuthSheet extends StatefulWidget {
  const AuthSheet({super.key, required this.register});
  final bool register;

  @override
  State<AuthSheet> createState() => _AuthSheetState();
}

class _AuthSheetState extends State<AuthSheet> {
  final TextEditingController _user = TextEditingController();
  final TextEditingController _pass = TextEditingController();
  final TextEditingController _pass2 = TextEditingController();
  bool _show = false;
  late bool _remember = jb(AppState.I.bio, 'available');

  @override
  void dispose() {
    _user.dispose();
    _pass.dispose();
    _pass2.dispose();
    super.dispose();
  }

  Future<void> _go() async {
    final AppState s = AppState.I;
    final String u = _user.text.trim();
    final String pw = _pass.text;
    if (u.isEmpty || pw.isEmpty) throw ApiException('missing', 400, <String, dynamic>{'message': L.t('Preencha usuário e senha.', 'Fill in username and password.')});
    if (widget.register) {
      if (!RegExp(r'^[A-Za-z0-9_.-]{3,24}$').hasMatch(u)) throw ApiException('INVALID_USERNAME', 400, <String, dynamic>{});
      if (pw.length < 4) throw ApiException('INVALID_PASSWORD', 400, <String, dynamic>{});
      if (pw != _pass2.text) throw ApiException('mismatch', 400, <String, dynamic>{'message': L.t('As senhas não conferem.', 'Passwords do not match.')});
    }
    final NavigatorState nav = Navigator.of(context);
    if (widget.register) {
      await s.register(s.activeId, u, pw, remember: _remember, useBio: _remember);
    } else {
      await s.login(s.activeId, u, pw, remember: _remember, useBio: _remember);
    }
    if (nav.mounted) await nav.maybePop();
    toast(widget.register ? L.t('Conta criada! Bem-vindo(a).', 'Account created! Welcome.') : L.t('Bem-vindo(a) de volta!', 'Welcome back!'), ok: true);
  }

  @override
  Widget build(BuildContext context) {
    final Pal p = Pal.of(context);
    final AppState s = AppState.I;
    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(22, 0, 22, 24),
      child: AutofillGroup(
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: <Widget>[
          Text(widget.register ? L.t('Criar conta', 'Create account') : L.t('Entrar', 'Sign in'), style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w900)),
          const SizedBox(height: 4),
          Text(L.t('Rede: ${s.active.name} (${s.active.host})', 'Network: ${s.active.name} (${s.active.host})'), style: TextStyle(color: p.fg2)),
          const SizedBox(height: 18),
          TextField(
            controller: _user,
            autofocus: true,
            autofillHints: const <String>[AutofillHints.username],
            textInputAction: TextInputAction.next,
            decoration: InputDecoration(labelText: L.t('Usuário', 'Username'), prefixIcon: const Icon(Icons.person_outline_rounded)),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _pass,
            obscureText: !_show,
            autofillHints: <String>[widget.register ? AutofillHints.newPassword : AutofillHints.password],
            textInputAction: widget.register ? TextInputAction.next : TextInputAction.done,
            decoration: InputDecoration(
              labelText: L.t('Senha', 'Password'),
              prefixIcon: const Icon(Icons.lock_outline_rounded),
              suffixIcon: IconButton(icon: Icon(_show ? Icons.visibility_off_rounded : Icons.visibility_rounded), onPressed: () => setState(() => _show = !_show)),
            ),
          ),
          if (widget.register) ...<Widget>[
            const SizedBox(height: 12),
            TextField(
              controller: _pass2,
              obscureText: !_show,
              decoration: InputDecoration(labelText: L.t('Repita a senha', 'Repeat the password'), prefixIcon: const Icon(Icons.lock_reset_rounded)),
            ),
            const SizedBox(height: 8),
            Text(L.t('Usuário: 3 a 24 caracteres (letras, números, _ . -). Senha: no mínimo 4 caracteres.', 'Username: 3-24 characters (letters, numbers, _ . -). Password: at least 4 characters.'),
                style: TextStyle(color: p.fg3, fontSize: 12)),
          ],
          const SizedBox(height: 6),
          CheckboxListTile(
            contentPadding: EdgeInsets.zero,
            value: _remember,
            onChanged: (bool? v) => setState(() => _remember = v ?? false),
            controlAffinity: ListTileControlAffinity.leading,
            title: Text(L.t('Salvar conta neste aparelho', 'Save account on this device'), style: const TextStyle(fontWeight: FontWeight.w700)),
            subtitle: Text(L.t('Entre depois com a digital, sem senha. Fica cifrada no Android Keystore.', 'Sign in later with your fingerprint, no password. Encrypted in the Android Keystore.'),
                style: TextStyle(color: p.fg2, fontSize: 12)),
          ),
          const SizedBox(height: 10),
          BusyButton(label: widget.register ? L.t('Criar conta', 'Create account') : L.t('Entrar', 'Sign in'), icon: widget.register ? Icons.person_add_alt_1_rounded : Icons.login_rounded, onPressed: _go),
        ]),
      ),
    );
  }
}
