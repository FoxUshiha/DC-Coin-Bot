import 'dart:async';

import 'package:flutter/material.dart';

import '../core/fmt.dart';
import '../core/i18n.dart';
import '../core/native.dart';
import '../core/state.dart';
import '../ui/common.dart';
import '../ui/netcfg.dart';
import '../ui/theme.dart';

const String kDefaultMainUrl = 'https://bank.foxsrv.net';

/// Configurações: URL da API principal, aparência, casas decimais, privacidade, notificações, segundo plano, contas salvas.
class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  final TextEditingController _url = TextEditingController(text: AppState.I.mainUrl);
  J _sys = <String, dynamic>{};
  String? _pingMsg;
  bool _pingOk = false;

  @override
  void initState() {
    super.initState();
    _loadSys();
  }

  @override
  void dispose() {
    _url.dispose();
    super.dispose();
  }

  Future<void> _loadSys() async {
    try {
      final J r = await Native.call('system');
      if (mounted) setState(() => _sys = r);
    } catch (_) {}
  }

  Future<void> _connect() async {
    String u = _url.text.trim();
    if (u.isEmpty) u = kDefaultMainUrl;
    if (!u.startsWith('http://') && !u.startsWith('https://')) u = 'https://$u';
    while (u.endsWith('/')) {
      u = u.substring(0, u.length - 1);
    }
    final J r = await Native.call('ping', <String, dynamic>{'url': u});
    if (!jb(r, 'ok')) {
      setState(() {
        _pingOk = false;
        _pingMsg = L.t('Sem resposta de $u', 'No response from $u');
      });
      throw ApiException('network', 0, <String, dynamic>{});
    }
    final AppState s = AppState.I;
    final bool changed = u != s.mainUrl;
    await s.setSettings(<String, dynamic>{'mainUrl': u});
    await s.reloadState();
    _url.text = u;
    setState(() {
      _pingOk = true;
      _pingMsg = L.t('Conectado · ${ji(r, 'ms')} ms', 'Connected · ${ji(r, 'ms')} ms');
    });
    if (changed && s.activeId == 'main') unawaited(s.refreshAll());
    toast(L.t('API salva e testada', 'API saved and tested'), ok: true);
  }

  Future<void> _notify(String key, bool v) async {
    if (v) {
      try {
        await Native.call('perm', <String, dynamic>{'kind': 'notifications'});
      } catch (_) {}
    }
    await AppState.I.setSettings(<String, dynamic>{key: v});
    unawaited(_loadSys());
  }

  @override
  Widget build(BuildContext context) {
    return Watch(builder: (BuildContext context) {
      final Pal p = Pal.of(context);
      final AppState s = AppState.I;
      final J st = s.settings;
      Widget sw(String key, String title, String sub, IconData ic, {bool def = false, bool enabled = true, ValueChanged<bool>? onChanged}) => SwitchListTile(
            value: jb(st, key, def),
            onChanged: !enabled ? null : (onChanged ?? ((bool v) => s.setSettings(<String, dynamic>{key: v}))),
            secondary: Icon(ic, color: enabled ? p.gold : p.fg3),
            title: Text(title, style: const TextStyle(fontWeight: FontWeight.w800)),
            subtitle: Text(sub, style: TextStyle(color: p.fg2, fontSize: 12)),
          );
      final bool notify = jb(st, 'notify', true);
      return Scaffold(
        appBar: AppBar(title: Text(L.t('Configurações', 'Settings'))),
        body: ListView(padding: const EdgeInsets.fromLTRB(16, 4, 16, 30), children: <Widget>[
          SectionTitle(L.t('API da rede principal', 'Main network API'), padding: const EdgeInsets.fromLTRB(4, 6, 4, 8)),
          AppCard(
            child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: <Widget>[
              TextField(
                controller: _url,
                keyboardType: TextInputType.url,
                autocorrect: false,
                decoration: InputDecoration(labelText: L.t('URL da API Coin', 'Coin API URL'), prefixIcon: const Icon(Icons.link_rounded), hintText: kDefaultMainUrl),
              ),
              if (_pingMsg != null)
                Padding(
                  padding: const EdgeInsets.only(top: 8),
                  child: Row(children: <Widget>[
                    Icon(_pingOk ? Icons.check_circle_rounded : Icons.error_outline_rounded, size: 16, color: _pingOk ? p.ok : p.bad),
                    const SizedBox(width: 6),
                    Text(_pingMsg!, style: TextStyle(color: _pingOk ? p.ok : p.bad, fontWeight: FontWeight.w700, fontSize: 12.5)),
                  ]),
                ),
              const SizedBox(height: 12),
              Row(children: <Widget>[
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: () {
                      _url.text = kDefaultMainUrl;
                      _connect().catchError((Object e) => toast(errText(e), error: true));
                    },
                    icon: const Icon(Icons.settings_backup_restore_rounded, size: 18),
                    label: Text(L.t('Voltar ao padrão', 'Reset to default')),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(child: BusyButton(label: L.t('Conectar', 'Connect'), icon: Icons.wifi_tethering_rounded, onPressed: _connect)),
              ]),
              const SizedBox(height: 8),
              Text(L.t('Use outra API compatível com o Coin Bank (a rede principal trabalha sempre com 8 casas na API).', 'Use another Coin Bank-compatible API (the main network API always uses 8 decimals).'), style: TextStyle(color: p.fg3, fontSize: 12)),
            ]),
          ),
          SectionTitle(L.t('Aparência', 'Appearance')),
          AppCard(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: <Widget>[
              Text(L.t('Tema', 'Theme'), style: const TextStyle(fontWeight: FontWeight.w800)),
              const SizedBox(height: 8),
              SizedBox(
                width: double.infinity,
                child: SegmentedButton<String>(
                  showSelectedIcon: false,
                  style: SegmentedButton.styleFrom(selectedBackgroundColor: p.goldSoft, selectedForegroundColor: p.gold),
                  segments: <ButtonSegment<String>>[
                    ButtonSegment<String>(value: 'system', icon: const Icon(Icons.brightness_auto_rounded), label: Text(L.t('Sistema', 'System'))),
                    ButtonSegment<String>(value: 'light', icon: const Icon(Icons.light_mode_rounded), label: Text(L.t('Claro', 'Light'))),
                    ButtonSegment<String>(value: 'dark', icon: const Icon(Icons.dark_mode_rounded), label: Text(L.t('Escuro', 'Dark'))),
                  ],
                  selected: <String>{js(st, 'theme', 'system')},
                  onSelectionChanged: (Set<String> v) => s.setSettings(<String, dynamic>{'theme': v.first}),
                ),
              ),
              const SizedBox(height: 16),
              Text(L.t('Idioma', 'Language'), style: const TextStyle(fontWeight: FontWeight.w800)),
              const SizedBox(height: 8),
              SizedBox(
                width: double.infinity,
                child: SegmentedButton<String>(
                  showSelectedIcon: false,
                  style: SegmentedButton.styleFrom(selectedBackgroundColor: p.goldSoft, selectedForegroundColor: p.gold),
                  segments: <ButtonSegment<String>>[
                    ButtonSegment<String>(value: 'auto', label: Text(L.t('Automático', 'Automatic'))),
                    const ButtonSegment<String>(value: 'pt', label: Text('Português')),
                    const ButtonSegment<String>(value: 'en', label: Text('English')),
                  ],
                  selected: <String>{js(st, 'lang', 'auto')},
                  onSelectionChanged: (Set<String> v) => s.setSettings(<String, dynamic>{'lang': v.first}),
                ),
              ),
            ]),
          ),
          SectionTitle(L.t('Moeda da rede ativa', 'Active network coin')),
          CoinConfigCard(key: ValueKey<String>('cc-${s.activeId}'), server: s.activeId),
          SectionTitle(L.t('Ícone do app', 'App icon')),
          const AppIconPicker(),
          SectionTitle(L.t('Privacidade', 'Privacy')),
          AppCard(
            padding: const EdgeInsets.symmetric(vertical: 4),
            child: Column(children: <Widget>[
              sw('hideCard', L.t('Ocultar código do cartão', 'Hide card code'), L.t('O cartão abre sempre com o código escondido', 'The card always opens with the code hidden'), Icons.credit_card_off_rounded, def: true),
              sw('hideBalance', L.t('Ocultar saldo', 'Hide balance'), L.t('Mostra •••••• até tocar no olho', 'Shows •••••• until you tap the eye'), Icons.visibility_off_rounded),
            ]),
          ),
          SectionTitle(L.t('Notificações', 'Notifications')),
          AppCard(
            padding: const EdgeInsets.symmetric(vertical: 4),
            child: Column(children: <Widget>[
              if (_sys.isNotEmpty && !jb(_sys, 'notifications', true))
                ListTile(
                  leading: Icon(Icons.notifications_off_rounded, color: p.bad),
                  title: Text(L.t('Notificações bloqueadas no Android', 'Notifications blocked on Android'), style: TextStyle(color: p.bad, fontWeight: FontWeight.w800)),
                  trailing: TextButton(onPressed: () => Native.call('appSettings'), child: Text(L.t('Abrir', 'Open'))),
                ),
              sw('notify', L.t('Notificações', 'Notifications'), L.t('Confere todas as redes em que você entrou', 'Checks every network you are signed in to'), Icons.notifications_active_rounded, def: true, onChanged: (bool v) => _notify('notify', v)),
              sw('notifyOutgoing', L.t('Transferências enviadas', 'Transfers sent'), L.t('Quando sair dinheiro da conta', 'When money leaves the account'), Icons.north_east_rounded, def: true, enabled: notify),
              sw('notifyIncoming', L.t('Pagamentos recebidos', 'Payments received'), L.t('Toda vez que chegar coins', 'Every time coins arrive'), Icons.south_west_rounded, def: true, enabled: notify),
              sw('notifyBills', L.t('Novas cobranças', 'New bills'), L.t('Quando alguém te cobrar', 'When someone bills you'), Icons.request_quote_rounded, def: true, enabled: notify),
              sw('notifyPaid', L.t('Cobranças pagas', 'Paid bills'), L.t('Quando pagarem uma cobrança sua', 'When someone pays your bill'), Icons.task_alt_rounded, def: true, enabled: notify),
            ]),
          ),
          SectionTitle(L.t('Segundo plano', 'Background')),
          AppCard(
            padding: const EdgeInsets.symmetric(vertical: 4),
            child: Column(children: <Widget>[
              sw('background', L.t('Notificação fixa (manter ativo)', 'Persistent notification (keep running)'), L.t('Permite avisos e resgate automático com o app fechado', 'Allows alerts and auto-claim with the app closed'), Icons.push_pin_rounded, def: true),
              sw('autoClaim', L.t('Resgate automático', 'Auto-claim'), L.t('Resgata sozinho a cada hora quando a recompensa estiver disponível', 'Claims by itself every hour when the reward is available'), Icons.redeem_rounded,
                  onChanged: (bool v) => s.setSettings(<String, dynamic>{'autoClaim': v, if (v) 'background': true})),
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 4, 16, 8),
                child: Wrap(spacing: 8, runSpacing: 8, children: <Widget>[
                  for (final MapEntry<String, String> e in <String, String>{'realtime': L.t('Tempo real', 'Real time'), 'balanced': L.t('Equilibrado', 'Balanced'), 'saver': L.t('Economia', 'Saver')}.entries)
                    ChoiceChip(label: Text(e.value), selected: js(st, 'battery', 'balanced') == e.key, onSelected: (bool _) => s.setSettings(<String, dynamic>{'battery': e.key})),
                ]),
              ),
              ListTile(
                leading: Icon(Icons.battery_charging_full_rounded, color: p.gold),
                title: Text(L.t('Ignorar otimização de bateria', 'Ignore battery optimization'), style: const TextStyle(fontWeight: FontWeight.w800)),
                subtitle: Text(jb(_sys, 'batteryIgnored') ? L.t('Liberado', 'Allowed') : L.t('Recomendado para não perder avisos', 'Recommended so you do not miss alerts'), style: TextStyle(color: p.fg2, fontSize: 12)),
                trailing: jb(_sys, 'batteryIgnored')
                    ? Icon(Icons.check_circle_rounded, color: p.ok)
                    : FilledButton.tonal(
                        onPressed: () async {
                          await Native.call('battery.request');
                          await Future<void>.delayed(const Duration(seconds: 2));
                          await _loadSys();
                        },
                        child: Text(L.t('Liberar', 'Allow'))),
              ),
            ]),
          ),
          SectionTitle(L.t('Contas salvas neste aparelho', 'Accounts saved on this device')),
          if (s.accounts.isEmpty)
            Padding(padding: const EdgeInsets.symmetric(horizontal: 6), child: Text(L.t('Nenhuma. Salve na tela de entrar ou em Conta.', 'None. Save one on the sign-in screen or in Account.'), style: TextStyle(color: p.fg3)))
          else
            AppCard(
              padding: const EdgeInsets.symmetric(vertical: 4),
              child: Column(children: <Widget>[
                for (final J a in s.accounts)
                  ListTile(
                    leading: Avatar(js(a, 'username'), size: 36),
                    title: Text(js(a, 'username'), style: const TextStyle(fontWeight: FontWeight.w800)),
                    subtitle: Text(Uri.tryParse(js(a, 'server'))?.host ?? js(a, 'server'), style: TextStyle(color: p.fg2, fontSize: 12)),
                    trailing: IconButton(
                      icon: Icon(Icons.delete_outline_rounded, color: p.bad),
                      onPressed: () async {
                        final bool ok = await confirm(context, danger: true, title: L.t('Remover conta salva?', 'Remove saved account?'), text: L.t('A senha cifrada é apagada deste aparelho.', 'The encrypted password is erased from this device.'), ok: L.t('Remover', 'Remove'));
                        if (!ok) return;
                        await Native.call('accounts.remove', <String, dynamic>{'id': js(a, 'id')});
                        await s.reloadState();
                      },
                    ),
                  ),
              ]),
            ),
          const SizedBox(height: 20),
          Center(child: Text('Coin Bank ${s.version} · ${L.t('aparelho', 'device')} ${s.device}', style: TextStyle(color: p.fg3, fontSize: 12))),
        ]),
      );
    });
  }
}

