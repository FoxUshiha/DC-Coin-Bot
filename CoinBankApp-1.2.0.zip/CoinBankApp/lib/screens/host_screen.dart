import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../core/fmt.dart';
import '../core/i18n.dart';
import '../core/models.dart';
import '../core/native.dart';
import '../core/state.dart';
import '../ui/common.dart';
import '../ui/netcfg.dart';
import '../ui/theme.dart';

/// adicionar uma rede pelo endereço (testa o ping antes)
Future<void> addNetworkDialog(BuildContext context) async {
  await showDialog<void>(context: context, builder: (BuildContext c) => const _AddNetworkDialog());
}

/// adicionar rede: URL, nome, casas da API/exibição e ícone da moeda (opcionais; redes do app informam sozinhas)
class _AddNetworkDialog extends StatefulWidget {
  const _AddNetworkDialog();

  @override
  State<_AddNetworkDialog> createState() => _AddNetworkDialogState();
}

class _AddNetworkDialogState extends State<_AddNetworkDialog> {
  final TextEditingController _url = TextEditingController();
  final TextEditingController _name = TextEditingController();
  final TextEditingController _api = TextEditingController();
  int _disp = -1;
  String _icon = '';

  @override
  void dispose() {
    _url.dispose();
    _name.dispose();
    _api.dispose();
    super.dispose();
  }

  Future<void> _add() async {
    final J args = <String, dynamic>{'url': _url.text.trim(), 'name': _name.text.trim()};
    final int? api = int.tryParse(_api.text.trim());
    if (api != null) args['api'] = api.clamp(0, 18);
    if (_disp >= 0) args['disp'] = _disp;
    if (_icon.isNotEmpty) args['icon'] = _icon;
    final J r = await Native.call('servers.add', args);
    await AppState.I.reloadState();
    toast(L.t('Rede adicionada (${ji(jm(r, 'ping'), 'ms')} ms)', 'Network added (${ji(jm(r, 'ping'), 'ms')} ms)'), ok: true);
    if (mounted) Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    final Pal p = Pal.of(context);
    return AlertDialog(
      title: Text(L.t('Adicionar rede', 'Add network')),
      content: SingleChildScrollView(
        child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: <Widget>[
          TextField(controller: _url, autofocus: true, keyboardType: TextInputType.url, decoration: const InputDecoration(labelText: 'URL', hintText: 'https://xxxx.trycloudflare.com')),
          const SizedBox(height: 10),
          TextField(controller: _name, decoration: InputDecoration(labelText: L.t('Nome (opcional)', 'Name (optional)'))),
          const SizedBox(height: 10),
          TextField(
            controller: _api,
            keyboardType: TextInputType.number,
            inputFormatters: <TextInputFormatter>[FilteringTextInputFormatter.digitsOnly, LengthLimitingTextInputFormatter(2)],
            decoration: InputDecoration(labelText: L.t('Casas da API (padrão 8)', 'API decimals (default 8)')),
          ),
          const SizedBox(height: 12),
          Text(L.t('Exibir com', 'Display with'), style: TextStyle(color: p.fg2, fontWeight: FontWeight.w700, fontSize: 12.5)),
          const SizedBox(height: 6),
          Wrap(spacing: 6, runSpacing: 6, children: <Widget>[
            for (final MapEntry<int, String> e in <int, String>{-1: L.t('Igual à API', 'Same as API'), 8: '8', 2: '2', 0: L.t('Inteiro', 'Integer')}.entries)
              ChoiceChip(label: Text(e.value), selected: _disp == e.key, onSelected: (bool _) => setState(() => _disp = e.key)),
          ]),
          const SizedBox(height: 12),
          Row(children: <Widget>[
            ClipRRect(
              borderRadius: BorderRadius.circular(12),
              child: _icon.isEmpty ? Image.asset('assets/coin.png', width: 44, height: 44, filterQuality: FilterQuality.none) : Image.memory(base64Decode(_icon), width: 44, height: 44, fit: BoxFit.cover),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: OutlinedButton(
                onPressed: () async {
                  try {
                    final J r = await Native.call('pickIcon');
                    if (js(r, 'icon').isNotEmpty) setState(() => _icon = js(r, 'icon'));
                  } catch (e) {
                    toast(errText(e), error: true);
                  }
                },
                child: Text(L.t('Ícone da moeda', 'Coin icon')),
              ),
            ),
          ]),
        ]),
      ),
      actions: <Widget>[
        TextButton(onPressed: () => Navigator.of(context).pop(), child: Text(L.t('Cancelar', 'Cancel'))),
        BusyButton(expand: false, label: L.t('Testar e adicionar', 'Test and add'), onPressed: _add),
      ],
    );
  }
}

/// abre a configuração da moeda de uma rede
Future<void> openCoinConfig(BuildContext context, String server) {
  return showSheet<void>(context, (BuildContext c) => SingleChildScrollView(padding: const EdgeInsets.fromLTRB(16, 0, 16, 24), child: CoinConfigCard(server: server)));
}

/// Hospedar: lista de servidores (principal, adicionados, o deste aparelho) e a sua própria moeda (banco local + trycloudflare).
class HostScreen extends StatelessWidget {
  const HostScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          title: Text(L.t('Hospedar', 'Host')),
          bottom: TabBar(tabs: <Widget>[Tab(text: L.t('Servidores', 'Servers')), Tab(text: L.t('Minha rede', 'My network'))]),
        ),
        body: const TabBarView(children: <Widget>[_ServersTab(), _MyNetworkTab()]),
      ),
    );
  }
}

class _ServersTab extends StatefulWidget {
  const _ServersTab();

  @override
  State<_ServersTab> createState() => _ServersTabState();
}

class _ServersTabState extends State<_ServersTab> {
  final Map<String, int?> _ping = <String, int?>{};
  List<Peer> _nearHosts = <Peer>[];
  Timer? _t;

  @override
  void initState() {
    super.initState();
    _pingAll();
    _scan();
    _t = Timer.periodic(const Duration(seconds: 4), (_) => _scan());
  }

  @override
  void dispose() {
    _t?.cancel();
    unawaited(Native.call('nearby.scan', <String, dynamic>{'on': false}).catchError((Object _) => <String, dynamic>{}));
    super.dispose();
  }

  Future<void> _pingAll() async {
    for (final Server s in AppState.I.servers) {
      Native.call('ping', <String, dynamic>{'url': s.url}).then((J r) {
        if (mounted) setState(() => _ping[s.id] = jb(r, 'ok') ? ji(r, 'ms') : -1);
      }).catchError((Object _) {
        if (mounted) setState(() => _ping[s.id] = -1);
      });
    }
  }

  Future<void> _scan() async {
    try {
      final J r = await Native.call('nearby.scan', <String, dynamic>{'on': true});
      if (!mounted) return;
      setState(() => _nearHosts = jl(r, 'peers').map((J m) => Peer(m)).where((Peer x) => x.hasHost && AppState.I.serverByUrl(js(x.host, 'url')) == null).toList());
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    return Watch(builder: (BuildContext context) {
      final Pal p = Pal.of(context);
      final AppState s = AppState.I;
      return ListView(padding: const EdgeInsets.fromLTRB(16, 12, 16, 30), children: <Widget>[
        for (final Server sv in s.servers)
          FadeSlide(
            child: AppCard(
              margin: const EdgeInsets.only(bottom: 10),
              child: Row(children: <Widget>[
                Container(
                  width: 46,
                  height: 46,
                  alignment: Alignment.center,
                  child: NetIcon(sv.id, size: 44),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: <Widget>[
                    Row(children: <Widget>[
                      Flexible(child: Text(sv.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w900))),
                      const SizedBox(width: 6),
                      if (sv.isMain) Pill(L.t('Principal', 'Main')),
                      if (sv.isHost) Pill(L.t('Este aparelho', 'This device'), color: p.blue),
                    ]),
                    Text(sv.url, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: p.fg2, fontSize: 12)),
                    const SizedBox(height: 4),
                    Row(children: <Widget>[
                      Icon(Icons.circle, size: 9, color: _ping[sv.id] == null ? p.fg3 : (_ping[sv.id]! < 0 ? p.bad : p.ok)),
                      const SizedBox(width: 5),
                      Text(_ping[sv.id] == null ? '…' : (_ping[sv.id]! < 0 ? L.t('fora do ar', 'offline') : '${_ping[sv.id]} ms'), style: TextStyle(color: p.fg3, fontSize: 11.5)),
                      const SizedBox(width: 8),
                      if (s.sessionOf(sv.id) != null) Text('· ${js(s.sessionOf(sv.id), 'username')}', style: TextStyle(color: p.fg3, fontSize: 11.5)),
                    ]),
                  ]),
                ),
                if (sv.id == s.activeId)
                  Icon(Icons.check_circle_rounded, color: p.ok)
                else
                  TextButton(
                    onPressed: () async {
                      await s.setActive(sv.id);
                      if (context.mounted) Navigator.of(context).popUntil((Route<dynamic> r) => r.isFirst);
                    },
                    child: Text(L.t('Usar', 'Use')),
                  ),
                PopupMenuButton<String>(
                    onSelected: (String v) async {
                      if (v == 'coin') {
                        await openCoinConfig(context, sv.id);
                      } else if (v == 'rename') {
                        final String? n = await askText(context, title: L.t('Renomear', 'Rename'), initial: sv.name);
                        if (n != null && n.trim().isNotEmpty) {
                          await Native.call('servers.rename', <String, dynamic>{'id': sv.id, 'name': n.trim()});
                          await s.reloadState();
                        }
                      } else if (v == 'rm') {
                        final bool ok = await confirm(context, danger: true, title: L.t('Remover rede?', 'Remove network?'), text: L.t('Sua sessão nesta rede neste aparelho é apagada. A conta continua no servidor.', 'Your session on this network on this device is erased. The account stays on the server.'), ok: L.t('Remover', 'Remove'));
                        if (ok) {
                          await Native.call('servers.remove', <String, dynamic>{'id': sv.id});
                          await s.reloadState();
                        }
                      }
                    },
                    itemBuilder: (BuildContext c) => <PopupMenuEntry<String>>[
                      PopupMenuItem<String>(value: 'coin', child: Text(L.t('Moeda: casas, nome e ícone', 'Coin: decimals, name and icon'))),
                      if (sv.kind == 'custom') PopupMenuItem<String>(value: 'rename', child: Text(L.t('Renomear', 'Rename'))),
                      if (sv.kind == 'custom') PopupMenuItem<String>(value: 'rm', child: Text(L.t('Remover', 'Remove'))),
                    ],
                  ),
              ]),
            ),
          ),
        const SizedBox(height: 4),
        OutlinedButton.icon(onPressed: () => addNetworkDialog(context), icon: const Icon(Icons.add_link_rounded), label: Text(L.t('Adicionar servidor', 'Add server'))),
        SectionTitle(L.t('Redes por perto', 'Networks nearby')),
        if (_nearHosts.isEmpty)
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 6),
            child: Text(L.t('Procurando redes hospedadas em celulares por perto (Wi-Fi/hotspot)…', 'Looking for networks hosted on phones nearby (Wi-Fi/hotspot)…'), style: TextStyle(color: p.fg3)),
          )
        else
          for (final Peer pe in _nearHosts)
            AppCard(
              margin: const EdgeInsets.only(bottom: 10),
              child: Row(children: <Widget>[
                Icon(jb(pe.host, 'cf') ? Icons.cloud_rounded : Icons.router_rounded, color: p.gold),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: <Widget>[
                    Text(js(pe.host, 'name'), style: const TextStyle(fontWeight: FontWeight.w900)),
                    Text(js(pe.host, 'url'), maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: p.fg2, fontSize: 12)),
                  ]),
                ),
                FilledButton.tonal(
                  onPressed: () async {
                    try {
                      await Native.call('servers.add', <String, dynamic>{'url': js(pe.host, 'url'), 'name': js(pe.host, 'name')});
                      await s.reloadState();
                      unawaited(_pingAll());
                      unawaited(_scan());
                    } catch (e) {
                      toast(errText(e), error: true);
                    }
                  },
                  child: Text(L.t('Adicionar', 'Add')),
                ),
              ]),
            ),
        const SizedBox(height: 12),
        AppCard(
          color: p.card2,
          child: Text(
              L.t('Todas as redes em que você entrou geram notificações (recebidos, enviados e cobranças), com o nome da rede e o ícone da moeda. Toque em ⋮ para configurar casas decimais, nome e ícone de cada moeda.',
                  'Every network you are signed in to sends notifications (received, sent and bills) with the network name and coin icon. Tap ⋮ to set decimals, name and icon of each coin.'),
              style: TextStyle(color: p.fg2, fontSize: 12.5)),
        ),
      ]);
    });
  }
}

class _MyNetworkTab extends StatefulWidget {
  const _MyNetworkTab();

  @override
  State<_MyNetworkTab> createState() => _MyNetworkTabState();
}

class _MyNetworkTabState extends State<_MyNetworkTab> {
  J _st = <String, dynamic>{};
  J _sys = <String, dynamic>{};
  Timer? _t;
  final TextEditingController _name = TextEditingController();
  final TextEditingController _claim = TextEditingController();
  final TextEditingController _cool = TextEditingController();
  final TextEditingController _port = TextEditingController();
  final TextEditingController _max = TextEditingController();
  bool _filled = false;

  @override
  void initState() {
    super.initState();
    _load();
    _t = Timer.periodic(const Duration(seconds: 3), (_) => _load());
    AppState.I.hostTick.addListener(_load);
  }

  @override
  void dispose() {
    _t?.cancel();
    AppState.I.hostTick.removeListener(_load);
    _name.dispose();
    _claim.dispose();
    _cool.dispose();
    _port.dispose();
    _max.dispose();
    super.dispose();
  }

  J get _cfg => jm(_st, 'config');

  Future<void> _load() async {
    try {
      final J r = await Native.call('host.status');
      final J y = await Native.call('system');
      if (!mounted) return;
      setState(() {
        _st = r;
        _sys = y;
        if (!_filled) {
          _filled = true;
          final J c = jm(r, 'config');
          _name.text = js(c, 'name');
          _claim.text = F.coins(ji(c, 'claimSats', 12), net: 'host');
          _cool.text = '${ji(c, 'cooldownMs', 3600000) ~/ 60000}';
          _port.text = '${ji(c, 'port', 26450)}';
          _max.text = '${ji(c, 'maxUsers', 1000)}';
        }
      });
    } catch (_) {}
  }

  Future<void> _set(J patch) async {
    final J r = await Native.call('host.set', <String, dynamic>{'patch': jsonString(patch)});
    await AppState.I.reloadState();
    if (mounted) setState(() => _st = r);
  }

  Future<void> _saveCoin() async {
    final int? claim = F.parse(_claim.text, 'host');
    final int? cool = int.tryParse(_cool.text.trim());
    final int? port = int.tryParse(_port.text.trim());
    final int? max = int.tryParse(_max.text.trim());
    if (claim == null || claim <= 0) throw ApiException('INVALID_AMOUNT', 400, <String, dynamic>{});
    if (cool == null || cool < 1) throw ApiException('INVALID_TIME', 400, <String, dynamic>{});
    if (port == null || port < 1024 || port > 65535) throw ApiException('port', 400, <String, dynamic>{'message': L.t('Porta entre 1024 e 65535', 'Port between 1024 and 65535')});
    await _set(<String, dynamic>{'name': _name.text.trim(), 'claimSats': claim, 'cooldownMs': cool * 60000, 'port': port, 'maxUsers': max ?? 1000});
    toast(L.t('Configuração da moeda salva', 'Coin settings saved'), ok: true);
  }

  @override
  Widget build(BuildContext context) {
    final Pal p = Pal.of(context);
    final AppState s = AppState.I;
    final J c = _cfg;
    final bool on = jb(c, 'enabled');
    final bool running = jb(_st, 'running');
    final J tun = jm(_st, 'tunnel');
    final J sto = jm(_st, 'storage');
    final String tunUrl = js(tun, 'url');
    return ListView(padding: const EdgeInsets.fromLTRB(16, 12, 16, 30), children: <Widget>[
      AppCard(
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: <Widget>[
          Row(children: <Widget>[
            Container(
              width: 50,
              height: 50,
              decoration: BoxDecoration(color: running ? p.okSoft : p.card2, borderRadius: BorderRadius.circular(16)),
              child: Icon(Icons.dns_rounded, color: running ? p.ok : p.fg3),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: <Widget>[
                Text(L.t('Hospedar minha moeda', 'Host my coin'), style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16)),
                Text(running ? L.t('No ar · ${js(_st, 'lan', js(_st, 'local'))}', 'Online · ${js(_st, 'lan', js(_st, 'local'))}') : L.t('Desligada · uma rede por aparelho', 'Off · one network per device'),
                    style: TextStyle(color: running ? p.ok : p.fg2, fontSize: 12.5)),
              ]),
            ),
            Switch(
              value: on,
              onChanged: (bool v) async {
                try {
                  if (v) await Native.call('perm', <String, dynamic>{'kind': 'notifications'});
                  await _set(<String, dynamic>{'enabled': v});
                } catch (e) {
                  toast(errText(e), error: true);
                }
              },
            ),
          ]),
          const SizedBox(height: 10),
          Text(
              L.t('Seu celular vira um servidor Coin com banco de dados local. Toda rede nova começa com 0,00000000 para todos e resgate de 0,00000012 a cada 1 h (ajustável abaixo). Quem está perto encontra sua rede pelo Wi-Fi/hotspot, ou de qualquer lugar pelo túnel Cloudflare.',
                  'Your phone becomes a Coin server with a local database. Every new network starts at 0.00000000 for everyone with a claim of 0.00000012 every 1 h (adjustable below). People nearby find it on Wi-Fi/hotspot, or from anywhere via the Cloudflare tunnel.'),
              style: TextStyle(color: p.fg2, fontSize: 12.5, height: 1.35)),
          if (js(_st, 'error').isNotEmpty && !running && on) Padding(padding: const EdgeInsets.only(top: 8), child: Text(js(_st, 'error'), style: TextStyle(color: p.bad, fontSize: 12))),
        ]),
      ),
      if (on) ...<Widget>[
        const SizedBox(height: 10),
        GridView.count(
          crossAxisCount: 3,
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          mainAxisSpacing: 8,
          crossAxisSpacing: 8,
          childAspectRatio: 1.25,
          children: <Widget>[
            _mini(p, Icons.groups_rounded, F.integer(ji(_st, 'users')), L.t('usuários', 'users')),
            _mini(p, Icons.swap_horiz_rounded, F.integer(ji(_st, 'transactions')), L.t('transações', 'transactions')),
            _mini(p, Icons.timer_outlined, F.duration(ji(_st, 'uptimeSec') * 1000), L.t('no ar', 'uptime')),
          ],
        ),
        const SizedBox(height: 10),
        BusyButton(
          label: s.activeId == 'host' ? L.t('Você está usando esta rede', 'You are using this network') : L.t('Entrar na minha rede', 'Use my network'),
          icon: Icons.login_rounded,
          onPressed: s.activeId == 'host'
              ? null
              : () async {
                  await s.setActive('host');
                  if (context.mounted) Navigator.of(context).popUntil((Route<dynamic> r) => r.isFirst);
                },
        ),
        SectionTitle(L.t('Acesso', 'Access')),
        AppCard(
          padding: const EdgeInsets.symmetric(vertical: 6),
          child: Column(children: <Widget>[
            ListTile(
              leading: Icon(Icons.router_rounded, color: p.gold),
              title: Text(L.t('Rede local', 'Local network'), style: const TextStyle(fontWeight: FontWeight.w800)),
              subtitle: Text(js(_st, 'lan', L.t('sem Wi-Fi/hotspot', 'no Wi-Fi/hotspot')), style: TextStyle(color: p.fg2, fontFamily: 'monospace', fontSize: 12)),
              trailing: js(_st, 'lan').isEmpty ? null : IconButton(icon: const Icon(Icons.copy_rounded), onPressed: () => copyText(js(_st, 'lan'), 'URL')),
            ),
            SwitchListTile(
              value: jb(c, 'cloudflare'),
              onChanged: jb(_st, 'cloudflaredAvailable')
                  ? (bool v) => _set(<String, dynamic>{'cloudflare': v}).catchError((Object e) => toast(errText(e), error: true))
                  : null,
              secondary: Icon(Icons.cloud_rounded, color: p.gold),
              title: Text(L.t('Túnel Cloudflare (trycloudflare)', 'Cloudflare tunnel (trycloudflare)'), style: const TextStyle(fontWeight: FontWeight.w800)),
              subtitle: Text(
                !jb(_st, 'cloudflaredAvailable')
                    ? L.t('Disponível em aparelhos ARM64', 'Available on ARM64 devices')
                    : (tunUrl.isNotEmpty
                        ? tunUrl
                        : (jb(c, 'cloudflare') ? L.t('Conectando… (${js(tun, 'state')})', 'Connecting… (${js(tun, 'state')})') : L.t('Acesso de qualquer lugar, sem abrir portas. Com ele ligado, quem está perto vê só o endereço Cloudflare.', 'Access from anywhere without opening ports. While on, people nearby only see the Cloudflare address.'))),
                style: TextStyle(color: tunUrl.isNotEmpty ? p.ok : p.fg2, fontSize: 12),
              ),
            ),
            if (tunUrl.isNotEmpty)
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 0, 16, 10),
                child: Row(children: <Widget>[
                  Expanded(child: OutlinedButton.icon(onPressed: () => copyText(tunUrl, 'URL'), icon: const Icon(Icons.copy_rounded, size: 18), label: Text(L.t('Copiar', 'Copy')))),
                  const SizedBox(width: 10),
                  Expanded(child: OutlinedButton.icon(onPressed: () => Native.call('shareText', <String, dynamic>{'text': tunUrl}), icon: const Icon(Icons.share_rounded, size: 18), label: Text(L.t('Enviar', 'Share')))),
                ]),
              ),
          ]),
        ),
      ],
      if (on) ...<Widget>[
        SectionTitle(L.t('Moeda: ícone, nome e casas', 'Coin: icon, name and decimals')),
        const CoinConfigCard(server: 'host'),
      ],
      SectionTitle(L.t('Padrões da moeda', 'Coin defaults')),
      AppCard(
        child: Column(children: <Widget>[
          TextField(controller: _name, maxLength: 40, decoration: InputDecoration(labelText: L.t('Nome da rede', 'Network name'), prefixIcon: const Icon(Icons.badge_outlined))),
          const SizedBox(height: 4),
          TextField(
            controller: _claim,
            keyboardType: const TextInputType.numberWithOptions(decimal: true),
            decoration: InputDecoration(labelText: L.t('Resgate (coins)', 'Claim (coins)'), prefixIcon: const Icon(Icons.redeem_rounded)),
          ),
          const SizedBox(height: 12),
          Row(children: <Widget>[
            Expanded(
              child: TextField(
                controller: _cool,
                keyboardType: TextInputType.number,
                inputFormatters: <TextInputFormatter>[FilteringTextInputFormatter.digitsOnly],
                decoration: InputDecoration(labelText: L.t('A cada (min)', 'Every (min)'), prefixIcon: const Icon(Icons.timer_outlined)),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: TextField(
                controller: _port,
                keyboardType: TextInputType.number,
                inputFormatters: <TextInputFormatter>[FilteringTextInputFormatter.digitsOnly],
                decoration: InputDecoration(labelText: L.t('Porta', 'Port'), prefixIcon: const Icon(Icons.settings_ethernet_rounded)),
              ),
            ),
          ]),
          const SizedBox(height: 12),
          TextField(
            controller: _max,
            keyboardType: TextInputType.number,
            inputFormatters: <TextInputFormatter>[FilteringTextInputFormatter.digitsOnly],
            decoration: InputDecoration(labelText: L.t('Máximo de contas', 'Max accounts'), prefixIcon: const Icon(Icons.group_add_outlined)),
          ),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            value: jb(c, 'openRegister', true),
            onChanged: (bool v) => _set(<String, dynamic>{'openRegister': v}),
            title: Text(L.t('Aceitar novas contas', 'Accept new accounts'), style: const TextStyle(fontWeight: FontWeight.w700)),
          ),
          const SizedBox(height: 6),
          BusyButton(label: L.t('Salvar padrões', 'Save defaults'), icon: Icons.save_rounded, onPressed: _saveCoin),
        ]),
      ),
      SectionTitle(L.t('Bateria e segundo plano', 'Battery and background')),
      AppCard(
        padding: const EdgeInsets.symmetric(vertical: 6),
        child: Column(children: <Widget>[
          ListTile(
            leading: Icon(Icons.battery_saver_rounded, color: p.gold),
            title: Text(L.t('Otimização de bateria', 'Battery optimization'), style: const TextStyle(fontWeight: FontWeight.w800)),
            subtitle: Text(jb(_sys, 'batteryIgnored') ? L.t('Liberado: o Android não pausa a rede', 'Allowed: Android will not pause the network') : L.t('Ative para a rede ficar no ar com a tela desligada', 'Enable so the network stays up with the screen off'),
                style: TextStyle(color: jb(_sys, 'batteryIgnored') ? p.ok : p.fg2, fontSize: 12)),
            trailing: jb(_sys, 'batteryIgnored') ? Icon(Icons.check_circle_rounded, color: p.ok) : FilledButton.tonal(onPressed: () => Native.call('battery.request'), child: Text(L.t('Liberar', 'Allow'))),
          ),
          SwitchListTile(
            value: jb(c, 'wakeLock'),
            onChanged: (bool v) => _set(<String, dynamic>{'wakeLock': v}),
            secondary: Icon(Icons.bolt_rounded, color: p.gold),
            title: Text(L.t('Manter processador ativo', 'Keep CPU awake'), style: const TextStyle(fontWeight: FontWeight.w800)),
            subtitle: Text(L.t('Responde mais rápido com a tela desligada (gasta mais bateria)', 'Responds faster with the screen off (uses more battery)'), style: TextStyle(color: p.fg2, fontSize: 12)),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 4, 16, 12),
            child: Wrap(spacing: 8, runSpacing: 8, children: <Widget>[
              for (final MapEntry<String, String> e in <String, String>{'realtime': L.t('Tempo real (5 s)', 'Real time (5 s)'), 'balanced': L.t('Equilibrado (15 s)', 'Balanced (15 s)'), 'saver': L.t('Economia (60 s)', 'Saver (60 s)')}.entries)
                ChoiceChip(label: Text(e.value), selected: js(s.settings, 'battery', 'balanced') == e.key, onSelected: (bool _) => s.setSettings(<String, dynamic>{'battery': e.key})),
            ]),
          ),
        ]),
      ),
      SectionTitle(L.t('Armazenamento', 'Storage')),
      AppCard(
        child: Column(children: <Widget>[
          InfoRow(L.t('Banco da moeda', 'Coin database'), F.bytes(ji(sto, 'dbBytes'))),
          InfoRow(L.t('Livre no aparelho', 'Free on device'), F.bytes(ji(sto, 'freeBytes'))),
          const SizedBox(height: 6),
          ClipRRect(
            borderRadius: BorderRadius.circular(99),
            child: LinearProgressIndicator(
              minHeight: 8,
              value: ji(sto, 'totalBytes') <= 0 ? 0.0 : (1 - ji(sto, 'freeBytes') / ji(sto, 'totalBytes')).clamp(0.0, 1.0),
              backgroundColor: p.card2,
              color: ji(sto, 'freeBytes') < 200 * 1024 * 1024 ? p.bad : p.gold,
            ),
          ),
          if (ji(sto, 'freeBytes') > 0 && ji(sto, 'freeBytes') < 200 * 1024 * 1024)
            Padding(padding: const EdgeInsets.only(top: 8), child: Text(L.t('Pouco espaço livre: a rede pode parar de gravar.', 'Low free space: the network may stop writing.'), style: TextStyle(color: p.bad, fontSize: 12))),
          const SizedBox(height: 10),
          TextButton.icon(
            onPressed: () async {
              final bool ok = await confirm(context,
                  danger: true,
                  icon: Icons.delete_forever_rounded,
                  title: L.t('Apagar dados da rede?', 'Erase network data?'),
                  text: L.t('Todas as contas, saldos e transações da SUA rede hospedada serão apagados. A rede principal não é afetada.', 'All accounts, balances and transactions of YOUR hosted network will be erased. The main network is not affected.'),
                  ok: L.t('Apagar tudo', 'Erase all'));
              if (!ok) return;
              try {
                await Native.call('host.wipe');
                await s.reloadState();
                toast(L.t('Dados apagados', 'Data erased'), ok: true);
              } catch (e) {
                toast(errText(e), error: true);
              }
            },
            icon: Icon(Icons.delete_outline_rounded, color: p.bad),
            label: Text(L.t('Apagar dados da minha rede', 'Erase my network data'), style: TextStyle(color: p.bad)),
          ),
        ]),
      ),
    ]);
  }

  Widget _mini(Pal p, IconData ic, String v, String label) => AppCard(
        padding: const EdgeInsets.all(10),
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: <Widget>[
          Icon(ic, color: p.gold, size: 20),
          const SizedBox(height: 4),
          FittedBox(fit: BoxFit.scaleDown, child: Text(v, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16))),
          Text(label, style: TextStyle(color: p.fg2, fontSize: 11)),
        ]),
      );
}
