import 'package:flutter/material.dart';

import '../core/fmt.dart';
import '../core/i18n.dart';
import '../core/models.dart';
import '../core/state.dart';
import '../ui/common.dart';
import '../ui/flows.dart';
import '../ui/theme.dart';

/// Aba Contas: cobranças para pagar e para receber; gerar cobrança, pagar por ID ou escaneando.
class BillsTab extends StatefulWidget {
  const BillsTab({super.key});

  @override
  State<BillsTab> createState() => _BillsTabState();
}

class _BillsTabState extends State<BillsTab> {
  String _seg = 'pay';

  @override
  Widget build(BuildContext context) {
    return Watch(builder: (BuildContext context) {
      final Pal p = Pal.of(context);
      final AppState s = AppState.I;
      final List<Bill> list = _seg == 'pay' ? s.toPay : s.toReceive;
      return RefreshIndicator(
        color: p.gold,
        onRefresh: () => s.refreshAll(),
        child: ListView(padding: const EdgeInsets.fromLTRB(16, 6, 16, 90), children: <Widget>[
          FadeSlide(
            child: Row(children: <Widget>[
              Expanded(child: _Tile(icon: Icons.add_card_rounded, label: L.t('Gerar cobrança', 'Create bill'), onTap: () => openCreateBill(context), primary: true)),
              const SizedBox(width: 10),
              Expanded(child: _Tile(icon: Icons.qr_code_scanner_rounded, label: L.t('Escanear conta', 'Scan bill'), onTap: () => scanToPay(context))),
              const SizedBox(width: 10),
              Expanded(child: _Tile(icon: Icons.keyboard_rounded, label: L.t('Pagar por ID', 'Pay by ID'), onTap: () => payBillById(context))),
            ]),
          ),
          const SizedBox(height: 14),
          SegmentedButton<String>(
            showSelectedIcon: false,
            style: SegmentedButton.styleFrom(selectedBackgroundColor: p.goldSoft, selectedForegroundColor: p.gold),
            segments: <ButtonSegment<String>>[
              ButtonSegment<String>(value: 'pay', icon: const Icon(Icons.call_made_rounded), label: Text(L.t('A pagar (${s.toPay.length})', 'To pay (${s.toPay.length})'))),
              ButtonSegment<String>(value: 'recv', icon: const Icon(Icons.call_received_rounded), label: Text(L.t('A receber (${s.toReceive.length})', 'To receive (${s.toReceive.length})'))),
            ],
            selected: <String>{_seg},
            onSelectionChanged: (Set<String> v) => setState(() => _seg = v.first),
          ),
          const SizedBox(height: 12),
          AnimatedSwitcher(
            duration: const Duration(milliseconds: 300),
            child: list.isEmpty
                ? EmptyState(
                    key: ValueKey<String>('e$_seg'),
                    icon: _seg == 'pay' ? Icons.task_alt_rounded : Icons.request_quote_outlined,
                    title: _seg == 'pay' ? L.t('Nenhuma conta para pagar', 'No bills to pay') : L.t('Nenhuma cobrança em aberto', 'No open bills'),
                    text: _seg == 'pay'
                        ? L.t('Quando alguém te cobrar, aparece aqui e você recebe uma notificação.', 'When someone bills you, it shows up here and you get a notification.')
                        : L.t('Gere uma cobrança e mande o QR ou o ID para quem vai pagar.', 'Create a bill and send the QR or ID to the payer.'),
                  )
                : Column(key: ValueKey<String>('l$_seg${list.length}'), children: <Widget>[
                    for (int i = 0; i < list.length; i++) FadeSlide(delay: 30 * i, child: _BillCard(bill: list[i], incoming: _seg == 'pay')),
                  ]),
          ),
        ]),
      );
    });
  }
}

class _BillCard extends StatelessWidget {
  const _BillCard({required this.bill, required this.incoming});
  final Bill bill;
  final bool incoming;

  @override
  Widget build(BuildContext context) {
    final Pal p = Pal.of(context);
    final AppState s = AppState.I;
    final DateTime? exp = bill.expiresAt;
    final bool soon = exp != null && exp.difference(DateTime.now()).inHours < 24;
    return AppCard(
      margin: const EdgeInsets.only(bottom: 10),
      onTap: () => openBill(context, server: s.activeId, bill: bill),
      child: Row(children: <Widget>[
        Container(
          width: 46,
          height: 46,
          decoration: BoxDecoration(color: incoming ? p.badSoft : p.okSoft, borderRadius: BorderRadius.circular(14)),
          child: Icon(incoming ? Icons.call_made_rounded : Icons.call_received_rounded, color: incoming ? p.bad : p.ok),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: <Widget>[
            Text(incoming ? L.t('Cobrança de ${F.short(bill.to, 5)}', 'Bill from ${F.short(bill.to, 5)}') : (bill.from.isEmpty ? L.t('Qualquer pessoa paga', 'Anyone can pay') : L.t('Para ${F.short(bill.from, 5)}', 'To ${F.short(bill.from, 5)}')),
                style: const TextStyle(fontWeight: FontWeight.w800)),
            const SizedBox(height: 2),
            Text(exp == null ? F.dateTime(bill.date) : L.t('Vence ${F.dateTime(exp)}', 'Due ${F.dateTime(exp)}'), style: TextStyle(color: soon ? p.bad : p.fg2, fontSize: 12.5)),
          ]),
        ),
        Column(crossAxisAlignment: CrossAxisAlignment.end, children: <Widget>[
          Text(F.coins(bill.sats), style: TextStyle(fontWeight: FontWeight.w900, color: p.gold)),
          const SizedBox(height: 4),
          Pill(incoming ? L.t('Pagar', 'Pay') : L.t('Ver QR', 'Show QR'), color: incoming ? p.bad : p.ok),
        ]),
      ]),
    );
  }
}

class _Tile extends StatelessWidget {
  const _Tile({required this.icon, required this.label, required this.onTap, this.primary = false});
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  final bool primary;

  @override
  Widget build(BuildContext context) {
    final Pal p = Pal.of(context);
    final Color fg = primary ? p.prifg : p.gold;
    return AppCard(
      color: primary ? p.pri : p.card,
      onTap: onTap,
      padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 8),
      child: Column(children: <Widget>[
        Icon(icon, color: fg, size: 26),
        const SizedBox(height: 6),
        Text(label, textAlign: TextAlign.center, maxLines: 2, style: TextStyle(fontWeight: FontWeight.w800, fontSize: 12.5, color: primary ? fg : p.fg)),
      ]),
    );
  }
}
