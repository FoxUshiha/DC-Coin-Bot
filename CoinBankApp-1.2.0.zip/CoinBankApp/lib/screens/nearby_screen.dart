import 'dart:async';

import 'package:flutter/material.dart';

import '../core/fmt.dart';
import '../core/i18n.dart';
import '../core/models.dart';
import '../core/native.dart';
import '../core/state.dart';
import '../ui/common.dart';
import '../ui/flows.dart';
import '../ui/theme.dart';

/// Por perto: ficar visível, pessoas próximas (pagar / cobrar) e redes hospedadas por perto.
class NearbyScreen extends StatefulWidget {
  const NearbyScreen({super.key});

  @override
  State<NearbyScreen> createState() => _NearbyScreenState();
}

class _NearbyScreenState extends State<NearbyScreen> with SingleTickerProviderStateMixin {
  List<Peer> _peers = <Peer>[];
  J _status = <String, dynamic>{};
  Timer? _t;
  late final AnimationController _radar = AnimationController(vsync: this, duration: const Duration(seconds: 3))..repeat();

  @override
  void initState() {
    super.initState();
    _load(true);
    _t = Timer.periodic(const Duration(seconds: 2), (_) => _load(false));
  }

  @override
  void dispose() {
    _t?.cancel();
    _radar.dispose();
    unawaited(Native.call('nearby.scan', <String, dynamic>{'on': false}).catchError((Object _) => <String, dynamic>{}));
    super.dispose();
  }

  Future<void> _load(bool start) async {
    try {
      final J r = await Native.call(start ? 'nearby.scan' : 'nearby.list', start ? <String, dynamic>{'on': true} : null);
      if (!mounted) return;
      setState(() {
        _status = jm(r, 'status');
        _peers = jl(r, 'peers').map((J m) => Peer(m)).toList();
      });
    } catch (_) {}
  }

  Future<void> _setVisible(bool v) async {
    await AppState.I.setSettings(<String, dynamic>{'visible': v});
    unawaited(_load(true));
  }

  Future<void> _setBle(bool v) async {
    if (v) {
      final J r = await Native.call('perm', <String, dynamic>{'kind': 'bluetooth'});
      if (!jb(r, 'granted')) {
        toast(L.t('Permissão de Bluetooth negada.', 'Bluetooth permission denied.'), error: true);
        return;
      }
    }
    await AppState.I.setSettings(<String, dynamic>{'bluetooth': v});
    unawaited(_load(true));
  }

  Future<void> _connectHost(Peer pe) async {
    final String url = js(pe.host, 'url');
    try {
      final J r = await Native.call('servers.add', <String, dynamic>{'url': url, 'name': js(pe.host, 'name')});
      await AppState.I.reloadState();
      await AppState.I.setActive(js(jm(r, 'server'), 'id'));
      if (mounted) Navigator.of(context).popUntil((Route<dynamic> r) => r.isFirst);
      toast(L.t('Conectado à rede ${js(pe.host, 'name')}', 'Connected to ${js(pe.host, 'name')}'), ok: true);
    } catch (e) {
      toast(errText(e), error: true);
    }
  }

  @override
  Widget build(BuildContext context) {
    final Pal p = Pal.of(context);
    final AppState s = AppState.I;
    final List<Peer> people = _peers.where((Peer x) => x.hasMe).toList();
    final List<Peer> hosts = _peers.where((Peer x) => x.hasHost).toList();
    final String ble = js(_status, 'ble', 'unsupported');
    return Scaffold(
      appBar: AppBar(title: Text(L.t('Por perto', 'Nearby'))),
      body: ListView(padding: const EdgeInsets.fromLTRB(16, 4, 16, 30), children: <Widget>[
        Center(
          child: SizedBox(
            width: 170,
            height: 170,
            child: AnimatedBuilder(
              animation: _radar,
              builder: (BuildContext c, Widget? ch) => Stack(alignment: Alignment.center, children: <Widget>[
                for (int i = 0; i < 3; i++)
                  Opacity(
                    opacity: (1 - ((_radar.value + i / 3) % 1)).clamp(0.0, 1.0) * 0.8,
                    child: Container(
                      width: 60 + 110 * ((_radar.value + i / 3) % 1),
                      height: 60 + 110 * ((_radar.value + i / 3) % 1),
                      decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: p.gold, width: 1.6)),
                    ),
                  ),
                ch!,
              ]),
              child: Avatar(s.username, size: 62),
            ),
          ),
        ),
        Center(child: Text(L.t('${people.length} pessoa(s) · ${hosts.length} rede(s) por perto', '${people.length} people · ${hosts.length} network(s) nearby'), style: TextStyle(color: p.fg2, fontWeight: FontWeight.w700))),
        const SizedBox(height: 14),
        AppCard(
          padding: const EdgeInsets.symmetric(vertical: 4),
          child: Column(children: <Widget>[
            SwitchListTile(
              value: jb(s.settings, 'visible'),
              onChanged: (bool v) => _setVisible(v),
              secondary: Icon(Icons.visibility_rounded, color: p.gold),
              title: Text(L.t('Ficar visível', 'Be visible'), style: const TextStyle(fontWeight: FontWeight.w800)),
              subtitle: Text(L.t('Mostra seu usuário e ID para quem está na mesma rede local (Wi-Fi/hotspot)', 'Shows your username and ID to people on the same local network (Wi-Fi/hotspot)'),
                  style: TextStyle(color: p.fg2, fontSize: 12)),
            ),
            SwitchListTile(
              value: jb(s.settings, 'bluetooth') && ble != 'unsupported',
              onChanged: ble == 'unsupported' ? null : (bool v) => _setBle(v),
              secondary: Icon(Icons.bluetooth_rounded, color: p.gold),
              title: Text('Bluetooth', style: const TextStyle(fontWeight: FontWeight.w800)),
              subtitle: Text(
                  ble == 'unsupported'
                      ? L.t('Indisponível neste aparelho', 'Unavailable on this device')
                      : (ble == 'off' ? L.t('O Bluetooth do aparelho está desligado', 'The device Bluetooth is off') : L.t('Encontra pessoas mesmo sem Wi-Fi em comum', 'Finds people even without shared Wi-Fi')),
                  style: TextStyle(color: p.fg2, fontSize: 12)),
            ),
            ListTile(
              leading: Icon(Icons.contactless_rounded, color: p.gold),
              title: Text(L.t('NFC (aproximação)', 'NFC (tap)'), style: const TextStyle(fontWeight: FontWeight.w800)),
              subtitle: Text(L.t('Cobrar: abra "Cobrar" e encoste. Pagar: "Aproximar" na carteira.', 'Charge: open "Charge" and tap. Pay: "Tap to pay" in the wallet.'), style: TextStyle(color: p.fg2, fontSize: 12)),
              trailing: Pill(s.nfc == 'on' ? 'ON' : (s.nfc == 'off' ? 'OFF' : '—'), color: s.nfc == 'on' ? p.ok : p.fg3),
              onTap: () => nfcPay(context),
            ),
          ]),
        ),
        SectionTitle(L.t('Pessoas', 'People')),
        if (people.isEmpty)
          EmptyState(icon: Icons.person_search_rounded, title: L.t('Procurando pessoas…', 'Looking for people…'), text: L.t('Peça para a outra pessoa abrir o app e ligar "Ficar visível". Vocês precisam estar no mesmo Wi-Fi/hotspot ou com Bluetooth ligado.', 'Ask the other person to open the app and turn on "Be visible". You need the same Wi-Fi/hotspot or Bluetooth on.'))
        else
          for (final Peer pe in people)
            FadeSlide(
              child: AppCard(
                margin: const EdgeInsets.only(bottom: 10),
                child: Column(children: <Widget>[
                  Row(children: <Widget>[
                    Avatar(pe.name.isEmpty ? '#' : pe.name),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: <Widget>[
                        Text(pe.name.isEmpty ? L.t('Conta ${F.short(pe.uid, 4)}', 'Account ${F.short(pe.uid, 4)}') : pe.name, style: const TextStyle(fontWeight: FontWeight.w900)),
                        Text('${pe.uid} · ${pe.netName.isEmpty ? '?' : pe.netName}', style: TextStyle(color: p.fg2, fontSize: 12, fontFamily: 'monospace')),
                      ]),
                    ),
                    Wrap(spacing: 4, children: <Widget>[for (final String v in pe.via) Pill(v == 'bluetooth' ? 'BT' : (v == 'nsd' ? 'mDNS' : 'Wi-Fi'), color: p.blue)]),
                  ]),
                  const SizedBox(height: 12),
                  Row(children: <Widget>[
                    Expanded(
                      child: FilledButton.icon(
                        style: FilledButton.styleFrom(backgroundColor: p.pri, foregroundColor: p.prifg),
                        onPressed: () => _pay(pe),
                        icon: const Icon(Icons.send_rounded, size: 18),
                        label: Text(L.t('Pagar', 'Pay')),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(child: OutlinedButton.icon(onPressed: () => _bill(pe), icon: const Icon(Icons.request_quote_rounded, size: 18), label: Text(L.t('Cobrar', 'Charge')))),
                  ]),
                ]),
              ),
            ),
        SectionTitle(L.t('Redes hospedadas por perto', 'Hosted networks nearby')),
        if (hosts.isEmpty)
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 6),
            child: Text(L.t('Nenhuma rede por perto. Quem hospeda uma moeda no app aparece aqui.', 'No networks nearby. Anyone hosting a coin in the app shows up here.'), style: TextStyle(color: p.fg3)),
          )
        else
          for (final Peer pe in hosts)
            AppCard(
              margin: const EdgeInsets.only(bottom: 10),
              child: Row(children: <Widget>[
                Container(width: 44, height: 44, decoration: BoxDecoration(color: p.goldSoft, borderRadius: BorderRadius.circular(14)), child: Icon(jb(pe.host, 'cf') ? Icons.cloud_rounded : Icons.router_rounded, color: p.gold)),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: <Widget>[
                    Text(js(pe.host, 'name', 'Coin'), style: const TextStyle(fontWeight: FontWeight.w900)),
                    Text(js(pe.host, 'url'), maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: p.fg2, fontSize: 12)),
                  ]),
                ),
                FilledButton.tonal(onPressed: () => _connectHost(pe), child: Text(L.t('Conectar', 'Connect'))),
              ]),
            ),
      ]),
    );
  }

  String _serverFor(Peer pe) {
    final Server? sv = pe.net.isEmpty ? null : AppState.I.serverByUrl(pe.net);
    return sv?.id ?? AppState.I.activeId;
  }

  Future<void> _pay(Peer pe) async {
    final String sid = _serverFor(pe);
    if (AppState.I.sessionOf(sid) == null) {
      toast(L.t('Essa pessoa está em outra rede (${pe.netName}). Entre nela para pagar.', 'This person is on another network (${pe.netName}). Sign in there to pay.'), error: true);
      return;
    }
    await openSend(context, server: sid, toId: pe.uid, name: pe.name);
  }

  Future<void> _bill(Peer pe) async {
    final String sid = _serverFor(pe);
    if (AppState.I.sessionOf(sid) == null) {
      toast(L.t('Essa pessoa está em outra rede (${pe.netName}).', 'This person is on another network (${pe.netName}).'), error: true);
      return;
    }
    await openCreateBill(context, server: sid, payerId: pe.uid, peer: pe);
  }
}
