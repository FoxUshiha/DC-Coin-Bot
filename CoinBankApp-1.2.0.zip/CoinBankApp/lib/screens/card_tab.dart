import 'package:flutter/material.dart';

import '../core/i18n.dart';
import '../core/state.dart';
import '../ui/common.dart';
import '../ui/flows.dart';
import '../ui/theme.dart';
import 'about_screen.dart';
import 'wallet_tab.dart';

/// Aba Cartão: cartão black (mostrar / copiar / resetar), aproximação e como usar o código do cartão.
class CardTab extends StatelessWidget {
  const CardTab({super.key});

  @override
  Widget build(BuildContext context) {
    return Watch(builder: (BuildContext context) {
      final Pal p = Pal.of(context);
      final AppState s = AppState.I;
      final String base = s.active.url;
      Widget tip(IconData ic, String title, String text) => Padding(
            padding: const EdgeInsets.symmetric(vertical: 7),
            child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: <Widget>[
              Container(width: 36, height: 36, decoration: BoxDecoration(color: p.goldSoft, borderRadius: BorderRadius.circular(11)), child: Icon(ic, color: p.gold, size: 19)),
              const SizedBox(width: 12),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: <Widget>[
                  Text(title, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 14)),
                  const SizedBox(height: 2),
                  Text(text, style: TextStyle(color: p.fg2, fontSize: 12.5, height: 1.35)),
                ]),
              ),
            ]),
          );
      final String sample = 'POST $base/api/transfer/card\n{ "cardCode": "…", "toId": "<ID>", "amount": "0.00000012" }';
      return RefreshIndicator(
        color: p.gold,
        onRefresh: () => s.refreshAll(),
        child: ListView(padding: const EdgeInsets.fromLTRB(16, 8, 16, 90), children: <Widget>[
          const FadeSlide(child: BlackCard()),
          const SizedBox(height: 16),
          FadeSlide(
            delay: 60,
            child: AppCard(
              onTap: () => nfcPay(context),
              child: Row(children: <Widget>[
                Container(width: 46, height: 46, decoration: BoxDecoration(color: p.goldSoft, borderRadius: BorderRadius.circular(14)), child: Icon(Icons.contactless_rounded, color: p.gold)),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: <Widget>[
                    Text(L.t('Pagar por aproximação', 'Tap to pay'), style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 15.5)),
                    Text(L.t('Encoste no celular de quem está cobrando (NFC)', 'Hold near the phone that is charging you (NFC)'), style: TextStyle(color: p.fg2, fontSize: 12.5)),
                  ]),
                ),
                Icon(Icons.chevron_right_rounded, color: p.fg3),
              ]),
            ),
          ),
          SectionTitle(L.t('Como o cartão funciona', 'How the card works')),
          FadeSlide(
            delay: 100,
            child: AppCard(
              child: Column(children: <Widget>[
                tip(Icons.key_rounded, L.t('Código = chave de pagamento', 'Code = payment key'),
                    L.t('O código do cartão autoriza pagamentos pela API (bots, plugins, sites). Não é um cartão bancário — nenhum dinheiro real é usado.',
                        'The card code authorizes payments through the API (bots, plugins, websites). It is not a bank card — no real money is involved.')),
                tip(Icons.visibility_off_rounded, L.t('Mantenha em segredo', 'Keep it secret'),
                    L.t('Quem tiver o código pode gastar seus coins. Nunca publique em repositórios ou no front-end de sites.', 'Anyone with the code can spend your coins. Never publish it in repositories or website front-ends.')),
                tip(Icons.autorenew_rounded, L.t('Vazou? Resete', 'Leaked? Reset it'),
                    L.t('O botão Resetar gera um código novo na hora e o antigo para de funcionar. Seu saldo não muda.', 'Reset generates a new code instantly and the old one stops working. Your balance does not change.')),
              ]),
            ),
          ),
          SectionTitle(L.t('Usar na API', 'Use it in the API'), action: L.t('Documentação', 'Docs'), onAction: () => openLocalDoc('/terms/documentation.html', L.t('Documentação da API', 'API documentation'))),
          FadeSlide(
            delay: 140,
            child: AppCard(
              onTap: () => copyText(sample, L.t('Exemplo', 'Example')),
              color: p.card2,
              child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: <Widget>[
                Expanded(child: Text(sample, style: TextStyle(fontFamily: 'monospace', fontSize: 12, color: p.fg, height: 1.45))),
                const SizedBox(width: 8),
                Icon(Icons.copy_rounded, size: 16, color: p.fg3),
              ]),
            ),
          ),
        ]),
      );
    });
  }
}
