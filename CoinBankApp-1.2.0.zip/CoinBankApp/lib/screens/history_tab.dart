import 'package:flutter/material.dart';

import '../core/fmt.dart';
import '../core/i18n.dart';
import '../core/models.dart';
import '../core/state.dart';
import '../ui/chart.dart';
import '../ui/common.dart';
import '../ui/flows.dart';
import '../ui/theme.dart';

/// Aba Histórico: gráfico do saldo e a lista de transferências (com filtro e carregamento contínuo).
class HistoryTab extends StatefulWidget {
  const HistoryTab({super.key});

  @override
  State<HistoryTab> createState() => _HistoryTabState();
}

class _HistoryTabState extends State<HistoryTab> {
  String _range = '30d';
  String _filter = 'all';

  Duration? get _dur => _range == '7d' ? const Duration(days: 7) : (_range == '30d' ? const Duration(days: 30) : null);

  bool _match(Tx t, String me) {
    switch (_filter) {
      case 'in':
        return !t.isClaim && t.incoming(me);
      case 'out':
        return !t.isClaim && !t.incoming(me);
      case 'claim':
        return t.isClaim;
    }
    return true;
  }

  @override
  Widget build(BuildContext context) {
    return Watch(builder: (BuildContext context) {
    final Pal p = Pal.of(context);
    final AppState s = AppState.I;
    final String me = s.userId;
    final List<Tx> list = s.txs.where((Tx t) => _match(t, me)).toList();
    int inSum = 0, outSum = 0;
    final DateTime? from = _dur == null ? null : DateTime.now().subtract(_dur!);
    for (final Tx t in s.txs) {
      if (from != null && t.date.isBefore(from)) continue;
      if (t.incoming(me)) {
        inSum += t.sats;
      } else if (t.from == me) {
        outSum += t.sats;
      }
    }
    final List<Widget> rows = <Widget>[];
    String lastDay = '';
    for (int i = 0; i < list.length; i++) {
      final Tx t = list[i];
      final String d = F.dayLabel(t.date);
      if (d != lastDay) {
        rows.add(Padding(padding: const EdgeInsets.fromLTRB(10, 12, 10, 4), child: Text(d, style: TextStyle(color: p.fg3, fontWeight: FontWeight.w800, fontSize: 12.5))));
        lastDay = d;
      }
      rows.add(TxTile(tx: t, me: me, onTap: () => openReceipt(context, server: s.activeId, tx: t)));
    }
    return NotificationListener<ScrollNotification>(
      onNotification: (ScrollNotification n) {
        if (n.metrics.pixels > n.metrics.maxScrollExtent - 300) s.loadMoreTx();
        return false;
      },
      child: RefreshIndicator(
        color: p.gold,
        onRefresh: () => s.refreshAll(),
        child: ListView(padding: const EdgeInsets.fromLTRB(16, 6, 16, 90), children: <Widget>[
          FadeSlide(
            child: AppCard(
              padding: const EdgeInsets.fromLTRB(16, 14, 16, 12),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: <Widget>[
                Row(children: <Widget>[
                  Expanded(child: Text(L.t('Evolução do saldo', 'Balance over time'), style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16))),
                  SegmentedButton<String>(
                    showSelectedIcon: false,
                    style: SegmentedButton.styleFrom(visualDensity: VisualDensity.compact, selectedBackgroundColor: p.goldSoft, selectedForegroundColor: p.gold),
                    segments: <ButtonSegment<String>>[
                      const ButtonSegment<String>(value: '7d', label: Text('7d')),
                      const ButtonSegment<String>(value: '30d', label: Text('30d')),
                      ButtonSegment<String>(value: 'all', label: Text(L.t('Tudo', 'All'))),
                    ],
                    selected: <String>{_range},
                    onSelectionChanged: (Set<String> v) => setState(() => _range = v.first),
                  ),
                ]),
                const SizedBox(height: 12),
                if (s.canShowMoney)
                  BalanceChart(points: balanceSeries(s.txs, s.balance ?? 0, me, range: _dur))
                else
                  SizedBox(height: 170, child: Center(child: Text(L.t('Sem conexão — gráfico indisponível', 'Offline — chart unavailable'), style: TextStyle(color: p.fg3)))),
                const SizedBox(height: 10),
                Row(children: <Widget>[
                  Expanded(child: _Stat(label: L.t('Entradas', 'In'), sats: inSum, color: p.ok, icon: Icons.south_west_rounded)),
                  const SizedBox(width: 10),
                  Expanded(child: _Stat(label: L.t('Saídas', 'Out'), sats: outSum, color: p.bad, icon: Icons.north_east_rounded)),
                ]),
              ]),
            ),
          ),
          const SizedBox(height: 10),
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(children: <Widget>[
              for (final MapEntry<String, String> e in <String, String>{
                'all': L.t('Todas', 'All'),
                'in': L.t('Recebidas', 'Received'),
                'out': L.t('Enviadas', 'Sent'),
                'claim': L.t('Resgates', 'Claims'),
              }.entries)
                Padding(
                  padding: const EdgeInsets.only(right: 8),
                  child: ChoiceChip(label: Text(e.value), selected: _filter == e.key, onSelected: (bool _) => setState(() => _filter = e.key)),
                ),
            ]),
          ),
          const SizedBox(height: 6),
          if (rows.isEmpty)
            EmptyState(icon: Icons.history_rounded, title: L.t('Nada por aqui', 'Nothing here'), text: s.canShowMoney ? null : L.t('O extrato aparece quando a conexão voltar.', 'The statement appears when the connection is back.'))
          else
            AppCard(padding: const EdgeInsets.all(6), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: rows)),
          if (s.txLoading) const Padding(padding: EdgeInsets.all(16), child: Center(child: CircularProgressIndicator())),
          if (!s.txMore && s.txs.isNotEmpty)
            Padding(padding: const EdgeInsets.all(14), child: Center(child: Text(L.t('Fim do extrato', 'End of statement'), style: TextStyle(color: p.fg3, fontSize: 12)))),
        ]),
      ),
    );
  });
  }
}

class _Stat extends StatelessWidget {
  const _Stat({required this.label, required this.sats, required this.color, required this.icon});
  final String label;
  final int sats;
  final Color color;
  final IconData icon;

  @override
  Widget build(BuildContext context) {
    final Pal p = Pal.of(context);
    return Container(
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(color: p.card2, borderRadius: BorderRadius.circular(14)),
      child: Row(children: <Widget>[
        Icon(icon, color: color, size: 18),
        const SizedBox(width: 8),
        Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: <Widget>[
            Text(label, style: TextStyle(color: p.fg2, fontSize: 11.5)),
            FittedBox(fit: BoxFit.scaleDown, alignment: Alignment.centerLeft, child: Text(F.coins(sats), style: TextStyle(color: color, fontWeight: FontWeight.w900))),
          ]),
        ),
      ]),
    );
  }
}
