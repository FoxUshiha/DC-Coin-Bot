import 'dart:async';

import 'package:flutter/material.dart';

import '../core/fmt.dart';
import '../core/i18n.dart';
import '../core/native.dart';
import '../core/state.dart';
import '../ui/chart.dart';
import '../ui/common.dart';
import '../ui/theme.dart';

/// Medições da rede ativa (ping + estatísticas públicas), compartilhadas pelo menu e pela tela de status.
class NetStats {
  NetStats._();
  static int? ping;
  static J stats = <String, dynamic>{};
  static DateTime? at;
  static String forServer = '';

  static Future<void> refresh() async {
    final AppState s = AppState.I;
    final String sid = s.activeId;
    try {
      final J p = await Native.call('ping', <String, dynamic>{'url': s.active.url});
      ping = jb(p, 'ok') ? ji(p, 'ms') : null;
    } catch (_) {
      ping = null;
    }
    try {
      stats = await Native.api(sid, 'GET', '/api/stats', noAuth: true);
    } catch (_) {
      try {
        stats = await Native.api(sid, 'GET', '/api/totalusers', noAuth: true);
      } catch (_) {
        if (forServer != sid) stats = <String, dynamic>{};
      }
    }
    forServer = sid;
    at = DateTime.now();
  }
}

Color pingColor(Pal p, int? ms) => ms == null ? p.bad : (ms < 250 ? p.ok : (ms < 800 ? p.gold : p.bad));

/// item do menu lateral com ping, usuários e transações
class NetworkStatusTile extends StatefulWidget {
  const NetworkStatusTile({super.key, required this.onTap});
  final VoidCallback onTap;

  @override
  State<NetworkStatusTile> createState() => _NetworkStatusTileState();
}

class _NetworkStatusTileState extends State<NetworkStatusTile> {
  @override
  void initState() {
    super.initState();
    NetStats.refresh().then((_) {
      if (mounted) setState(() {});
    });
  }

  @override
  Widget build(BuildContext context) {
    final Pal p = Pal.of(context);
    final int? ms = NetStats.ping;
    final Color c = pingColor(p, ms);
    return AppCard(
      margin: const EdgeInsets.symmetric(horizontal: 6),
      onTap: widget.onTap,
      padding: const EdgeInsets.all(14),
      child: Row(children: <Widget>[
        Container(
          width: 44,
          height: 44,
          decoration: BoxDecoration(color: c.withValues(alpha: 0.14), borderRadius: BorderRadius.circular(14)),
          child: Icon(Icons.network_check_rounded, color: c),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: <Widget>[
            Text(L.t('Status da rede', 'Network status'), style: const TextStyle(fontWeight: FontWeight.w900)),
            const SizedBox(height: 2),
            Text(
              ms == null ? L.t('verificando…', 'checking…') : '${ms}ms · ${F.integer(ji(NetStats.stats, 'totalUsers'))} ${L.t('usuários', 'users')} · ${F.integer(ji(NetStats.stats, 'totalTransactions'))} tx',
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(color: p.fg2, fontSize: 12),
            ),
          ]),
        ),
        Icon(Icons.chevron_right_rounded, color: p.fg3),
      ]),
    );
  }
}

class NetworkScreen extends StatefulWidget {
  const NetworkScreen({super.key});

  @override
  State<NetworkScreen> createState() => _NetworkScreenState();
}

class _NetworkScreenState extends State<NetworkScreen> {
  List<J> _days = <J>[];
  Timer? _t;
  bool _busy = false;
  final List<int> _pings = <int>[];

  @override
  void initState() {
    super.initState();
    _refresh();
    _t = Timer.periodic(const Duration(seconds: 5), (_) => _refresh());
  }

  @override
  void dispose() {
    _t?.cancel();
    super.dispose();
  }

  Future<void> _refresh() async {
    if (_busy) return;
    _busy = true;
    await NetStats.refresh();
    final int? ms = NetStats.ping;
    if (ms != null) {
      _pings.add(ms);
      if (_pings.length > 20) _pings.removeAt(0);
    }
    try {
      final J h = await Native.api(AppState.I.activeId, 'GET', '/api/stats/history?days=14', noAuth: true);
      _days = jl(h, 'days');
    } catch (_) {}
    _busy = false;
    if (mounted) setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    final Pal p = Pal.of(context);
    final AppState s = AppState.I;
    final J st = NetStats.stats;
    final int? ms = NetStats.ping;
    final Color c = pingColor(p, ms);
    Widget tile(IconData ic, String label, String value) => AppCard(
          padding: const EdgeInsets.all(14),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: <Widget>[
            Icon(ic, color: p.gold, size: 22),
            const SizedBox(height: 10),
            FittedBox(fit: BoxFit.scaleDown, alignment: Alignment.centerLeft, child: Text(value, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900))),
            Text(label, style: TextStyle(color: p.fg2, fontSize: 12)),
          ]),
        );
    return Scaffold(
      appBar: AppBar(title: Text(L.t('Status da rede', 'Network status')), actions: <Widget>[IconButton(onPressed: _refresh, icon: const Icon(Icons.refresh_rounded))]),
      body: ListView(padding: const EdgeInsets.fromLTRB(16, 4, 16, 30), children: <Widget>[
        FadeSlide(
          child: AppCard(
            child: Row(children: <Widget>[
              TweenAnimationBuilder<double>(
                tween: Tween<double>(begin: 0, end: ms == null ? 0.0 : (1 - (ms / 1000)).clamp(0.08, 1.0)),
                duration: const Duration(milliseconds: 600),
                builder: (BuildContext c2, double v, Widget? _) => SizedBox(
                  width: 74,
                  height: 74,
                  child: Stack(alignment: Alignment.center, children: <Widget>[
                    SizedBox(width: 74, height: 74, child: CircularProgressIndicator(value: v, strokeWidth: 7, color: c, backgroundColor: p.card2)),
                    Column(mainAxisSize: MainAxisSize.min, children: <Widget>[
                      Text(ms == null ? '—' : '$ms', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 18, color: c)),
                      Text('ms', style: TextStyle(color: p.fg3, fontSize: 11)),
                    ]),
                  ]),
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: <Widget>[
                  Text(s.active.name, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
                  Text(s.active.url, style: TextStyle(color: p.fg2, fontSize: 12.5)),
                  const SizedBox(height: 6),
                  Pill(ms == null ? L.t('Fora do ar', 'Offline') : (ms < 250 ? L.t('Excelente', 'Excellent') : (ms < 800 ? L.t('Boa', 'Good') : L.t('Lenta', 'Slow'))), color: c, icon: Icons.circle),
                ]),
              ),
            ]),
          ),
        ),
        const SizedBox(height: 12),
        GridView.count(
          crossAxisCount: 2,
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          mainAxisSpacing: 10,
          crossAxisSpacing: 10,
          childAspectRatio: 1.55,
          children: <Widget>[
            tile(Icons.groups_rounded, L.t('Usuários', 'Users'), F.integer(ji(st, 'totalUsers'))),
            tile(Icons.swap_horiz_rounded, L.t('Transações', 'Transactions'), F.integer(ji(st, 'totalTransactions'))),
            tile(Icons.bolt_rounded, L.t('Transações 24 h', 'Transactions 24h'), F.integer(ji(st, 'transactions24h'))),
            tile(Icons.toll_rounded, L.t('Coins em circulação', 'Coins in circulation'), st.containsKey('totalSats') || st.containsKey('totalCoins') ? F.coins(F.satsOf(st, 'totalSats', 'totalCoins')) : '—'),
            tile(Icons.redeem_rounded, L.t('Resgate', 'Claim'), st.containsKey('claimAmount') ? '${F.coins(F.satsOf(st, 'claimAmountSats', 'claimAmount'))}' : '—'),
            tile(Icons.request_quote_rounded, L.t('Cobranças abertas', 'Open bills'), F.integer(ji(st, 'openBills'))),
          ],
        ),
        if (_days.isNotEmpty) ...<Widget>[
          SectionTitle(L.t('Transações por dia (14 dias)', 'Transactions per day (14 days)')),
          AppCard(
            child: BarsChart(
              values: _days.map((J d) => ji(d, 'transactions').toDouble()).toList(),
              labels: _days.map((J d) {
                final DateTime? x = F.parseDate(js(d, 'date'));
                return x == null ? '' : F.shortDay(x);
              }).toList(),
            ),
          ),
        ],
        if (_pings.length > 1) ...<Widget>[
          SectionTitle(L.t('Ping (últimas medições)', 'Ping (latest samples)')),
          AppCard(child: BarsChart(values: _pings.map((int e) => e.toDouble()).toList(), labels: _pings.map((int e) => '$e').toList(), height: 90)),
        ],
        const SizedBox(height: 10),
        Center(child: Text(NetStats.at == null ? '' : L.t('Atualizado às ${F.time(NetStats.at!)} · a cada 5 s', 'Updated at ${F.time(NetStats.at!)} · every 5 s'), style: TextStyle(color: p.fg3, fontSize: 12))),
      ]),
    );
  }
}
