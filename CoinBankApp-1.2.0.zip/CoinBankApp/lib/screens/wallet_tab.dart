import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../core/fmt.dart';
import '../core/i18n.dart';
import '../core/models.dart';
import '../core/native.dart';
import '../core/state.dart';
import '../ui/common.dart';
import '../ui/flows.dart';
import '../ui/theme.dart';
import 'nearby_screen.dart';

/// Aba Carteira: saldo, pagar/receber, ações rápidas, pessoas por perto e últimas transações (o cartão fica na aba Cartão).
class WalletTab extends StatelessWidget {
  const WalletTab({super.key, required this.onOpenTab});
  final ValueChanged<int> onOpenTab;

  @override
  Widget build(BuildContext context) {
    return Watch(builder: (BuildContext context) {
    final Pal p = Pal.of(context);
    final AppState s = AppState.I;
    final List<Tx> recent = s.txs.take(4).toList();
    return RefreshIndicator(
      color: p.gold,
      onRefresh: () => s.refreshAll(),
      child: ListView(padding: const EdgeInsets.fromLTRB(16, 6, 16, 90), children: <Widget>[
        const FadeSlide(child: BalanceCard()),
        const SizedBox(height: 16),
        FadeSlide(
          delay: 60,
          child: Row(children: <Widget>[
            Expanded(child: _BigAction(icon: Icons.qr_code_scanner_rounded, title: L.t('Pagar', 'Pay'), sub: L.t('escanear QR', 'scan a QR'), onTap: () => scanToPay(context), primary: true)),
            const SizedBox(width: 12),
            Expanded(child: _BigAction(icon: Icons.qr_code_2_rounded, title: L.t('Receber', 'Receive'), sub: L.t('QR ou aproximação', 'QR or tap'), onTap: () => openCharge(context))),
          ]),
        ),
        const SizedBox(height: 12),
        FadeSlide(
          delay: 140,
          child: AppCard(
            padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 4),
            child: Row(children: <Widget>[
              Expanded(child: _Small(icon: Icons.send_rounded, label: L.t('Enviar', 'Send'), onTap: () => openSend(context))),
              Expanded(child: _Small(icon: Icons.contactless_rounded, label: L.t('Aproximar', 'Tap to pay'), onTap: () => nfcPay(context))),
              Expanded(child: _Small(icon: Icons.request_quote_rounded, label: L.t('Gerar conta', 'New bill'), onTap: () => openCreateBill(context))),
              Expanded(child: _Small(icon: Icons.receipt_long_rounded, label: L.t('Pagar conta', 'Pay bill'), onTap: () => payBillById(context))),
            ]),
          ),
        ),
        const SizedBox(height: 12),
        FadeSlide(
          delay: 180,
          child: AppCard(
            onTap: () => Navigator.of(context).push(MaterialPageRoute<void>(builder: (BuildContext c) => const NearbyScreen())),
            child: Row(children: <Widget>[
              Container(width: 46, height: 46, decoration: BoxDecoration(color: p.goldSoft, borderRadius: BorderRadius.circular(14)), child: Icon(Icons.wifi_tethering_rounded, color: p.gold)),
              const SizedBox(width: 12),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: <Widget>[
                  Text(L.t('Pessoas próximas', 'People nearby'), style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 15.5)),
                  Text(jb(s.settings, 'visible') ? L.t('Você está visível · pague e cobre quem está perto', 'You are visible · pay and charge people nearby') : L.t('Pague e cobre por Wi-Fi, Bluetooth ou NFC', 'Pay and charge via Wi-Fi, Bluetooth or NFC'),
                      style: TextStyle(color: p.fg2, fontSize: 12.5)),
                ]),
              ),
              Icon(Icons.chevron_right_rounded, color: p.fg3),
            ]),
          ),
        ),
        SectionTitle(L.t('Últimas transações', 'Recent transactions'), action: L.t('Ver tudo', 'See all'), onAction: () => onOpenTab(2)),
        if (!s.canShowMoney && recent.isEmpty)
          EmptyState(icon: Icons.cloud_off_rounded, title: L.t('Sem dados agora', 'No data right now'), text: L.t('Os saldos e o extrato aparecem quando a conexão com a rede voltar.', 'Balances and statement appear when the network connection is back.'))
        else if (recent.isEmpty)
          EmptyState(icon: Icons.receipt_long_rounded, title: L.t('Nenhuma transação ainda', 'No transactions yet'), text: L.t('Toque no presente 🎁 lá em cima para resgatar seus primeiros coins.', 'Tap the gift 🎁 at the top to claim your first coins.'))
        else
          AppCard(
            padding: const EdgeInsets.all(6),
            child: Column(children: <Widget>[
              for (int i = 0; i < recent.length; i++)
                FadeSlide(delay: 30 * i, child: TxTile(tx: recent[i], me: s.userId, onTap: () => openReceipt(context, server: s.activeId, tx: recent[i]))),
            ]),
          ),
      ]),
    );
  });
  }
}

class BalanceCard extends StatelessWidget {
  const BalanceCard({super.key});

  @override
  Widget build(BuildContext context) {
    return Watch(builder: (BuildContext context) {
    final Pal p = Pal.of(context);
    final AppState s = AppState.I;
    final bool hide = s.hideBalance;
    final int? bal = s.canShowMoney ? s.balance : null;
    return AppCard(
      padding: const EdgeInsets.fromLTRB(20, 18, 12, 18),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: <Widget>[
        Row(children: <Widget>[
          Text(L.t('Saldo disponível', 'Available balance'), style: TextStyle(color: p.fg2, fontWeight: FontWeight.w700)),
          const Spacer(),
          IconButton(
            visualDensity: VisualDensity.compact,
            tooltip: hide ? L.t('Mostrar', 'Show') : L.t('Ocultar', 'Hide'),
            onPressed: () => s.setSettings(<String, dynamic>{'hideBalance': !hide}),
            icon: Icon(hide ? Icons.visibility_off_rounded : Icons.visibility_rounded, color: p.fg3, size: 20),
          ),
        ]),
        AnimatedSwitcher(
          duration: const Duration(milliseconds: 350),
          transitionBuilder: (Widget ch, Animation<double> a) => FadeTransition(opacity: a, child: SizeTransition(sizeFactor: a, axisAlignment: -1, child: ch)),
          child: bal == null
              ? Text('— — —', key: const ValueKey<String>('none'), style: TextStyle(fontSize: 34, fontWeight: FontWeight.w900, color: p.fg3))
              : hide
                  ? Text('••••••', key: const ValueKey<String>('hid'), style: TextStyle(fontSize: 34, fontWeight: FontWeight.w900, color: p.fg))
                  : TweenAnimationBuilder<double>(
                      key: const ValueKey<String>('bal'),
                      tween: Tween<double>(begin: bal.toDouble(), end: bal.toDouble()),
                      duration: const Duration(milliseconds: 600),
                      builder: (BuildContext c, double v, Widget? _) => FittedBox(fit: BoxFit.scaleDown, alignment: Alignment.centerLeft, child: CoinText(v.round(), size: 36, weight: FontWeight.w900)),
                    ),
        ),
        const SizedBox(height: 6),
        TickBuilder(
          builder: (BuildContext c) => Text(
            !s.online
                ? L.t('Sem internet', 'Offline')
                : (s.lastSync == null ? L.t('Atualizando…', 'Updating…') : L.t('Atualizado ${F.ago(s.lastSync!)} · ${s.active.name}', 'Updated ${F.ago(s.lastSync!)} · ${s.active.name}')),
            style: TextStyle(color: p.fg3, fontSize: 12),
          ),
        ),
        const SizedBox(height: 12),
        Wrap(spacing: 8, runSpacing: 8, crossAxisAlignment: WrapCrossAlignment.center, children: <Widget>[
          // formato do saldo (igual ao site): 8 casas · 2 casas · inteiro
          Container(
            padding: const EdgeInsets.all(3),
            decoration: BoxDecoration(color: p.card2, borderRadius: BorderRadius.circular(99), border: Border.all(color: p.line)),
            child: Row(mainAxisSize: MainAxisSize.min, children: <Widget>[
              for (final MapEntry<int, String> e in <int, String>{8: '0,00000000', 2: '0,00', 0: L.t('Inteiro', 'Integer')}.entries)
                GestureDetector(
                  onTap: () => s.setNetCfg(s.activeId, <String, dynamic>{'disp': e.key}),
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 200),
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                    decoration: BoxDecoration(color: s.decimals == e.key ? p.card : Colors.transparent, borderRadius: BorderRadius.circular(99), boxShadow: s.decimals == e.key ? const <BoxShadow>[BoxShadow(color: Color(0x1A000000), blurRadius: 4, offset: Offset(0, 1))] : null),
                    child: Text(L.pt ? e.value : e.value.replaceAll(',', '.'), style: TextStyle(fontSize: 11.5, fontWeight: FontWeight.w700, color: s.decimals == e.key ? p.fg : p.fg3)),
                  ),
                ),
            ]),
          ),
          GestureDetector(
            onTap: () => copyText(s.userId, 'ID'),
            child: Container(
              padding: const EdgeInsets.fromLTRB(11, 6, 9, 6),
              decoration: BoxDecoration(color: p.card2, borderRadius: BorderRadius.circular(99), border: Border.all(color: p.line)),
              child: Row(mainAxisSize: MainAxisSize.min, children: <Widget>[
                Text('ID ${s.userId}', style: TextStyle(fontFamily: 'monospace', fontSize: 11.5, color: p.fg2, fontWeight: FontWeight.w600)),
                const SizedBox(width: 6),
                Icon(Icons.copy_rounded, size: 13, color: p.fg3),
              ]),
            ),
          ),
        ]),
      ]),
    );
  });
  }
}

/// cartão black igual ao do site: código oculto por padrão, mostrar / copiar / resetar (com confirmação)
class BlackCard extends StatefulWidget {
  const BlackCard({super.key, this.compact = false});
  final bool compact;

  @override
  State<BlackCard> createState() => _BlackCardState();
}

class _BlackCardState extends State<BlackCard> with SingleTickerProviderStateMixin {
  late bool _hidden = AppState.I.hideCardDefault;
  late final AnimationController _flip = AnimationController(vsync: this, duration: const Duration(milliseconds: 520));

  @override
  void dispose() {
    _flip.dispose();
    super.dispose();
  }

  Future<void> _reset() async {
    final bool ok = await confirm(context,
        icon: Icons.autorenew_rounded,
        danger: true,
        title: L.t('Resetar código do cartão?', 'Reset card code?'),
        text: L.t('O código atual para de funcionar na hora (plugins, sites e apps que o usam precisarão do novo). Seu saldo não muda.',
            'The current code stops working right away (plugins, sites and apps using it will need the new one). Your balance does not change.'),
        ok: L.t('Resetar', 'Reset'));
    if (!ok) return;
    try {
      await AppState.I.resetCard();
      _flip.reset();
      unawaited(_flip.forward());
      if (mounted) setState(() => _hidden = false);
      toast(L.t('Novo código gerado', 'New code generated'), ok: true);
    } catch (e) {
      toast(errText(e), error: true);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Watch(builder: (BuildContext context) {
      final Pal p = Pal.of(context);
      final AppState s = AppState.I;
      final String code = s.cardCode ?? '';
      final String shown = code.isEmpty ? '•••• •••• •••• ••••' : (_hidden ? '•••• •••• •••• ${code.length >= 4 ? code.substring(code.length - 4).toUpperCase() : '••••'}' : _group(code));
      final Widget card = AnimatedBuilder(
        animation: _flip,
        builder: (BuildContext c, Widget? child) {
          final double t = _flip.isAnimating ? _flip.value : 0;
          return Transform(
            alignment: Alignment.center,
            transform: Matrix4.identity()
              ..setEntry(3, 2, 0.0012)
              ..rotateY(math.sin(t * math.pi) * 0.9),
            child: child,
          );
        },
        child: AspectRatio(
          aspectRatio: 1.586,
          child: Container(
            clipBehavior: Clip.antiAlias,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(22),
              gradient: const RadialGradient(center: Alignment.topLeft, radius: 1.5, colors: <Color>[Color(0xFF2B2D31), Color(0xFF141518), Color(0xFF070708)], stops: <double>[0, 0.42, 1]),
              border: Border.all(color: const Color(0x0FFFFFFF)),
              boxShadow: const <BoxShadow>[BoxShadow(color: Color(0x66000000), blurRadius: 34, spreadRadius: -8, offset: Offset(0, 18))],
            ),
            child: CustomPaint(
              painter: _CardTexture(),
              child: Padding(
                padding: EdgeInsets.fromLTRB(widget.compact ? 18 : 22, widget.compact ? 16 : 20, widget.compact ? 18 : 22, widget.compact ? 14 : 18),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: <Widget>[
                  Row(crossAxisAlignment: CrossAxisAlignment.start, children: <Widget>[
                    Image.asset('assets/wallet.png', width: 28, height: 28, filterQuality: FilterQuality.none),
                    const SizedBox(width: 8),
                    const Text('COIN', style: TextStyle(color: Color(0xFFE9E9EA), fontSize: 15, letterSpacing: 3, fontWeight: FontWeight.w800)),
                    const Spacer(),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 3),
                      decoration: BoxDecoration(borderRadius: BorderRadius.circular(99), border: Border.all(color: const Color(0x29FFFFFF))),
                      child: const Text('BLACK', style: TextStyle(color: Color(0xFFB9B9BB), fontSize: 10.5, letterSpacing: 3.5, fontWeight: FontWeight.w700)),
                    ),
                  ]),
                  const Spacer(),
                  Row(children: <Widget>[
                    const _Chip(),
                    const SizedBox(width: 12),
                    Icon(Icons.contactless_outlined, color: const Color(0xFFBDBDC0).withValues(alpha: 0.85), size: 26),
                  ]),
                  const Spacer(),
                  AnimatedSwitcher(
                    duration: const Duration(milliseconds: 220),
                    child: FittedBox(
                      key: ValueKey<String>(shown),
                      fit: BoxFit.scaleDown,
                      alignment: Alignment.centerLeft,
                      child: Text(shown,
                          style: TextStyle(
                              color: const Color(0xFFF3F3F4),
                              fontSize: widget.compact ? 17 : 20,
                              fontFamily: 'monospace',
                              fontWeight: FontWeight.w600,
                              letterSpacing: 2.2,
                              shadows: const <Shadow>[Shadow(color: Color(0x99000000), offset: Offset(0, 1))])),
                    ),
                  ),
                  const SizedBox(height: 10),
                  Row(crossAxisAlignment: CrossAxisAlignment.end, children: <Widget>[
                    Expanded(
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: <Widget>[
                        Text(L.t('TITULAR', 'CARD HOLDER'), style: const TextStyle(color: Color(0xFF8D8D91), fontSize: 9, letterSpacing: 1.6, fontWeight: FontWeight.w700)),
                        Text(s.username.toUpperCase(), maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Color(0xFFE9E9EA), fontSize: 13, letterSpacing: 1.2, fontWeight: FontWeight.w700)),
                        const SizedBox(height: 4),
                        const Text('ID', style: TextStyle(color: Color(0xFF8D8D91), fontSize: 9, letterSpacing: 1.6, fontWeight: FontWeight.w700)),
                        Text(s.userId, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Color(0xFFE9E9EA), fontSize: 12, fontFamily: 'monospace', fontWeight: FontWeight.w600)),
                      ]),
                    ),
                    SizedBox(
                      width: 46,
                      height: 28,
                      child: Stack(children: const <Widget>[
                        Positioned(left: 0, child: CircleAvatar(radius: 14, backgroundColor: Color(0xFF3A3A3D))),
                        Positioned(left: 17, child: Opacity(opacity: 0.9, child: CircleAvatar(radius: 14, backgroundColor: Color(0xFF6C6C70)))),
                      ]),
                    ),
                  ]),
                ]),
              ),
            ),
          ),
        ),
      );
      return Column(children: <Widget>[
        card,
        const SizedBox(height: 12),
        Row(children: <Widget>[
          Expanded(child: _CardBtn(icon: _hidden ? Icons.visibility_rounded : Icons.visibility_off_rounded, label: _hidden ? L.t('Mostrar', 'Show') : L.t('Ocultar', 'Hide'), onTap: () => setState(() => _hidden = !_hidden))),
          const SizedBox(width: 8),
          Expanded(child: _CardBtn(icon: Icons.copy_rounded, label: L.t('Copiar', 'Copy'), onTap: code.isEmpty ? null : () => copyText(code, L.t('Código do cartão', 'Card code')))),
          const SizedBox(width: 8),
          Expanded(child: _CardBtn(icon: Icons.autorenew_rounded, label: L.t('Resetar', 'Reset'), onTap: _reset, color: p.bad)),
        ]),
      ]);
    });
  }

  static String _group(String c) {
    final StringBuffer b = StringBuffer();
    for (int i = 0; i < c.length; i++) {
      if (i > 0 && i % 4 == 0) b.write(' ');
      b.write(c[i]);
    }
    return b.toString().toUpperCase();
  }
}

/// chip dourado do cartão
class _Chip extends StatelessWidget {
  const _Chip();

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 46,
      height: 35,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(8),
        gradient: const LinearGradient(colors: <Color>[Color(0xFFE9CF86), Color(0xFFB8923E), Color(0xFFF1DC9C), Color(0xFFA47F30)], stops: <double>[0, 0.45, 0.6, 1], begin: Alignment.topLeft, end: Alignment.bottomRight),
        border: Border.all(color: const Color(0x40000000)),
      ),
      child: CustomPaint(painter: _ChipLines()),
    );
  }
}

class _ChipLines extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final Paint p = Paint()
      ..color = const Color(0x7346320A)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.3;
    canvas.drawRRect(RRect.fromRectAndRadius(Rect.fromLTRB(10, 6, size.width - 10, size.height - 6), const Radius.circular(4)), p);
    canvas.drawLine(Offset(0, size.height / 2), Offset(size.width, size.height / 2), p);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

/// textura diagonal discreta (igual ao ::before do cartão no site)
class _CardTexture extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final Paint p = Paint()
      ..color = const Color(0x06FFFFFF)
      ..strokeWidth = 1;
    for (double x = -size.height; x < size.width; x += 4) {
      canvas.drawLine(Offset(x, size.height), Offset(x + size.height, 0), p);
    }
    final Paint shine = Paint()
      ..shader = const LinearGradient(colors: <Color>[Color(0x00FFFFFF), Color(0x10FFFFFF), Color(0x00FFFFFF)], stops: <double>[0.35, 0.5, 0.65], begin: Alignment.topLeft, end: Alignment.bottomRight)
          .createShader(Offset.zero & size);
    canvas.drawRect(Offset.zero & size, shine);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class _CardBtn extends StatelessWidget {
  const _CardBtn({required this.icon, required this.label, required this.onTap, this.color});
  final IconData icon;
  final String label;
  final VoidCallback? onTap;
  final Color? color;

  @override
  Widget build(BuildContext context) {
    final Pal p = Pal.of(context);
    final Color c = onTap == null ? p.fg3 : (color ?? p.fg);
    return Material(
      color: p.card,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12), side: BorderSide(color: p.line)),
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 11),
          child: Row(mainAxisAlignment: MainAxisAlignment.center, children: <Widget>[
            Icon(icon, size: 17, color: c),
            const SizedBox(width: 6),
            Flexible(child: Text(label, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontWeight: FontWeight.w700, fontSize: 13, color: c))),
          ]),
        ),
      ),
    );
  }
}

class _BigAction extends StatelessWidget {
  const _BigAction({required this.icon, required this.title, required this.sub, required this.onTap, this.primary = false});
  final IconData icon;
  final String title;
  final String sub;
  final VoidCallback onTap;
  final bool primary;

  @override
  Widget build(BuildContext context) {
    final Pal p = Pal.of(context);
    final Color fg = primary ? p.prifg : p.fg;
    return AppCard(
      color: primary ? p.pri : p.card,
      onTap: onTap,
      padding: const EdgeInsets.fromLTRB(16, 16, 12, 16),
      child: Row(children: <Widget>[
        Icon(icon, color: primary ? fg : p.gold, size: 32),
        const SizedBox(width: 10),
        Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: <Widget>[
            Text(title, style: TextStyle(fontWeight: FontWeight.w900, fontSize: 16, color: fg)),
            Text(sub, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 12, color: primary ? fg.withValues(alpha: 0.8) : p.fg2)),
          ]),
        ),
      ]),
    );
  }
}

class _Small extends StatelessWidget {
  const _Small({required this.icon, required this.label, required this.onTap});
  final IconData icon;
  final String label;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final Pal p = Pal.of(context);
    return InkWell(
      borderRadius: BorderRadius.circular(14),
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 8),
        child: Column(children: <Widget>[
          Container(width: 46, height: 46, decoration: BoxDecoration(color: p.goldSoft, borderRadius: BorderRadius.circular(15)), child: Icon(icon, color: p.gold)),
          const SizedBox(height: 6),
          Text(label, textAlign: TextAlign.center, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 11.5, fontWeight: FontWeight.w700, color: p.fg2)),
        ]),
      ),
    );
  }
}
