import 'package:flutter/material.dart';

import '../core/docs.dart';
import '../core/i18n.dart';
import '../core/native.dart';
import '../core/state.dart';
import '../ui/common.dart';
import '../ui/theme.dart';

/// abre os documentos do site embutidos no APK (funcionam offline, no tema e idioma do app)
Future<void> openLocalDoc(String path, String title) => Native.call('browser', <String, dynamic>{'url': 'https://docs.coinbank.local$path', 'title': title});

const String kDonationBtc = 'bc1qg4pfxutjmtd76cheygzcg4ee5vwvvsp0jsyn6n';

/// Sobre: versão, termos/privacidade/documentação embutidos (offline), links e doação em Bitcoin.
class AboutScreen extends StatelessWidget {
  const AboutScreen({super.key});

  void _open(BuildContext context, Doc d) => Navigator.of(context).push(MaterialPageRoute<void>(builder: (BuildContext c) => DocScreen(doc: d)));

  @override
  Widget build(BuildContext context) {
    final Pal p = Pal.of(context);
    final AppState s = AppState.I;
    Widget link(IconData ic, String title, String sub, VoidCallback onTap) => ListTile(
          leading: Icon(ic, color: p.gold),
          title: Text(title, style: const TextStyle(fontWeight: FontWeight.w800)),
          subtitle: Text(sub, style: TextStyle(color: p.fg2, fontSize: 12)),
          trailing: Icon(Icons.chevron_right_rounded, color: p.fg3),
          onTap: onTap,
        );
    return Scaffold(
      appBar: AppBar(title: Text(L.t('Sobre o app', 'About the app'))),
      body: ListView(padding: const EdgeInsets.fromLTRB(16, 4, 16, 34), children: <Widget>[
        FadeSlide(
          child: Column(children: <Widget>[
            const SizedBox(height: 8),
            ClipRRect(borderRadius: BorderRadius.circular(26), child: Image.asset('assets/icon.png', width: 96, height: 96)),
            const SizedBox(height: 12),
            const Text('Coin Bank', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w900)),
            Text('${L.t('Versão', 'Version')} ${s.version.isEmpty ? '1.0.0' : s.version}', style: TextStyle(color: p.fg2)),
            const SizedBox(height: 10),
            Text(
              L.t('Carteira da moeda virtual Coin: envie, cobre por QR ou aproximação, pague contas, veja comprovantes e hospede sua própria rede. Coins não têm valor real — nenhum dinheiro ou cartão real é usado.',
                  'Wallet for the Coin virtual currency: send, charge by QR or tap, pay bills, see receipts and host your own network. Coins have no real value — no real money or cards are involved.'),
              textAlign: TextAlign.center,
              style: TextStyle(color: p.fg2, height: 1.4),
            ),
          ]),
        ),
        SectionTitle(L.t('Documentos (offline)', 'Documents (offline)')),
        AppCard(
          padding: const EdgeInsets.symmetric(vertical: 4),
          child: Column(children: <Widget>[
            link(Icons.lightbulb_outline_rounded, L.t('Como funciona', 'How it works'), L.t('Guia rápido do app', 'Quick app guide'), () => _open(context, Docs.howItWorks())),
            link(Icons.gavel_rounded, L.t('Termos de Uso', 'Terms of Use'), L.t('Regras do serviço · embutido no app', 'Service rules · built into the app'), () => openLocalDoc('/terms/', L.t('Termos de Uso', 'Terms of Use'))),
            link(Icons.privacy_tip_outlined, L.t('Privacidade', 'Privacy'), L.t('O que é guardado e como é protegido', 'What is stored and how it is protected'), () => openLocalDoc('/terms/privacy.html', L.t('Privacidade', 'Privacy'))),
            link(Icons.code_rounded, L.t('Documentação da API', 'API documentation'), L.t('Endpoints para desenvolvedores', 'Endpoints for developers'), () => openLocalDoc('/terms/documentation.html', L.t('Documentação da API', 'API documentation'))),
          ]),
        ),
        SectionTitle(L.t('Online', 'Online')),
        AppCard(
          padding: const EdgeInsets.symmetric(vertical: 4),
          child: Column(children: <Widget>[
            link(Icons.public_rounded, L.t('Termos do servidor atual', 'Current server terms'), '${s.active.url}/terms/', () => Native.call('browser', <String, dynamic>{'url': '${s.active.url}/terms/', 'title': L.t('Termos', 'Terms')})),
            link(Icons.language_rounded, L.t('Site da rede', 'Network website'), s.active.url, () => Native.call('browser', <String, dynamic>{'url': s.active.url, 'title': s.active.name})),
            link(Icons.forum_rounded, L.t('Servidor de suporte (Discord)', 'Support server (Discord)'), 'discord.gg/C5cAfhcdRp', () => Native.call('open', <String, dynamic>{'url': 'https://discord.gg/C5cAfhcdRp'})),
            link(Icons.description_outlined, L.t('Licenças de código aberto', 'Open-source licenses'), 'Flutter · ZXing (Apache 2.0) · cloudflared (Apache 2.0)',
                () => showLicensePage(context: context, applicationName: 'Coin Bank', applicationVersion: s.version, applicationIcon: Padding(padding: const EdgeInsets.all(8), child: Image.asset('assets/icon.png', width: 56)))),
          ]),
        ),
        SectionTitle(L.t('Apoie o projeto', 'Support the project')),
        AppCard(
          color: p.goldSoft,
          child: Column(children: <Widget>[
            Icon(Icons.favorite_rounded, color: p.gold, size: 30),
            const SizedBox(height: 8),
            Text(
              L.t('O Coin Bank é gratuito e sem anúncios. Se ele te diverte, considere uma doação em Bitcoin para ajudar a manter os servidores e o desenvolvimento do projeto. Qualquer valor ajuda — obrigado! 🧡',
                  'Coin Bank is free and ad-free. If you enjoy it, please consider a Bitcoin donation to help keep the servers and the project\'s development going. Any amount helps — thank you! 🧡'),
              textAlign: TextAlign.center,
              style: TextStyle(color: p.fg, height: 1.4, fontWeight: FontWeight.w600),
            ),
            const SizedBox(height: 14),
            const QrView('bitcoin:$kDonationBtc', size: 170),
            const SizedBox(height: 12),
            SelectableText(kDonationBtc, textAlign: TextAlign.center, style: TextStyle(fontFamily: 'monospace', fontWeight: FontWeight.w700, color: p.fg, fontSize: 13)),
            const SizedBox(height: 10),
            Row(children: <Widget>[
              Expanded(
                child: FilledButton.icon(
                  style: FilledButton.styleFrom(backgroundColor: p.pri, foregroundColor: p.prifg),
                  onPressed: () => copyText(kDonationBtc, L.t('Endereço Bitcoin', 'Bitcoin address')),
                  icon: const Icon(Icons.copy_rounded, size: 18),
                  label: Text(L.t('Copiar endereço', 'Copy address')),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: () => Native.call('open', <String, dynamic>{'url': 'bitcoin:$kDonationBtc'}).catchError((Object e) {
                    toast(errText(e), error: true);
                    return <String, dynamic>{};
                  }),
                  icon: const Icon(Icons.currency_bitcoin_rounded, size: 18),
                  label: Text(L.t('Abrir carteira', 'Open wallet')),
                ),
              ),
            ]),
          ]),
        ),
        const SizedBox(height: 18),
        Center(child: Text('© 2026 FoxSrv · Coin Bank', style: TextStyle(color: p.fg3, fontSize: 12))),
      ]),
    );
  }
}

/// leitor de documento embutido (segue idioma e tema do app, sem internet)
class DocScreen extends StatelessWidget {
  const DocScreen({super.key, required this.doc});
  final Doc doc;

  @override
  Widget build(BuildContext context) {
    final Pal p = Pal.of(context);
    return Scaffold(
      appBar: AppBar(title: Text(doc.title)),
      body: ListView(padding: const EdgeInsets.fromLTRB(18, 4, 18, 34), children: <Widget>[
        Text(doc.title, style: TextStyle(fontSize: 26, fontWeight: FontWeight.w900, color: p.fg, letterSpacing: -0.4)),
        const SizedBox(height: 4),
        Text(doc.updated, style: TextStyle(color: p.fg3)),
        const SizedBox(height: 12),
        for (final DocBlock b in doc.blocks) _block(p, b),
      ]),
    );
  }

  Widget _block(Pal p, DocBlock b) {
    switch (b.kind) {
      case 'h':
        return Padding(padding: const EdgeInsets.only(top: 18, bottom: 6), child: Text(b.text, style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900, color: p.fg)));
      case 'note':
        return Container(
          margin: const EdgeInsets.symmetric(vertical: 8),
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(color: p.goldSoft, borderRadius: BorderRadius.circular(14), border: Border.all(color: p.gold.withValues(alpha: 0.35))),
          child: Text(b.text, style: TextStyle(color: p.fg, height: 1.45, fontWeight: FontWeight.w600)),
        );
      case 'code':
        return Container(
          width: double.infinity,
          margin: const EdgeInsets.symmetric(vertical: 6),
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(color: p.card2, borderRadius: BorderRadius.circular(12), border: Border.all(color: p.line)),
          child: SingleChildScrollView(scrollDirection: Axis.horizontal, child: SelectableText(b.text, style: TextStyle(fontFamily: 'monospace', fontSize: 12.5, color: p.fg, height: 1.5))),
        );
      case 'list':
        return Column(crossAxisAlignment: CrossAxisAlignment.start, children: <Widget>[
          for (final String it in b.items)
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 4),
              child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: <Widget>[
                Padding(padding: const EdgeInsets.only(top: 7, right: 10), child: Container(width: 6, height: 6, decoration: BoxDecoration(color: p.gold, shape: BoxShape.circle))),
                Expanded(child: Text(it, style: TextStyle(color: p.fg2, height: 1.45))),
              ]),
            ),
        ]);
      default:
        return Padding(padding: const EdgeInsets.symmetric(vertical: 4), child: Text(b.text, style: TextStyle(color: p.fg2, height: 1.5, fontSize: 15)));
    }
  }
}
