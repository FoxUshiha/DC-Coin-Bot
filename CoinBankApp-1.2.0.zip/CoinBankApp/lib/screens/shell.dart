import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../core/fmt.dart';
import '../core/i18n.dart';
import '../core/models.dart';
import '../core/native.dart';
import '../core/state.dart';
import '../ui/claim.dart';
import '../ui/common.dart';
import '../ui/flows.dart';
import '../ui/netcfg.dart';
import '../ui/theme.dart';
import 'about_screen.dart';
import 'account_screen.dart';
import 'bills_tab.dart';
import 'card_tab.dart';
import 'history_tab.dart';
import 'host_screen.dart';
import 'login_screen.dart';
import 'nearby_screen.dart';
import 'network_screen.dart';
import 'settings_screen.dart';
import 'wallet_tab.dart';

/// Tela principal: Carteira · Cartão · Histórico · Contas, menu lateral, presente (resgate) e escanear.
class Shell extends StatefulWidget {
  const Shell({super.key});

  @override
  State<Shell> createState() => _ShellState();
}

class _ShellState extends State<Shell> {
  int _tab = 0;
  StreamSubscription<J>? _msgSub;
  Notice? _notice;
  Timer? _noticeTimer;

  @override
  void initState() {
    super.initState();
    final AppState s = AppState.I;
    s.routeRequest.addListener(_onRoute);
    s.notice.addListener(_onNotice);
    _msgSub = s.nearbyMessages.stream.listen(_onNearbyMessage);
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final String? r = s.pendingRoute;
      if (r != null) {
        s.pendingRoute = null;
        _handleRoute(r);
      }
      _askNotificationsOnce();
    });
  }

  @override
  void dispose() {
    final AppState s = AppState.I;
    s.routeRequest.removeListener(_onRoute);
    s.notice.removeListener(_onNotice);
    _msgSub?.cancel();
    _noticeTimer?.cancel();
    super.dispose();
  }

  Future<void> _askNotificationsOnce() async {
    final AppState s = AppState.I;
    if (jb(s.settings, 'onboarded')) return;
    await s.setSettings(<String, dynamic>{'onboarded': true});
    try {
      await Native.call('perm', <String, dynamic>{'kind': 'notifications'});
    } catch (_) {}
  }

  void _onRoute() {
    final String? r = AppState.I.routeRequest.value;
    if (r == null) return;
    AppState.I.routeRequest.value = null;
    AppState.I.pendingRoute = null;
    _handleRoute(r);
  }

  Future<void> _handleRoute(String r) async {
    final BuildContext ctx = context;
    if (r == 'bills') {
      setState(() => _tab = 3);
      return;
    }
    // rotas das notificações: "tx:<id>@<rede>" e "bill:<id>@<rede>" (sem @ = rede principal)
    String rid(String x) => x.contains('@') ? x.substring(0, x.lastIndexOf('@')) : x;
    String rnet(String x) {
      final String n = x.contains('@') ? x.substring(x.lastIndexOf('@') + 1) : 'main';
      return AppState.I.serverById(n) != null ? n : 'main';
    }
    if (r.startsWith('tx:')) {
      final String x = r.substring(3);
      await openReceipt(ctx, server: rnet(x), txId: rid(x));
      return;
    }
    if (r.startsWith('bill:')) {
      final String x = r.substring(5);
      final String net = rnet(x);
      if (net == AppState.I.activeId) setState(() => _tab = 3);
      try {
        final J b = await Native.api(net, 'GET', '/api/bill/${rid(x)}', noAuth: true);
        final BuildContext? c = navKey.currentContext;
        if (c != null && c.mounted) await openBill(c, server: net, bill: Bill.fromJson(jm(b, 'bill')));
      } catch (e) {
        toast(errText(e), error: true);
      }
      return;
    }
    if (r.startsWith('pay:')) {
      await handleScanned(ctx, r.substring(4));
    }
  }

  void _onNotice() {
    final Notice? n = AppState.I.notice.value;
    if (n == null) return;
    HapticFeedback.lightImpact();
    setState(() => _notice = n);
    _noticeTimer?.cancel();
    _noticeTimer = Timer(const Duration(seconds: 5), () {
      if (mounted) setState(() => _notice = null);
    });
  }

  Future<void> _onNearbyMessage(J e) async {
    final J m = jm(e, 'msg');
    final J from = jm(m, 'fromMe');
    final String who = js(from, 'name').isNotEmpty ? js(from, 'name') : L.t('Alguém por perto', 'Someone nearby');
    final int sats = F.parseApi(js(m, 'amount')) ?? 0;
    final String kind = js(m, 'kind');
    final BuildContext? c = navKey.currentContext;
    if (c == null || !c.mounted) return;
    HapticFeedback.heavyImpact();
    final bool open = await confirm(c,
        icon: Icons.wifi_tethering_rounded,
        title: kind == 'bill' ? L.t('$who te enviou uma cobrança', '$who sent you a bill') : L.t('$who está cobrando você', '$who is charging you'),
        text: L.t('${sats > 0 ? '${F.coins(sats)} coins' : 'Valor livre'} na rede ${js(m, 'netName', 'Coin')}. Abrir para conferir e pagar?',
            '${sats > 0 ? '${F.coins(sats)} coins' : 'Any amount'} on ${js(m, 'netName', 'Coin')}. Open to review and pay?'),
        ok: L.t('Abrir', 'Open'));
    if (!open) return;
    final BuildContext? c2 = navKey.currentContext;
    if (c2 == null || !c2.mounted) return;
    if (kind == 'bill') {
      Server? sv = AppState.I.serverByUrl(js(m, 'net'));
      if (sv == null && js(m, 'net').isNotEmpty) {
        // cobrança de uma rede que ainda não está no app (ex.: rede hospedada no celular de quem cobra)
        try {
          final J a = await Native.call('servers.add', <String, dynamic>{'url': js(m, 'net'), 'name': js(m, 'netName')});
          await AppState.I.reloadState();
          sv = AppState.I.serverById(js(jm(a, 'server'), 'id'));
        } catch (_) {}
      }
      final String sid = sv?.id ?? AppState.I.activeId;
      try {
        final J b = await Native.api(sid, 'GET', '/api/bill/${js(m, 'billId')}', noAuth: true);
        final BuildContext? c3 = navKey.currentContext;
        if (c3 != null && c3.mounted) await openBill(c3, server: sid, bill: Bill.fromJson(jm(b, 'bill')));
      } catch (err) {
        toast(errText(err), error: true);
      }
    } else {
      await handleScanned(c2, js(m, 'url'));
    }
  }

  void _push(Widget page) {
    Navigator.of(context).push(MaterialPageRoute<void>(builder: (BuildContext c) => page));
  }

  @override
  Widget build(BuildContext context) {
    final Pal p = Pal.of(context);
    return ListenableBuilder(
      listenable: AppState.I,
      builder: (BuildContext c, Widget? _) {
        final AppState s = AppState.I;
        return Scaffold(
          appBar: AppBar(
            titleSpacing: 0,
            title: InkWell(
              borderRadius: BorderRadius.circular(12),
              onTap: () => pickNetwork(context),
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 4),
                child: Row(mainAxisSize: MainAxisSize.min, children: <Widget>[
                  NetIcon(s.activeId, size: 30),
                  const SizedBox(width: 10),
                  Flexible(
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: <Widget>[
                      Text(s.active.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 17, fontWeight: FontWeight.w900, color: p.fg)),
                      Row(mainAxisSize: MainAxisSize.min, children: <Widget>[
                        Container(width: 7, height: 7, decoration: BoxDecoration(shape: BoxShape.circle, color: s.online && s.reachable ? p.ok : p.bad)),
                        const SizedBox(width: 5),
                        Text(s.online ? (s.reachable ? s.active.host : L.t('rede fora do ar', 'network down')) : L.t('sem internet', 'offline'),
                            style: TextStyle(fontSize: 11.5, color: p.fg2, fontWeight: FontWeight.w600)),
                      ]),
                    ]),
                  ),
                  Icon(Icons.expand_more_rounded, color: p.fg3, size: 18),
                ]),
              ),
            ),
            actions: <Widget>[
              TickBuilder(
                builder: (BuildContext c) => IconButton(
                  tooltip: L.t('Resgate', 'Claim'),
                  onPressed: () => openClaim(context),
                  icon: Badge(
                    isLabelVisible: s.claimReady && s.canShowMoney,
                    backgroundColor: p.ok,
                    smallSize: 9,
                    child: Icon(Icons.card_giftcard_rounded, color: s.claimReady && s.canShowMoney ? p.gold : p.fg),
                  ),
                ),
              ),
              IconButton(tooltip: L.t('Escanear', 'Scan'), onPressed: () => scanToPay(context), icon: const Icon(Icons.qr_code_scanner_rounded)),
              const SizedBox(width: 4),
            ],
          ),
          drawer: _drawer(context, s, p),
          body: Stack(children: <Widget>[
            AnimatedSwitcher(
              duration: const Duration(milliseconds: 300),
              transitionBuilder: (Widget ch, Animation<double> a) => FadeTransition(opacity: a, child: ch),
              child: KeyedSubtree(
                key: ValueKey<int>(_tab),
                child: switch (_tab) { 0 => WalletTab(onOpenTab: (int i) => setState(() => _tab = i)), 1 => const CardTab(), 2 => const HistoryTab(), _ => const BillsTab() },
              ),
            ),
            if (!s.online || !s.reachable)
              Positioned(
                left: 12,
                right: 12,
                bottom: 10,
                child: FadeSlide(
                  child: AppCard(
                    color: p.badSoft,
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                    child: Row(children: <Widget>[
                      Icon(s.online ? Icons.cloud_off_rounded : Icons.wifi_off_rounded, color: p.bad, size: 20),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Text(s.online ? L.t('Não foi possível falar com a rede. Tentando de novo…', 'Could not reach the network. Retrying…') : L.t('Sem internet — saldos ocultos até reconectar.', 'Offline — balances hidden until reconnected.'),
                            style: TextStyle(color: p.bad, fontWeight: FontWeight.w700, fontSize: 13)),
                      ),
                    ]),
                  ),
                ),
              ),
            AnimatedPositioned(
              duration: const Duration(milliseconds: 380),
              curve: Curves.easeOutBack,
              left: 12,
              right: 12,
              top: _notice == null ? -140 : 8,
              child: _notice == null ? const SizedBox.shrink() : _banner(p, _notice!),
            ),
          ]),
          bottomNavigationBar: NavigationBar(
            selectedIndex: _tab,
            onDestinationSelected: (int i) => setState(() => _tab = i),
            destinations: <Widget>[
              NavigationDestination(icon: const Icon(Icons.account_balance_wallet_outlined), selectedIcon: const Icon(Icons.account_balance_wallet_rounded), label: L.t('Carteira', 'Wallet')),
              NavigationDestination(icon: const Icon(Icons.credit_card_outlined), selectedIcon: const Icon(Icons.credit_card_rounded), label: L.t('Cartão', 'Card')),
              NavigationDestination(icon: const Icon(Icons.show_chart_rounded), selectedIcon: const Icon(Icons.insights_rounded), label: L.t('Histórico', 'History')),
              NavigationDestination(
                icon: Badge(isLabelVisible: s.toPay.isNotEmpty, label: Text('${s.toPay.length}'), child: const Icon(Icons.receipt_long_outlined)),
                selectedIcon: const Icon(Icons.receipt_long_rounded),
                label: L.t('Contas', 'Bills'),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _banner(Pal p, Notice n) {
    return GestureDetector(
      onTap: () {
        setState(() => _notice = null);
        final String? r = n.route;
        if (r != null && r.isNotEmpty) _handleRoute(r);
      },
      child: Material(
        elevation: 8,
        shadowColor: Colors.black38,
        color: p.card,
        borderRadius: BorderRadius.circular(18),
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Row(children: <Widget>[
            Container(
              width: 42,
              height: 42,
              decoration: BoxDecoration(color: n.kind == 'bill' ? p.goldSoft : p.okSoft, borderRadius: BorderRadius.circular(13)),
              child: Icon(n.kind == 'bill' ? Icons.request_quote_rounded : (n.kind == 'outgoing' ? Icons.north_east_rounded : Icons.south_west_rounded), color: n.kind == 'bill' ? p.gold : (n.kind == 'outgoing' ? p.fg2 : p.ok)),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: <Widget>[
                Text(n.title, style: TextStyle(fontWeight: FontWeight.w900, color: p.fg)),
                Text(n.text, maxLines: 2, overflow: TextOverflow.ellipsis, style: TextStyle(color: p.fg2, fontSize: 12.5)),
              ]),
            ),
          ]),
        ),
      ),
    );
  }

  Widget _drawer(BuildContext context, AppState s, Pal p) {
    Widget item(IconData ic, String label, VoidCallback onTap, {String? sub, Color? color}) => ListTile(
          leading: Icon(ic, color: color ?? p.fg2),
          title: Text(label, style: TextStyle(fontWeight: FontWeight.w700, color: color ?? p.fg)),
          subtitle: sub == null ? null : Text(sub, style: TextStyle(color: p.fg3, fontSize: 12)),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
          onTap: () {
            Navigator.of(context).pop();
            onTap();
          },
        );
    return Drawer(
      child: SafeArea(
        child: ListView(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8), children: <Widget>[
          AppCard(
            margin: const EdgeInsets.all(6),
            onTap: () {
              Navigator.of(context).pop();
              _push(const AccountScreen());
            },
            child: Row(children: <Widget>[
              Avatar(s.username, size: 50),
              const SizedBox(width: 12),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: <Widget>[
                  Text(s.username.isEmpty ? L.t('Minha conta', 'My account') : s.username, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 17), maxLines: 1, overflow: TextOverflow.ellipsis),
                  GestureDetector(onTap: () => copyText(s.userId, 'ID'), child: Text('ID ${s.userId}', style: TextStyle(color: p.fg2, fontFamily: 'monospace', fontSize: 12.5))),
                  const SizedBox(height: 4),
                  Pill(s.active.name, icon: s.active.isMain ? Icons.public_rounded : Icons.hub_rounded),
                ]),
              ),
            ]),
          ),
          const SizedBox(height: 6),
          // status da rede (ping, usuários, transações)
          NetworkStatusTile(onTap: () {
            Navigator.of(context).pop();
            _push(const NetworkScreen());
          }),
          const Divider(height: 18),
          item(Icons.person_outline_rounded, L.t('Conta', 'Account'), () => _push(const AccountScreen())),
          item(Icons.wifi_tethering_rounded, L.t('Por perto', 'Nearby'), () => _push(const NearbyScreen()), sub: L.t('Pagar e cobrar quem está perto', 'Pay and charge people nearby')),
          item(Icons.dns_rounded, L.t('Hospedar', 'Host'), () => _push(const HostScreen()), sub: L.t('Servidores e sua própria moeda', 'Servers and your own coin')),
          item(Icons.settings_outlined, L.t('Configurações', 'Settings'), () => _push(const SettingsScreen())),
          item(Icons.info_outline_rounded, L.t('Sobre', 'About'), () => _push(const AboutScreen())),
          const Divider(height: 18),
          item(Icons.logout_rounded, L.t('Sair', 'Sign out'), () async {
            final bool ok = await confirm(context, title: L.t('Sair da conta?', 'Sign out?'), text: L.t('Você sai da rede ${s.active.name} neste aparelho.', 'You will sign out of ${s.active.name} on this device.'), ok: L.t('Sair', 'Sign out'), danger: true);
            if (ok) await s.logout();
          }, color: p.bad),
          Padding(
            padding: const EdgeInsets.all(16),
            child: Text('Coin Bank ${s.version}', textAlign: TextAlign.center, style: TextStyle(color: p.fg3, fontSize: 12)),
          ),
        ]),
      ),
    );
  }
}
