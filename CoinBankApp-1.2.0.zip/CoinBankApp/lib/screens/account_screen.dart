import 'package:flutter/material.dart';

import '../core/fmt.dart';
import '../core/i18n.dart';
import '../core/native.dart';
import '../core/state.dart';
import '../ui/common.dart';
import '../ui/flows.dart';
import '../ui/theme.dart';
import 'wallet_tab.dart';

/// Conta: dados, cartão, códigos de backup (modal + baixar), restaurar, conta salva (digital), senha, sair, excluir login.
class AccountScreen extends StatelessWidget {
  const AccountScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Watch(builder: (BuildContext context) {
      final Pal p = Pal.of(context);
      final AppState s = AppState.I;
      final DateTime? created = F.parseDate(s.me['createdAt']);
      final bool saved = s.hasSavedAccount();
      return Scaffold(
        appBar: AppBar(title: Text(L.t('Minha conta', 'My account'))),
        body: ListView(padding: const EdgeInsets.fromLTRB(16, 4, 16, 30), children: <Widget>[
          FadeSlide(
            child: AppCard(
              child: Column(children: <Widget>[
                Avatar(s.username, size: 72),
                const SizedBox(height: 10),
                Text(s.username, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
                const SizedBox(height: 4),
                Pill(s.active.name, icon: Icons.public_rounded),
                const SizedBox(height: 10),
                InfoRow(L.t('ID da conta', 'Account ID'), s.userId, mono: true, copy: true),
                if (s.canShowMoney) InfoRow(L.t('Saldo', 'Balance'), '${F.coins(s.balance ?? 0)} coins'),
                if (s.me['totalTransactions'] != null) InfoRow(L.t('Transações', 'Transactions'), F.integer(ji(s.me, 'totalTransactions'))),
                if (s.me['rank'] != null) InfoRow(L.t('Posição no ranking', 'Rank position'), '#${js(s.me, 'rank')}'),
                if (created != null) InfoRow(L.t('Membro desde', 'Member since'), F.date(created)),
                InfoRow(L.t('Rede', 'Network'), s.active.host),
              ]),
            ),
          ),
          SectionTitle(L.t('Cartão', 'Card')),
          const BlackCard(),
          const SizedBox(height: 6),
          Text(L.t('O código do cartão permite pagar pela API (plugins, sites). Não compartilhe.', 'The card code allows API payments (plugins, sites). Do not share it.'), style: TextStyle(color: p.fg3, fontSize: 12)),
          SectionTitle(L.t('Segurança', 'Security')),
          AppCard(
            padding: const EdgeInsets.symmetric(vertical: 6),
            child: Column(children: <Widget>[
              ListTile(
                leading: Icon(Icons.key_rounded, color: p.gold),
                title: Text(L.t('Códigos de backup', 'Backup codes'), style: const TextStyle(fontWeight: FontWeight.w800)),
                subtitle: Text(L.t('Recuperam o saldo desta carteira em outra conta', 'Recover this wallet\'s balance into another account'), style: TextStyle(color: p.fg2, fontSize: 12)),
                trailing: Icon(Icons.chevron_right_rounded, color: p.fg3),
                onTap: () => showDialog<void>(context: context, builder: (BuildContext c) => const BackupDialog()),
              ),
              ListTile(
                leading: Icon(Icons.settings_backup_restore_rounded, color: p.gold),
                title: Text(L.t('Restaurar um backup', 'Restore a backup'), style: const TextStyle(fontWeight: FontWeight.w800)),
                subtitle: Text(L.t('Traz o saldo de outra carteira para esta', 'Brings another wallet\'s balance into this one'), style: TextStyle(color: p.fg2, fontSize: 12)),
                onTap: () => _restore(context),
              ),
              ListTile(
                leading: Icon(Icons.fingerprint_rounded, color: p.gold),
                title: Text(saved ? L.t('Conta salva com digital', 'Account saved with fingerprint') : L.t('Salvar conta e entrar com digital', 'Save account and use fingerprint'), style: const TextStyle(fontWeight: FontWeight.w800)),
                subtitle: Text(saved ? L.t('Entra sem senha e renova a sessão sozinho', 'Signs in without password and renews the session') : L.t('A senha fica cifrada no Android Keystore', 'The password is encrypted in the Android Keystore'),
                    style: TextStyle(color: p.fg2, fontSize: 12)),
                trailing: saved ? Icon(Icons.check_circle_rounded, color: p.ok) : null,
                onTap: saved ? null : () => _save(context),
              ),
              ListTile(
                leading: Icon(Icons.password_rounded, color: p.gold),
                title: Text(L.t('Trocar senha / usuário', 'Change password / username'), style: const TextStyle(fontWeight: FontWeight.w800)),
                onTap: () => showSheet<void>(context, (BuildContext c) => const _ChangeSheet()),
              ),
            ]),
          ),
          const SizedBox(height: 16),
          OutlinedButton.icon(
            onPressed: () async {
              final bool ok = await confirm(context, title: L.t('Sair da conta?', 'Sign out?'), text: L.t('Você sai desta rede neste aparelho.', 'You sign out of this network on this device.'), ok: L.t('Sair', 'Sign out'));
              if (!ok) return;
              await s.logout();
              if (context.mounted) Navigator.of(context).popUntil((Route<dynamic> r) => r.isFirst);
            },
            icon: const Icon(Icons.logout_rounded),
            label: Text(L.t('Sair', 'Sign out')),
          ),
          const SizedBox(height: 8),
          TextButton.icon(
            onPressed: () => _unregister(context),
            icon: Icon(Icons.delete_forever_rounded, color: p.bad),
            label: Text(L.t('Excluir login do site/app', 'Delete website/app login'), style: TextStyle(color: p.bad)),
          ),
        ]),
      );
    });
  }

  Future<void> _restore(BuildContext context) async {
    final String? code = await askText(context, title: L.t('Restaurar backup', 'Restore backup'), hint: L.t('Código de backup', 'Backup code'), ok: L.t('Restaurar', 'Restore'));
    if (code == null || code.trim().isEmpty) return;
    try {
      final J r = await AppState.I.api('POST', '/api/backup/restore', <String, dynamic>{'backupId': code.trim()});
      await AppState.I.refreshAll();
      toast(L.t('Restaurado: ${F.coins(F.satsOf(r, 'amountSats', 'amount'))} coins', 'Restored: ${F.coins(F.satsOf(r, 'amountSats', 'amount'))} coins'), ok: true);
    } catch (e) {
      toast(errText(e), error: true);
    }
  }

  Future<void> _save(BuildContext context) async {
    final String? pw = await askText(context, title: L.t('Confirme sua senha', 'Confirm your password'), hint: L.t('Senha', 'Password'), obscure: true, ok: L.t('Salvar', 'Save'));
    if (pw == null || pw.isEmpty) return;
    try {
      await Native.call('accounts.save', <String, dynamic>{'server': AppState.I.activeId, 'password': pw});
      await AppState.I.reloadState();
      toast(L.t('Conta salva. Na próxima vez, entre com a digital.', 'Account saved. Next time, sign in with your fingerprint.'), ok: true);
    } catch (e) {
      toast(errText(e), error: true);
    }
  }

  Future<void> _unregister(BuildContext context) async {
    final bool ok = await confirm(context,
        danger: true,
        icon: Icons.warning_amber_rounded,
        title: L.t('Excluir login?', 'Delete login?'),
        text: L.t('Seu usuário e senha serão apagados desta rede. O saldo continua na carteira (ID), mas você não conseguirá mais entrar com este usuário. Guarde seus códigos de backup antes.',
            'Your username and password will be erased from this network. The balance stays in the wallet (ID), but you will not be able to sign in with this username. Save your backup codes first.'),
        ok: L.t('Excluir', 'Delete'));
    if (!ok) return;
    try {
      await AppState.I.api('POST', '/api/account/unregister');
      await AppState.I.logout();
      if (context.mounted) Navigator.of(context).popUntil((Route<dynamic> r) => r.isFirst);
    } catch (e) {
      toast(errText(e), error: true);
    }
  }
}

/// modal dos códigos de backup: gerar, copiar e baixar (.txt na pasta Download/CoinBank)
class BackupDialog extends StatefulWidget {
  const BackupDialog({super.key});

  @override
  State<BackupDialog> createState() => _BackupDialogState();
}

class _BackupDialogState extends State<BackupDialog> {
  List<String> _codes = <String>[];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final J r = await AppState.I.api('POST', '/api/backup/list');
      if (mounted) setState(() => _codes = jsl(r, 'backups'));
    } catch (e) {
      toast(errText(e), error: true);
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _create() async {
    await AppState.I.api('POST', '/api/backup/create');
    await _load();
    toast(L.t('Códigos gerados', 'Codes generated'), ok: true);
  }

  String _text() {
    final AppState s = AppState.I;
    return 'Coin Bank — ${L.t('códigos de backup', 'backup codes')}\n${L.t('Rede', 'Network')}: ${s.active.url}\n${L.t('Conta', 'Account')}: ${s.username} (ID ${s.userId})\n${L.t('Gerado em', 'Generated on')}: ${F.dateTime(DateTime.now())}\n\n'
        '${_codes.join('\n')}\n\n${L.t('Cada código move TODO o saldo desta carteira para a conta que o usar. Guarde em local seguro.', 'Each code moves the WHOLE balance of this wallet to the account that uses it. Keep them safe.')}\n';
  }

  Future<void> _download() async {
    final J r = await Native.call('saveText', <String, dynamic>{'name': 'coinbank-backup-${AppState.I.userId}.txt', 'text': _text()});
    toast(L.t('Salvo em ${js(r, 'path')}', 'Saved to ${js(r, 'path')}'), ok: true);
  }

  @override
  Widget build(BuildContext context) {
    final Pal p = Pal.of(context);
    return Dialog(
      insetPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 30),
      child: Padding(
        padding: const EdgeInsets.fromLTRB(20, 18, 20, 16),
        child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: <Widget>[
          Row(children: <Widget>[
            Icon(Icons.key_rounded, color: p.gold),
            const SizedBox(width: 10),
            Expanded(child: Text(L.t('Códigos de backup', 'Backup codes'), style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w900))),
            IconButton(onPressed: () => Navigator.of(context).pop(), icon: const Icon(Icons.close_rounded)),
          ]),
          Text(L.t('Cada código transfere todo o saldo desta carteira para a conta que o usar (Restaurar backup). Guarde-os offline.', 'Each code transfers the whole balance of this wallet to the account that uses it (Restore backup). Keep them offline.'),
              style: TextStyle(color: p.fg2, fontSize: 12.5)),
          const SizedBox(height: 12),
          if (_loading)
            const Padding(padding: EdgeInsets.all(30), child: Center(child: CircularProgressIndicator()))
          else if (_codes.isEmpty)
            Padding(padding: const EdgeInsets.symmetric(vertical: 18), child: Text(L.t('Nenhum código ainda.', 'No codes yet.'), textAlign: TextAlign.center, style: TextStyle(color: p.fg3)))
          else
            ConstrainedBox(
              constraints: const BoxConstraints(maxHeight: 300),
              child: Container(
                decoration: BoxDecoration(color: p.card2, borderRadius: BorderRadius.circular(14)),
                child: ListView.builder(
                  shrinkWrap: true,
                  padding: const EdgeInsets.symmetric(vertical: 6),
                  itemCount: _codes.length,
                  itemBuilder: (BuildContext c, int i) => ListTile(
                    dense: true,
                    leading: Text('${i + 1}'.padLeft(2, '0'), style: TextStyle(color: p.fg3, fontFamily: 'monospace')),
                    title: SelectableText(_codes[i], style: const TextStyle(fontFamily: 'monospace', fontWeight: FontWeight.w700)),
                    trailing: IconButton(icon: const Icon(Icons.copy_rounded, size: 18), onPressed: () => copyText(_codes[i], L.t('Código', 'Code'))),
                  ),
                ),
              ),
            ),
          const SizedBox(height: 14),
          if (_codes.isEmpty)
            BusyButton(label: L.t('Gerar códigos', 'Generate codes'), icon: Icons.add_rounded, onPressed: _create)
          else ...<Widget>[
            BusyButton(label: L.t('Baixar e salvar no aparelho', 'Download and save to device'), icon: Icons.download_rounded, onPressed: _download),
            const SizedBox(height: 8),
            OutlinedButton.icon(onPressed: () => copyText(_text(), L.t('Códigos', 'Codes')), icon: const Icon(Icons.copy_all_rounded), label: Text(L.t('Copiar todos', 'Copy all'))),
          ],
        ]),
      ),
    );
  }
}

class _ChangeSheet extends StatefulWidget {
  const _ChangeSheet();

  @override
  State<_ChangeSheet> createState() => _ChangeSheetState();
}

class _ChangeSheetState extends State<_ChangeSheet> {
  final TextEditingController _user = TextEditingController(text: AppState.I.username);
  final TextEditingController _pass = TextEditingController();

  @override
  void dispose() {
    _user.dispose();
    _pass.dispose();
    super.dispose();
  }

  Future<void> _go() async {
    if (_pass.text.length < 4) throw ApiException('INVALID_PASSWORD', 400, <String, dynamic>{});
    await AppState.I.api('POST', '/api/account/change', <String, dynamic>{'username': _user.text.trim(), 'password': _pass.text});
    toast(L.t('Dados alterados. Entre de novo com a nova senha.', 'Updated. Sign in again with the new password.'), ok: true);
    final NavigatorState nav = Navigator.of(context);
    await AppState.I.logout();
    if (nav.mounted) nav.popUntil((Route<dynamic> r) => r.isFirst);
  }

  @override
  Widget build(BuildContext context) {
    final Pal p = Pal.of(context);
    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(20, 0, 20, 22),
      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: <Widget>[
        sheetTitle(context, Icons.password_rounded, L.t('Trocar senha / usuário', 'Change password / username')),
        TextField(controller: _user, decoration: InputDecoration(labelText: L.t('Usuário', 'Username'), prefixIcon: const Icon(Icons.person_outline_rounded))),
        const SizedBox(height: 12),
        TextField(controller: _pass, obscureText: true, decoration: InputDecoration(labelText: L.t('Nova senha', 'New password'), prefixIcon: const Icon(Icons.lock_outline_rounded))),
        const SizedBox(height: 8),
        Text(L.t('Por segurança, todas as sessões são encerradas.', 'For security, all sessions are ended.'), style: TextStyle(color: p.fg3, fontSize: 12)),
        const SizedBox(height: 16),
        BusyButton(label: L.t('Salvar', 'Save'), icon: Icons.check_rounded, onPressed: _go),
      ]),
    );
  }
}
