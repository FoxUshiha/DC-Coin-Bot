import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_localizations/flutter_localizations.dart';

import 'core/i18n.dart';
import 'core/state.dart';
import 'screens/login_screen.dart';
import 'screens/shell.dart';
import 'ui/common.dart';
import 'ui/theme.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  AppState.I.boot();
  runApp(const CoinBankApp());
}

class CoinBankApp extends StatelessWidget {
  const CoinBankApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: AppState.I,
      builder: (BuildContext c, Widget? child) {
        final AppState s = AppState.I;
        return MaterialApp(
          title: 'Coin Bank',
          debugShowCheckedModeBanner: false,
          navigatorKey: navKey,
          scaffoldMessengerKey: messengerKey,
          theme: buildTheme(Brightness.light),
          darkTheme: buildTheme(Brightness.dark),
          themeMode: s.themeMode,
          themeAnimationDuration: const Duration(milliseconds: 350),
          locale: s.langChoice == 'auto' ? null : Locale(L.lang),
          supportedLocales: const <Locale>[Locale('pt'), Locale('en')],
          localizationsDelegates: const <LocalizationsDelegate<dynamic>>[
            GlobalMaterialLocalizations.delegate,
            GlobalWidgetsLocalizations.delegate,
            GlobalCupertinoLocalizations.delegate,
          ],
          builder: (BuildContext c, Widget? child) => NavBarSpace(child: child ?? const SizedBox.shrink()),
          home: const _Gate(),
        );
      },
    );
  }
}

/// Reserva o espaço da barra de navegação do Android (gestos ou 3 botões): nada fica por baixo dela.
class NavBarSpace extends StatelessWidget {
  const NavBarSpace({super.key, required this.child});
  final Widget child;

  @override
  Widget build(BuildContext context) {
    final MediaQueryData mq = MediaQuery.of(context);
    final ThemeData th = Theme.of(context);
    final bool dark = th.brightness == Brightness.dark;
    final bool keyboard = mq.viewInsets.bottom > 0;
    final double nav = keyboard ? 0 : mq.viewPadding.bottom;
    final Color bar = th.navigationBarTheme.backgroundColor ?? th.colorScheme.surface;
    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: SystemUiOverlayStyle(
        statusBarColor: Colors.transparent,
        statusBarIconBrightness: dark ? Brightness.light : Brightness.dark,
        systemNavigationBarColor: bar,
        systemNavigationBarDividerColor: bar,
        systemNavigationBarIconBrightness: dark ? Brightness.light : Brightness.dark,
        systemNavigationBarContrastEnforced: false,
      ),
      child: ColoredBox(
        color: bar,
        child: Padding(
          padding: EdgeInsets.only(bottom: nav),
          child: MediaQuery(
            data: mq.copyWith(
              size: Size(mq.size.width, mq.size.height - nav),
              padding: mq.padding.copyWith(bottom: 0),
              viewPadding: mq.viewPadding.copyWith(bottom: 0),
            ),
            child: child,
          ),
        ),
      ),
    );
  }
}

class _Gate extends StatelessWidget {
  const _Gate();

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: AppState.I,
      builder: (BuildContext c, Widget? child) {
        final AppState s = AppState.I;
        final Widget page = !s.ready ? const SplashScreen() : (!s.loggedIn ? const LoginScreen() : const Shell());
        return AnimatedSwitcher(
          duration: const Duration(milliseconds: 420),
          switchInCurve: Curves.easeOutCubic,
          transitionBuilder: (Widget ch, Animation<double> a) => FadeTransition(
            opacity: a,
            child: ScaleTransition(scale: Tween<double>(begin: 0.98, end: 1).animate(a), child: ch),
          ),
          child: KeyedSubtree(key: ValueKey<String>(!s.ready ? 'splash' : (!s.loggedIn ? 'login-${s.activeId}' : 'shell-${s.activeId}')), child: page),
        );
      },
    );
  }
}

class SplashScreen extends StatelessWidget {
  const SplashScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final Pal p = Pal.of(context);
    return Scaffold(
      body: Center(
        child: Column(mainAxisSize: MainAxisSize.min, children: <Widget>[
          ClipRRect(borderRadius: BorderRadius.circular(26), child: Image.asset('assets/icon.png', width: 104, height: 104)),
          const SizedBox(height: 22),
          SizedBox(width: 26, height: 26, child: CircularProgressIndicator(strokeWidth: 3, color: p.gold)),
        ]),
      ),
    );
  }
}
