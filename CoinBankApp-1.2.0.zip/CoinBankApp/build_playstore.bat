@echo off
cd /d "%~dp0"
call "%~dp0build.bat" aab
