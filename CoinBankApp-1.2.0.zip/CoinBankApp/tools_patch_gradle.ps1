# Ajusta o projeto Android gerado pelo "flutter create" para compilar com o
# Flutter/AGP instalados (inclusive Android Gradle Plugin 9+).
#  1) minSdk = minimo suportado pelo seu Flutter (flutter.minSdkVersion).
#     O Flutter atual recusa minSdk < 23 e o motor dele exige Android 7.0 (API 24);
#     em Flutter antigo esse valor e 21 (Android 5.0).
#  2) Desliga o "lint vital" do release (so avisos; nao derruba o build), (o leitor de QR vem embutido, ZXing)
#     e extrai as libs nativas (o cloudflared do tunel Cloudflare precisa ser um arquivo executavel).
#  3) gradle.properties: libera 'proguard-android.txt' em plugins antigos (AGP 9+)
#     e desliga a compilacao incremental do Kotlin (evita o erro "this and base files
#     have different roots" quando o projeto fica num drive e o cache do Pub em outro, ex.: E: e C:).
param([string]$Dir)
$ErrorActionPreference = 'Stop'
$utf8 = New-Object System.Text.UTF8Encoding($false)

function Save([string]$f, [string]$t, [string]$o) {
    if ($t -ne $o) { [System.IO.File]::WriteAllText($f, $t, $utf8) }
}

# ---------- app/build.gradle(.kts) ----------
$done = $false
foreach ($n in @('app\build.gradle.kts', 'app\build.gradle')) {
    $f = Join-Path $Dir $n
    if (-not (Test-Path $f)) { continue }
    $t = [System.IO.File]::ReadAllText($f)
    $o = $t
    $nl = "`r`n"
    if ($n.EndsWith('.kts')) {
        $t = [regex]::Replace($t, '(?m)^(\s*)minSdk\s*=\s*[^\r\n]+', '${1}minSdk = flutter.minSdkVersion')
        $t = [regex]::Replace($t, '(?m)^(\s*)minSdkVersion\s*\([^\r\n]*', '${1}minSdk = flutter.minSdkVersion')
        if ($t -notmatch 'coinbank-lint') {
            $t = $t.TrimEnd() + $nl + $nl +
                '// coinbank-lint: lint so como aviso no release' + $nl +
                'android {' + $nl +
                '    lint {' + $nl +
                '        checkReleaseBuilds = false' + $nl +
                '        abortOnError = false' + $nl +
                '    }' + $nl +
                '}' + $nl
        }
        # 2.4.3 gerava um bloco com java.util.Properties, que nao compila em .kts (o "java" do Gradle e a extensao java): troca pelo novo
        if ($t -match 'java\.util\.Properties\(\)') {
            $t = [regex]::Replace($t, '(?s)\r?\n// coinbank-signing:.*?\nif \(!coinKeyProps\.isEmpty\(\)\) \{.*?\n\}[ \t]*(?=\r?\n|$)', '')
        }
        if ($t -notmatch 'coinbank-signing') {
            $t = $t.TrimEnd() + $nl + $nl +
                '// coinbank-signing: assinatura de release (Play Store) com android/key.properties (criado pelo build_playstore.bat).' + $nl +
                '// Sem o arquivo, o release continua assinado com a chave de debug (APK para instalar direto).' + $nl +
                'val coinKeyProps: Map<String, String> = rootProject.file("key.properties").let { f ->' + $nl +
                '    if (!f.exists()) emptyMap() else f.readLines().mapNotNull { line ->' + $nl +
                '        val i = line.indexOf(''='')' + $nl +
                '        if (i <= 0 || line.trimStart().startsWith("#")) null else line.substring(0, i).trim() to line.substring(i + 1).trim()' + $nl +
                '    }.toMap()' + $nl +
                '}' + $nl +
                'if (coinKeyProps.isNotEmpty()) {' + $nl +
                '    android {' + $nl +
                '        signingConfigs {' + $nl +
                '            create("coinRelease") {' + $nl +
                '                keyAlias = coinKeyProps["keyAlias"]' + $nl +
                '                keyPassword = coinKeyProps["keyPassword"]' + $nl +
                '                storeFile = file(coinKeyProps.getValue("storeFile"))' + $nl +
                '                storePassword = coinKeyProps["storePassword"]' + $nl +
                '            }' + $nl +
                '        }' + $nl +
                '        buildTypes {' + $nl +
                '            getByName("release") {' + $nl +
                '                signingConfig = signingConfigs.getByName("coinRelease")' + $nl +
                '            }' + $nl +
                '        }' + $nl +
                '    }' + $nl +
                '}' + $nl
        }
        if ($t -notmatch 'coinbank-jni') {
            $t = $t.TrimEnd() + $nl + $nl +
                '// coinbank-jni: cloudflared (tunel Cloudflare) vai como libcloudflared.so e precisa ser extraido para poder executar' + $nl +
                'android {' + $nl +
                '    packaging {' + $nl +
                '        jniLibs {' + $nl +
                '            useLegacyPackaging = true' + $nl +
                '            keepDebugSymbols.add("**/libcloudflared.so")' + $nl +
                '        }' + $nl +
                '    }' + $nl +
                '}' + $nl
        }
    } else {
        $t = [regex]::Replace($t, '(?m)^(\s*)minSdkVersion\s+[^\r\n]+', '${1}minSdkVersion flutter.minSdkVersion')
        $t = [regex]::Replace($t, '(?m)^(\s*)minSdk\s*=\s*[^\r\n]+', '${1}minSdk = flutter.minSdkVersion')
        if ($t -notmatch 'coinbank-lint') {
            $t = $t.TrimEnd() + $nl + $nl +
                '// coinbank-lint: lint so como aviso no release' + $nl +
                'android {' + $nl +
                '    lint {' + $nl +
                '        checkReleaseBuilds = false' + $nl +
                '        abortOnError = false' + $nl +
                '    }' + $nl +
                '}' + $nl
        }
        if ($t -notmatch 'coinbank-signing') {
            $t = $t.TrimEnd() + $nl + $nl +
                '// coinbank-signing: assinatura de release (Play Store) com android/key.properties (criado pelo build_playstore.bat).' + $nl +
                '// Sem o arquivo, o release continua assinado com a chave de debug (APK para instalar direto).' + $nl +
                'def coinKeyProps = new Properties()' + $nl +
                "def coinKeyFile = rootProject.file('key.properties')" + $nl +
                'if (coinKeyFile.exists()) { coinKeyFile.withInputStream { coinKeyProps.load(it) } }' + $nl +
                'if (!coinKeyProps.isEmpty()) {' + $nl +
                '    android {' + $nl +
                '        signingConfigs {' + $nl +
                '            coinRelease {' + $nl +
                "                keyAlias coinKeyProps.getProperty('keyAlias')" + $nl +
                "                keyPassword coinKeyProps.getProperty('keyPassword')" + $nl +
                "                storeFile file(coinKeyProps.getProperty('storeFile'))" + $nl +
                "                storePassword coinKeyProps.getProperty('storePassword')" + $nl +
                '            }' + $nl +
                '        }' + $nl +
                '        buildTypes {' + $nl +
                '            release {' + $nl +
                '                signingConfig signingConfigs.coinRelease' + $nl +
                '            }' + $nl +
                '        }' + $nl +
                '    }' + $nl +
                '}' + $nl
        }
        if ($t -notmatch 'coinbank-jni') {
            $t = $t.TrimEnd() + $nl + $nl +
                '// coinbank-jni: cloudflared (tunel Cloudflare) vai como libcloudflared.so e precisa ser extraido para poder executar' + $nl +
                'android {' + $nl +
                '    packaging {' + $nl +
                '        jniLibs {' + $nl +
                '            useLegacyPackaging = true' + $nl +
                "            keepDebugSymbols.add('**/libcloudflared.so')" + $nl +
                '        }' + $nl +
                '    }' + $nl +
                '}' + $nl
        }
    }
    Save $f $t $o
    Write-Host "minSdk = flutter.minSdkVersion e lint ajustados em $n"
    $done = $true
}
if (-not $done) { Write-Host 'AVISO: build.gradle do app nao encontrado.'; exit 2 }

# ---------- gradle.properties ----------
$gp = Join-Path $Dir 'gradle.properties'
$t = ''
if (Test-Path $gp) { $t = [System.IO.File]::ReadAllText($gp) }
$o = $t
if ($t -notmatch '(?m)^\s*android\.r8\.proguardAndroidTxt\.disallowed') {
    if ($t.Length -gt 0 -and -not $t.EndsWith("`n")) { $t += "`r`n" }
    $t += "# Coin Bank: plugins antigos ainda usam proguard-android.txt (recusado pelo AGP 9+)`r`n"
    $t += "android.r8.proguardAndroidTxt.disallowed=false`r`n"
}
if ($t -notmatch '(?m)^\s*kotlin\.incremental\s*=') {
    if ($t.Length -gt 0 -and -not $t.EndsWith("`n")) { $t += "`r`n" }
    $t += "# Coin Bank: projeto e cache do Pub em drives diferentes quebram o cache incremental do Kotlin`r`n"
    $t += "kotlin.incremental=false`r`n"
} else {
    $t = [regex]::Replace($t, '(?m)^\s*kotlin\.incremental\s*=.*$', 'kotlin.incremental=false')
}
Save $gp $t $o
Write-Host 'gradle.properties ajustado.'
exit 0
