# Assinatura de envio (upload key) para publicar na Google Play.
# Cria assinatura\coinbank-upload.jks + assinatura\key.properties na primeira vez (senha aleatoria forte)
# e copia para android\key.properties (com o caminho absoluto do .jks) a cada build do App Bundle.
# GUARDE A PASTA "assinatura" EM LUGAR SEGURO: sem ela voce nao consegue enviar atualizacoes do app.
# Ja tem uma chave? Coloque o .jks em assinatura\ e crie assinatura\key.properties com:
#   storePassword=...  keyPassword=...  keyAlias=...  storeFile=nome-do-arquivo.jks
param([string]$Root)
$ErrorActionPreference = 'Stop'
$utf8 = New-Object System.Text.UTF8Encoding($false)
$Root = (Resolve-Path $Root).Path
$dir = Join-Path $Root 'assinatura'
$jks = Join-Path $dir 'coinbank-upload.jks'
$props = Join-Path $dir 'key.properties'
if (-not (Test-Path $dir)) { New-Item -ItemType Directory -Force -Path $dir | Out-Null }

function Find-Keytool {
    $c = @()
    if ($env:JAVA_HOME) { $c += (Join-Path $env:JAVA_HOME 'bin\keytool.exe'); $c += (Join-Path $env:JAVA_HOME 'bin/keytool') }
    if ($env:ProgramFiles) {
        $c += (Join-Path $env:ProgramFiles 'Android\Android Studio\jbr\bin\keytool.exe')
        $c += (Join-Path $env:ProgramFiles 'Android\Android Studio\jre\bin\keytool.exe')
    }
    if (${env:ProgramFiles(x86)}) { $c += (Join-Path ${env:ProgramFiles(x86)} 'Android\Android Studio\jbr\bin\keytool.exe') }
    if ($env:LOCALAPPDATA) {
        $c += (Join-Path $env:LOCALAPPDATA 'Programs\Android Studio\jbr\bin\keytool.exe')
        $c += (Join-Path $env:LOCALAPPDATA 'Android\Android Studio\jbr\bin\keytool.exe')
    }
    foreach ($p in $c) { if ($p -and (Test-Path $p)) { return $p } }
    $cmd = Get-Command keytool -ErrorAction SilentlyContinue
    if ($cmd) { return $cmd.Source }
    # o mesmo Java que o Flutter usa (flutter doctor -v: "Java binary at: ...")
    try {
        $d = (& flutter doctor -v 2>$null) | Out-String
        $m = [regex]::Match($d, 'Java binary at:\s*(.+?)\s*$', 'Multiline')
        if ($m.Success) {
            $bin = Split-Path $m.Groups[1].Value.Trim()
            foreach ($n in @('keytool.exe', 'keytool')) { $k = Join-Path $bin $n; if (Test-Path $k) { return $k } }
        }
    } catch { }
    return $null
}

function New-Password {
    $chars = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789'
    $rng = [System.Security.Cryptography.RandomNumberGenerator]::Create()
    $b = New-Object byte[] 28
    $rng.GetBytes($b)
    return -join ($b | ForEach-Object { $chars[$_ % $chars.Length] })
}

if (-not (Test-Path $props)) {
    if (Test-Path $jks) {
        Write-Host '[ERRO] Existe assinatura\coinbank-upload.jks mas falta assinatura\key.properties (com as senhas).'
        Write-Host '       Restaure o key.properties do seu backup. Nao apague o .jks.'
        exit 3
    }
    $kt = Find-Keytool
    if (-not $kt) {
        Write-Host '[ERRO] keytool (Java) nao encontrado. Instale o Android Studio (ele traz o Java em "jbr")'
        Write-Host '       ou defina JAVA_HOME, e rode de novo.'
        exit 2
    }
    Write-Host "Criando a chave de envio da Play Store com: $kt"
    $pw = New-Password
    & $kt -genkeypair -keystore $jks -storetype PKCS12 -keyalg RSA -keysize 2048 -validity 10000 -alias upload `
        -storepass $pw -keypass $pw -dname 'CN=Coin Bank, OU=FoxSrv, O=FoxSrv, L=Sao Paulo, ST=SP, C=BR' | Out-Null
    if ($LASTEXITCODE -ne 0 -or -not (Test-Path $jks)) { Write-Host '[ERRO] keytool falhou ao criar a chave.'; exit 4 }
    $txt = "storePassword=$pw`r`nkeyPassword=$pw`r`nkeyAlias=upload`r`nstoreFile=coinbank-upload.jks`r`n"
    [System.IO.File]::WriteAllText($props, $txt, $utf8)
    Write-Host ''
    Write-Host '=================================================================='
    Write-Host '  CHAVE DE ENVIO CRIADA em: assinatura\'
    Write-Host '  FACA BACKUP DESTA PASTA (pendrive, nuvem). Sem ela nao da para'
    Write-Host '  enviar atualizacoes do app para a Play Store.'
    Write-Host '=================================================================='
    Write-Host ''
}

# le o key.properties e grava android\key.properties com o caminho absoluto do .jks
$map = @{}
foreach ($line in [System.IO.File]::ReadAllLines($props)) {
    $l = $line.Trim()
    if ($l -eq '' -or $l.StartsWith('#')) { continue }
    $i = $l.IndexOf('=')
    if ($i -gt 0) { $map[$l.Substring(0, $i).Trim()] = $l.Substring($i + 1).Trim() }
}
foreach ($k in @('storePassword', 'keyPassword', 'keyAlias', 'storeFile')) {
    if (-not $map.ContainsKey($k) -or $map[$k] -eq '') { Write-Host "[ERRO] assinatura\key.properties sem '$k'."; exit 5 }
}
$sf = $map['storeFile']
if (-not [System.IO.Path]::IsPathRooted($sf)) { $sf = Join-Path $dir $sf }
if (-not (Test-Path $sf)) { Write-Host "[ERRO] arquivo da chave nao encontrado: $sf"; exit 6 }
$sf = (Resolve-Path $sf).Path -replace '\\', '/'
$out = "storePassword=$($map['storePassword'])`r`nkeyPassword=$($map['keyPassword'])`r`nkeyAlias=$($map['keyAlias'])`r`nstoreFile=$sf`r`n"
$androidDir = Join-Path $Root 'android'
if (-not (Test-Path $androidDir)) { Write-Host '[ERRO] pasta android nao existe.'; exit 7 }
[System.IO.File]::WriteAllText((Join-Path $androidDir 'key.properties'), $out, $utf8)
Write-Host "Assinatura de release: $sf (alias $($map['keyAlias']))"
exit 0
