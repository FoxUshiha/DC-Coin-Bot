# API Coin — comprovante pelo link (atualização do `api.js`)

Substitua o `api.js` da sua API Coin (CoinBank v2) por este. Nada muda para os clientes que já usam a API.
Só foram adicionadas duas coisas:

- **`GET /api/tx/:id/link`** → `{ success, id, url, png, pdf, svg, json, tx }`.
  - `url` é o link público do comprovante, para copiar e mandar.
  - Ele usa o `api.public_url` do `config.yml`; sem ele, usa o endereço da requisição.
- **Página do comprovante embutida na API**, em `/tx/<id>` e `/receipt/<id>`.
  - Mostra a imagem gerada na hora, os dados da transação, os botões para baixar imagem e PDF e o botão **Copiar link**.
  - Funciona mesmo com `site_enabled: false` ou sem a pasta `site/`. Antes, `/tx/<id>` dava 404 nesse caso.
  - Se a pasta `site/` tiver o `tx.html`, ele continua sendo usado em `/tx/<id>`.

A rede hospedada no app oferece os mesmos `/tx/<id>`, `/api/tx/<id>/link` e `/api/tx/<id>/receipt.png|pdf`.
Ela é um espelho da API principal, também pelo túnel Cloudflare.
