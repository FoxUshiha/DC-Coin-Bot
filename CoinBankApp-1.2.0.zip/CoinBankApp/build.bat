@echo off
setlocal EnableExtensions
cd /d "%~dp0"
rem uso: build.bat          -> APK para instalar direto no celular (out\CoinBank.apk)
rem      build.bat aab      -> App Bundle assinado para a Google Play (out\CoinBank.aab) - o mesmo que build_playstore.bat
set "MODE=%~1"
if /i "%MODE%"=="aab" (set "WHAT=App Bundle para a Google Play") else (set "MODE=apk" & set "WHAT=APK")
title Coin Bank - Build Android %WHAT%

echo ==================================================
echo   Coin Bank 1.2.0 - compilando %WHAT%
echo ==================================================
echo.

where flutter >nul 2>nul
if errorlevel 1 (
  echo [ERRO] Flutter nao encontrado no PATH.
  echo        Instale em https://docs.flutter.dev/get-started/install/windows
  echo        e rode "flutter doctor" ate o Android toolchain ficar OK.
  goto :fail
)

rem ---- 1) gera a pasta android\ (compativel com o Flutter instalado) ----
if not exist "android\gradlew.bat" (
  echo [1/5] Gerando projeto Android base...
  if exist "_gen" rmdir /s /q "_gen"
  call flutter create --platforms=android --org net.foxsrv --project-name coinbank --no-pub _gen
  if errorlevel 1 goto :fail
  if not exist "_gen\android" (
    echo [ERRO] flutter create nao gerou a pasta android.
    goto :fail
  )
  xcopy "_gen\android" "android" /e /i /y /q >nul
  rmdir /s /q "_gen"
) else (
  echo [1/5] Projeto Android base ja existe.
)

rem ---- 2) aplica manifest, icones, codigo nativo (Kotlin + ZXing), cloudflared e ajustes do Gradle ----
echo [2/5] Aplicando icone, manifest, codigo nativo e ajustes do Gradle...
if exist "android\app\src\main\res\values-night" rmdir /s /q "android\app\src\main\res\values-night"
if exist "android\app\src\main\res\drawable-v21" rmdir /s /q "android\app\src\main\res\drawable-v21"
if exist "android\app\src\main\kotlin\net\foxsrv\coinbank" del /q "android\app\src\main\kotlin\net\foxsrv\coinbank\*.kt" >nul 2>nul
if exist "android\app\src\main\java\net\foxsrv\coinbank" rmdir /s /q "android\app\src\main\java\net\foxsrv\coinbank"
xcopy "android_overlay" "android" /e /i /y /q >nul
if errorlevel 1 goto :fail
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools_patch_gradle.ps1" -Dir "%~dp0android"
if errorlevel 1 goto :fail

rem ---- 3) dependencias ----
echo [3/5] Baixando dependencias (flutter pub get)...
call flutter pub get
if errorlevel 1 goto :fail

if /i "%MODE%"=="aab" goto :build_aab

rem ---- 4) compila ----
echo [4/5] Compilando APK release (pode demorar na primeira vez)...
rem APK para instalar direto: assinado com a chave de debug (nao usa a chave da Play Store)
if exist "android\key.properties" del /q "android\key.properties"
if exist "out\CoinBank.apk" del /q "out\CoinBank.apk"
if exist "build\app\outputs\flutter-apk\app-release.apk" del /q "build\app\outputs\flutter-apk\app-release.apk"
call flutter build apk --release
if errorlevel 1 goto :fail

echo [5/5] Copiando APK para a pasta out...
if not exist "out" mkdir "out"
set "APK=build\app\outputs\flutter-apk\app-release.apk"
if not exist "%APK%" (
  echo [ERRO] APK nao encontrado em %APK%
  goto :fail
)
copy /y "%APK%" "out\CoinBank.apk" >nul
if errorlevel 1 goto :fail

echo.
echo ==================================================
echo   PRONTO:  %~dp0out\CoinBank.apk
echo ==================================================
echo   Copie o APK para o celular e instale (permitir
echo   "fontes desconhecidas").
echo.
pause
exit /b 0

rem ================= App Bundle (Google Play) =================
:build_aab
echo [4/6] Preparando a chave de envio da Play Store (pasta assinatura)...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools_keystore.ps1" -Root "%~dp0."
if errorlevel 1 goto :fail

echo [5/6] Compilando o App Bundle de release (pode demorar)...
set "AAB=build\app\outputs\bundle\release\app-release.aab"
if exist "%AAB%" del /q "%AAB%"
if exist "out\CoinBank.aab" del /q "out\CoinBank.aab"
call flutter build appbundle --release
if not errorlevel 1 goto :aab_copy
rem Sem "Android SDK Command-line Tools"/NDK a conferencia final do Flutter falha, mas o .aab ja foi gerado e assinado.
if not exist "%AAB%" goto :fail
echo.
echo [AVISO] O App Bundle foi gerado e assinado; so a conferencia de simbolos de depuracao falhou.
echo         Instale "Android SDK Command-line Tools" e "NDK (Side by side)" no Android Studio para o aviso sumir.
echo.

:aab_copy
echo [6/6] Copiando o App Bundle para a pasta out...
if not exist "out" mkdir "out"
if not exist "%AAB%" (
  echo [ERRO] App Bundle nao encontrado em %AAB%
  goto :fail
)
copy /y "%AAB%" "out\CoinBank.aab" >nul
if errorlevel 1 goto :fail
if exist "android\key.properties" del /q "android\key.properties"
echo.
echo ==================================================
echo   PRONTO:  %~dp0out\CoinBank.aab
echo ==================================================
echo   FACA BACKUP DA PASTA "assinatura": sem ela nao da para enviar atualizacoes.
echo.
pause
exit /b 0

:fail
echo.
echo ==================================================
echo   FALHOU. Dicas:
echo    - flutter doctor -v
echo    - flutter doctor --android-licenses   (aceite tudo com "y")
echo    - Instale Android SDK, Platform-Tools e Build-Tools 34+ pelo Android Studio
echo    - Se um erro citar minSdk/AGP/Kotlin, rode: flutter upgrade
echo    - Projeto Android corrompido? apague as pastas android e build e rode de novo
echo ==================================================
pause
exit /b 1
