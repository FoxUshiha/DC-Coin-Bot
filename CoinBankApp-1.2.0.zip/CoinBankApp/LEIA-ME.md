# Coin Bank 1.0 — app Android

Carteira completa da moeda virtual **Coin**. Conecta na rede principal (**https://bank.foxsrv.net**), em outras redes Coin e na rede que o próprio celular pode hospedar.

A estrutura é a mesma do FoxDrive:
- **Flutter** cuida das telas (`lib/`).
- **Kotlin** cuida de todo o resto (`android_overlay/`):
  - câmera/QR, NFC, rede local e Bluetooth;
  - notificações e serviço em segundo plano;
  - digital (Keystore), comprovantes PNG/PDF e navegador interno;
  - servidor local da moeda, com túnel Cloudflare.
- **Nenhum plugin de terceiros:** o `pubspec.yaml` só usa o Flutter e o `flutter_localizations`.

## Novidades da 1.2.0

- Abas: **Carteira** (saldo, Pagar/Receber, ações, pessoas por perto, últimas transações) · **Cartão** (cartão black, aproximação, como usar o código na API) · **Histórico** · **Contas**.
- Termos, Privacidade e Documentação da API do site embutidos no app (`assets/site/`): abrem sem internet em Sobre e no login.
- Resgate com física: moedas caem do topo da tela para dentro da carteira (1 moedinha por unidade da última casa exibida, até 12), passam entre o fundo e a frente da carteira, podem ser seguradas, arrastadas, jogadas e batem nas bordas. Toque na carteira = balança; 2 toques rápidos = moedinhas sobem meio para fora; tocando de novo = elas pulam para fora. Transferência recebida com o resgate aberto = moedas caem; pagamento enviado = moedas saem voando para cima. Só fecha pelo X ou pelo voltar.
- Novos ícones (app, moeda e carteira).

## Como compilar (Windows)
1. Instale o Flutter (stable 3.27 ou mais novo; testado contra a 3.47) e o Android Studio.
2. Rode `flutter doctor --android-licenses` e aceite tudo.
3. Dê dois cliques em **build.bat**.
   - O script cria a pasta `android` com `flutter create`, aplica o `android_overlay`, ajusta o Gradle e compila.
   - O APK sai em **out\CoinBank.apk**.
4. Para a Google Play, use **build_playstore.bat**.
   - Ele gera **out\CoinBank.aab**, assinado com a chave criada em `assinatura\`.
   - **Faça backup da pasta `assinatura`.**
5. A cada envio para a Play, aumente o número depois do `+` em `pubspec.yaml`.

Atualizou o código? Rode o `build.bat` de novo. Ele recopia o `android_overlay` sem apagar a pasta `android`. Se algo estranho acontecer, apague `android` e `build` e rode outra vez.

## O que tem no app

**Tela inicial**
- Logo, escolha da rede, contas salvas (entra com a digital) e os botões **Entrar** e **Criar conta**.
- Rodapé com os **Termos** do servidor atual, que abrem no navegador interno.
- No canto, os botões **Sobre/termos** (offline) e **Redes**. Também há **Como funciona o app?**.

**Carteira**
- Saldo, com opção de ocultar.
- **Cartão black**: o código fica oculto por padrão; dá para mostrar, copiar ou resetar (com confirmação).
- **Cobrar** por QR Code, por aproximação (NFC) ou mandando para quem está perto.
- **Escanear para pagar** com a câmera dentro do app. Também lê da galeria ou do que estiver copiado.
- Atalhos: **Enviar**, **Aproximar para pagar**, **Gerar conta** e **Pagar conta**.
- **Pessoas próximas** e as últimas transações.

**Histórico**
- Gráfico animado do saldo (7 dias, 30 dias ou tudo) e totais de entradas e saídas.
- Extrato com filtros, agrupado por dia e com carregamento contínuo.

**Contas (bills)**
- Listas de cobranças a pagar e a receber.
- Gerar cobrança com vencimento: mostra o QR do ID e pode mandar para quem está perto.
- Pagar por ID ou escaneando; encerrar uma cobrança sua.

**Comprovantes**
- Toda transação abre um comprovante gerado na hora no aparelho, com QR de verificação.
- Dá para salvar como **imagem** ou **PDF** (em Download/CoinBank) e compartilhar.
- **Link web** abre o `/tx/<id>` da rede num navegador em modal, dentro do app.

**Resgate 🎁**
- O botão de presente no topo abre o modal com o cronômetro, igual ao site.
- Ao resgatar, aparece a animação da carteira com as moedas caindo dentro.
- Depois do resgate, o cronômetro até o próximo continua na tela.
- **Resgate automático**: com a notificação fixa ligada, resgata sozinho a cada 1 h.

**Atualização**
- A tela atualiza a cada 2 s.
- A API é consultada a cada 5 s: saldo, resgate, extrato e cobranças.

**Sem internet**
- O app abre normalmente; só não mostra saldos.

**Menu lateral**
- Conta, Status da rede (ping, usuários, transações, gráfico por dia), Por perto, Hospedar, Configurações, Sobre e Sair.

**Conta**
- **Códigos de backup** num modal: gerar, copiar e **baixar o .txt** para o aparelho.
- Restaurar um backup.
- **Salvar conta e entrar com a digital**: a senha fica cifrada no Android Keystore.
- Trocar senha ou usuário, excluir o login.

**Configurações**
- **URL da API da rede principal**, com **Voltar ao padrão** e **Conectar** (testa o ping e salva).
- Tema (sistema, claro, escuro), idioma (automático, PT, EN) e **casas decimais** (8 por padrão, 2 ou inteiros).
- Cartão oculto por padrão e ocultar saldo.
- **Notificações** (ligadas por padrão): pagamentos recebidos, novas cobranças e cobranças pagas.
- Segundo plano (notificação fixa e modo de bateria), resgate automático e contas salvas.

**Por perto**
- **Ficar visível** (desligado por padrão) anuncia seu usuário e ID na rede local (UDP + mDNS) e, se você ligar, por **Bluetooth LE**.
- Para cada pessoa encontrada: **Pagar** ou **Cobrar**. A cobrança aparece na hora no app da outra pessoa.
- Também lista as redes hospedadas por perto.

**NFC**
- Quem cobra vira um "cartão" (HCE, AID `F0434F494E504159`).
- Quem paga toca em **Aproximar** e encosta os celulares; a cobrança abre para confirmar.

**Hospedar**
- **Servidores**:
  - lista com a principal, as adicionadas e a deste aparelho;
  - ping de cada uma, botão **Usar**, renomear e remover;
  - adicionar pelo endereço;
  - redes hospedadas por perto.
- **Minha rede**:
  - uma rede por aparelho, com servidor HTTP e banco SQLite locais, falando a mesma API da rede principal;
  - começa em **0,00000000** para todos, com resgate de **0,00000012 a cada 1 h** (ajustável);
  - túnel **trycloudflare** (`libcloudflared.so`, ARM64). Com ele ligado, quem está perto vê só o endereço Cloudflare;
  - opções de bateria: liberar a otimização, manter o processador ativo e modo de conferência;
  - armazenamento (tamanho do banco e espaço livre) e apagar os dados da rede.

**Só a rede principal gera notificações.** As outras funcionam normalmente como moeda no app.

**Sobre**
- Termos, Privacidade, Documentação da API e Como funciona, **embutidos**: abrem sem internet, no idioma e no tema do app.
- Doação em **Bitcoin** com QR e botão de copiar: `bc1qg4pfxutjmtd76cheygzcg4ee5vwvvsp0jsyn6n`.

## Permissões e declarações na Play
Câmera (QR), NFC, Bluetooth/dispositivos por perto (opcional), notificações e "ignorar otimização de bateria" (opcional).

Serviço em primeiro plano do tipo **specialUse**, usado para os avisos de pagamentos, o resgate automático e o servidor local da moeda. Declare tudo isso em "Conteúdo do app".

## Avisos
- O túnel Cloudflare usa o binário `cloudflared` para ARM64, o mesmo do FoxDrive. Em aparelhos x86 ou ARM 32 bits a opção aparece desativada; a rede local continua funcionando.
- Os coins não têm valor real. Nenhum dinheiro real ou cartão real é usado.
- O leitor de QR usa o ZXing (Apache 2.0, veja `THIRD_PARTY_NOTICES-ZXING.txt`).
