@echo off
setlocal EnableExtensions
title Coin Bank 1.0 - Compilar para Windows
cd /d "%~dp0"
echo ==================================================
echo   Coin Bank 1.0 para Windows 10/11
echo   Gera o instalador com as versoes 32 e 64 bits
echo   (app de bandeja + carteira + rede local + rede hospedada)
echo ==================================================
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0build\build.ps1"
if errorlevel 1 goto :fail
echo.
echo   Instalador pronto: %~dp0out\CoinBank-Setup.exe
echo.
choice /c SN /n /m "Abrir o instalador agora? [S/N] "
if errorlevel 2 goto :end
start "" "%~dp0out\CoinBank-Setup.exe"
goto :end

:fail
echo.
echo ==================================================
echo   FALHOU. Veja a mensagem [ERRO] acima.
echo    - Na primeira vez precisa de internet (baixa o Node.js 22 do nodejs.org)
echo    - Precisa do .NET Framework 4.6.2+ (ja vem no Windows 10/11 atualizado)
echo    - Se o Coin Bank estiver aberto: bandeja ^> Sair, e rode de novo
echo ==================================================
pause
exit /b 1

:end
endlocal
exit /b 0
