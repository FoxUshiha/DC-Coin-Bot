// Coin Bank para Windows - ponto de entrada.
// Instancia unica; abre so na bandeja (com o Windows: --minimized, sem painel); abrir de novo mostra o painel da bandeja.
using System;
using System.Net;
using System.Threading;
using System.Windows.Forms;

namespace CoinBank
{
    static class Program
    {
        public const string AppVersion = "1.0.0";
        public static bool DevTools;
        const string MutexName = "Local\\CoinBankWindowsApp";
        public const string ShowEventName = "Local\\CoinBankWindowsApp.Show";

        [STAThread]
        static void Main(string[] args)
        {
            bool minimized = false;
            string openUrl = null;
            foreach (var a in args)
            {
                if (a == "--minimized" || a == "/minimized") minimized = true;
                if (a == "--devtools") DevTools = true;
                if (a != null && a.StartsWith("coinbank:", StringComparison.OrdinalIgnoreCase)) openUrl = a;
            }

            bool created;
            using (var mutex = new Mutex(true, MutexName, out created))
            {
                if (!created)
                {
                    // ja esta aberto (na bandeja): pede para ele mostrar o painel (ou abrir o link coinbank://)
                    if (openUrl != null) { try { System.IO.File.WriteAllText(Paths.PendingOpen, openUrl); } catch { } }
                    try { using (var ev = EventWaitHandle.OpenExisting(ShowEventName)) ev.Set(); } catch { }
                    return;
                }
                Application.ThreadException += delegate (object s, ThreadExceptionEventArgs e) { Log.W("UI: " + e.Exception); };
                AppDomain.CurrentDomain.UnhandledException += delegate (object s, UnhandledExceptionEventArgs e) { Log.W("fatal: " + e.ExceptionObject); };
                Application.SetUnhandledExceptionMode(UnhandledExceptionMode.CatchException);
                Application.EnableVisualStyles();
                Application.SetCompatibleTextRenderingDefault(false);
                try { ServicePointManager.SecurityProtocol |= SecurityProtocolType.Tls12; } catch { }
                Log.W("CoinBank " + AppVersion + " iniciando (" + (Environment.Is64BitProcess ? "x64" : "x86") + ", " + Environment.OSVersion + (minimized ? ", com o Windows" : "") + ")");

                Protocol.Register();
                var app = new TrayApp(!minimized && openUrl == null);
                if (openUrl != null) { var r0 = Protocol.ToRoute(openUrl); if (r0 != null) app.Ui(delegate { app.ShowMain(r0); }); }

                // segunda instancia -> mostra o painel da bandeja
                EventWaitHandle showEv = null;
                try
                {
                    showEv = new EventWaitHandle(false, EventResetMode.AutoReset, ShowEventName);
                    var th = new Thread(delegate ()
                    {
                        while (true)
                        {
                            try { showEv.WaitOne(); } catch { return; }
                            string pending = null;
                            try { if (System.IO.File.Exists(Paths.PendingOpen)) { pending = System.IO.File.ReadAllText(Paths.PendingOpen); System.IO.File.Delete(Paths.PendingOpen); } } catch { }
                            var route = Protocol.ToRoute(pending);
                            if (route != null) app.Ui(delegate { app.ShowMain(route); });
                            else app.Ui(app.ShowFlyout);
                        }
                    });
                    th.IsBackground = true;
                    th.Start();
                }
                catch (Exception e) { Log.W("evento de instancia: " + e.Message); }

                Application.Run(app);
                GC.KeepAlive(mutex);
                GC.KeepAlive(showEv);
            }
            // garante que nenhuma thread segure o processo depois do "Sair"
            Environment.Exit(0);
        }
    }
}
