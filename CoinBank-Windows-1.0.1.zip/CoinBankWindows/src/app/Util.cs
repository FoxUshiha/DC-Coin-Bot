// Coin Bank para Windows - utilitarios (JSON, caminhos, log, chamadas nativas).
// Escrito em C# 5 para compilar com o csc.exe que ja vem no Windows (.NET Framework 4.x).
using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Web.Script.Serialization;
using System.Windows.Forms;
using Microsoft.Win32;

namespace CoinBank
{
    /// <summary>Ajudantes de JSON sobre o JavaScriptSerializer (objetos = Dictionary, listas = object[]/ArrayList).</summary>
    public static class J
    {
        static JavaScriptSerializer Make()
        {
            var s = new JavaScriptSerializer();
            s.MaxJsonLength = int.MaxValue;
            s.RecursionLimit = 64;
            return s;
        }

        public static string Ser(object o) { return Make().Serialize(o); }

        public static Dictionary<string, object> Obj(string json)
        {
            if (string.IsNullOrEmpty(json)) return new Dictionary<string, object>();
            try
            {
                var o = Make().DeserializeObject(json) as Dictionary<string, object>;
                return o ?? new Dictionary<string, object>();
            }
            catch { return new Dictionary<string, object>(); }
        }

        public static object Get(IDictionary<string, object> d, string k)
        {
            object v;
            if (d == null || !d.TryGetValue(k, out v)) return null;
            return v;
        }

        public static string Str(IDictionary<string, object> d, string k, string def)
        {
            var v = Get(d, k);
            if (v == null) return def;
            var s = v as string;
            return s ?? Convert.ToString(v, CultureInfo.InvariantCulture);
        }

        public static bool IsNum(object v)
        {
            return v is int || v is long || v is double || v is decimal || v is float || v is short || v is byte;
        }

        public static double Dbl(IDictionary<string, object> d, string k, double def)
        {
            var v = Get(d, k);
            if (IsNum(v)) return Convert.ToDouble(v, CultureInfo.InvariantCulture);
            var s = v as string;
            double r;
            if (s != null && double.TryParse(s, NumberStyles.Float, CultureInfo.InvariantCulture, out r)) return r;
            return def;
        }

        public static long Long(IDictionary<string, object> d, string k, long def)
        {
            var x = Dbl(d, k, double.NaN);
            if (double.IsNaN(x) || double.IsInfinity(x)) return def;
            if (x > long.MaxValue / 2) return long.MaxValue / 2;
            if (x < long.MinValue / 2) return long.MinValue / 2;
            return (long)Math.Round(x);
        }

        public static int Int(IDictionary<string, object> d, string k, int def)
        {
            var x = Long(d, k, def);
            if (x > int.MaxValue) return int.MaxValue;
            if (x < int.MinValue) return int.MinValue;
            return (int)x;
        }

        public static bool Bool(IDictionary<string, object> d, string k, bool def)
        {
            var v = Get(d, k);
            if (v is bool) return (bool)v;
            return def;
        }

        public static Dictionary<string, object> Sub(IDictionary<string, object> d, string k)
        {
            return Get(d, k) as Dictionary<string, object>;
        }

        public static List<object> List(IDictionary<string, object> d, string k)
        {
            var v = Get(d, k);
            var res = new List<object>();
            var e = v as IEnumerable;
            if (e == null || v is string) return res;
            foreach (var x in e) res.Add(x);
            return res;
        }

        public static Dictionary<string, object> D(params object[] kv)
        {
            var d = new Dictionary<string, object>();
            for (int i = 0; i + 1 < kv.Length; i += 2) d[(string)kv[i]] = kv[i + 1];
            return d;
        }
    }

    public static class Paths
    {
        /// <summary>%LOCALAPPDATA%\CoinBank — configuracao, sessoes cifradas, rede hospedada, log e dados do WebView2.</summary>
        public static string AppData
        {
            get
            {
                var p = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "CoinBank");
                Directory.CreateDirectory(p);
                return p;
            }
        }

        /// <summary>Pasta onde o CoinBank.exe esta instalado.</summary>
        public static string AppDir { get { return Path.GetDirectoryName(Application.ExecutablePath); } }
        public static string EngineExe { get { return Path.Combine(Path.Combine(AppDir, "runtime"), "CoinBankEngine.exe"); } }
        public static string EngineJs { get { return Path.Combine(Path.Combine(AppDir, "engine"), "engine.js"); } }
        public static string ConfigFile { get { return Path.Combine(AppData, "config.json"); } }
        public static string LogFile { get { return Path.Combine(AppData, "coinbank.log"); } }
        public static string WebData { get { return Path.Combine(AppData, "WebView2"); } }
        public static string SealFile { get { return Path.Combine(AppData, "seal.dpapi"); } }
        public static string PendingOpen { get { return Path.Combine(AppData, "pending-open.txt"); } }
    }

    /// <summary>Chave que protege os segredos do motor (sessao da conta). Guardada cifrada pelo Windows (DPAPI, so este usuario abre).</summary>
    public static class Seal
    {
        static string cached;
        public static string KeyB64()
        {
            if (cached != null) return cached;
            byte[] key = null;
            try
            {
                if (File.Exists(Paths.SealFile))
                {
                    var prot = File.ReadAllBytes(Paths.SealFile);
                    key = ProtectedData.Unprotect(prot, Encoding.UTF8.GetBytes("CoinBank.seal.v1"), DataProtectionScope.CurrentUser);
                    if (key == null || key.Length != 32) key = null;
                }
            }
            catch (Exception e) { Log.W("seal: " + e.Message); key = null; }
            if (key == null)
            {
                key = new byte[32];
                using (var r = RandomNumberGenerator.Create()) r.GetBytes(key);
                try
                {
                    var prot = ProtectedData.Protect(key, Encoding.UTF8.GetBytes("CoinBank.seal.v1"), DataProtectionScope.CurrentUser);
                    File.WriteAllBytes(Paths.SealFile, prot);
                }
                catch (Exception e) { Log.W("seal (gravar): " + e.Message); }
            }
            cached = Convert.ToBase64String(key);
            return cached;
        }
    }

    /// <summary>Links coinbank:// (pagar um QR/pedido no app). Registrado em HKCU (sem administrador).</summary>
    public static class Protocol
    {
        public static void Register()
        {
            try
            {
                using (var k = Registry.CurrentUser.CreateSubKey(@"Software\Classes\coinbank"))
                {
                    if (k == null) return;
                    k.SetValue("", "URL:Coin Bank");
                    k.SetValue("URL Protocol", "");
                    using (var ic = k.CreateSubKey("DefaultIcon")) { if (ic != null) ic.SetValue("", "\"" + Application.ExecutablePath + "\",0"); }
                    using (var cmd = k.CreateSubKey(@"shell\open\command")) { if (cmd != null) cmd.SetValue("", "\"" + Application.ExecutablePath + "\" \"%1\""); }
                }
            }
            catch (Exception e) { Log.W("protocolo coinbank://: " + e.Message); }
        }

        /// <summary>coinbank://pay/ID ou coinbank://user/ID → rota "pay|coinbank://..." (a interface confirma antes de pagar);
        /// coinbank://open/claim → "claim". Nulo se invalido.</summary>
        public static string ToRoute(string url)
        {
            if (string.IsNullOrEmpty(url)) return null;
            var u = url.Trim();
            if (!u.StartsWith("coinbank:", StringComparison.OrdinalIgnoreCase) || u.Length > 600) return null;
            var rest = u.Substring("coinbank:".Length).TrimStart('/');
            var parts = rest.Split(new[] { '/', '?', '#' }, StringSplitOptions.RemoveEmptyEntries);
            if (parts.Length >= 2 && (parts[0] == "pay" || parts[0] == "user") && Safe(parts[1])) return "pay|" + u;
            if (parts.Length >= 2 && parts[0] == "open" && Safe(parts[1])) return parts[1];
            return "wallet";
        }

        static bool Safe(string s)
        {
            if (string.IsNullOrEmpty(s) || s.Length > 200) return false;
            foreach (var c in s) if (!(char.IsLetterOrDigit(c) || c == '-' || c == '_' || c == '%' || c == '.' || c == '=' || c == '&')) return false;
            return true;
        }
    }

    public static class Log
    {
        static readonly object Lk = new object();

        public static void W(string msg)
        {
            try
            {
                lock (Lk)
                {
                    var f = Paths.LogFile;
                    var fi = new FileInfo(f);
                    if (fi.Exists && fi.Length > 2 * 1024 * 1024)
                    {
                        var old = f + ".1";
                        if (File.Exists(old)) File.Delete(old);
                        File.Move(f, old);
                    }
                    File.AppendAllText(f, DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture) + "  " + msg + "\r\n", Encoding.UTF8);
                }
            }
            catch { }
        }
    }

    /// <summary>Leitura direta de algumas chaves do config.json (o motor e o dono do arquivo).</summary>
    public static class Settings
    {
        public static Dictionary<string, object> Read()
        {
            try
            {
                if (File.Exists(Paths.ConfigFile)) return J.Obj(File.ReadAllText(Paths.ConfigFile, Encoding.UTF8));
            }
            catch { }
            return new Dictionary<string, object>();
        }
    }

    /// <summary>Iniciar com o Windows (HKCU\...\Run). Sempre aponta para o exe atual, com --minimized (so bandeja).</summary>
    public static class AutoStart
    {
        const string RunKey = @"Software\Microsoft\Windows\CurrentVersion\Run";
        const string Name = "CoinBank";

        public static bool IsOn()
        {
            try
            {
                using (var k = Registry.CurrentUser.OpenSubKey(RunKey))
                {
                    var v = k == null ? null : k.GetValue(Name) as string;
                    return !string.IsNullOrEmpty(v);
                }
            }
            catch { return false; }
        }

        public static bool Set(bool on)
        {
            try
            {
                using (var k = Registry.CurrentUser.CreateSubKey(RunKey))
                {
                    if (k == null) return false;
                    if (on) k.SetValue(Name, "\"" + Application.ExecutablePath + "\" --minimized");
                    else k.DeleteValue(Name, false);
                }
                return true;
            }
            catch (Exception e) { Log.W("autostart: " + e.Message); return false; }
        }
    }

    public static class Native
    {
        [DllImport("kernel32.dll")]
        static extern uint SetThreadExecutionState(uint esFlags);
        const uint ES_CONTINUOUS = 0x80000000;
        const uint ES_SYSTEM_REQUIRED = 0x00000001;

        /// <summary>Impede (ou volta a permitir) a suspensao automatica do PC. Chamar sempre da thread da UI.</summary>
        public static void KeepAwake(bool on)
        {
            try { SetThreadExecutionState(on ? (ES_CONTINUOUS | ES_SYSTEM_REQUIRED) : ES_CONTINUOUS); } catch { }
        }

        [DllImport("dwmapi.dll")]
        static extern int DwmSetWindowAttribute(IntPtr hwnd, int attr, ref int attrValue, int attrSize);

        /// <summary>Barra de titulo escura (Windows 10 20H1+ e 11).</summary>
        public static void TitleBarTheme(IntPtr hwnd, bool dark)
        {
            try
            {
                int on = dark ? 1 : 0;
                if (DwmSetWindowAttribute(hwnd, 20, ref on, 4) != 0) DwmSetWindowAttribute(hwnd, 19, ref on, 4);
            }
            catch { }
        }

        /// <summary>Cantos arredondados no Windows 11 (ignorado no 10).</summary>
        public static void RoundCorners(IntPtr hwnd)
        {
            try { int pref = 2; DwmSetWindowAttribute(hwnd, 33, ref pref, 4); } catch { }
        }

        [DllImport("user32.dll")]
        [return: MarshalAs(UnmanagedType.Bool)]
        public static extern bool SetForegroundWindow(IntPtr hWnd);

        /// <summary>Tema de aplicativos do Windows (Configuracoes > Personalizacao > Cores).</summary>
        public static bool WindowsDark()
        {
            try
            {
                using (var k = Registry.CurrentUser.OpenSubKey(@"Software\Microsoft\Windows\CurrentVersion\Themes\Personalize"))
                {
                    var v = k == null ? null : k.GetValue("AppsUseLightTheme");
                    if (v is int) return (int)v == 0;
                }
            }
            catch { }
            return false;
        }

        /// <summary>Abre telas do Windows (so ms-settings:, ex.: hotspot e Wi-Fi).</summary>
        public static void OpenSettingsUri(string uri)
        {
            if (string.IsNullOrEmpty(uri) || !uri.StartsWith("ms-settings:", StringComparison.OrdinalIgnoreCase) || uri.Length > 80) return;
            foreach (var c in uri) if (!(char.IsLetterOrDigit(c) || c == ':' || c == '-' || c == '_')) return;
            try { Process.Start(new ProcessStartInfo(uri) { UseShellExecute = true }); }
            catch (Exception e) { Log.W("abrir " + uri + ": " + e.Message); }
        }

        public static void OpenUrl(string url)
        {
            try { Process.Start(new ProcessStartInfo(url) { UseShellExecute = true }); }
            catch (Exception e) { Log.W("abrir " + url + ": " + e.Message); }
        }
    }

    /// <summary>Downloads do app (site do Drive, exchange, navegador interno): vao direto para a pasta Downloads do Windows.</summary>
    public static class Downloads
    {
        [DllImport("shell32.dll", CharSet = CharSet.Unicode)]
        static extern int SHGetKnownFolderPath([MarshalAs(UnmanagedType.LPStruct)] Guid rfid, uint dwFlags, IntPtr hToken, out IntPtr ppszPath);
        static readonly Guid FOLDERID_Downloads = new Guid("374DE290-123F-4565-9164-39C4925E467B");

        public static string Folder()
        {
            string dir = null;
            try
            {
                IntPtr p;
                if (SHGetKnownFolderPath(FOLDERID_Downloads, 0, IntPtr.Zero, out p) == 0 && p != IntPtr.Zero)
                {
                    try { dir = Marshal.PtrToStringUni(p); } finally { Marshal.FreeCoTaskMem(p); }
                }
            }
            catch { dir = null; }
            if (string.IsNullOrEmpty(dir)) dir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), "Downloads");
            try { Directory.CreateDirectory(dir); } catch { }
            return dir;
        }

        static string Clean(string name)
        {
            if (string.IsNullOrEmpty(name)) name = "download";
            foreach (var c in Path.GetInvalidFileNameChars()) name = name.Replace(c, '_');
            name = name.Trim().TrimEnd('.');
            if (name.Length == 0) name = "download";
            if (name.Length > 150) { var ext = Path.GetExtension(name); if (ext.Length > 12) ext = ""; name = name.Substring(0, 150 - ext.Length) + ext; }
            return name;
        }

        /// <summary>nome livre: "arquivo.pdf", "arquivo (1).pdf", ...</summary>
        public static string Unique(string dir, string name)
        {
            name = Clean(name);
            var path = Path.Combine(dir, name);
            if (!File.Exists(path)) return path;
            var b = Path.GetFileNameWithoutExtension(name); var ext = Path.GetExtension(name);
            for (int i = 1; i < 10000; i++) { path = Path.Combine(dir, b + " (" + i + ")" + ext); if (!File.Exists(path)) return path; }
            return Path.Combine(dir, b + " " + DateTime.Now.Ticks + ext);
        }

        public static void Reveal(string path)
        {
            try
            {
                if (File.Exists(path)) Process.Start(new ProcessStartInfo("explorer.exe", "/select,\"" + path + "\"") { UseShellExecute = true });
                else Process.Start(new ProcessStartInfo(Folder()) { UseShellExecute = true });
            }
            catch (Exception e) { Log.W("abrir Downloads: " + e.Message); }
        }

        /// <summary>liga o WebView a esta politica: salva em Downloads sem perguntar e avisa quando terminar</summary>
        public static void Hook(Microsoft.Web.WebView2.Core.CoreWebView2 cw, TrayApp app)
        {
            try { cw.Profile.DefaultDownloadFolderPath = Folder(); } catch { }   // runtime antigo: ignora
            cw.DownloadStarting += delegate (object s, Microsoft.Web.WebView2.Core.CoreWebView2DownloadStartingEventArgs e)
            {
                try
                {
                    var name = Path.GetFileName(e.ResultFilePath ?? "");
                    var dest = Unique(Folder(), name);
                    e.ResultFilePath = dest;
                    e.Handled = true;                                    // sem a janelinha de downloads do Edge
                    var op = e.DownloadOperation;
                    op.StateChanged += delegate
                    {
                        try
                        {
                            if (op.State == Microsoft.Web.WebView2.Core.CoreWebView2DownloadState.Completed) { Log.W("download salvo: " + op.ResultFilePath); app.NotifyDownload(op.ResultFilePath, true, null); }
                            else if (op.State == Microsoft.Web.WebView2.Core.CoreWebView2DownloadState.Interrupted && op.InterruptReason != Microsoft.Web.WebView2.Core.CoreWebView2DownloadInterruptReason.UserCanceled && op.InterruptReason != Microsoft.Web.WebView2.Core.CoreWebView2DownloadInterruptReason.UserShutdown && op.InterruptReason != Microsoft.Web.WebView2.Core.CoreWebView2DownloadInterruptReason.UserPaused)
                                app.NotifyDownload(op.ResultFilePath, false, op.InterruptReason.ToString());
                        }
                        catch { }
                    };
                }
                catch (Exception x) { Log.W("download: " + x.Message); }
            };
        }
    }
}
