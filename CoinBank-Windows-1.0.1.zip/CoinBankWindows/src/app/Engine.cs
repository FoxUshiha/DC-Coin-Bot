// Coin Bank para Windows - inicia e vigia o motor (runtime\CoinBankEngine.exe engine\engine.js).
// O motor serve a interface interna, vigia as carteiras (avisos e resgate automatico), a rede local e a rede hospedada.
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Security.Cryptography;
using System.Text;
using System.Threading;

namespace CoinBank
{
    public class EngineHost
    {
        public readonly string Token;
        readonly object lk = new object();
        Process proc;
        volatile int port;
        volatile bool stopping;
        int fails;
        DateTime startedAt;
        Timer restartTimer;
        public volatile string LastError;

        /// <summary>Motor pronto (porta conhecida). Disparado numa thread qualquer.</summary>
        public event Action<int> Ready;
        /// <summary>Motor caiu ou nao iniciou. Disparado numa thread qualquer.</summary>
        public event Action<string> Down;

        public EngineHost()
        {
            var b = new byte[24];
            using (var r = RandomNumberGenerator.Create()) r.GetBytes(b);
            Token = Convert.ToBase64String(b).Replace('+', '-').Replace('/', '_').TrimEnd('=');
        }

        public int Port { get { return port; } }
        public string BaseUrl { get { int p = port; return p > 0 ? "http://127.0.0.1:" + p : null; } }
        public bool IsUp { get { return port > 0; } }

        static string Q(string s) { return "\"" + (s ?? "").TrimEnd('\\') + "\""; }

        public void Start()
        {
            lock (lk)
            {
                if (proc != null || stopping) return;
                Launch();
            }
        }

        void Launch()
        {
            var exe = Paths.EngineExe;
            var js = Paths.EngineJs;
            if (!File.Exists(exe) || !File.Exists(js))
            {
                LastError = "Arquivos do motor não encontrados em " + Paths.AppDir + " (runtime\\CoinBankEngine.exe e engine\\engine.js). Reinstale o Coin Bank.";
                Log.W(LastError);
                Fire(Down, LastError);
                return;
            }
            var psi = new ProcessStartInfo(exe);
            psi.Arguments = "--experimental-sqlite --disable-warning=ExperimentalWarning " + Q(js) + " --data " + Q(Paths.AppData) + " --token " + Token +
                            " --parent " + Process.GetCurrentProcess().Id + " --app-version " + Program.AppVersion;
            psi.UseShellExecute = false;
            psi.CreateNoWindow = true;
            psi.WindowStyle = ProcessWindowStyle.Hidden;
            psi.RedirectStandardInput = true;   // se o CoinBank.exe morrer, o pipe fecha e o motor encerra sozinho
            psi.RedirectStandardOutput = true;
            psi.RedirectStandardError = true;
            psi.StandardOutputEncoding = Encoding.UTF8;
            psi.StandardErrorEncoding = Encoding.UTF8;
            psi.WorkingDirectory = Path.GetDirectoryName(js);
            psi.EnvironmentVariables["COINBANK_APP"] = "1";
            try { psi.EnvironmentVariables["COINBANK_SEAL"] = Seal.KeyB64(); } catch (Exception e) { Log.W("seal: " + e.Message); }
            if (psi.EnvironmentVariables.ContainsKey("NODE_OPTIONS")) psi.EnvironmentVariables.Remove("NODE_OPTIONS");

            var p = new Process();
            p.StartInfo = psi;
            p.EnableRaisingEvents = true;
            p.OutputDataReceived += delegate (object s, DataReceivedEventArgs e) { OnOut(e.Data); };
            p.ErrorDataReceived += delegate (object s, DataReceivedEventArgs e) { if (!string.IsNullOrEmpty(e.Data)) Log.W("motor: " + e.Data); };
            p.Exited += delegate { OnExit(p); };
            try
            {
                p.Start();
                p.BeginOutputReadLine();
                p.BeginErrorReadLine();
                proc = p;
                startedAt = DateTime.UtcNow;
                Log.W("motor iniciado (pid " + p.Id + ")");
            }
            catch (Exception e)
            {
                LastError = "Não foi possível iniciar o motor: " + e.Message;
                Log.W(LastError);
                proc = null;
                Fire(Down, LastError);
                ScheduleRestart();
            }
        }

        void OnOut(string line)
        {
            if (string.IsNullOrEmpty(line)) return;
            const string mark = "COINBANK_READY ";
            if (line.StartsWith(mark, StringComparison.Ordinal))
            {
                var d = J.Obj(line.Substring(mark.Length));
                int pt = J.Int(d, "port", 0);
                if (pt > 0)
                {
                    port = pt;
                    LastError = null;
                    Log.W("motor pronto em http://127.0.0.1:" + pt);
                    var h = Ready;
                    if (h != null) { try { h(pt); } catch (Exception e) { Log.W("Ready: " + e.Message); } }
                }
                return;
            }
            Log.W("motor: " + line);
        }

        void OnExit(Process p)
        {
            int code = -1;
            try { code = p.ExitCode; } catch { }
            lock (lk)
            {
                if (proc != p) return;
                proc = null;
                port = 0;
            }
            try { p.Dispose(); } catch { }
            if (stopping) return;
            LastError = "o motor parou (código " + code + ")";
            Log.W(LastError + "; reiniciando…");
            Fire(Down, LastError);
            ScheduleRestart();
        }

        void ScheduleRestart()
        {
            if (stopping) return;
            if ((DateTime.UtcNow - startedAt).TotalSeconds > 120) fails = 0;
            fails++;
            int ms = Math.Min(60000, 1500 * (1 << Math.Min(5, fails - 1)));  // 1,5 s · 3 s · 6 s · 12 s · 24 s · 48 s
            var old = restartTimer;
            restartTimer = new Timer(delegate { lock (lk) { if (proc == null && !stopping) Launch(); } }, null, ms, Timeout.Infinite);
            if (old != null) old.Dispose();
        }

        static void Fire(Action<string> h, string msg)
        {
            if (h == null) return;
            try { h(msg); } catch { }
        }

        /// <summary>Chamada a API de controle do motor (/app/api/...). Nao usar na thread da UI.</summary>
        public Dictionary<string, object> Api(string method, string path, object body, int timeoutMs)
        {
            var b = BaseUrl;
            if (b == null) throw new InvalidOperationException("motor iniciando");
            var req = (HttpWebRequest)WebRequest.Create(b + "/app/api/" + path);
            req.Method = method;
            req.Proxy = null;
            req.KeepAlive = false;
            req.Timeout = timeoutMs;
            req.ReadWriteTimeout = timeoutMs;
            req.Headers["x-coinbank-token"] = Token;
            req.Accept = "application/json";
            if (body != null)
            {
                var data = Encoding.UTF8.GetBytes(J.Ser(body));
                req.ContentType = "application/json";
                req.ContentLength = data.Length;
                using (var s = req.GetRequestStream()) s.Write(data, 0, data.Length);
            }
            else if (method == "POST") req.ContentLength = 0;
            HttpWebResponse resp;
            try { resp = (HttpWebResponse)req.GetResponse(); }
            catch (WebException we)
            {
                resp = we.Response as HttpWebResponse;
                if (resp == null) throw;
            }
            using (resp)
            using (var sr = new StreamReader(resp.GetResponseStream(), Encoding.UTF8))
                return J.Obj(sr.ReadToEnd());
        }

        /// <summary>Encerra com elegancia: a rede hospedada fecha o banco, as contas sao salvas. Mata o processo se passar do tempo.</summary>
        public void Shutdown(int waitMs)
        {
            Process p;
            lock (lk)
            {
                stopping = true;
                p = proc;
                if (restartTimer != null) { restartTimer.Dispose(); restartTimer = null; }
            }
            if (p == null) return;
            try { Api("POST", "shutdown", null, 3000); } catch { }
            bool done = false;
            try { done = p.WaitForExit(waitMs); } catch { done = true; }
            if (!done)
            {
                Log.W("motor não encerrou a tempo; finalizando o processo");
                try { p.Kill(); p.WaitForExit(3000); } catch { }
            }
            try { p.StandardInput.Close(); } catch { }
            port = 0;
        }
    }
}
