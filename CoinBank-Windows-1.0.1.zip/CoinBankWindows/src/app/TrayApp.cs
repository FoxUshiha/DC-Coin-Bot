// Coin Bank para Windows - o app de bandeja: icone ao lado do relogio (com o saldo no texto), painel resumido,
// janela principal, motor (carteira, resgate automatico, rede local, rede hospedada), inicio com o Windows e avisos.
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Reflection;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Web.WebView2.Core;
using Microsoft.Win32;

namespace CoinBank
{
    public class TrayApp : ApplicationContext
    {
        public readonly EngineHost Engine = new EngineHost();
        public readonly Icon AppIcon;
        readonly Icon trayIcon, trayIconDim;
        readonly NotifyIcon tray;
        readonly ToolStripMenuItem statusItem, balanceItem, autoClaimItem, visibleItem, hostItem;
        readonly Control ui;                                  // so para voltar a thread da UI (BeginInvoke)
        readonly System.Windows.Forms.Timer pollTimer, infoTimer, evTimer;
        long evSince = -1;
        bool notifyOn = true;
        string balloonRoute;
        int evPolling;
        MainWindow main;
        Flyout flyout;
        volatile bool exiting;
        bool hinted;
        int polling;
        bool dim, autoClaimOn, visibleOn, hostOn;
        string siteUrl = "https://bank.foxsrv.net";

        static Task<CoreWebView2Environment> envTask;
        /// <summary>Ambiente WebView2 compartilhado pelas janelas (dados em %LOCALAPPDATA%\CoinBank\WebView2).</summary>
        public static Task<CoreWebView2Environment> WebEnv()
        {
            if (envTask == null || envTask.IsFaulted || envTask.IsCanceled) envTask = CoreWebView2Environment.CreateAsync(null, Paths.WebData, null);
            return envTask;
        }

        public bool Exiting { get { return exiting; } }
        /// <summary>Site da rede ativa (links relativos da interface viram links deste site).</summary>
        public string SiteUrl { get { return siteUrl; } }

        public TrayApp(bool showPanel)
        {
            ui = new Control();
            var forceHandle = ui.Handle;   // cria o handle agora, na thread da UI
            GC.KeepAlive(forceHandle);

            AppIcon = LoadIcon(32);
            trayIcon = LoadIcon(SystemInformation.SmallIconSize.Width);
            trayIconDim = MakeDim(trayIcon);

            var menu = new ContextMenuStrip();
            statusItem = new ToolStripMenuItem("Coin Bank · iniciando…") { Enabled = false };
            balanceItem = new ToolStripMenuItem("Saldo: —") { Enabled = false };
            menu.Items.Add(statusItem);
            menu.Items.Add(balanceItem);
            menu.Items.Add(new ToolStripSeparator());
            var openItem = new ToolStripMenuItem("Abrir Coin Bank", null, delegate { ShowMain("wallet"); });
            openItem.Font = new Font(openItem.Font, FontStyle.Bold);
            menu.Items.Add(openItem);
            menu.Items.Add("Resgate 🎁", null, delegate { ShowMain("claim"); });
            menu.Items.Add("Receber (QR na tela)", null, delegate { ShowMain("receive"); });
            menu.Items.Add("Pagar / enviar", null, delegate { ShowMain("pay"); });
            menu.Items.Add("Pessoas por perto", null, delegate { ShowMain("nearby"); });
            menu.Items.Add("Hospedar uma rede", null, delegate { ShowMain("host"); });
            menu.Items.Add("Configurações", null, delegate { ShowMain("settings"); });
            menu.Items.Add(new ToolStripSeparator());
            autoClaimItem = new ToolStripMenuItem("Resgate automático", null, delegate { Toggle("autoClaim", !autoClaimOn); });
            visibleItem = new ToolStripMenuItem("Visível na rede local", null, delegate { Toggle("visible", !visibleOn); });
            hostItem = new ToolStripMenuItem("Rede hospedada ligada", null, delegate { ToggleHost(!hostOn); });
            menu.Items.Add(autoClaimItem);
            menu.Items.Add(visibleItem);
            menu.Items.Add(hostItem);
            menu.Items.Add(new ToolStripSeparator());
            menu.Items.Add("Sair", null, delegate { Exit(); });

            tray = new NotifyIcon { Icon = trayIcon, Text = "Coin Bank", ContextMenuStrip = menu, Visible = true };
            tray.MouseClick += delegate (object s, MouseEventArgs e) { if (e.Button == MouseButtons.Left) ToggleFlyout(); };
            tray.DoubleClick += delegate { ShowMain("wallet"); };
            tray.BalloonTipClicked += delegate
            {
                var r = balloonRoute; balloonRoute = null;
                if (!string.IsNullOrEmpty(r)) ShowMain(r); else ShowFlyout();
            };

            // inicio com o Windows: ligado por padrao (o usuario pode desligar em Configuracoes)
            var cfg = Settings.Read();
            if (J.Bool(J.Sub(cfg, "settings") ?? cfg, "autoStart", true)) AutoStart.Set(true);

            Engine.Ready += delegate { Ui(OnEngineReady); };
            Engine.Down += delegate { Ui(delegate { SetTray("Coin Bank · reiniciando o motor…", true); }); };
            Engine.Start();

            pollTimer = new System.Windows.Forms.Timer { Interval = 3000 };
            pollTimer.Tick += delegate { Poll(); };
            pollTimer.Start();
            infoTimer = new System.Windows.Forms.Timer { Interval = 60000 };
            infoTimer.Tick += delegate { PushHostInfo(); };
            infoTimer.Start();
            evTimer = new System.Windows.Forms.Timer { Interval = 2500 };
            evTimer.Tick += delegate { PollEvents(); };
            evTimer.Start();

            SystemEvents.PowerModeChanged += OnPower;
            SystemEvents.SessionEnding += OnSessionEnding;

            if (showPanel) Ui(delegate { ShowFlyout(); });
            else if (!File.Exists(Path.Combine(Paths.AppData, ".tray-hint")))
            {
                try { File.WriteAllText(Path.Combine(Paths.AppData, ".tray-hint"), DateTime.Now.ToString("s")); } catch { }
                Ui(delegate { HintTray(); });
            }
        }

        // ───────────── icones ─────────────
        static Icon LoadIcon(int size)
        {
            try
            {
                using (var st = Assembly.GetExecutingAssembly().GetManifestResourceStream("CoinBank.app.ico"))
                    if (st != null) return new Icon(st, new Size(size, size));
            }
            catch { }
            try { return Icon.ExtractAssociatedIcon(Application.ExecutablePath); } catch { }
            return SystemIcons.Application;
        }

        /// <summary>Versao apagada do icone (sem conexao com a rede).</summary>
        static Icon MakeDim(Icon src)
        {
            try
            {
                using (var bmp = src.ToBitmap())
                using (var dst = new Bitmap(bmp.Width, bmp.Height, PixelFormat.Format32bppArgb))
                {
                    using (var g = Graphics.FromImage(dst))
                    {
                        var cm = new ColorMatrix(new float[][] {
                            new float[] { .30f, .30f, .30f, 0, 0 }, new float[] { .59f, .59f, .59f, 0, 0 },
                            new float[] { .11f, .11f, .11f, 0, 0 }, new float[] { 0, 0, 0, .75f, 0 }, new float[] { 0, 0, 0, 0, 1 } });
                        using (var ia = new ImageAttributes())
                        {
                            ia.SetColorMatrix(cm);
                            g.DrawImage(bmp, new Rectangle(0, 0, bmp.Width, bmp.Height), 0, 0, bmp.Width, bmp.Height, GraphicsUnit.Pixel, ia);
                        }
                    }
                    return Icon.FromHandle(dst.GetHicon());
                }
            }
            catch { return src; }
        }

        // ───────────── utilidades ─────────────
        public void Ui(Action a)
        {
            try { if (ui.IsHandleCreated && !ui.IsDisposed) ui.BeginInvoke(a); } catch { }
        }

        static void Bg(Action a) { ThreadPool.QueueUserWorkItem(delegate { try { a(); } catch (Exception e) { Log.W("bg: " + e.Message); } }); }

        void SetTray(string text, bool dimmed)
        {
            try
            {
                tray.Text = text.Length > 63 ? text.Substring(0, 63) : text;
                statusItem.Text = text.Length > 90 ? text.Substring(0, 90) : text;
                if (dimmed != dim) { dim = dimmed; tray.Icon = dimmed ? trayIconDim : trayIcon; }
            }
            catch { }
        }

        public void HintTray()
        {
            if (hinted || exiting) return;
            hinted = true;
            try { tray.ShowBalloonTip(5000, "O Coin Bank está na bandeja", "Ele continua com o resgate automático, os avisos e a rede local. Clique no ícone para o painel; botão direito > Sair para fechar.", ToolTipIcon.Info); } catch { }
        }

        // ───────────── motor ─────────────
        void OnEngineReady()
        {
            if (exiting) return;
            if (main != null) main.EngineChanged();
            if (flyout != null) flyout.EngineChanged();
            PushHostInfo();
            Poll();
        }

        void Poll()
        {
            if (exiting || !Engine.IsUp) return;
            if (Interlocked.CompareExchange(ref polling, 1, 0) != 0) return;
            Bg(delegate
            {
                try
                {
                    var st = Engine.Api("GET", "tray", null, 5000);
                    Ui(delegate { ApplyState(st); });
                }
                catch { }
                finally { Interlocked.Exchange(ref polling, 0); }
            });
        }

        void ApplyState(Dictionary<string, object> st)
        {
            if (exiting || st == null || !J.Bool(st, "ok", false)) return;
            notifyOn = J.Bool(st, "notify", true);
            autoClaimOn = J.Bool(st, "autoClaim", false);
            visibleOn = J.Bool(st, "visible", false);
            hostOn = J.Bool(st, "host", false);
            siteUrl = J.Str(st, "site", siteUrl);
            autoClaimItem.Checked = autoClaimOn;
            visibleItem.Checked = visibleOn;
            hostItem.Checked = hostOn;
            bool online = J.Bool(st, "online", false);
            bool logged = J.Bool(st, "logged", false);
            string net = J.Str(st, "netName", "Coin");
            string bal = J.Str(st, "balance", null);
            int near = J.Int(st, "nearby", 0);
            balanceItem.Text = !logged ? "Entre na sua conta para ver o saldo" : "Saldo: " + (bal ?? "—") + " · " + net;
            string line = "Coin Bank · " + net + (!logged ? " · sem login" : (online ? " · " + (bal ?? "—") : " · offline"));
            if (near > 0) line += " · " + near + " por perto";
            SetTray(line, !online);
            Native.KeepAwake(hostOn && J.Bool(st, "preventSleep", false));
        }

        /// <summary>Notificacoes do Windows (balao da bandeja): coins recebidos/enviados, resgate, cobrancas, por perto, rede hospedada.</summary>
        void PollEvents()
        {
            if (exiting || !Engine.IsUp) return;
            if (Interlocked.CompareExchange(ref evPolling, 1, 0) != 0) return;
            long since = evSince;
            Bg(delegate
            {
                try
                {
                    var r = Engine.Api("GET", "events?since=" + (since < 0 ? 0 : since), null, 5000);
                    if (!J.Bool(r, "ok", false)) return;
                    long last = J.Long(r, "last", 0);
                    var list = J.List(r, "events");
                    Ui(delegate
                    {
                        if (evSince < 0 || last < evSince) { evSince = last; return; }   // primeira leitura (ou motor reiniciou): nao repete avisos antigos
                        evSince = last;
                        if (list.Count == 0) return;
                        if (main != null && !main.IsDisposed) main.Post(J.D("type", "events"));
                        if (flyout != null && !flyout.IsDisposed) flyout.Post(J.D("type", "events"));
                        if (!notifyOn) return;
                        Dictionary<string, object> ev = null;
                        for (int i = list.Count - 1; i >= 0; i--) { var e = list[i] as Dictionary<string, object>; if (e != null && !J.Bool(e, "silent", false)) { ev = e; break; } }
                        if (ev == null) return;
                        var kind = J.Str(ev, "kind", "");
                        var icon = kind.EndsWith("error") || kind == "down" ? ToolTipIcon.Warning : ToolTipIcon.Info;
                        balloonRoute = J.Str(ev, "route", null);
                        string text = J.Str(ev, "text", "");
                        if (list.Count > 1) text += "  (+" + (list.Count - 1) + " aviso(s))";
                        try { tray.ShowBalloonTip(6000, J.Str(ev, "title", "Coin Bank"), string.IsNullOrEmpty(text) ? " " : text, icon); } catch { }
                    });
                }
                catch { }
                finally { Interlocked.Exchange(ref evPolling, 0); }
            });
        }

        /// <summary>Nome do PC e energia para o motor (o nome aparece para quem esta por perto).</summary>
        void PushHostInfo()
        {
            if (exiting || !Engine.IsUp) return;
            Bg(delegate
            {
                var power = J.D("hasBattery", false, "onBattery", false, "percent", -1);
                try
                {
                    var ps = SystemInformation.PowerStatus;
                    bool has = (ps.BatteryChargeStatus & BatteryChargeStatus.NoSystemBattery) == 0 && ps.BatteryChargeStatus != BatteryChargeStatus.Unknown;
                    power = J.D("hasBattery", has, "onBattery", ps.PowerLineStatus == PowerLineStatus.Offline,
                        "percent", has ? (int)Math.Round(ps.BatteryLifePercent * 100) : -1);
                }
                catch { }
                try { Engine.Api("POST", "hostinfo", J.D("power", power, "machine", Environment.MachineName, "user", Environment.UserName, "dark", Native.WindowsDark()), 5000); } catch { }
            });
        }

        void OnPower(object sender, PowerModeChangedEventArgs e)
        {
            Ui(PushHostInfo);
            if (e.Mode == PowerModes.Resume) Bg(delegate { try { Engine.Api("POST", "wake", null, 5000); } catch { } });
        }

        void OnSessionEnding(object sender, SessionEndingEventArgs e)
        {
            // logoff / desligamento: encerra rapido (a rede hospedada volta sozinha no proximo inicio)
            if (exiting) return;
            exiting = true;
            try { tray.Visible = false; } catch { }
            Engine.Shutdown(6000);
        }

        void Toggle(string key, bool on)
        {
            Bg(delegate { try { Engine.Api("POST", "settings", J.D("patch", J.D(key, on)), 8000); } catch { } Ui(Poll); });
        }

        void ToggleHost(bool on)
        {
            Bg(delegate { try { Engine.Api("POST", "host/set", J.D("enabled", on), 30000); } catch { } Ui(Poll); });
        }

        // ───────────── janelas ─────────────
        public void ShowMain(string route)
        {
            if (exiting) return;
            if (flyout != null) flyout.HideNow();
            if (main == null || main.IsDisposed) main = new MainWindow(this);
            main.ShowRoute(route);
        }

        public void ShowFlyout()
        {
            if (exiting) return;
            if (flyout == null || flyout.IsDisposed) flyout = new Flyout(this);
            flyout.ShowNear();
        }

        void ToggleFlyout()
        {
            if (exiting) return;
            if (flyout == null || flyout.IsDisposed) flyout = new Flyout(this);
            flyout.Toggle();
        }

        /// <summary>Aviso de download concluido (comprovantes, QR): clicar abre a pasta Downloads.</summary>
        public void NotifyDownload(string path, bool ok, string why)
        {
            Ui(delegate
            {
                balloonRoute = null;
                try
                {
                    if (ok) { Downloads.Reveal(path); tray.ShowBalloonTip(4000, "Download concluído", Path.GetFileName(path) + " está em Downloads.", ToolTipIcon.Info); }
                    else tray.ShowBalloonTip(5000, "Download não concluído", Path.GetFileName(path) + (string.IsNullOrEmpty(why) ? "" : " (" + why + ")"), ToolTipIcon.Warning);
                }
                catch { }
            });
        }

        /// <summary>Links que nao sao da interface interna abrem no navegador. Caminhos locais viram o endereco do site da rede.</summary>
        public void OpenOutside(string url)
        {
            if (string.IsNullOrEmpty(url)) return;
            var b = Engine.BaseUrl;
            if (b != null && url.StartsWith(b, StringComparison.OrdinalIgnoreCase)) url = siteUrl.TrimEnd('/') + url.Substring(b.Length);
            if (url.StartsWith("http://", StringComparison.OrdinalIgnoreCase) || url.StartsWith("https://", StringComparison.OrdinalIgnoreCase) ||
                url.StartsWith("mailto:", StringComparison.OrdinalIgnoreCase)) Native.OpenUrl(url);
        }

        // ───────────── comandos vindos da interface (window.chrome.webview.postMessage) ─────────────
        public void HandleMessage(WebHostForm from, string json)
        {
            var m = J.Obj(json);
            int id = J.Int(m, "id", 0);
            string cmd = J.Str(m, "cmd", "");
            var a = J.Sub(m, "args") ?? new Dictionary<string, object>();
            Action<bool, object, string> reply = delegate (bool ok, object data, string err)
            {
                from.Post(J.D("type", "reply", "id", id, "ok", ok, "data", data, "error", err));
            };
            try
            {
                switch (cmd)
                {
                    case "openExternal":
                        OpenOutside(J.Str(a, "url", ""));
                        reply(true, null, null);
                        break;
                    case "openMain":
                        reply(true, null, null);
                        ShowMain(J.Str(a, "route", "wallet"));
                        break;
                    case "hideFlyout":
                        reply(true, null, null);
                        if (flyout != null) flyout.HideNow();
                        break;
                    case "exit":
                        reply(true, null, null);
                        Ui(Exit);
                        break;
                    case "refreshTray":
                        reply(true, null, null);
                        Ui(Poll);
                        break;
                    case "openUri":
                        Native.OpenSettingsUri(J.Str(a, "uri", ""));
                        reply(true, null, null);
                        break;
                    case "copy":
                        Ui(delegate
                        {
                            bool ok = false;
                            try { var t = J.Str(a, "text", ""); if (t.Length > 0) { Clipboard.SetText(t); ok = true; } } catch { }
                            reply(ok, null, ok ? null : "área de transferência ocupada");
                        });
                        break;
                    case "paste":
                        Ui(delegate
                        {
                            string t = null;
                            try { if (Clipboard.ContainsText()) t = Clipboard.GetText(); } catch { }
                            reply(true, t, null);
                        });
                        break;
                    case "saveImage":
                        Ui(delegate
                        {
                            string path = null;
                            try
                            {
                                var b64 = J.Str(a, "png", "");
                                int comma = b64.IndexOf(',');
                                if (comma >= 0) b64 = b64.Substring(comma + 1);
                                var bytes = Convert.FromBase64String(b64);
                                path = Downloads.Unique(Downloads.Folder(), J.Str(a, "name", "coinbank-qr.png"));
                                File.WriteAllBytes(path, bytes);
                                Downloads.Reveal(path);
                            }
                            catch (Exception x) { reply(false, null, x.Message); return; }
                            reply(true, path, null);
                        });
                        break;
                    case "getAutostart":
                        reply(true, J.D("on", AutoStart.IsOn()), null);
                        break;
                    case "setAutostart":
                        {
                            bool ok = AutoStart.Set(J.Bool(a, "on", true));
                            reply(ok, J.D("on", AutoStart.IsOn()), ok ? null : "registro do Windows recusou");
                        }
                        break;
                    case "openDataFolder":
                        Native.OpenUrl(Paths.AppData);
                        reply(true, null, null);
                        break;
                    default:
                        reply(false, null, "comando desconhecido: " + cmd);
                        break;
                }
            }
            catch (Exception e) { reply(false, null, e.Message); }
        }

        // ───────────── sair ─────────────
        public void Exit()
        {
            if (exiting) return;
            exiting = true;
            Log.W("saindo (pedido do usuário)");
            try { pollTimer.Stop(); infoTimer.Stop(); evTimer.Stop(); } catch { }
            try { if (flyout != null) flyout.Hide(); } catch { }
            try { if (main != null) main.Hide(); } catch { }
            try { tray.Visible = false; } catch { }
            Native.KeepAwake(false);
            var t = new Thread(delegate ()
            {
                try { Engine.Shutdown(15000); } catch { }
                Ui(delegate
                {
                    try { SystemEvents.PowerModeChanged -= OnPower; SystemEvents.SessionEnding -= OnSessionEnding; } catch { }
                    try { if (flyout != null) flyout.Dispose(); } catch { }
                    try { if (main != null) main.Dispose(); } catch { }
                    try { tray.Dispose(); } catch { }
                    ExitThread();
                });
            });
            t.IsBackground = true;
            t.Start();
            // seguranca: se algo travar, encerra mesmo assim
            var guard = new Thread(delegate () { Thread.Sleep(25000); Environment.Exit(0); });
            guard.IsBackground = true;
            guard.Start();
        }
    }
}
