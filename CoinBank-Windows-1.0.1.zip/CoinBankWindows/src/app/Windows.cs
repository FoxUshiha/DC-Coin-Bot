// Coin Bank para Windows - janelas com WebView2: o painel da bandeja e a janela principal.
// As duas mostram a interface INTERNA servida pelo motor local (http://127.0.0.1:<porta>/app/), que funciona offline.
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using Microsoft.Web.WebView2.Core;
using Microsoft.Web.WebView2.WinForms;

namespace CoinBank
{
    /// <summary>Base: uma janela com um WebView2, politica de navegacao e ponte de mensagens com o app.</summary>
    public class WebHostForm : Form
    {
        protected readonly TrayApp App;
        protected WebView2 Web;
        protected bool WebReady;
        bool initing;
        string pendingUrl;
        Panel missing;

        public WebHostForm(TrayApp app)
        {
            App = app;
            AutoScaleMode = AutoScaleMode.Dpi;
            AutoScaleDimensions = new SizeF(96f, 96f);
            Text = "Coin Bank";
            Font = new Font("Segoe UI", 9.5f);
            bool dark = Native.WindowsDark();
            BackColor = dark ? Color.FromArgb(16, 17, 19) : Color.FromArgb(236, 238, 241);
            ForeColor = dark ? Color.FromArgb(232, 234, 237) : Color.FromArgb(20, 22, 26);
            Icon = app.AppIcon;
        }

        protected override void OnHandleCreated(EventArgs e)
        {
            base.OnHandleCreated(e);
            Native.TitleBarTheme(Handle, Native.WindowsDark());
        }

        /// <summary>Endereco atual (ou null se o WebView ainda nao abriu nada).</summary>
        public string CurrentUrl
        {
            get { try { return WebReady ? Web.CoreWebView2.Source : null; } catch { return null; } }
        }

        public void Navigate(string url)
        {
            if (url == null) return;
            if (WebReady) { try { Web.CoreWebView2.Navigate(url); } catch (Exception e) { Log.W("navegar: " + e.Message); } return; }
            pendingUrl = url;
            InitWeb();
        }

        async void InitWeb()
        {
            if (WebReady || initing) return;
            initing = true;
            try
            {
                string ver = null;
                try { ver = CoreWebView2Environment.GetAvailableBrowserVersionString(null); }
                catch (WebView2RuntimeNotFoundException) { ver = null; }
                if (string.IsNullOrEmpty(ver)) { ShowMissing(); return; }
                var env = await TrayApp.WebEnv();
                if (Web == null)
                {
                    Web = new WebView2();
                    Web.Dock = DockStyle.Fill;
                    Web.DefaultBackgroundColor = BackColor;
                    Controls.Add(Web);
                    Web.BringToFront();
                }
                await Web.EnsureCoreWebView2Async(env);
                var cw = Web.CoreWebView2;
                cw.Settings.AreDevToolsEnabled = Program.DevTools;
                cw.Settings.IsStatusBarEnabled = false;
                cw.Settings.IsZoomControlEnabled = true;
                cw.Settings.AreDefaultContextMenusEnabled = true;
                try { cw.Settings.UserAgent = cw.Settings.UserAgent + " CoinBankApp/" + Program.AppVersion + " (Windows)"; } catch { }
                cw.NavigationStarting += OnNavStarting;
                cw.FrameNavigationStarting += OnNavStarting;
                cw.NewWindowRequested += OnNewWindow;
                cw.WebMessageReceived += OnWebMessage;
                Downloads.Hook(cw, App);
                cw.DocumentTitleChanged += delegate { OnTitle(cw.DocumentTitle); };
                WebReady = true;
                if (missing != null) missing.Visible = false;
                var u = pendingUrl; pendingUrl = null;
                if (u != null) cw.Navigate(u);
                OnWebReady();
            }
            catch (Exception e)
            {
                Log.W("WebView2: " + e);
                ShowMissing();
            }
            finally { initing = false; }
        }

        protected virtual void OnWebReady() { }
        protected virtual void OnTitle(string t) { }

        void ShowMissing()
        {
            if (missing == null)
            {
                missing = new Panel { Dock = DockStyle.Fill, BackColor = BackColor };
                var lbl = new Label
                {
                    Dock = DockStyle.Top, Height = 150, TextAlign = ContentAlignment.BottomCenter, ForeColor = ForeColor,
                    Font = new Font("Segoe UI", 10.5f),
                    Text = "O componente WebView2 da Microsoft (motor do Edge) não está instalado.\nEle mostra a interface do Coin Bank. O resgate automático e os avisos continuam na bandeja."
                };
                var btn = new Button { Text = "Baixar o WebView2 (Microsoft)", AutoSize = true, FlatStyle = FlatStyle.Flat, Height = 34, BackColor = Color.FromArgb(35, 39, 45), ForeColor = Color.White, Cursor = Cursors.Hand };
                btn.FlatAppearance.BorderSize = 0;
                btn.Click += delegate { Native.OpenUrl("https://go.microsoft.com/fwlink/p/?LinkId=2124703"); };
                var flow = new FlowLayoutPanel { Dock = DockStyle.Top, Height = 60, Padding = new Padding(0, 14, 0, 0) };
                flow.Controls.Add(btn);
                flow.Resize += delegate { flow.Padding = new Padding(Math.Max(0, (flow.Width - btn.Width) / 2), 14, 0, 0); };
                missing.Controls.Add(flow);
                missing.Controls.Add(lbl);
                Controls.Add(missing);
            }
            missing.Visible = true;
            missing.BringToFront();
        }

        // ───────────── politica de navegacao: so a interface interna fica dentro do app ─────────────
        static readonly string[] LocalPrefixes = { "/app/", "/terms/", "/terms", "/coin-icon.png", "/favicon.ico", "/app" };

        bool Allowed(string u)
        {
            if (string.IsNullOrEmpty(u)) return true;
            if (u.StartsWith("about:", StringComparison.OrdinalIgnoreCase) || u.StartsWith("data:", StringComparison.OrdinalIgnoreCase) ||
                u.StartsWith("blob:", StringComparison.OrdinalIgnoreCase)) return true;
            var b = App.Engine.BaseUrl;
            string rest = null;
            if (b != null && u.StartsWith(b + "/", StringComparison.OrdinalIgnoreCase)) rest = u.Substring(b.Length);
            else if (b == null && u.StartsWith("http://127.0.0.1:", StringComparison.OrdinalIgnoreCase))
            {
                // motor reiniciando: aceita a interface local em qualquer porta (ela recarrega sozinha)
                int i = u.IndexOf('/', "http://127.0.0.1:".Length);
                if (i > 0) rest = u.Substring(i);
            }
            if (rest == null) return false;
            foreach (var p in LocalPrefixes) if (rest.StartsWith(p, StringComparison.OrdinalIgnoreCase)) return true;
            return false;
        }

        void OnNavStarting(object sender, CoreWebView2NavigationStartingEventArgs e)
        {
            var u = e.Uri ?? "";
            if (Allowed(u)) return;
            e.Cancel = true;
            App.OpenOutside(u);
        }

        void OnNewWindow(object sender, CoreWebView2NewWindowRequestedEventArgs e)
        {
            var u = e.Uri ?? "";
            if (u.StartsWith("blob:", StringComparison.OrdinalIgnoreCase) || u.StartsWith("data:", StringComparison.OrdinalIgnoreCase)) return; // pre-visualizacao de arquivo: janela do proprio WebView
            e.Handled = true;
            App.OpenOutside(u);
        }

        void OnWebMessage(object sender, CoreWebView2WebMessageReceivedEventArgs e)
        {
            var b = App.Engine.BaseUrl;
            var src = e.Source ?? "";
            if (b == null || !src.StartsWith(b + "/app/", StringComparison.OrdinalIgnoreCase)) return;   // so as telas do app (nunca o site) mandam comandos
            string msg;
            try { msg = e.TryGetWebMessageAsString(); } catch { return; }
            App.HandleMessage(this, msg);
        }

        public void Post(object o)
        {
            if (!WebReady) return;
            try { Web.CoreWebView2.PostWebMessageAsJson(J.Ser(o)); } catch { }
        }
    }

    /// <summary>Janela principal: Carteira, Cartão, Histórico, Contas, Por perto, Hospedar, Redes, Configurações e Sobre.</summary>
    public class MainWindow : WebHostForm
    {
        string route = "wallet";
        string loadedBase;

        public MainWindow(TrayApp app) : base(app)
        {
            StartPosition = FormStartPosition.CenterScreen;
            ClientSize = new Size(1180, 780);
            MinimumSize = new Size(820, 580);
            ShowInTaskbar = true;
        }

        public void ShowRoute(string r)
        {
            if (!string.IsNullOrEmpty(r)) route = r;
            if (!Visible) Show();
            if (WindowState == FormWindowState.Minimized) WindowState = FormWindowState.Normal;
            Activate();
            BringToFront();
            try { Native.SetForegroundWindow(Handle); } catch { }
            var b = App.Engine.BaseUrl;
            if (b == null) return;                                    // o motor avisa quando estiver pronto (Reload)
            if (WebReady && loadedBase == b && CurrentUrl != null && CurrentUrl.StartsWith(b + "/app/", StringComparison.OrdinalIgnoreCase))
            {
                Post(J.D("type", "route", "data", route));
                if (route.IndexOf('|') >= 0) route = "wallet";        // link coinbank:// e de uma vez so (nao reabre quando o motor reinicia)
            }
            else LoadApp(b);
        }

        string pendingOpen;
        void LoadApp(string b)
        {
            loadedBase = b;
            string r = route;
            if (r != null && r.IndexOf('|') >= 0) { pendingOpen = r; r = "wallet"; route = r; }    // link coinbank:// : abre depois que a interface carregar (uma vez so)
            Navigate(b + "/app/#t=" + App.Engine.Token + "&r=" + r);
        }

        protected override void OnWebReady()
        {
            try
            {
                Web.CoreWebView2.NavigationCompleted += delegate
                {
                    var p = pendingOpen; pendingOpen = null;
                    if (p != null) Post(J.D("type", "route", "data", p));
                };
            }
            catch { }
        }

        /// <summary>O motor reiniciou (talvez em outra porta): recarrega se a janela estiver aberta.</summary>
        public void EngineChanged()
        {
            var b = App.Engine.BaseUrl;
            if (b == null || b == loadedBase) return;
            if (Visible || WebReady) LoadApp(b);
        }

        protected override void OnResize(EventArgs e)
        {
            base.OnResize(e);
        }

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            // telas pequenas (ex.: 1366x768): a janela nunca passa da area util
            var wa = Screen.FromPoint(Cursor.Position).WorkingArea;
            int w = Math.Min(Width, wa.Width - 40), h = Math.Min(Height, wa.Height - 40);
            if (w != Width || h != Height) { Size = new Size(w, h); Location = new Point(wa.Left + (wa.Width - w) / 2, wa.Top + (wa.Height - h) / 2); }
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            if (!App.Exiting && e.CloseReason == CloseReason.UserClosing)
            {
                e.Cancel = true;        // X: continua na bandeja (resgate automático, avisos, rede local)
                Hide();
                App.HintTray();
                return;
            }
            base.OnFormClosing(e);
        }
    }

    /// <summary>Painel da bandeja: saldo, resgate, rede local, pessoas por perto e avisos. Aparece acima do relogio e some ao clicar fora.</summary>
    public class Flyout : WebHostForm
    {
        DateTime hiddenAt = DateTime.MinValue;
        string loadedBase;

        public Flyout(TrayApp app) : base(app)
        {
            FormBorderStyle = FormBorderStyle.None;
            ShowInTaskbar = false;
            TopMost = true;
            StartPosition = FormStartPosition.Manual;
            AutoScaleMode = AutoScaleMode.None;           // tamanho calculado aqui (precisa estar certo antes de posicionar)
            float k = 1f;
            try { using (var g = Graphics.FromHwnd(IntPtr.Zero)) k = Math.Max(1f, g.DpiX / 96f); } catch { }
            ClientSize = new Size((int)(380 * k), (int)(600 * k));
            KeyPreview = true;
        }

        protected override CreateParams CreateParams
        {
            get
            {
                var cp = base.CreateParams;
                cp.ClassStyle |= 0x20000;   // CS_DROPSHADOW
                cp.ExStyle |= 0x80;         // WS_EX_TOOLWINDOW (fora do Alt+Tab)
                return cp;
            }
        }

        protected override void OnHandleCreated(EventArgs e)
        {
            base.OnHandleCreated(e);
            Native.RoundCorners(Handle);
        }

        public void Toggle()
        {
            if (Visible) { HideNow(); return; }
            if ((DateTime.UtcNow - hiddenAt).TotalMilliseconds < 400) return;   // o clique no icone acabou de fechar o painel
            ShowNear();
        }

        public void ShowNear()
        {
            var scr = Screen.FromPoint(Cursor.Position);
            var wa = scr.WorkingArea;
            var bd = scr.Bounds;
            int m = 12;
            int x = wa.Right - Width - m, y = wa.Bottom - Height - m;     // barra de tarefas embaixo (padrao)
            if (wa.Top > bd.Top) y = wa.Top + m;                          // barra em cima
            else if (wa.Left > bd.Left) { x = wa.Left + m; }               // barra a esquerda
            Location = new Point(Math.Max(wa.Left, x), Math.Max(wa.Top, y));
            if (!Visible) Show();
            Activate();
            try { Native.SetForegroundWindow(Handle); } catch { }
            var b = App.Engine.BaseUrl;
            if (b != null && (loadedBase != b || !WebReady)) { loadedBase = b; Navigate(b + "/app/flyout.html#t=" + App.Engine.Token); }
            else Post(J.D("type", "shown"));
            if (WebReady) { try { Web.Focus(); } catch { } }
        }

        public void EngineChanged()
        {
            var b = App.Engine.BaseUrl;
            if (b == null || b == loadedBase) return;
            loadedBase = b;
            if (Visible || WebReady) Navigate(b + "/app/flyout.html#t=" + App.Engine.Token);
        }

        public void HideNow()
        {
            if (!Visible) return;
            Hide();
            hiddenAt = DateTime.UtcNow;
        }

        protected override void OnDeactivate(EventArgs e)
        {
            base.OnDeactivate(e);
            HideNow();
        }

        protected override void OnKeyDown(KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape) { HideNow(); e.Handled = true; return; }
            base.OnKeyDown(e);
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            if (!App.Exiting && e.CloseReason == CloseReason.UserClosing) { e.Cancel = true; HideNow(); return; }
            base.OnFormClosing(e);
        }
    }
}
