// Coin Bank - instalador para Windows 10/11. Leva as versoes 32 bits (x86) e 64 bits (x64) embutidas
// (app + motor com o Node.js da versao certa) e pergunta qual instalar. Instala no perfil do usuario (sem pedir administrador), cria atalhos,
// registra o desinstalador em "Aplicativos instalados" e verifica o WebView2 Runtime.
// C# 5 para compilar com o csc.exe que ja vem no Windows.
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.IO.Compression;
using System.Net;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Web.Script.Serialization;
using System.Windows.Forms;
using Microsoft.Win32;

namespace CoinBankSetup
{
    static class Program
    {
        public const string AppName = "CoinBank";
        public const string Version = "1.0.0";
        public const string UninstKey = @"Software\Microsoft\Windows\CurrentVersion\Uninstall\CoinBank";
        public const string WebView2Guid = "{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}";

        [STAThread]
        static void Main(string[] args)
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            try { ServicePointManager.SecurityProtocol |= SecurityProtocolType.Tls12; } catch { }

            string mode = args.Length > 0 ? args[0].ToLowerInvariant() : "";
            if (mode == "/uninstall") { Uninstaller.Start(); return; }
            if (mode == "/uninstall-run" && args.Length > 1)
            {
                bool purge = args.Length > 2 && args[2] == "/purge";
                Uninstaller.Run(args[1], purge);
                return;
            }
            Application.Run(new SetupForm());
        }
    }

    // ─────────────────────────── utilitarios ───────────────────────────
    static class Sys
    {
        public static string DefaultDir
        {
            get { return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Programs\\CoinBank"); }
        }
        public static string DataDir
        {
            get { return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "CoinBank"); }
        }
        public static string StartMenuLink
        {
            get { return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Programs), "CoinBank.lnk"); }
        }
        public static string DesktopLink
        {
            get { return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory), "CoinBank.lnk"); }
        }

        /// <summary>Versao do WebView2 Runtime instalada (ou null).</summary>
        public static string WebView2Version()
        {
            var places = new List<KeyValuePair<RegistryHive, RegistryView>>();
            places.Add(new KeyValuePair<RegistryHive, RegistryView>(RegistryHive.LocalMachine, RegistryView.Registry32));
            places.Add(new KeyValuePair<RegistryHive, RegistryView>(RegistryHive.LocalMachine, RegistryView.Registry64));
            places.Add(new KeyValuePair<RegistryHive, RegistryView>(RegistryHive.CurrentUser, RegistryView.Registry32));
            places.Add(new KeyValuePair<RegistryHive, RegistryView>(RegistryHive.CurrentUser, RegistryView.Registry64));
            foreach (var p in places)
            {
                try
                {
                    if (p.Value == RegistryView.Registry64 && !Environment.Is64BitOperatingSystem) continue;
                    using (var b = RegistryKey.OpenBaseKey(p.Key, p.Value))
                    using (var k = b.OpenSubKey(@"SOFTWARE\Microsoft\EdgeUpdate\Clients\" + Program.WebView2Guid))
                    {
                        if (k == null) continue;
                        var v = k.GetValue("pv") as string;
                        if (!string.IsNullOrEmpty(v) && v != "0.0.0.0") return v;
                    }
                }
                catch { }
            }
            return null;
        }

        /// <summary>Fecha o CoinBank se estiver aberto (inclusive escondido na bandeja).</summary>
        public static bool CloseRunningApp(IWin32Window owner)
        {
            var procs = Process.GetProcessesByName("CoinBank");
            var engines = Process.GetProcessesByName("CoinBankEngine");
            if (procs.Length == 0 && engines.Length == 0) return true;
            if (procs.Length > 0)
            {
                var r = MessageBox.Show(owner,
                    "O Coin Bank está aberto (na bandeja, ao lado do relógio).\n\n" +
                    "Ele será fechado para continuar. O resgate automático, os avisos e a rede hospedada voltam sozinhos quando o app abrir de novo.\n\nFechar o Coin Bank agora?",
                    "CoinBank", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
                if (r != DialogResult.OK) return false;
            }
            foreach (var p in procs)
            {
                try { if (!p.HasExited) { p.Kill(); p.WaitForExit(8000); } } catch { }
            }
            // o motor encerra sozinho quando o app fecha; espera um pouco e finaliza o que sobrar
            for (int i = 0; i < 40; i++)
            {
                engines = Process.GetProcessesByName("CoinBankEngine");
                if (engines.Length == 0) break;
                if (i == 20) foreach (var e in engines) { try { e.Kill(); } catch { } }
                Thread.Sleep(250);
            }
            KillTunnel();
            Thread.Sleep(400);
            return true;
        }

        /// <summary>O tunel Cloudflare (runtime\cloudflared.exe) do CoinBank: fecha para liberar o arquivo.</summary>
        public static void KillTunnel()
        {
            foreach (var p in Process.GetProcessesByName("cloudflared"))
            {
                try
                {
                    string f = null;
                    try { f = p.MainModule.FileName; } catch { f = null; }
                    if (f != null && f.IndexOf("CoinBank", StringComparison.OrdinalIgnoreCase) >= 0) { p.Kill(); p.WaitForExit(3000); }
                }
                catch { }
            }
        }

        /// <summary>Libera o motor no Firewall do Windows (entrada TCP/UDP: rede local e rede hospedada). Pede administrador (UAC).</summary>
        public static bool AllowFirewall(string engineExe, bool add)
        {
            try
            {
                string name = "Coin Bank";
                string cmd = "/c netsh advfirewall firewall delete rule name=\"" + name + "\" >nul 2>&1";
                if (add) cmd += " & netsh advfirewall firewall add rule name=\"" + name + "\" dir=in action=allow program=\"" + engineExe + "\" enable=yes profile=any";
                var psi = new ProcessStartInfo("cmd.exe", cmd) { UseShellExecute = true, Verb = "runas", WindowStyle = ProcessWindowStyle.Hidden };
                var p = Process.Start(psi);
                if (p != null) p.WaitForExit(60000);
                return p != null && p.ExitCode == 0;
            }
            catch { return false; }   // o usuario recusou o UAC: a carteira funciona igual (so a rede local/hospedada fica sem entrada)
        }

        public static void CreateShortcut(string lnk, string target, string workDir, string description)
        {
            var t = Type.GetTypeFromProgID("WScript.Shell");
            if (t == null) return;
            object shell = Activator.CreateInstance(t);
            try
            {
                object sc = t.InvokeMember("CreateShortcut", BindingFlags.InvokeMethod, null, shell, new object[] { lnk });
                var st = sc.GetType();
                st.InvokeMember("TargetPath", BindingFlags.SetProperty, null, sc, new object[] { target });
                st.InvokeMember("WorkingDirectory", BindingFlags.SetProperty, null, sc, new object[] { workDir });
                st.InvokeMember("Description", BindingFlags.SetProperty, null, sc, new object[] { description });
                st.InvokeMember("IconLocation", BindingFlags.SetProperty, null, sc, new object[] { target + ",0" });
                st.InvokeMember("Save", BindingFlags.InvokeMethod, null, sc, null);
                System.Runtime.InteropServices.Marshal.FinalReleaseComObject(sc);
            }
            finally { System.Runtime.InteropServices.Marshal.FinalReleaseComObject(shell); }
        }

        public static void TryDelete(string f) { try { if (File.Exists(f)) File.Delete(f); } catch { } }

        public static void SetRun(string exe, bool on)
        {
            try
            {
                using (var k = Registry.CurrentUser.CreateSubKey(@"Software\Microsoft\Windows\CurrentVersion\Run"))
                {
                    if (k == null) return;
                    if (on) k.SetValue("CoinBank", "\"" + exe + "\" --minimized");
                    else k.DeleteValue("CoinBank", false);
                }
            }
            catch { }
        }

        /// <summary>Grava a escolha "iniciar com o Windows" na configuracao do app (preservando o resto).</summary>
        public static void SetAppAutoStart(bool on)
        {
            try
            {
                Directory.CreateDirectory(DataDir);
                var f = Path.Combine(DataDir, "config.json");
                var js = new JavaScriptSerializer();
                js.MaxJsonLength = int.MaxValue;
                Dictionary<string, object> d = null;
                if (File.Exists(f))
                {
                    try { d = js.DeserializeObject(File.ReadAllText(f, Encoding.UTF8)) as Dictionary<string, object>; } catch { d = null; }
                }
                if (d == null) d = new Dictionary<string, object>();
                d["autoStart"] = on;
                File.WriteAllText(f, js.Serialize(d), new UTF8Encoding(false));
            }
            catch { }
        }

        public static long DirSizeKb(string dir)
        {
            long n = 0;
            try { foreach (var f in Directory.GetFiles(dir, "*", SearchOption.AllDirectories)) n += new FileInfo(f).Length; } catch { }
            return n / 1024;
        }
    }

    // ─────────────────────────── janela do instalador ───────────────────────────
    class SetupForm : Form
    {
        static readonly Color Bg = Color.FromArgb(15, 17, 21);
        static readonly Color Surface = Color.FromArgb(24, 27, 34);
        static readonly Color Muted = Color.FromArgb(154, 163, 178);
        static readonly Color Accent = Color.FromArgb(59, 130, 246);

        readonly RadioButton rb64, rb32;
        readonly TextBox dirBox;
        readonly CheckBox cbDesktop, cbAutostart, cbLaunch, cbWebView, cbFirewall;
        readonly Label wvLabel, status;
        readonly ProgressBar bar;
        readonly Button btnInstall, btnCancel, btnBrowse;
        readonly Panel optionsPanel;
        bool done, busy;
        string installedExe;

        public SetupForm()
        {
            Text = "Instalar Coin Bank " + Program.Version;
            AutoScaleMode = AutoScaleMode.Dpi;
            AutoScaleDimensions = new SizeF(96f, 96f);
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false;
            StartPosition = FormStartPosition.CenterScreen;
            ClientSize = new Size(640, 590);
            BackColor = Bg;
            ForeColor = Color.White;
            Font = new Font("Segoe UI", 9.75f);
            try { Icon = Icon.ExtractAssociatedIcon(Application.ExecutablePath); } catch { }

            var logo = new PictureBox { Location = new Point(26, 22), Size = new Size(56, 56), SizeMode = PictureBoxSizeMode.Zoom };
            try { var st = Assembly.GetExecutingAssembly().GetManifestResourceStream("CoinBank.icon.png"); if (st != null) logo.Image = Image.FromStream(st); } catch { }
            Controls.Add(logo);
            Controls.Add(new Label { Text = "Coin Bank para Windows", Location = new Point(94, 24), AutoSize = true, Font = new Font("Segoe UI Semibold", 16f) });
            Controls.Add(new Label { Text = "Nuvem descentralizada e criptografada · versão " + Program.Version, Location = new Point(96, 56), AutoSize = true, ForeColor = Muted });

            optionsPanel = new Panel { Location = new Point(26, 96), Size = new Size(588, 390), BackColor = Bg };
            Controls.Add(optionsPanel);

            bool os64 = Environment.Is64BitOperatingSystem;
            optionsPanel.Controls.Add(Title("Qual versão instalar?", 0));
            optionsPanel.Controls.Add(new Label
            {
                Text = "Este Windows é " + (os64 ? "64 bits." : "32 bits — só a versão 32 bits funciona nele."),
                Location = new Point(0, 24), AutoSize = true, ForeColor = Muted
            });
            rb64 = new RadioButton
            {
                Text = "64 bits (x64)" + (os64 ? "  — recomendada para este PC" : "  — não suportada neste Windows"),
                Location = new Point(4, 50), AutoSize = true, Enabled = os64, Checked = os64
            };
            rb32 = new RadioButton
            {
                Text = "32 bits (x86)  — Windows 32 bits ou PCs antigos",
                Location = new Point(4, 78), AutoSize = true, Checked = !os64
            };
            optionsPanel.Controls.Add(rb64);
            optionsPanel.Controls.Add(rb32);

            optionsPanel.Controls.Add(Title("Pasta de instalação", 120));
            dirBox = new TextBox { Location = new Point(0, 146), Width = 476, BackColor = Surface, ForeColor = Color.White, BorderStyle = BorderStyle.FixedSingle, Text = Sys.DefaultDir };
            btnBrowse = Btn("Procurar…", false);
            btnBrowse.Location = new Point(486, 143);
            btnBrowse.Width = 100;
            btnBrowse.Click += delegate
            {
                using (var d = new FolderBrowserDialog { Description = "Escolha onde instalar o Coin Bank", ShowNewFolderButton = true })
                {
                    if (d.ShowDialog(this) == DialogResult.OK)
                    {
                        var p = d.SelectedPath;
                        if (!p.TrimEnd('\\').EndsWith("CoinBank", StringComparison.OrdinalIgnoreCase)) p = Path.Combine(p, "CoinBank");
                        dirBox.Text = p;
                    }
                }
            };
            optionsPanel.Controls.Add(dirBox);
            optionsPanel.Controls.Add(btnBrowse);

            optionsPanel.Controls.Add(Title("Opções", 190));
            cbDesktop = Check("Criar atalho na Área de Trabalho", 216, true);
            cbAutostart = Check("Iniciar com o Windows (recomendado: fica na bandeja com o resgate automático e os avisos)", 242, true);
            cbFirewall = Check("Liberar a rede local e a rede hospedada no Firewall do Windows (pede administrador)", 268, true);
            cbLaunch = Check("Abrir o Coin Bank ao terminar", 294, true);
            optionsPanel.Controls.Add(cbDesktop);
            optionsPanel.Controls.Add(cbAutostart);
            optionsPanel.Controls.Add(cbFirewall);
            optionsPanel.Controls.Add(cbLaunch);

            var wv = Sys.WebView2Version();
            wvLabel = new Label { Location = new Point(0, 332), Size = new Size(588, 22), ForeColor = wv != null ? Color.FromArgb(52, 211, 153) : Color.FromArgb(251, 191, 36) };
            wvLabel.Text = wv != null ? "✓ WebView2 Runtime da Microsoft já instalado (" + wv + ")." : "WebView2 Runtime da Microsoft não encontrado (o Coin Bank precisa dele).";
            cbWebView = Check("Baixar e instalar o WebView2 Runtime agora (gratuito, da Microsoft)", 356, wv == null);
            cbWebView.Visible = wv == null;
            optionsPanel.Controls.Add(wvLabel);
            optionsPanel.Controls.Add(cbWebView);

            status = new Label { Location = new Point(26, 498), Size = new Size(588, 22), ForeColor = Muted, Text = "Pronto para instalar." };
            bar = new ProgressBar { Location = new Point(26, 522), Size = new Size(588, 8), Style = ProgressBarStyle.Continuous, Visible = false };
            Controls.Add(status);
            Controls.Add(bar);

            btnCancel = Btn("Cancelar", false);
            btnCancel.Location = new Point(404, 542);
            btnCancel.Click += delegate { Close(); };
            btnInstall = Btn("Instalar", true);
            btnInstall.Location = new Point(514, 542);
            btnInstall.Click += delegate { OnInstallClick(); };
            Controls.Add(btnCancel);
            Controls.Add(btnInstall);
            AcceptButton = btnInstall;

            // atualizacao: reaproveita pasta e versao da instalacao anterior
            try
            {
                using (var k = Registry.CurrentUser.OpenSubKey(Program.UninstKey))
                {
                    if (k != null)
                    {
                        var loc = k.GetValue("InstallLocation") as string;
                        var arch = k.GetValue("CoinBankArch") as string;
                        if (!string.IsNullOrEmpty(loc)) dirBox.Text = loc;
                        if (arch == "x86") rb32.Checked = true;
                        else if (arch == "x64" && os64) rb64.Checked = true;
                        btnInstall.Text = "Atualizar";
                        status.Text = "Coin Bank já instalado: será atualizado (contas salvas, configurações e a rede hospedada são mantidas).";
                    }
                }
            }
            catch { }
        }

        protected override void OnHandleCreated(EventArgs e)
        {
            base.OnHandleCreated(e);
            try { int on = 1; if (DwmSetWindowAttribute(Handle, 20, ref on, 4) != 0) DwmSetWindowAttribute(Handle, 19, ref on, 4); } catch { }
        }

        [System.Runtime.InteropServices.DllImport("dwmapi.dll")]
        static extern int DwmSetWindowAttribute(IntPtr hwnd, int attr, ref int attrValue, int attrSize);

        static Label Title(string t, int y)
        {
            return new Label { Text = t, Location = new Point(0, y), AutoSize = true, Font = new Font("Segoe UI Semibold", 10.5f) };
        }

        static CheckBox Check(string t, int y, bool on)
        {
            return new CheckBox { Text = t, Location = new Point(4, y), AutoSize = true, Checked = on };
        }

        static Button Btn(string t, bool primary)
        {
            var b = new Button
            {
                Text = t, Size = new Size(100, 34), FlatStyle = FlatStyle.Flat, Cursor = Cursors.Hand,
                BackColor = primary ? Accent : Surface, ForeColor = Color.White
            };
            b.FlatAppearance.BorderColor = primary ? Accent : Color.FromArgb(45, 52, 66);
            return b;
        }

        void SetStatus(string t, int pct)
        {
            if (InvokeRequired) { BeginInvoke((Action)delegate { SetStatus(t, pct); }); return; }
            status.Text = t;
            if (pct >= 0) { bar.Visible = true; bar.Value = Math.Max(0, Math.Min(100, pct)); }
        }

        void OnInstallClick()
        {
            if (done)
            {
                if (cbLaunch.Checked && installedExe != null)
                {
                    try { Process.Start(new ProcessStartInfo(installedExe) { UseShellExecute = true, WorkingDirectory = Path.GetDirectoryName(installedExe) }); } catch { }
                }
                Close();
                return;
            }
            var dir = (dirBox.Text ?? "").Trim();
            if (dir.Length < 4 || !Path.IsPathRooted(dir)) { MessageBox.Show(this, "Escolha uma pasta de instalação válida.", "CoinBank"); return; }
            if (!Sys.CloseRunningApp(this)) return;
            string arch = rb64.Checked ? "x64" : "x86";
            bool desktop = cbDesktop.Checked, autostart = cbAutostart.Checked, wv = cbWebView.Visible && cbWebView.Checked, fw = cbFirewall.Checked;
            busy = true;
            optionsPanel.Enabled = false;
            btnInstall.Enabled = false;
            btnCancel.Enabled = false;
            var t = new Thread(delegate ()
            {
                string err = null;
                try { Install(dir, arch, desktop, autostart, wv, fw); }
                catch (UnauthorizedAccessException) { err = "Sem permissão para gravar em:\n" + dir + "\n\nEscolha uma pasta do seu usuário (o padrão) ou execute o instalador como administrador."; }
                catch (Exception e) { err = e.Message; }
                try { BeginInvoke((Action)delegate { Finished(err); }); } catch { }
            });
            t.IsBackground = true;
            t.Start();
        }

        void Install(string dir, string arch, bool desktop, bool autostart, bool installWebView, bool firewall)
        {
            SetStatus("Preparando a pasta…", 5);
            Directory.CreateDirectory(dir);
            // motor e interface da versao anterior saem antes (nada de arquivo velho misturado)
            foreach (var sub in new[] { "engine", "runtime" })
            {
                var d = Path.Combine(dir, sub);
                for (int tries = 0; tries < 10 && Directory.Exists(d); tries++)
                {
                    try { Directory.Delete(d, true); } catch { Thread.Sleep(500); }
                }
            }
            // copia os arquivos da versao escolhida
            using (var st = Assembly.GetExecutingAssembly().GetManifestResourceStream("CoinBank.payload-" + arch + ".zip"))
            {
                if (st == null) throw new Exception("Pacote da versão " + arch + " não está dentro do instalador. Recompile com COMPILAR.bat.");
                using (var zip = new ZipArchive(st, ZipArchiveMode.Read))
                {
                    int i = 0, n = Math.Max(1, zip.Entries.Count);
                    foreach (var e in zip.Entries)
                    {
                        i++;
                        var rel = e.FullName.Replace('/', '\\');
                        if (rel.Length == 0 || rel.EndsWith("\\")) continue;
                        var dest = Path.GetFullPath(Path.Combine(dir, rel));
                        if (!dest.StartsWith(Path.GetFullPath(dir), StringComparison.OrdinalIgnoreCase)) continue;
                        Directory.CreateDirectory(Path.GetDirectoryName(dest));
                        SetStatus("Copiando " + rel + "…", 5 + 55 * i / n);
                        for (int tries = 0; ; tries++)
                        {
                            try { e.ExtractToFile(dest, true); break; }
                            catch (IOException) { if (tries >= 10) throw; Thread.Sleep(500); } // arquivo ainda preso pelo app que acabou de fechar
                        }
                    }
                }
            }
            var exe = Path.Combine(dir, "CoinBank.exe");
            if (!File.Exists(exe)) throw new Exception("CoinBank.exe não foi copiado.");
            var engineExe = Path.Combine(Path.Combine(dir, "runtime"), "CoinBankEngine.exe");
            if (!File.Exists(engineExe) || !File.Exists(Path.Combine(Path.Combine(dir, "engine"), "engine.js")))
                throw new Exception("O motor (runtime\\CoinBankEngine.exe / engine\\engine.js) não foi copiado.");

            SetStatus("Registrando o desinstalador…", 70);
            var uninst = Path.Combine(dir, "Uninstall.exe");
            try { File.Copy(Application.ExecutablePath, uninst, true); } catch { }
            using (var k = Registry.CurrentUser.CreateSubKey(Program.UninstKey))
            {
                k.SetValue("DisplayName", "Coin Bank");
                k.SetValue("DisplayVersion", Program.Version);
                k.SetValue("Publisher", "CoinBank");
                k.SetValue("DisplayIcon", exe + ",0");
                k.SetValue("InstallLocation", dir);
                k.SetValue("UninstallString", "\"" + uninst + "\" /uninstall");
                k.SetValue("QuietUninstallString", "\"" + uninst + "\" /uninstall");
                k.SetValue("NoModify", 1, RegistryValueKind.DWord);
                k.SetValue("NoRepair", 1, RegistryValueKind.DWord);
                k.SetValue("EstimatedSize", (int)Math.Min(int.MaxValue, Sys.DirSizeKb(dir)), RegistryValueKind.DWord);
                k.SetValue("CoinBankArch", arch);
                k.SetValue("InstallDate", DateTime.Now.ToString("yyyyMMdd"));
            }

            SetStatus("Criando atalhos…", 78);
            try { Sys.CreateShortcut(Sys.StartMenuLink, exe, dir, "Coin Bank - carteira da moeda Coin"); } catch { }
            if (desktop) { try { Sys.CreateShortcut(Sys.DesktopLink, exe, dir, "Coin Bank - carteira da moeda Coin"); } catch { } }
            else Sys.TryDelete(Sys.DesktopLink);
            Sys.SetAppAutoStart(autostart);
            Sys.SetRun(exe, autostart);

            if (firewall)
            {
                SetStatus("Liberando a rede local no Firewall do Windows (confirme a permissão)…", 80);
                bool ok = Sys.AllowFirewall(engineExe, true);
                try { using (var k = Registry.CurrentUser.CreateSubKey(Program.UninstKey)) k.SetValue("CoinBankFirewall", ok ? 1 : 0, RegistryValueKind.DWord); } catch { }
            }

            if (installWebView && Sys.WebView2Version() == null)
            {
                SetStatus("Baixando o WebView2 Runtime da Microsoft…", 82);
                var tmp = Path.Combine(Path.GetTempPath(), "MicrosoftEdgeWebview2Setup.exe");
                bool ok = false;
                try
                {
                    using (var wc = new WebClient()) wc.DownloadFile("https://go.microsoft.com/fwlink/p/?LinkId=2124703", tmp);
                    SetStatus("Instalando o WebView2 Runtime (pode pedir permissão)…", 90);
                    var p = Process.Start(new ProcessStartInfo(tmp, "/silent /install") { UseShellExecute = true });
                    if (p != null) p.WaitForExit(10 * 60 * 1000);
                    ok = Sys.WebView2Version() != null;
                }
                catch { ok = false; }
                if (!ok)
                {
                    BeginInvoke((Action)delegate
                    {
                        MessageBox.Show(this, "Não consegui instalar o WebView2 automaticamente.\nVou abrir a página da Microsoft para você baixar e instalar.", "CoinBank");
                        try { Process.Start(new ProcessStartInfo("https://developer.microsoft.com/microsoft-edge/webview2/") { UseShellExecute = true }); } catch { }
                    });
                }
            }
            installedExe = exe;
            SetStatus("Concluído.", 100);
        }

        // fechar no meio da copia deixaria a instalacao pela metade (a thread e de fundo)
        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            if (busy && e.CloseReason == CloseReason.UserClosing) { e.Cancel = true; return; }
            base.OnFormClosing(e);
        }

        void Finished(string err)
        {
            busy = false;
            if (err != null)
            {
                MessageBox.Show(this, "A instalação não terminou:\n\n" + err, "CoinBank", MessageBoxButtons.OK, MessageBoxIcon.Error);
                optionsPanel.Enabled = true;
                btnInstall.Enabled = true;
                btnCancel.Enabled = true;
                SetStatus("Corrija e tente de novo.", -1);
                return;
            }
            done = true;
            status.Text = "Pronto! O Coin Bank fica na bandeja, ao lado do relógio — clique no ícone para abrir.";
            btnInstall.Text = "Concluir";
            btnInstall.Enabled = true;
            btnCancel.Visible = false;
            foreach (Control c in optionsPanel.Controls) c.Enabled = c == cbLaunch;
            optionsPanel.Enabled = true;
        }
    }

    // ─────────────────────────── desinstalador ───────────────────────────
    static class Uninstaller
    {
        static string InstallDir()
        {
            try
            {
                using (var k = Registry.CurrentUser.OpenSubKey(Program.UninstKey))
                {
                    var v = k == null ? null : k.GetValue("InstallLocation") as string;
                    if (!string.IsNullOrEmpty(v)) return v;
                }
            }
            catch { }
            return Path.GetDirectoryName(Application.ExecutablePath);
        }

        /// <summary>Chamado por "Aplicativos instalados": confirma e se copia para a pasta temporaria (para poder apagar a pasta do app).</summary>
        public static void Start()
        {
            var dir = InstallDir();
            if (MessageBox.Show("Remover o Coin Bank deste computador?\n\nPasta: " + dir, "Desinstalar Coin Bank",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes) return;
            bool purge = MessageBox.Show(
                "Apagar também as configurações, as contas salvas no app e o banco da rede hospedada neste PC?\n\n" +
                "(%LOCALAPPDATA%\\CoinBank)\n" +
                "Os coins ficam nas redes (servidores), não neste PC: nada do seu saldo é apagado.",
                "Desinstalar Coin Bank", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes;
            if (!Sys.CloseRunningApp(null)) return;
            try
            {
                using (var k = Registry.CurrentUser.OpenSubKey(Program.UninstKey))
                    if (k != null && k.GetValue("CoinBankFirewall") is int && (int)k.GetValue("CoinBankFirewall") == 1)
                        Sys.AllowFirewall(Path.Combine(Path.Combine(dir, "runtime"), "CoinBankEngine.exe"), false);
            }
            catch { }
            var tmp = Path.Combine(Path.GetTempPath(), "CoinBank-Uninstall-" + Guid.NewGuid().ToString("N").Substring(0, 8) + ".exe");
            File.Copy(Application.ExecutablePath, tmp, true);
            Process.Start(new ProcessStartInfo(tmp, "/uninstall-run \"" + dir + "\"" + (purge ? " /purge" : "")) { UseShellExecute = false });
        }

        public static void Run(string dir, bool purge)
        {
            Thread.Sleep(1200); // deixa o Uninstall.exe original terminar
            foreach (var p in Process.GetProcessesByName("CoinBank")) { try { p.Kill(); p.WaitForExit(5000); } catch { } }
            foreach (var p in Process.GetProcessesByName("CoinBankEngine")) { try { p.Kill(); p.WaitForExit(5000); } catch { } }
            Sys.KillTunnel();
            string exe = Path.Combine(dir, "CoinBank.exe");
            Sys.SetRun(exe, false);
            Sys.TryDelete(Sys.StartMenuLink);
            Sys.TryDelete(Sys.DesktopLink);
            try { Registry.CurrentUser.DeleteSubKeyTree(Program.UninstKey, false); } catch { }
            try { Registry.CurrentUser.DeleteSubKeyTree(@"Software\Classes\coinbank", false); } catch { }   // links coinbank://
            bool leftovers = false;
            foreach (var name in InstalledFiles)
            {
                var f = Path.Combine(dir, name);
                for (int tries = 0; tries < 10 && File.Exists(f); tries++)
                {
                    try { File.Delete(f); }
                    catch { Thread.Sleep(500); }
                }
                if (File.Exists(f)) leftovers = true;
            }
            foreach (var sub in InstalledDirs)
            {
                var d = Path.Combine(dir, sub);
                for (int tries = 0; tries < 10 && Directory.Exists(d); tries++)
                {
                    try { Directory.Delete(d, true); }
                    catch { Thread.Sleep(500); }
                }
                if (Directory.Exists(d)) leftovers = true;
            }
            try { if (Directory.Exists(dir) && Directory.GetFileSystemEntries(dir).Length == 0) Directory.Delete(dir); } catch { }
            if (purge) { try { if (Directory.Exists(Sys.DataDir)) Directory.Delete(Sys.DataDir, true); } catch { leftovers = true; } }
            MessageBox.Show(leftovers ? "Coin Bank removido. Alguns arquivos estavam em uso e podem ser apagados manualmente:\n" + dir : "Coin Bank removido.",
                "Desinstalar Coin Bank", MessageBoxButtons.OK, MessageBoxIcon.Information);
            // apaga esta copia temporaria depois de sair
            try
            {
                Process.Start(new ProcessStartInfo("cmd.exe", "/c ping 127.0.0.1 -n 3 > nul & del /f /q \"" + Application.ExecutablePath + "\"")
                { CreateNoWindow = true, UseShellExecute = false, WindowStyle = ProcessWindowStyle.Hidden });
            }
            catch { }
        }

        /// <summary>So os arquivos que o instalador coloca; a pasta so e removida se ficar vazia.</summary>
        static readonly string[] InstalledFiles = {
            "CoinBank.exe", "CoinBank.exe.config", "Microsoft.Web.WebView2.Core.dll", "Microsoft.Web.WebView2.WinForms.dll",
            "WebView2Loader.dll", "LEIA-ME.txt", "Uninstall.exe"
        };

        /// <summary>Pastas do motor (Node.js + engine) que o instalador coloca.</summary>
        static readonly string[] InstalledDirs = { "runtime", "engine" };
    }
}
