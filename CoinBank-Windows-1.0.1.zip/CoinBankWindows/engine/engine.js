'use strict';
/**
 * Coin Bank para Windows — motor (Node.js, roda escondido ao lado do CoinBank.exe).
 *
 *  • serve a interface interna em http://127.0.0.1:<porta>/app/ (janela e painel da bandeja) + documentos offline (/terms/…)
 *  • API de controle /app/api/* (só com o token que o CoinBank.exe gerou)
 *  • contas por rede (rede principal bank.foxsrv.net, outras redes e a rede hospedada neste PC), sessões e senhas
 *    salvas cifradas com a chave protegida pelo Windows (DPAPI, só este usuário abre)
 *  • vigia saldo, extrato e cobranças → avisos na bandeja (recebidos, enviados, resgate, cobranças) em todas as redes
 *  • resgate automático em todas as redes em que você entrou
 *  • rede local (UDP 26452, o mesmo protocolo do app do celular): pessoas por perto, cobranças e redes hospedadas
 *  • rede hospedada: o servidor Coin Bank completo embutido (server/), na rede local e na internet pelo túnel Cloudflare
 */
const http = require('http');
const fs = require('fs');
const path = require('path');
const os = require('os');
const crypto = require('crypto');
const dgram = require('dgram');
const { spawn } = require('child_process');

// ───────────────────────── argumentos ─────────────────────────
const ARGS = (() => {
  const a = process.argv.slice(2), o = {};
  for (let i = 0; i < a.length; i++) if (a[i].startsWith('--')) { const k = a[i].slice(2); const v = a[i + 1] && !a[i + 1].startsWith('--') ? a[++i] : '1'; o[k] = v; }
  return o;
})();
const APP_VERSION = ARGS['app-version'] || '1.0.0';
const DATA = path.resolve(ARGS.data || path.join(os.homedir(), 'AppData', 'Local', 'CoinBank'));
const TOKEN = ARGS.token || crypto.randomBytes(18).toString('base64url');
const APP_DIR = path.resolve(__dirname, '..');
const UI_DIR = path.join(__dirname, 'ui');
const SITE_DIR = path.join(__dirname, 'site');
const MAIN_URL = 'https://bank.foxsrv.net';
const NEAR_PORT = 26452;
fs.mkdirSync(DATA, { recursive: true });

// ───────────────────────── log ─────────────────────────
const LOG_FILE = path.join(DATA, 'engine.log');
function log(...a) {
  const line = new Date().toISOString().replace('T', ' ').slice(0, 19) + '  ' + a.map((x) => (x instanceof Error ? x.stack || x.message : typeof x === 'string' ? x : JSON.stringify(x))).join(' ');
  try {
    const st = fs.statSync(LOG_FILE);
    if (st.size > 2 * 1024 * 1024) fs.renameSync(LOG_FILE, LOG_FILE + '.1');
  } catch {}
  try { fs.appendFileSync(LOG_FILE, line + '\n'); } catch {}
}
process.on('uncaughtException', (e) => log('erro não tratado:', e));
process.on('unhandledRejection', (e) => log('promise rejeitada:', e));

// se o CoinBank.exe morrer, o pipe do stdin fecha e o motor encerra sozinho
if (ARGS.parent) { process.stdin.on('end', () => shutdown('pai encerrou')); process.stdin.on('error', () => {}); process.stdin.resume(); }

// ───────────────────────── arquivos e segredos ─────────────────────────
const CONFIG_FILE = path.join(DATA, 'config.json');
const SECRETS_FILE = path.join(DATA, 'secrets.bin');
const readJson = (f, def) => { try { return JSON.parse(fs.readFileSync(f, 'utf8')); } catch { return def; } };
const writeJson = (f, v) => { const t = f + '.tmp'; fs.writeFileSync(t, JSON.stringify(v, null, 2)); fs.renameSync(t, f); };

const SEAL = (() => {
  if (process.env.COINBANK_SEAL) { try { const k = Buffer.from(process.env.COINBANK_SEAL, 'base64'); if (k.length === 32) return k; } catch {} }
  // fora do app (testes): chave local
  const f = path.join(DATA, '.dev-seal');
  try { const k = fs.readFileSync(f); if (k.length === 32) return k; } catch {}
  const k = crypto.randomBytes(32); try { fs.writeFileSync(f, k); } catch {} return k;
})();
function seal(obj) {
  const iv = crypto.randomBytes(12), c = crypto.createCipheriv('aes-256-gcm', SEAL, iv);
  const body = Buffer.concat([c.update(JSON.stringify(obj), 'utf8'), c.final()]);
  return Buffer.concat([Buffer.from('CB1'), iv, c.getAuthTag(), body]);
}
function unseal(buf) {
  if (!buf || buf.length < 31 || buf.slice(0, 3).toString() !== 'CB1') return null;
  const d = crypto.createDecipheriv('aes-256-gcm', SEAL, buf.slice(3, 15)); d.setAuthTag(buf.slice(15, 31));
  return JSON.parse(Buffer.concat([d.update(buf.slice(31)), d.final()]).toString('utf8'));
}

const DEFAULT_SETTINGS = {
  autoStart: true, notify: true, notifyOutgoing: true, autoClaim: true, visible: true, lang: 'auto', theme: 'auto',
  preventSleep: false, hideBalance: false, hideCard: true, sound: true
};
const DEFAULT_HOST = { enabled: false, name: 'Minha rede', port: 26450, cloudflare: false, claimAmount: '0.00000012', claimCooldownMs: 3600000, transferCooldownMs: 1000 };

let cfg = readJson(CONFIG_FILE, {});
cfg.settings = Object.assign({}, DEFAULT_SETTINGS, cfg.settings || {});
cfg.host = Object.assign({}, DEFAULT_HOST, cfg.host || {});
cfg.servers = Array.isArray(cfg.servers) ? cfg.servers.filter((s) => s && s.id && s.url) : [];
if (!cfg.servers.find((s) => s.id === 'main')) cfg.servers.unshift({ id: 'main', name: 'Coin Bank', url: MAIN_URL, kind: 'main' });
cfg.netcfg = cfg.netcfg || {};
cfg.active = cfg.active || 'main';
cfg.device = cfg.device || crypto.randomBytes(6).toString('hex');
let saveTimer = null;
function saveConfig() { clearTimeout(saveTimer); saveTimer = setTimeout(() => { try { writeJson(CONFIG_FILE, cfg); } catch (e) { log('config:', e.message); } }, 150); }
saveConfig();

let secrets = (() => { try { return unseal(fs.readFileSync(SECRETS_FILE)) || {}; } catch (e) { if (fs.existsSync(SECRETS_FILE)) log('segredos ilegíveis (outra conta do Windows?):', e.message); return {}; } })();
secrets.sessions = secrets.sessions || {};
secrets.accounts = secrets.accounts || {};
function saveSecrets() { try { const t = SECRETS_FILE + '.tmp'; fs.writeFileSync(t, seal(secrets)); fs.renameSync(t, SECRETS_FILE); } catch (e) { log('segredos:', e.message); } }

let hostInfo = { machine: os.hostname(), user: os.userInfo().username, dark: false, power: {} };

// ───────────────────────── idioma e formatação ─────────────────────────
const sysLang = (() => { try { return (Intl.DateTimeFormat().resolvedOptions().locale || '').toLowerCase().startsWith('pt') ? 'pt' : 'en'; } catch { return 'pt'; } })();
const lang = () => (cfg.settings.lang === 'pt' || cfg.settings.lang === 'en' ? cfg.settings.lang : sysLang);
const T = (pt, en) => (lang() === 'pt' ? pt : en);
function netCfg(sid) { const c = cfg.netcfg[sid] || {}; return { api: Number.isInteger(c.api) ? c.api : 8, disp: Number.isInteger(c.disp) ? c.disp : 8, coin: c.coin || 'coins' }; }
/** unidades (menor unidade da moeda) → texto com as casas exibidas da rede: o ponto decimal só anda a partir da direita (igual ao site e ao celular) */
function fmt(sats, sid) {
  const d = Math.max(0, Math.min(18, netCfg(sid).disp)); let v = BigInt(Math.trunc(Number(sats) || 0));
  const neg = v < 0n; if (neg) v = -v;
  const base = 10n ** BigInt(d);
  const int = (v / base).toString(), frac = d ? (v % base).toString().padStart(d, '0') : '';
  const sep = lang() === 'pt' ? ['.', ','] : [',', '.'];
  return (neg ? '−' : '') + int.replace(/\B(?=(\d{3})+(?!\d))/g, sep[0]) + (d ? sep[1] + frac : '');
}
/** "0.00000012" (API) → sats */
function parseApi(v, sid) {
  if (v === null || v === undefined || v === '') return null;
  const api = netCfg(sid).api; const s = String(v).trim(); if (!/^-?\d*([.,]\d*)?$/.test(s)) return null;
  const neg = s.startsWith('-'); const [a, b = ''] = s.replace('-', '').replace(',', '.').split('.');
  const n = BigInt(a || '0') * 10n ** BigInt(api) + BigInt((b + '0'.repeat(api)).slice(0, api) || '0');
  return Number(neg ? -n : n);
}

// ───────────────────────── eventos (avisos) ─────────────────────────
const events = []; let evSeq = 0;
function emit(kind, title, text, extra = {}) {
  const ev = Object.assign({ id: ++evSeq, ts: Date.now(), kind, title, text }, extra);
  events.push(ev); if (events.length > 300) events.splice(0, events.length - 300);
  if (!extra.silent) log('aviso:', kind, title, '—', text);
  return ev;
}

// ───────────────────────── redes ─────────────────────────
const serverById = (id) => (id === 'host' ? hostServer() : cfg.servers.find((s) => s.id === id)) || null;
const allServers = () => { const l = cfg.servers.slice(); const h = hostServer(); if (h) l.push(h); return l; };
function cleanUrl(u) {
  u = String(u || '').trim(); if (!u) return null;
  if (!/^https?:\/\//i.test(u)) u = (/^(localhost|127\.|10\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.)/.test(u) ? 'http://' : 'https://') + u;
  try { const x = new URL(u); return (x.protocol + '//' + x.host + x.pathname).replace(/\/+$/, ''); } catch { return null; }
}

async function rawCall(base, method, p, body, token, timeoutMs = 15000) {
  const headers = { Accept: 'application/json', 'User-Agent': `CoinBankWindows/${APP_VERSION}` };
  if (token) headers.Authorization = 'Bearer ' + token;
  let payload;
  if (body !== undefined && body !== null && method !== 'GET') { headers['Content-Type'] = 'application/json'; payload = JSON.stringify(body); }
  if (method === 'POST' && /\/(transfer|pay|bill\/pay)/.test(p)) headers['Idempotency-Key'] = crypto.randomUUID();
  const r = await fetch(base.replace(/\/+$/, '') + p, { method, headers, body: payload, signal: AbortSignal.timeout(timeoutMs) });
  const txt = await r.text(); let json = null;
  try { json = txt ? JSON.parse(txt) : {}; } catch { json = { error: 'BAD_RESPONSE', message: txt.slice(0, 200) }; }
  return { status: r.status, json };
}

/** chamada autenticada; se a sessão venceu e a senha está salva, entra de novo sozinho e repete */
async function netCall(sid, method, p, body, { auth = true, timeoutMs } = {}) {
  const sv = serverById(sid); if (!sv) return { status: 404, json: { error: 'SERVER_NOT_FOUND' } };
  const ses = secrets.sessions[sid];
  let r = await rawCall(sv.url, method, p, body, auth && ses ? ses.token : null, timeoutMs);
  if (auth && r.status === 401 && secrets.accounts[sid]) {
    const ok = await relogin(sid).catch(() => false);
    if (ok) r = await rawCall(sv.url, method, p, body, secrets.sessions[sid].token, timeoutMs);
  }
  if (auth && r.status === 401 && ses && !secrets.accounts[sid]) { delete secrets.sessions[sid]; saveSecrets(); }
  return r;
}

async function login(sid, username, password, remember) {
  const sv = serverById(sid); if (!sv) throw new Error('SERVER_NOT_FOUND');
  const r = await rawCall(sv.url, 'POST', '/api/login', { username, password });
  if (r.status === 429) throw new Error(r.json.error || 'IP_LOCKED');
  if (!r.json || !r.json.sessionCreated) throw new Error(T('Usuário ou senha incorretos.', 'Wrong username or password.'));
  secrets.sessions[sid] = { token: r.json.sessionId, userId: String(r.json.userId), username, at: Date.now() };
  if (remember) secrets.accounts[sid] = { username, password }; else delete secrets.accounts[sid];
  saveSecrets();
  resetWatch(sid);
  return secrets.sessions[sid];
}
async function relogin(sid) {
  const a = secrets.accounts[sid]; if (!a) return false;
  try { await login(sid, a.username, a.password, true); log('sessão renovada em', sid); return true; }
  catch (e) { log('não consegui renovar a sessão em', sid, e.message); return false; }
}

// ───────────────────────── vigia: saldo, extrato, cobranças, resgate automático ─────────────────────────
const watch = {}; // sid → estado
function resetWatch(sid) { watch[sid] = { seeded: false, bal: null, tx: new Set(), bills: new Set(), online: false, claimLeft: -1, claimAt: 0, cooldownMs: 0, claimSats: 0, lastPoll: 0, me: null, busy: false, failures: 0 }; }
function W(sid) { if (!watch[sid]) resetWatch(sid); return watch[sid]; }

async function pollServer(sid) {
  const ses = secrets.sessions[sid]; const w = W(sid);
  if (!ses || w.busy) return; w.busy = true; w.lastPoll = Date.now();
  const sv = serverById(sid); const net = sv ? sv.name : 'Coin';
  try {
    const me = await netCall(sid, 'GET', '/api/me', null, { timeoutMs: 10000 });
    if (me.status !== 200) { w.online = me.status < 500 && me.status !== 401 ? w.online : false; if (me.status === 401) w.online = true; return; }
    w.online = true; w.failures = 0; w.me = me.json;
    const bal = Number(me.json.sats);
    const cl = me.json.claim || {};
    w.claimLeft = Number(cl.cooldownRemainingMs ?? me.json.cooldownRemainingMs ?? 0); w.claimAt = Date.now();
    w.cooldownMs = Number(cl.cooldownMs ?? me.json.cooldownMs ?? 0); w.claimSats = Number(cl.claimAmountSats ?? 0);
    if (me.json.username && ses.username !== me.json.username) { ses.username = me.json.username; saveSecrets(); }
    const changed = w.bal === null || bal !== w.bal;
    w.bal = bal;
    if (changed || !w.seeded || Date.now() - (w.txAt || 0) > 60000) {
      w.txAt = Date.now();
      const tx = await netCall(sid, 'GET', '/api/transactions?page=1', null, { timeoutMs: 10000 });
      const list = tx.status === 200 && Array.isArray(tx.json.transactions) ? tx.json.transactions : [];
      for (const t of list.slice().reverse()) {
        if (w.tx.has(t.id)) continue; w.tx.add(t.id);
        if (!w.seeded) continue;
        const sats = Number(t.amountSats ?? parseApi(t.amount, sid));
        const out = String(t.from_id) === String(ses.userId);
        const route = 'tx:' + t.id + '@' + sid;
        if (out) {
          if (cfg.settings.notifyOutgoing) emit('outgoing', T(`Você enviou ${fmt(sats, sid)} ${netCfg(sid).coin}`, `You sent ${fmt(sats, sid)} ${netCfg(sid).coin}`), T(`Para ${t.to_id} · ${net}`, `To ${t.to_id} · ${net}`), { route, server: sid, sats });
        } else if (/^0+$/.test(String(t.from_id))) {
          emit('claim', T(`+${fmt(sats, sid)} ${netCfg(sid).coin} resgatados`, `+${fmt(sats, sid)} ${netCfg(sid).coin} claimed`), net, { route, server: sid, sats, silent: !!w.autoClaimed });
          w.autoClaimed = false;
        } else {
          emit('incoming', T(`Você recebeu ${fmt(sats, sid)} ${netCfg(sid).coin}`, `You received ${fmt(sats, sid)} ${netCfg(sid).coin}`), T(`De ${t.from_id} · ${net}`, `From ${t.from_id} · ${net}`), { route, server: sid, sats });
        }
      }
      if (w.tx.size > 500) w.tx = new Set([...w.tx].slice(-300));
      const bl = await netCall(sid, 'POST', '/api/bill/list', { page: 1 }, { timeoutMs: 10000 });
      const toPay = bl.status === 200 && Array.isArray(bl.json.toPay) ? bl.json.toPay : [];
      w.toPay = toPay.length;
      for (const b of toPay) {
        if (w.bills.has(b.id)) continue; w.bills.add(b.id);
        if (!w.seeded) continue;
        emit('bill', T('Nova cobrança para você', 'New bill for you'), T(`${fmt(b.amountSats, sid)} ${netCfg(sid).coin} para ${b.to_id} · ${net}`, `${fmt(b.amountSats, sid)} ${netCfg(sid).coin} to ${b.to_id} · ${net}`), { route: 'bill:' + b.id + '@' + sid, server: sid });
      }
      w.seeded = true;
    }
    await maybeAutoClaim(sid);
  } catch (e) {
    w.failures++; if (w.failures >= 2) w.online = false;
  } finally { w.busy = false; }
}

async function maybeAutoClaim(sid) {
  const w = W(sid);
  if (!cfg.settings.autoClaim || !secrets.sessions[sid] || w.claimLeft < 0) return;
  const left = w.claimLeft - (Date.now() - w.claimAt);
  if (left > 0) return;
  const r = await netCall(sid, 'POST', '/api/claim', {}, { timeoutMs: 15000 });
  if (r.status === 200 && r.json.success) {
    const sats = Number(r.json.claimedSats ?? parseApi(r.json.claimed, sid));
    const sv = serverById(sid);
    w.autoClaimed = true;
    emit('claim', T(`Resgate automático: +${fmt(sats, sid)} ${netCfg(sid).coin}`, `Auto-claim: +${fmt(sats, sid)} ${netCfg(sid).coin}`), sv ? sv.name : '', { route: 'claim', server: sid, sats, auto: true });
    w.claimLeft = Number(r.json.nextClaimInMs || w.cooldownMs || 3600000); w.claimAt = Date.now();
    if (r.json.txId) w.tx.add(r.json.txId);
    setTimeout(() => pollServer(sid), 400);
  } else if (r.status === 429) { w.claimLeft = Number(r.json.nextClaimInMs || 60000); w.claimAt = Date.now(); }
  else { w.claimLeft = 60000; w.claimAt = Date.now(); }
}

let pollTick = 0;
setInterval(() => {
  pollTick++;
  for (const sid of Object.keys(secrets.sessions)) {
    if (!serverById(sid)) continue;
    const w = W(sid);
    const every = sid === cfg.active ? 4000 : 15000;
    if (Date.now() - w.lastPoll >= every - 200) pollServer(sid);
  }
}, 1000).unref();

// ───────────────────────── rede local (pessoas por perto) ─────────────────────────
const peers = new Map(); // device → { id, ip, me, host, via, seen }
const inbox = []; // cobranças recebidas por perto
let udp = null, udpOk = false, lastWho = 0;

function lanAddrs() {
  const out = [];
  for (const [name, list] of Object.entries(os.networkInterfaces())) {
    for (const a of list || []) {
      if (a.family !== 'IPv4' && a.family !== 4) continue;
      if (a.internal) continue;
      const virt = /vethernet|virtualbox|vmware|hyper-v|wsl|docker|loopback|tailscale|zerotier|hamachi/i.test(name);
      const ip = a.address.split('.').map(Number), mask = (a.netmask || '255.255.255.0').split('.').map(Number);
      const bc = ip.map((x, i) => (x | (~mask[i] & 255))).join('.');
      const priv = /^(10\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.)/.test(a.address);
      out.push({ name, ip: a.address, broadcast: bc, score: (priv ? 2 : 0) + (virt ? -3 : 1) });
    }
  }
  return out.sort((a, b) => b.score - a.score);
}
const lanIp = () => { const l = lanAddrs(); return l.length ? l[0].ip : null; };

function meAnnounce() {
  if (!cfg.settings.visible) return null;
  const sid = cfg.active, ses = secrets.sessions[sid], sv = serverById(sid);
  if (!ses || !sv) return null;
  let net = sv.url;
  if (sid === 'host') net = hostPublicBase() || net;
  return { uid: ses.userId, name: ses.username || hostInfo.machine, net, netName: sv.name };
}
function hostAnnounce() {
  if (!host.running) return null;
  const url = host.tunnel || (cfg.host.cloudflare ? null : (lanIp() ? `http://${lanIp()}:${cfg.host.port}` : null));
  return url ? { name: cfg.host.name, url, cf: !!host.tunnel } : null;
}
const hello = () => ({ cb: 1, t: 'hi', d: cfg.device, me: meAnnounce(), host: hostAnnounce(), pc: true });

function udpSend(obj, ip) {
  if (!udp || !udpOk) return;
  const b = Buffer.from(JSON.stringify(obj));
  const targets = ip ? [ip] : [...new Set(lanAddrs().map((a) => a.broadcast).concat('255.255.255.255'))];
  for (const t of targets) { try { udp.send(b, NEAR_PORT, t); } catch {} }
}
function startUdp() {
  try {
    udp = dgram.createSocket({ type: 'udp4', reuseAddr: true });
    udp.on('error', (e) => { log('rede local (UDP):', e.message); udpOk = false; try { udp.close(); } catch {} udp = null; setTimeout(startUdp, 15000); });
    udp.on('message', (buf, rinfo) => {
      let o; try { o = JSON.parse(buf.toString('utf8')); } catch { return; }
      if (!o || o.cb !== 1 || !o.d || o.d === cfg.device) return;
      if (o.t === 'hi') offer(o.d, rinfo.address, o.me, o.host, o.pc);
      else if (o.t === 'who') udpSend(hello(), rinfo.address);
      else if (o.t === 'msg' && o.to === cfg.device) onNearMsg(o.d, rinfo.address, o.m || {});
    });
    udp.bind(NEAR_PORT, () => { try { udp.setBroadcast(true); } catch {} udpOk = true; log('rede local ouvindo na UDP', NEAR_PORT); udpSend({ cb: 1, t: 'who', d: cfg.device }); });
  } catch (e) { log('rede local:', e.message); setTimeout(startUdp, 15000); }
}
function offer(d, ip, me, hostAnn, pc) {
  const cur = peers.get(d) || { id: d, first: Date.now() };
  const isNew = !peers.has(d) || (!cur.me && me);
  cur.ip = ip; cur.me = me || null; cur.host = hostAnn || null; cur.pc = !!pc; cur.seen = Date.now(); cur.via = ['wifi'];
  peers.set(d, cur);
  if (isNew && me && me.name) emit('nearby', T(`${me.name} está por perto`, `${me.name} is nearby`), me.netName || '', { route: 'nearby', silent: true });
}
const recentMsgs = new Map();
function onNearMsg(from, ip, m) {
  // a mesma mensagem pode chegar por mais de um endereço de broadcast: ignora repetidas por 10 s
  const key = from + '|' + JSON.stringify(m); const now = Date.now();
  for (const [k, t] of recentMsgs) if (now - t > 10000) recentMsgs.delete(k);
  if (recentMsgs.has(key)) return; recentMsgs.set(key, now);
  const who = (m.fromMe && m.fromMe.name) || T('Alguém por perto', 'Someone nearby');
  const sv = cfg.servers.find((s) => cleanUrl(s.url) === cleanUrl(m.net));
  const sid = sv ? sv.id : null;
  const sats = sid ? parseApi(m.amount, sid) : parseApi(m.amount, 'main');
  const amt = sats ? `${fmt(sats, sid || 'main')} ${netCfg(sid || 'main').coin}` : T('valor livre', 'any amount');
  const item = { id: crypto.randomBytes(6).toString('hex'), ts: Date.now(), from, ip, who, msg: m };
  inbox.unshift(item); if (inbox.length > 30) inbox.pop();
  if (m.kind === 'bill') emit('bill', T(`${who} te enviou uma cobrança`, `${who} sent you a bill`), `${amt} · ${m.netName || ''}`, { route: 'near:' + item.id });
  else emit('charge', T(`${who} está cobrando você`, `${who} is charging you`), `${amt} · ${m.netName || ''}`, { route: 'near:' + item.id });
}
setInterval(() => {
  udpSend(hello());
  const now = Date.now();
  if (now - lastWho > 9000) { lastWho = now; udpSend({ cb: 1, t: 'who', d: cfg.device }); }
  for (const [k, p] of peers) if (now - p.seen > 16000) peers.delete(k);
}, 3000).unref();

// ───────────────────────── rede hospedada (servidor Coin Bank embutido) ─────────────────────────
const host = { running: false, starting: false, bank: null, error: null, tunnel: null, cf: null, cfState: 'off', cfError: null, startedAt: 0 };
const HOST_DIR = path.join(DATA, 'host');
function hostServer() {
  if (!cfg.host.enabled) return null;
  return { id: 'host', name: cfg.host.name || 'Minha rede', url: `http://127.0.0.1:${cfg.host.port}`, kind: 'host' };
}
function hostPublicBase() { return host.tunnel || (lanIp() ? `http://${lanIp()}:${cfg.host.port}` : `http://127.0.0.1:${cfg.host.port}`); }

async function startHost() {
  if (host.running || host.starting) return;
  host.starting = true; host.error = null;
  try {
    fs.mkdirSync(HOST_DIR, { recursive: true });
    process.env.COIN_BANK_NO_AUTOSTART = '1';
    const bank = host.bank || require('./server/index.js');
    host.bank = bank;
    const c = cfg.host;
    await bank.start({
      config: path.join(HOST_DIR, 'config.yml'),
      overrides: {
        system: { autostart: false, handle_signals: false, temp_dir: path.join(HOST_DIR, 'temp') },
        logging: { level: 'warn', timestamps: true },
        discord: { enabled: false },
        economy: { claim_amount: String(c.claimAmount || '0.00000012'), claim_cooldown_ms: Number(c.claimCooldownMs) || 3600000, transfer_cooldown_ms: Number(c.transferCooldownMs) || 1000 },
        api: { enabled: true, host: '0.0.0.0', port: Number(c.port) || 26450, public_url: hostPublicBase(), site_enabled: true },
        cloudflare: { tunnel: { enabled: false }, quick_tunnel: { enabled: false } },
        database: { file: path.join(HOST_DIR, 'coinbank.db'), backup: { enabled: true, dir: path.join(HOST_DIR, 'backups') } },
        dm_queue: { enabled: false },
        memory: { enabled: true, log_stats: false }
      }
    });
    if (!bank.api.getServer()) throw new Error(T(`a porta ${c.port} já está em uso`, `port ${c.port} is already in use`));
    host.running = true; host.startedAt = Date.now();
    log('rede hospedada ligada na porta', c.port);
    emit('host', T('Rede hospedada ligada', 'Hosted network on'), `${c.name} · ${hostPublicBase()}`, { route: 'host', silent: true });
    if (c.cloudflare) startTunnel();
  } catch (e) {
    host.error = e.message; log('rede hospedada não iniciou:', e);
    try { if (host.bank) await host.bank.stop('erro'); } catch {}
    emit('host_error', T('A rede hospedada não iniciou', 'The hosted network did not start'), e.message, { route: 'host' });
  } finally { host.starting = false; }
}
async function stopHost() {
  stopTunnel();
  if (host.bank && host.running) { try { await host.bank.stop('desligada'); } catch (e) { log('parar rede:', e.message); } }
  host.running = false;
}
async function restartHost() { await stopHost(); if (cfg.host.enabled) await startHost(); }
function hostStatus() {
  let info = null;
  try { if (host.running) info = host.bank.status(); } catch {}
  const lan = lanIp();
  return {
    enabled: !!cfg.host.enabled, running: host.running, starting: host.starting, error: host.error,
    config: cfg.host, lanUrl: lan ? `http://${lan}:${cfg.host.port}` : null, localUrl: `http://127.0.0.1:${cfg.host.port}`,
    tunnel: host.tunnel, cloudflare: { state: host.cfState, error: host.cfError, installed: !!cloudflaredPath() },
    publicUrl: host.running ? hostPublicBase() : null, uptime: host.running ? Date.now() - host.startedAt : 0,
    db: info && info.database ? info.database : null
  };
}

// túnel Cloudflare (https://*.trycloudflare.com, sem abrir porta no roteador)
function cloudflaredPath() {
  for (const f of [path.join(APP_DIR, 'runtime', 'cloudflared.exe'), path.join(DATA, 'cloudflared.exe')]) if (fs.existsSync(f)) return f;
  return null;
}
async function downloadCloudflared() {
  const name = process.arch === 'x64' ? 'cloudflared-windows-amd64.exe' : 'cloudflared-windows-386.exe';
  const dest = path.join(DATA, 'cloudflared.exe');
  host.cfState = 'downloading';
  const r = await fetch(`https://github.com/cloudflare/cloudflared/releases/latest/download/${name}`, { signal: AbortSignal.timeout(600000) });
  if (!r.ok) throw new Error('HTTP ' + r.status);
  const buf = Buffer.from(await r.arrayBuffer());
  if (buf.length < 5e6) throw new Error(T('arquivo do cloudflared incompleto', 'incomplete cloudflared download'));
  fs.writeFileSync(dest + '.part', buf); fs.renameSync(dest + '.part', dest);
  return dest;
}
let cfRestart = null, cfFails = 0;
async function startTunnel() {
  if (host.cf || !host.running) return;
  clearTimeout(cfRestart);
  let exe = cloudflaredPath();
  try { if (!exe) exe = await downloadCloudflared(); }
  catch (e) { host.cfState = 'error'; host.cfError = T('não consegui baixar o cloudflared: ', 'could not download cloudflared: ') + e.message; return; }
  host.cfState = 'starting'; host.cfError = null;
  const p = spawn(exe, ['tunnel', '--no-autoupdate', '--url', `http://127.0.0.1:${cfg.host.port}`], { windowsHide: true, stdio: ['ignore', 'pipe', 'pipe'] });
  host.cf = p;
  const onData = (d) => {
    const m = String(d).match(/https:\/\/[a-z0-9-]+\.trycloudflare\.com/i);
    if (m && host.tunnel !== m[0]) {
      host.tunnel = m[0]; host.cfState = 'on'; cfFails = 0;
      try { host.bank.config.api.public_url = host.tunnel; } catch {}
      log('túnel Cloudflare:', host.tunnel);
      emit('host', T('Rede na internet', 'Network online'), host.tunnel, { route: 'host' });
    }
  };
  p.stdout.on('data', onData); p.stderr.on('data', onData);
  p.on('error', (e) => { host.cfError = e.message; });
  p.on('exit', (code) => {
    host.cf = null; host.tunnel = null;
    try { if (host.bank && host.bank.config) host.bank.config.api.public_url = hostPublicBase(); } catch {}
    if (!cfg.host.cloudflare || !host.running || shuttingDown) { host.cfState = 'off'; return; }
    host.cfState = 'retrying'; cfFails++;
    cfRestart = setTimeout(startTunnel, Math.min(60000, 3000 * cfFails));
  });
}
function stopTunnel() {
  clearTimeout(cfRestart);
  if (host.cf) { try { host.cf.kill(); } catch {} host.cf = null; }
  host.tunnel = null; host.cfState = 'off';
}

// ───────────────────────── estado para a interface ─────────────────────────
function sessionView(sid) { const s = secrets.sessions[sid]; return s ? { userId: s.userId, username: s.username, saved: !!secrets.accounts[sid] } : null; }
function walletView(sid) {
  const w = W(sid);
  const left = w.claimLeft < 0 ? -1 : Math.max(0, w.claimLeft - (Date.now() - w.claimAt));
  return { online: w.online, balance: w.bal, balanceText: w.bal === null ? null : fmt(w.bal, sid), claimLeftMs: left, cooldownMs: w.cooldownMs, claimSats: w.claimSats, toPay: w.toPay || 0, me: w.me };
}
function state() {
  const servers = allServers().map((s) => Object.assign({}, s, { session: sessionView(s.id), netcfg: netCfg(s.id), wallet: secrets.sessions[s.id] ? walletView(s.id) : null }));
  return {
    ok: true, version: APP_VERSION, lang: lang(), settings: cfg.settings, active: serverById(cfg.active) ? cfg.active : 'main', servers,
    device: cfg.device, machine: hostInfo.machine, dark: hostInfo.dark,
    lan: { ip: lanIp(), ok: udpOk, visible: !!cfg.settings.visible, peers: peers.size },
    host: hostStatus(), lastEvent: evSeq
  };
}

// ───────────────────────── servidor HTTP local ─────────────────────────
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'application/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.png': 'image/png', '.ico': 'image/x-icon', '.svg': 'image/svg+xml', '.json': 'application/json', '.woff2': 'font/woff2' };
function sendFile(res, file) {
  fs.readFile(file, (err, buf) => {
    if (err) { res.writeHead(404, { 'Content-Type': 'text/plain' }); return res.end('not found'); }
    res.writeHead(200, { 'Content-Type': MIME[path.extname(file).toLowerCase()] || 'application/octet-stream', 'Cache-Control': 'no-cache', 'X-Content-Type-Options': 'nosniff' });
    res.end(buf);
  });
}
const json = (res, status, obj) => { res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' }); res.end(JSON.stringify(obj)); };
function readBody(req, limit = 1 << 20) {
  return new Promise((resolve) => {
    const chunks = []; let n = 0;
    req.on('data', (c) => { n += c.length; if (n > limit) { req.destroy(); resolve({}); } else chunks.push(c); });
    req.on('end', () => { try { resolve(chunks.length ? JSON.parse(Buffer.concat(chunks).toString('utf8')) : {}); } catch { resolve({}); } });
    req.on('error', () => resolve({}));
  });
}
function safeJoin(base, rel) { const f = path.normalize(path.join(base, rel)); return f.startsWith(base) ? f : null; }

const api = {
  'GET state': () => state(),
  'GET tray': () => {
    const sid = serverById(cfg.active) ? cfg.active : 'main'; const sv = serverById(sid); const ses = secrets.sessions[sid]; const w = W(sid);
    return { ok: true, notify: cfg.settings.notify, autoClaim: cfg.settings.autoClaim, visible: cfg.settings.visible, host: host.running, preventSleep: cfg.settings.preventSleep,
      site: sv ? sv.url : MAIN_URL, netName: sv ? sv.name : 'Coin', logged: !!ses, online: !!w.online, balance: w.bal === null ? null : `${fmt(w.bal, sid)} ${netCfg(sid).coin}`, nearby: [...peers.values()].filter((p) => p.me).length };
  },
  'GET events': (q) => { const since = Number(q.get('since')) || 0; return { ok: true, last: evSeq, events: events.filter((e) => e.id > since).slice(-50) }; },
  'GET history': () => ({ ok: true, events: events.slice(-60).reverse() }),
  'POST hostinfo': (q, b) => { hostInfo = Object.assign(hostInfo, b || {}); return { ok: true }; },
  'POST wake': () => { for (const sid of Object.keys(secrets.sessions)) W(sid).lastPoll = 0; udpSend({ cb: 1, t: 'who', d: cfg.device }); return { ok: true }; },
  'POST settings': (q, b) => {
    const patch = (b && b.patch) || {};
    for (const k of Object.keys(DEFAULT_SETTINGS)) if (k in patch && typeof patch[k] === typeof DEFAULT_SETTINGS[k]) cfg.settings[k] = patch[k];
    saveConfig(); if ('visible' in patch) udpSend(hello());
    return { ok: true, settings: cfg.settings };
  },
  'POST netcfg': (q, b) => {
    const sid = String(b.server || ''); if (!serverById(sid)) return { ok: false, error: 'SERVER_NOT_FOUND' };
    const c = Object.assign({}, cfg.netcfg[sid] || {});
    const p = b.patch || {};
    if (Number.isInteger(p.api) && p.api >= 0 && p.api <= 18) c.api = p.api;
    if (Number.isInteger(p.disp) && p.disp >= 0 && p.disp <= 18) c.disp = p.disp;
    if (typeof p.coin === 'string') c.coin = p.coin.trim().slice(0, 24) || 'coins';
    cfg.netcfg[sid] = c; saveConfig(); return { ok: true, netcfg: netCfg(sid) };
  },
  'POST servers/add': async (q, b) => {
    const url = cleanUrl(b.url); if (!url) return { ok: false, error: T('Endereço inválido', 'Invalid address') };
    if (cfg.servers.find((s) => cleanUrl(s.url) === url)) return { ok: true, server: cfg.servers.find((s) => cleanUrl(s.url) === url) };
    let name = String(b.name || '').trim().slice(0, 40);
    try { const r = await rawCall(url, 'GET', '/api/health', null, null, 8000); if (r.status !== 200) throw new Error('HTTP ' + r.status); }
    catch (e) { return { ok: false, error: T('Não encontrei uma rede Coin Bank nesse endereço', 'No Coin Bank network found at that address') + ' (' + e.message + ')' }; }
    if (!name) { try { name = new URL(url).hostname; } catch { name = 'Coin'; } }
    const sv = { id: 's' + crypto.randomBytes(4).toString('hex'), name, url, kind: 'custom' };
    cfg.servers.push(sv); saveConfig(); return { ok: true, server: sv };
  },
  'POST servers/remove': (q, b) => {
    const id = String(b.id || ''); if (id === 'main' || id === 'host') return { ok: false, error: 'PROTECTED' };
    cfg.servers = cfg.servers.filter((s) => s.id !== id); delete secrets.sessions[id]; delete secrets.accounts[id]; delete watch[id]; saveSecrets();
    if (cfg.active === id) cfg.active = 'main'; saveConfig(); return { ok: true };
  },
  'POST servers/rename': (q, b) => { const s = cfg.servers.find((x) => x.id === b.id); if (s) { s.name = String(b.name || s.name).slice(0, 40); saveConfig(); } return { ok: !!s }; },
  'POST active': (q, b) => { if (!serverById(b.id)) return { ok: false, error: 'SERVER_NOT_FOUND' }; cfg.active = b.id; saveConfig(); W(b.id).lastPoll = 0; udpSend(hello()); return { ok: true }; },
  'POST login': async (q, b) => {
    try { const s = await login(String(b.server || cfg.active), String(b.username || ''), String(b.password || ''), b.remember !== false); if (b.activate !== false) { cfg.active = String(b.server || cfg.active); saveConfig(); } pollServer(String(b.server || cfg.active)); return { ok: true, session: { userId: s.userId, username: s.username } }; }
    catch (e) { return { ok: false, error: e.message }; }
  },
  'POST register': async (q, b) => {
    const sid = String(b.server || cfg.active); const sv = serverById(sid); if (!sv) return { ok: false, error: 'SERVER_NOT_FOUND' };
    try {
      const r = await rawCall(sv.url, 'POST', '/api/register', { username: b.username, password: b.password });
      if (!r.json || r.json.success === false || r.status >= 400) return { ok: false, error: (r.json && (r.json.message || r.json.error)) || 'HTTP ' + r.status };
      const s = await login(sid, String(b.username), String(b.password), b.remember !== false);
      cfg.active = sid; saveConfig(); pollServer(sid);
      return { ok: true, session: { userId: s.userId, username: s.username } };
    } catch (e) { return { ok: false, error: e.message }; }
  },
  'POST logout': async (q, b) => {
    const sid = String(b.server || cfg.active); const s = secrets.sessions[sid];
    if (s) { try { await netCall(sid, 'POST', '/api/logout', {}, { timeoutMs: 6000 }); } catch {} }
    delete secrets.sessions[sid]; if (b.forget !== false) delete secrets.accounts[sid]; delete watch[sid]; saveSecrets(); udpSend(hello());
    return { ok: true };
  },
  'POST claim': async (q, b) => {
    const sid = String(b.server || cfg.active);
    const r = await netCall(sid, 'POST', '/api/claim', {}, { timeoutMs: 15000 });
    if (r.status === 200 && r.json.success) { const w = W(sid); if (r.json.txId) w.tx.add(r.json.txId); w.claimLeft = Number(r.json.nextClaimInMs || w.cooldownMs); w.claimAt = Date.now(); setTimeout(() => pollServer(sid), 300); }
    return Object.assign({ ok: r.status === 200, status: r.status }, r.json);
  },
  'POST refresh': async (q, b) => { const sid = String(b.server || cfg.active); W(sid).txAt = 0; await pollServer(sid); return { ok: true, wallet: walletView(sid) }; },
  'GET nearby': () => ({ ok: true, device: cfg.device, lan: { ip: lanIp(), ok: udpOk, addrs: lanAddrs().map((a) => ({ name: a.name, ip: a.ip })) }, visible: cfg.settings.visible, me: meAnnounce(), peers: [...peers.values()].sort((a, b) => b.seen - a.seen), inbox }),
  'POST nearby/scan': () => { udpSend({ cb: 1, t: 'who', d: cfg.device }); return { ok: true }; },
  'POST nearby/send': (q, b) => {
    const p = peers.get(String(b.device || '')); if (!p || !p.ip) return { ok: false, error: T('Essa pessoa não está mais por perto', 'That person is no longer nearby') };
    const m = Object.assign({}, b.msg || {}, { fromMe: meAnnounce() || { name: hostInfo.machine } });
    if (typeof m.net === 'string' && /^http:\/\/(127\.0\.0\.1|localhost)/.test(m.net)) m.net = hostPublicBase();
    // outro Coin Bank neste mesmo PC: o unicast cairia no nosso próprio socket, então vai por broadcast (o destino filtra pelo "to")
    const sameHost = lanAddrs().some((a) => a.ip === p.ip) || p.ip === '127.0.0.1';
    udpSend({ cb: 1, t: 'msg', d: cfg.device, to: p.id, m }, sameHost ? undefined : p.ip);
    return { ok: true };
  },
  'POST nearby/dismiss': (q, b) => { const i = inbox.findIndex((x) => x.id === b.id); if (i >= 0) inbox.splice(i, 1); return { ok: true }; },
  'GET host/status': () => Object.assign({ ok: true }, hostStatus()),
  'POST host/set': async (q, b) => {
    const p = b || {}; const c = cfg.host; const before = JSON.stringify(c);
    if (typeof p.name === 'string') c.name = p.name.trim().slice(0, 40) || 'Minha rede';
    if (Number.isInteger(p.port) && p.port >= 1024 && p.port <= 65535) c.port = p.port;
    if (typeof p.cloudflare === 'boolean') c.cloudflare = p.cloudflare;
    if (typeof p.claimAmount === 'string' && /^\d+(\.\d{1,18})?$/.test(p.claimAmount.trim())) c.claimAmount = p.claimAmount.trim();
    if (Number.isFinite(p.claimCooldownMs) && p.claimCooldownMs >= 60000) c.claimCooldownMs = Math.round(p.claimCooldownMs);
    if (typeof p.enabled === 'boolean') c.enabled = p.enabled;
    saveConfig();
    const changed = before !== JSON.stringify(c);
    const needRestart = changed && host.running && (JSON.parse(before).port !== c.port || JSON.parse(before).claimAmount !== c.claimAmount || JSON.parse(before).claimCooldownMs !== c.claimCooldownMs);
    if (!c.enabled) { await stopHost(); if (cfg.active === 'host') cfg.active = 'main'; }
    else if (!host.running) await startHost();
    else if (needRestart) await restartHost();
    else if (c.cloudflare && !host.cf) startTunnel();
    else if (!c.cloudflare && host.cf) { stopTunnel(); try { host.bank.config.api.public_url = hostPublicBase(); } catch {} }
    udpSend(hello());
    return Object.assign({ ok: !host.error }, hostStatus(), { error: host.error });
  },
  'POST host/wipe': async () => {
    await stopHost();
    try { fs.rmSync(HOST_DIR, { recursive: true, force: true }); } catch (e) { return { ok: false, error: e.message }; }
    delete secrets.sessions.host; delete secrets.accounts.host; delete watch.host; saveSecrets();
    if (cfg.host.enabled) await startHost();
    return Object.assign({ ok: true }, hostStatus());
  },
  'POST shutdown': () => { setTimeout(() => shutdown('pedido do app'), 50); return { ok: true }; }
};

const server = http.createServer(async (req, res) => {
  try {
    const u = new URL(req.url, 'http://127.0.0.1');
    let p = decodeURIComponent(u.pathname);
    if (p.startsWith('/app/api/')) {
      const tok = req.headers['x-coinbank-token'] || u.searchParams.get('t');
      if (tok !== TOKEN) return json(res, 403, { ok: false, error: 'FORBIDDEN' });
      if ((req.headers.origin || '') && !/^http:\/\/127\.0\.0\.1(:\d+)?$/.test(req.headers.origin)) return json(res, 403, { ok: false, error: 'ORIGIN' });
      const rest = p.slice('/app/api/'.length);
      // proxy autenticado para a API da rede: /app/api/net/<rede>/api/...
      const nm = rest.match(/^net\/([A-Za-z0-9_-]+)(\/api\/.*)$/);
      if (nm) {
        const body = req.method === 'GET' ? null : await readBody(req);
        try {
          const qs = new URLSearchParams(u.searchParams); qs.delete('t'); qs.delete('noauth'); const qstr = qs.toString();
          const r = await netCall(nm[1], req.method, nm[2] + (qstr ? '?' + qstr : ''), body, { auth: u.searchParams.get('noauth') !== '1' });
          if (r.status === 200 && /\/(transfer|claim|pay|bill\/pay|bill\/create)/.test(nm[2]) && req.method === 'POST') setTimeout(() => { W(nm[1]).txAt = 0; pollServer(nm[1]); }, 300);
          return json(res, r.status, r.json);
        } catch (e) { return json(res, 502, { error: 'NETWORK_DOWN', message: e.message }); }
      }
      const h = api[req.method + ' ' + rest];
      if (!h) return json(res, 404, { ok: false, error: 'NOT_FOUND' });
      const body = req.method === 'POST' ? await readBody(req) : null;
      return json(res, 200, await h(u.searchParams, body));
    }
    if (p === '/' || p === '/app') { res.writeHead(302, { Location: '/app/' }); return res.end(); }
    if (p.startsWith('/app/')) { let rel = p.slice(5) || 'app.html'; if (rel.endsWith('/')) rel += 'app.html'; const f = safeJoin(UI_DIR, rel); return f ? sendFile(res, f) : json(res, 404, {}); }
    // documentos do site embutidos (funcionam offline)
    if (p === '/terms' || p === '/terms/') return sendFile(res, path.join(SITE_DIR, 'terms', 'terms.html'));
    if (p.startsWith('/terms/')) { const f = safeJoin(path.join(SITE_DIR, 'terms'), p.slice(7)); return f ? sendFile(res, f) : json(res, 404, {}); }
    if (p === '/coin-icon.png' || p === '/favicon.ico') return sendFile(res, path.join(SITE_DIR, p.slice(1)));
    res.writeHead(404, { 'Content-Type': 'text/plain' }); res.end('not found');
  } catch (e) { log('http:', e); try { json(res, 500, { ok: false, error: e.message }); } catch {} }
});
server.keepAliveTimeout = 5000;

// ───────────────────────── início e fim ─────────────────────────
let shuttingDown = false;
async function shutdown(why) {
  if (shuttingDown) return; shuttingDown = true;
  log('encerrando:', why);
  try { saveSecrets(); writeJson(CONFIG_FILE, cfg); } catch {}
  try { udpSend(Object.assign(hello(), { me: null, host: null })); } catch {}
  try { await stopHost(); } catch {}
  try { udp && udp.close(); } catch {}
  try { server.close(); } catch {}
  setTimeout(() => process.exit(0), 200);
}
process.on('SIGINT', () => shutdown('SIGINT'));
process.on('SIGTERM', () => shutdown('SIGTERM'));

server.listen(Number(ARGS.port) || 0, '127.0.0.1', () => {
  const port = server.address().port;
  log(`motor ${APP_VERSION} pronto em http://127.0.0.1:${port} (node ${process.version}, ${process.arch})`);
  process.stdout.write('COINBANK_READY ' + JSON.stringify({ port }) + '\n');
  startUdp();
  if (cfg.host.enabled) startHost();
  for (const sid of Object.keys(secrets.sessions)) pollServer(sid);
});
