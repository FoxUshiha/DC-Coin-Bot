/* Coin Bank para Windows — utilidades comuns da janela (app.html) e do painel da bandeja (flyout.html).
   Fala com o motor local (/app/api/*, com token) e com o app do Windows (window.chrome.webview). */
'use strict';
const NS = 'http://www.w3.org/2000/svg';
const ICONS = {
  wallet: '<rect x="3" y="6" width="18" height="14" rx="2.5"/><path d="M3 10h18M16 15h2"/><path d="M6 6V5a2 2 0 0 1 2-2h9"/>',
  card: '<rect x="2.5" y="5" width="19" height="14" rx="2.5"/><path d="M2.5 10h19M6 15h4"/>',
  chart: '<path d="M4 19V5M4 19h16M8 15l3-4 3 2 5-6"/>',
  bill: '<path d="M6 3h12v18l-3-2-3 2-3-2-3 2z"/><path d="M9 8h6M9 12h6"/>',
  radar: '<path d="M2 9a15 15 0 0 1 20 0M5 12.5a10 10 0 0 1 14 0M8.5 16a5 5 0 0 1 7 0"/><circle cx="12" cy="19.5" r="1"/>',
  server: '<rect x="3" y="4" width="18" height="7" rx="2"/><rect x="3" y="13" width="18" height="7" rx="2"/><path d="M7 7.5h.01M7 16.5h.01"/>',
  globe: '<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a14 14 0 0 1 0 18M12 3a14 14 0 0 0 0 18"/>',
  gear: '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z"/>',
  info: '<circle cx="12" cy="12" r="9"/><path d="M12 11v6M12 7.5v.5"/>',
  gift: '<rect x="3" y="8" width="18" height="5" rx="1"/><path d="M5 13v8h14v-8M12 8v13M12 8S10.5 3 8 3.5 7 8 12 8zm0 0s1.5-5 4-4.5S17 8 12 8z"/>',
  qr: '<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><path d="M14 14h3v3h-3zM20 14v.01M14 20h.01M17 17h4v4h-4"/>',
  scan: '<path d="M4 8V5a1 1 0 0 1 1-1h3M16 4h3a1 1 0 0 1 1 1v3M20 16v3a1 1 0 0 1-1 1h-3M8 20H5a1 1 0 0 1-1-1v-3M4 12h16"/>',
  send: '<path d="M22 2 11 13M22 2l-7 20-4-9-9-4z"/>',
  plus: '<path d="M12 5v14M5 12h14"/>', x: '<path d="M6 6l12 12M18 6 6 18"/>', check: '<path d="m5 12 5 5 9-10"/>',
  refresh: '<path d="M20 11a8 8 0 0 0-14.5-4M4 4v4h4M4 13a8 8 0 0 0 14.5 4M20 20v-4h-4"/>',
  copy: '<rect x="8" y="8" width="12" height="12" rx="2"/><path d="M16 8V6a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h2"/>',
  eye: '<path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
  eyeoff: '<path d="M3 3l18 18M10.6 5.1A9.7 9.7 0 0 1 12 5c6.5 0 10 7 10 7a17 17 0 0 1-3.2 4M6.6 6.6C3.9 8.4 2 12 2 12s3.5 7 10 7a9.6 9.6 0 0 0 5.4-1.6M9.9 9.9a3 3 0 0 0 4.2 4.2"/>',
  in: '<path d="M17 7 7 17M7 9v8h8"/>', out: '<path d="M7 17 17 7M9 7h8v8"/>',
  user: '<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/>', users: '<circle cx="9" cy="8" r="3.5"/><path d="M2.5 20a6.5 6.5 0 0 1 13 0M16 4.5a3.5 3.5 0 0 1 0 7M18 14a6 6 0 0 1 3.5 6"/>',
  logout: '<path d="M15 4h3a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2h-3M10 16l-4-4 4-4M6 12h10"/>',
  ext: '<path d="M14 4h6v6M20 4l-9 9"/><path d="M18 14v4a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4"/>',
  trash: '<path d="M4 7h16M10 11v6M14 11v6M6 7l1 12a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2l1-12M9 7V4h6v3"/>',
  bell: '<path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/><path d="M10.3 21a1.9 1.9 0 0 0 3.4 0"/>',
  cf: '<path d="M7 18a4.5 4.5 0 0 1-.6-8.96A6 6 0 0 1 18 8.5a4 4 0 0 1-.5 9.5H7z"/>',
  lan: '<rect x="9" y="3" width="6" height="5" rx="1"/><rect x="3" y="16" width="6" height="5" rx="1"/><rect x="15" y="16" width="6" height="5" rx="1"/><path d="M12 8v4M6 16v-2h12v2"/>',
  power: '<path d="M12 3v8"/><path d="M6.3 7.2a8 8 0 1 0 11.4 0"/>', key: '<circle cx="8" cy="15" r="4"/><path d="m11 12 9-9M17 6l3 3M14 9l2 2"/>',
  doc: '<path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><path d="M14 3v5h5M9 13h6M9 17h6"/>',
  shield: '<path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z"/><path d="m9 12 2 2 4-4"/>',
  code: '<path d="m8 8-5 4 5 4M16 8l5 4-5 4M14 4l-4 16"/>', heart: '<path d="M12 20s-7-4.5-9-9a5 5 0 0 1 9-3 5 5 0 0 1 9 3c-2 4.5-9 9-9 9z"/>',
  clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>', home: '<path d="M3 11 12 4l9 7"/><path d="M5 10v10h14V10"/>',
  contactless: '<path d="M8.5 8.5a5 5 0 0 1 0 7M12 6a8.5 8.5 0 0 1 0 12M15.5 3.5a12 12 0 0 1 0 17"/>', down: '<path d="M12 5v14M6 13l6 6 6-6"/>',
  more: '<circle cx="5" cy="12" r="1.3"/><circle cx="12" cy="12" r="1.3"/><circle cx="19" cy="12" r="1.3"/>', chev: '<path d="m9 6 6 6-6 6"/>',
  paste: '<rect x="6" y="4" width="12" height="17" rx="2"/><path d="M9 4V3h6v1M9 10h6M9 14h6"/>', moon: '<path d="M21 13A9 9 0 1 1 11 3a7 7 0 0 0 10 10z"/>',
};
function ico(name, size) { const s = document.createElementNS(NS, 'svg'); s.setAttribute('viewBox', '0 0 24 24'); s.setAttribute('class', 'i'); if (size) { s.style.width = s.style.height = size + 'px'; } s.innerHTML = ICONS[name] || ICONS.info; return s; }
function h(tag, attrs, ...kids) {
  const e = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs || {})) {
    if (v == null || v === false) continue;
    if (k === 'class') e.className = v; else if (k === 'style' && typeof v === 'object') Object.assign(e.style, v);
    else if (k.startsWith('on') && typeof v === 'function') e.addEventListener(k.slice(2), v);
    else if (k === 'html') e.innerHTML = v; else if (k === 'value') e.value = v; else if (v === true) e.setAttribute(k, ''); else e.setAttribute(k, v);
  }
  for (const k of kids.flat(Infinity)) { if (k == null || k === false) continue; e.append(k instanceof Node ? k : document.createTextNode(String(k))); }
  return e;
}
// append() ignora null/false (assim dá para montar telas com "cond ? h(...) : null" sem aparecer "null")
(function () { for (const P of [Element.prototype, DocumentFragment.prototype]) { const orig = P.append; P.append = function (...k) { return orig.apply(this, k.flat(Infinity).filter((x) => x != null && x !== false)); }; } })();
const $ = (s, r) => (r || document).querySelector(s);
const clear = (e) => { while (e && e.firstChild) e.removeChild(e.firstChild); return e; };
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

/* token: chega no endereço (#t=…) vindo do app; fica só nesta aba */
const TOKEN = (() => {
  const m = /[#&]t=([A-Za-z0-9_-]+)/.exec(location.hash);
  if (m) { try { sessionStorage.setItem('cb_t', m[1]); } catch { /* */ } }
  let t = m ? m[1] : null; if (!t) { try { t = sessionStorage.getItem('cb_t'); } catch { /* */ } }
  return t || '';
})();
function initialRoute(def) {
  const m = /[#&]r=([^&]+)/.exec(location.hash); const r = m ? decodeURIComponent(m[1]) : def;
  try { history.replaceState(null, '', location.pathname); } catch { /* */ }
  return r;
}

/* idioma (segue o do app/sistema) */
const L = { pt: (navigator.language || 'pt').toLowerCase().startsWith('pt'), t(pt, en) { return this.pt ? pt : en; } };

class ApiError extends Error { constructor(msg, status, body) { super(msg); this.status = status; this.body = body; } }
function errText(e) {
  const b = e && e.body; const code = b && (b.error || b.code);
  const map = {
    INSUFFICIENT_FUNDS: L.t('Saldo insuficiente.', 'Insufficient balance.'), 'Insufficient funds': L.t('Saldo insuficiente.', 'Insufficient balance.'),
    INVALID_TARGET: L.t('ID de destino inválido.', 'Invalid destination ID.'), SELF_TRANSFER: L.t('Você não pode enviar para você mesmo.', 'You cannot send to yourself.'),
    COOLDOWN_ACTIVE: L.t('Aguarde um pouco antes de tentar de novo.', 'Wait a moment and try again.'), 'Cooldown active': L.t('Resgate ainda não disponível.', 'Claim not available yet.'),
    PAYREQ_NOT_FOUND: L.t('Pedido de pagamento não encontrado ou vencido.', 'Payment request not found or expired.'), BILL_NOT_FOUND: L.t('Cobrança não encontrada.', 'Bill not found.'),
    NETWORK_DOWN: L.t('A rede não respondeu. Confira a internet.', 'The network did not respond. Check your internet.'), UNAUTHORIZED: L.t('Sessão expirada. Entre de novo.', 'Session expired. Sign in again.'),
    'Invalid parameters': L.t('Valor ou dados inválidos.', 'Invalid amount or data.'), TRANSFER_COOLDOWN: L.t('Aguarde 1 segundo entre transferências.', 'Wait 1 second between transfers.'),
  };
  if (code && map[code]) return map[code];
  return (b && (b.message || b.error)) || (e && e.message) || String(e);
}
async function api(path, body, method) {
  let res;
  try {
    res = await fetch('/app/api/' + path, { method: method || (body === undefined ? 'GET' : 'POST'), headers: { 'x-coinbank-token': TOKEN, ...(body === undefined ? {} : { 'content-type': 'application/json' }) }, body: body === undefined ? undefined : JSON.stringify(body) });
  } catch { throw new ApiError(L.t('O motor do Coin Bank não respondeu. Ele reinicia sozinho em alguns segundos.', 'The Coin Bank engine did not respond. It restarts by itself in a few seconds.'), 0, { error: 'engine_down' }); }
  let j = null; try { j = await res.json(); } catch { /* */ }
  if (!res.ok || !j || j.ok === false || j.success === false) throw new ApiError((j && (j.message || j.error)) || 'HTTP ' + res.status, res.status, j || {});
  return j;
}
/** chamada à API da rede (pelo motor, que põe a sessão): net('main', 'GET', '/api/transactions?page=1') */
const net = (sid, method, path, body) => api('net/' + sid + path, method === 'GET' ? undefined : (body || {}), method);

/* ponte com o app do Windows (WebView2). Fora do app (navegador comum), usa alternativas simples. */
const Host = {
  has: !!(window.chrome && window.chrome.webview),
  seq: 0, waits: new Map(), handlers: {},
  send(cmd, args) {
    if (!this.has) return Promise.resolve(Host.fallback(cmd, args || {}));
    return new Promise((resolve) => {
      const id = ++this.seq; this.waits.set(id, resolve);
      window.chrome.webview.postMessage(JSON.stringify({ id, cmd, args: args || {} }));
      setTimeout(() => { if (this.waits.has(id)) { this.waits.delete(id); resolve({ ok: false, error: 'timeout' }); } }, 120e3);
    });
  },
  on(type, fn) { (this.handlers[type] = this.handlers[type] || []).push(fn); },
  fallback(cmd, a) {
    if (cmd === 'openExternal') { window.open(a.url, '_blank', 'noopener'); return { ok: true }; }
    if (cmd === 'openMain') { location.href = '/app/#r=' + (a.route || 'wallet') + '&t=' + TOKEN; return { ok: true }; }
    if (cmd === 'copy') { try { navigator.clipboard.writeText(a.text); return { ok: true }; } catch { return { ok: false }; } }
    return { ok: false, error: 'fora do app' };
  },
};
if (Host.has) {
  window.chrome.webview.addEventListener('message', (e) => {
    let m = e.data; if (typeof m === 'string') { try { m = JSON.parse(m); } catch { return; } }
    if (!m) return;
    if (m.type === 'reply' && Host.waits.has(m.id)) { const r = Host.waits.get(m.id); Host.waits.delete(m.id); r(m); return; }
    for (const fn of Host.handlers[m.type] || []) { try { fn(m.data, m); } catch (err) { console.error(err); } }
  });
}
const openExternal = (url) => Host.send('openExternal', { url });

/* tema: segue o Windows, ou o escolhido nas configurações */
function applyTheme(pref, winDark) {
  const dark = pref === 'dark' || (pref !== 'light' && (winDark != null ? winDark : matchMedia('(prefers-color-scheme: dark)').matches));
  document.documentElement.setAttribute('data-theme', dark ? 'dark' : 'light');
}

/* ───── valores: a menor unidade da moeda (inteiro) ↔ texto, com as casas da rede (igual ao celular) ───── */
const F = {
  cfgs: {}, active: 'main',
  cfg(sid) { return this.cfgs[sid || this.active] || { api: 8, disp: 8, coin: 'coins' }; },
  unit(sid) { const c = (this.cfg(sid).coin || '').trim(); return !c || c.toLowerCase() === 'coin' ? 'coins' : c; },
  coins(v, sid, sign) {
    const d = Math.max(0, Math.min(18, this.cfg(sid).disp)); let n = BigInt(Math.trunc(Number(v) || 0)); const neg = n < 0n; if (neg) n = -n;
    const base = 10n ** BigInt(d); const ip = (n / base).toString(); const fr = d ? (n % base).toString().padStart(d, '0') : '';
    const out = ip.replace(/\B(?=(\d{3})+(?!\d))/g, L.pt ? '.' : ',') + (d ? (L.pt ? ',' : '.') + fr : '');
    return neg ? '−' + out : (sign && n > 0n ? '+' + out : out);
  },
  _dec(input, d, strict) {
    let s = String(input || '').trim().replace(/\s/g, ''); if (!s) return null;
    if (s.includes(',') && s.includes('.')) s = s.lastIndexOf(',') > s.lastIndexOf('.') ? s.replace(/\./g, '').replace(',', '.') : s.replace(/,/g, '');
    else s = s.replace(',', '.');
    if (!/^\d+(\.\d+)?$/.test(s) && !/^\.\d+$/.test(s)) return null;
    const [a, b0 = ''] = s.split('.'); let b = b0;
    if (b.length > d) { if (strict) return null; b = b.slice(0, d); }
    return Number(BigInt(a || '0') * 10n ** BigInt(d) + BigInt((b.padEnd(d, '0')) || '0'));
  },
  /** o que o usuário digita (nas casas exibidas) → unidades */
  parse(input, sid) { return this._dec(input, Math.max(0, Math.min(18, this.cfg(sid).disp)), true); },
  /** valor da API → unidades */
  parseApi(v, sid) { if (v == null || v === '') return null; return this._dec(typeof v === 'number' ? v.toFixed(18) : String(v), this.cfg(sid).api, false); },
  /** unidades → texto da API */
  api(v, sid) { const d = this.cfg(sid).api; let n = BigInt(Math.trunc(v)); if (!d) return n.toString(); const base = 10n ** BigInt(d); return (n / base).toString() + '.' + (n % base).toString().padStart(d, '0'); },
  sats(o, key, sid) { if (!o) return 0; const s = o[key + 'Sats'] ?? o.amountSats ?? o.sats; if (s != null && s !== '') return Number(s); return this.parseApi(o[key] ?? o.amount, sid) || 0; },
  date(d) { const x = new Date(d); return isNaN(x) ? '—' : x.toLocaleString(L.pt ? 'pt-BR' : 'en-US', { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' }); },
  ago(ts) {
    const s = Math.max(0, Math.round((Date.now() - ts) / 1000));
    if (s < 10) return L.t('agora', 'now'); if (s < 60) return L.t(`há ${s} s`, `${s}s ago`);
    const m = Math.round(s / 60); if (m < 60) return L.t(`há ${m} min`, `${m} min ago`);
    const hh = Math.round(m / 60); if (hh < 24) return L.t(`há ${hh} h`, `${hh} h ago`); return L.t(`há ${Math.round(hh / 24)} d`, `${Math.round(hh / 24)} d ago`);
  },
  countdown(ms) { const s = Math.max(0, Math.ceil(ms / 1000)); const hh = Math.floor(s / 3600), mm = Math.floor((s % 3600) / 60), ss = s % 60; const p = (x) => String(x).padStart(2, '0'); return (hh ? hh + ':' + p(mm) : mm) + ':' + p(ss); },
  duration(ms) { const m = Math.round(ms / 60000); if (m < 60) return m + ' min'; const hh = m / 60; if (hh < 24) return (Number.isInteger(hh) ? hh : hh.toFixed(1)) + ' h'; return Math.round(hh / 24) + ' d'; },
};

/* ───── avisos e janelas ───── */
let toastTimer = null;
function toast(msg, kind) {
  document.querySelectorAll('.toast').forEach((t) => t.remove());
  const t = h('div', { class: 'toast ' + (kind || '') }, kind === 'ok' ? ico('check') : kind === 'bad' ? ico('info') : null, h('span', {}, msg));
  document.body.append(t); clearTimeout(toastTimer); toastTimer = setTimeout(() => t.remove(), 3200);
}
async function copyText(text, what) {
  let ok = false;
  try { await navigator.clipboard.writeText(text); ok = true; } catch { const r = await Host.send('copy', { text }); ok = !!r.ok; }
  toast(ok ? L.t(`${what || 'Texto'} copiado`, `${what || 'Text'} copied`) : L.t('Não consegui copiar', 'Could not copy'), ok ? 'ok' : 'bad');
}
async function pasteText() {
  try { const t = await navigator.clipboard.readText(); if (t) return t; } catch { /* */ }
  const r = await Host.send('paste'); return r && r.ok ? r.data || '' : '';
}
/** janela modal: modal({ title, body: Node, wide, onClose, dismiss }) → { close, root } */
function modal({ title, body, wide, onClose, dismiss = true, cls }) {
  const box = h('div', { class: 'modal' + (wide ? ' wide' : '') + (cls ? ' ' + cls : '') });
  const ov = h('div', { class: 'ov' }, box);
  let closed = false;
  const close = () => { if (closed) return; closed = true; ov.remove(); document.removeEventListener('keydown', onKey); if (onClose) onClose(); };
  const onKey = (e) => { if (e.key === 'Escape' && dismiss) close(); };
  if (title) box.append(h('div', { class: 'mh' }, h('h3', {}, title), h('button', { class: 'ib', onclick: close, title: L.t('Fechar', 'Close') }, ico('x'))));
  box.append(body);
  if (dismiss) ov.addEventListener('mousedown', (e) => { if (e.target === ov) close(); });
  document.addEventListener('keydown', onKey);
  document.body.append(ov);
  return { close, root: box };
}
function confirmBox({ title, text, ok, danger, icon }) {
  return new Promise((resolve) => {
    let done = false;
    const fin = (v) => { if (done) return; done = true; m.close(); resolve(v); };
    const m = modal({
      title, onClose: () => fin(false),
      body: h('div', { class: 'col' },
        text ? h('div', { class: 'muted', style: { whiteSpace: 'pre-line' } }, text) : null,
        h('div', { class: 'row', style: { justifyContent: 'flex-end', marginTop: '8px' } },
          h('button', { class: 'btn', onclick: () => fin(false) }, L.t('Cancelar', 'Cancel')),
          h('button', { class: 'btn ' + (danger ? 'danger fill' : 'pri'), onclick: () => fin(true) }, icon ? ico(icon) : null, ok || 'OK'))),
    });
  });
}
function qrCanvas(text, px) {
  const c = CoinQR.toCanvas(text, (px || 236) * 2, { margin: 1, level: 'M' });
  c.style.width = c.style.height = (px || 236) + 'px';
  return c;
}
function sw(checked, onchange) {
  const inp = h('input', { type: 'checkbox' }); inp.checked = !!checked;
  inp.addEventListener('change', () => onchange(inp.checked, inp));
  return h('label', { class: 'sw' }, inp, h('span'));
}
