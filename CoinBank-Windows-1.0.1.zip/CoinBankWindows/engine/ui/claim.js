/* Coin Bank para Windows — resgate com a carteira e as moedas com física (o mesmo do app do celular).
 *  • a carteira tem duas camadas (fundo e frente); as moedas passam ENTRE elas, entram pela boca e somem;
 *    as bordas e as laterais têm colisão (nada atravessa a carteira)
 *  • moedas caem de fora da janela com gravidade: 1 moedinha por unidade da última casa exibida (até 12)
 *  • arraste com o mouse/dedo (o círculo exato da moeda), jogue para dentro, para fora ou para cima
 *  • clique na carteira: balança · 2 cliques rápidos: moedinhas sobem meio para fora · clicando de novo: pulam para fora
 *  • transferência recebida com o resgate aberto: moedas caem · pagamento enviado: moedas saem voando para cima
 *  • só fecha pelo X ou pelo Esc (clicar fora não fecha — as moedas têm física)
 *
 * openClaim({ sid, getWallet: () => wallet, onClaim: async () => sats, unitsOf: (sats) => n, balanceUnits: () => n, onClose })
 */
'use strict';
(function () {
  const PNG = 350, BODY_L = 34, BODY_R = 316, FRONT_TOP = 124, BODY_B = 313, BACK_TOP = 106, COIN_FILL = 0.474;
  const GRAVITY = 1450, MAX_WALLET = 12, MAX_PEEK = 6;
  const imgs = {};
  for (const k of ['coin', 'wallet_back', 'wallet_front']) { const im = new Image(); im.src = '/app/' + k + '.png'; imgs[k] = im; }

  window.openClaim = function (opt) {
    const st = {
      coins: [], pending: [], geo: null, now: 0, last: 0,
      shakeStart: -10, shakeDur: 0.5, shakeAmp: 0.07, shakeFreq: 4, tilt: 0, tiltTarget: 0, tiltHold: 0, bumpStart: -10,
      lastTap: -10, lastInteraction: 0, busy: false, got: 0, gotUntil: 0, raf: 0, closed: false, lastHaptic: 0,
    };
    const dpr = () => window.devicePixelRatio || 1;
    // ── tela
    const canvas = h('canvas', { style: { position: 'fixed', inset: '0', width: '100%', height: '100%', pointerEvents: 'none', zIndex: '602' } });
    const slot = h('div', { style: { width: '250px', height: '196px', margin: '10px auto 4px' } });
    const status = h('div', { style: { textAlign: 'center', minHeight: '58px', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center' } });
    const sub = h('div', { class: 'dim', style: { textAlign: 'center', fontSize: '12.5px' } });
    const btn = h('button', { class: 'btn pri lg', style: { width: '100%', marginTop: '12px' }, onclick: () => doClaim() }, L.t('Resgatar', 'Claim'));
    const auto = sw(false, async (v) => { try { await api('settings', { patch: { autoClaim: v } }); toast(v ? L.t('Resgate automático ligado', 'Auto-claim on') : L.t('Resgate automático desligado', 'Auto-claim off'), 'ok'); Host.send('refreshTray'); } catch (e) { toast(errText(e), 'bad'); } });
    api('state').then((s) => { auto.querySelector('input').checked = !!s.settings.autoClaim; }).catch(() => {});
    const card = h('div', { class: 'modal', style: { width: '380px', position: 'relative', zIndex: '601', padding: '10px 22px 16px', userSelect: 'none' } },
      h('div', { class: 'row' }, h('div', { style: { width: '38px' } }), h('div', { class: 'grow', style: { textAlign: 'center', fontWeight: '800', fontSize: '17px' } }, L.t('Resgate', 'Claim')), h('button', { class: 'ib', onclick: () => close(), title: L.t('Fechar', 'Close') }, ico('x'))),
      slot, status, sub, btn,
      h('div', { class: 'row', style: { marginTop: '12px' } }, h('div', { class: 'grow' }, h('div', { class: 't1', style: { fontSize: '13.5px' } }, L.t('Resgate automático', 'Auto-claim')), h('div', { class: 'hint' }, L.t('Todas as redes em que você entrou, com o app na bandeja', 'Every network you signed in to, with the app in the tray'))), auto));
    const ov = h('div', { class: 'ov', style: { zIndex: '600' } }, card);
    document.body.append(ov, canvas);
    const onKey = (e) => { if (e.key === 'Escape') close(); };
    document.addEventListener('keydown', onKey);

    function close() {
      if (st.closed) return; st.closed = true;
      cancelAnimationFrame(st.raf); ov.remove(); canvas.remove();
      document.removeEventListener('keydown', onKey);
      window.removeEventListener('pointerdown', down, true); window.removeEventListener('pointermove', move, true); window.removeEventListener('pointerup', up, true); window.removeEventListener('pointercancel', up, true);
      window.removeEventListener('resize', resize);
      if (opt.onClose) opt.onClose();
    }

    // ── geometria (coordenadas da janela)
    function geo() {
      const r = slot.getBoundingClientRect(); const S = r.width; const img = { x: r.left, y: r.top - S * 0.17, s: S };
      const k = S / PNG;
      const g = { img, left: img.x + BODY_L * k, right: img.x + BODY_R * k, top: img.y + FRONT_TOP * k, bottom: img.y + BODY_B * k, backTop: img.y + BACK_TOP * k, rim: 12 * k };
      g.r = (g.right - g.left) * 0.135;
      const baseTop = g.top + g.r * 2.25;
      g.boxes = [[g.left, g.top, g.left + g.rim, g.bottom], [g.right - g.rim, g.top, g.right, g.bottom], [g.left, baseTop, g.right, g.bottom]];
      g.cx = (g.left + g.right) / 2; g.mouthL = g.left + g.rim; g.mouthR = g.right - g.rim; g.pivot = [g.cx, g.bottom];
      g.coinPx = g.r / COIN_FILL;
      return g;
    }
    function resize() { canvas.width = Math.round(innerWidth * dpr()); canvas.height = Math.round(innerHeight * dpr()); st.geo = geo(); }
    window.addEventListener('resize', resize);
    resize();

    // ── regras
    const unitsOf = (a) => opt.unitsOf(a);
    const balanceUnits = () => opt.balanceUnits();
    const walletOut = () => st.coins.filter((c) => c.fromWallet).length;
    const rnd = Math.random;

    function shake(fast, strength = 1) { st.shakeStart = st.now; st.shakeDur = fast ? 0.42 : 0.55; st.shakeAmp = (fast ? 0.095 : 0.06) * strength; st.shakeFreq = fast ? 6.5 : 4; }
    function walletAngle() {
      let a = st.tilt; const t = st.now - st.shakeStart;
      if (t >= 0 && t < st.shakeDur) { const k = t / st.shakeDur; a += Math.sin(k * st.shakeFreq * 2 * Math.PI) * st.shakeAmp * (1 - k); }
      const b = st.now - st.bumpStart; if (b >= 0 && b < 0.25) a += Math.sin(b / 0.25 * Math.PI * 2) * 0.025 * (1 - b / 0.25);
      return a;
    }
    function walletDip() { const b = st.now - st.bumpStart; return b >= 0 && b < 0.22 ? Math.sin(b / 0.22 * Math.PI) * 3.5 : 0; }
    const coin = (x, y, o = {}) => Object.assign({ x, y, vx: 0, vy: 0, g: 1, a: 0, spin: 0, fromWallet: false, front: false, pointer: null, fx: 0, fy: 0, hist: [], peek: false, slot: 0, peekT: 0, peekBack: false }, o);

    function rain(n) {
      const g = st.geo; if (n <= 0 || !g) return;
      const half = (g.mouthR - g.mouthL) / 2 - g.r;
      for (let i = 0; i < n; i++) {
        const c = coin(g.cx + (rnd() * 2 - 1) * half * 0.75, -g.r - 8 - rnd() * 24, { vx: (rnd() - 0.5) * 30, vy: 60 + rnd() * 40, spin: (rnd() - 0.5) * 5, a: rnd() * Math.PI });
        st.pending.push({ at: st.now + i * 0.15 + rnd() * 0.05, c });
      }
    }
    function outgoing(n) {
      const g = st.geo; if (n <= 0 || !g) return;
      shake(true);
      const half = (g.mouthR - g.mouthL) / 2 - g.r;
      for (let i = 0; i < n; i++) st.pending.push({ at: st.now + 0.08 + i * 0.11, c: coin(g.cx + (rnd() * 2 - 1) * half, g.top + g.r * 0.9, { g: -1, vx: (rnd() - 0.5) * 220, vy: -(260 + rnd() * 240), spin: (rnd() - 0.5) * 9 }) });
    }
    function slotOffset(slot) {
      const g = st.geo; const maxOff = (g.mouthR - g.mouthL) / 2 - g.r * 1.02; const step = (maxOff * 2) / (MAX_PEEK - 1);
      return [-maxOff + step * slot, slot % 2 === 0 ? 0 : 3];
    }
    function freeSlot() {
      const used = new Set(st.coins.filter((c) => c.peek).map((c) => c.slot));
      const free = []; for (let i = 0; i < MAX_PEEK; i++) if (!used.has(i)) free.push(i);
      if (!free.length) return null;
      const key = {}; for (const i of free) key[i] = Math.abs(i - (MAX_PEEK - 1) / 2) + rnd() * 1.6;
      free.sort((a, b) => key[a] - key[b]); return free[0];
    }
    function spawnPeek(delay = 0) {
      if (!st.geo) return false;
      const units = balanceUnits();
      if (walletOut() >= Math.min(units, MAX_WALLET)) return false;
      if (st.coins.filter((c) => c.peek).length >= Math.min(units, MAX_PEEK)) return false;
      const slot = freeSlot(); if (slot == null) return false;
      const c = coin(0, 0, { fromWallet: true, peek: true, slot, peekT: -delay / 0.4, a: (rnd() - 0.5) * 0.5 });
      st.coins.push(c); place(c); return true;
    }
    const easeOutBack = (t) => { const c1 = 1.70158, c3 = c1 + 1; return 1 + c3 * Math.pow(t - 1, 3) + c1 * Math.pow(t - 1, 2); };
    function rotate(px, py, ox, oy, a) { if (!a) return [px, py]; const s = Math.sin(a), co = Math.cos(a), dx = px - ox, dy = py - oy; return [ox + dx * co - dy * s, oy + dx * s + dy * co]; }
    function place(c) {
      const g = st.geo; const t = Math.max(0, Math.min(1, c.peekT));
      const e = c.peekBack ? t * t : easeOutBack(t);
      const [ox, oy] = slotOffset(c.slot);
      const sh = st.now - st.shakeStart;
      const jig = sh >= 0 && sh < st.shakeDur ? -Math.sin(sh / st.shakeDur * Math.PI) * 6 * (1 - sh / st.shakeDur) * (c.slot % 2 === 0 ? 1 : 0.6) : 0;
      const [x, y] = rotate(g.cx + ox, g.top + g.r * 1.1 - e * g.r * 1.1 + oy + jig + walletDip(), g.pivot[0], g.pivot[1], walletAngle());
      c.x = x; c.y = y;
    }
    function popPeek(c) {
      const g = st.geo; c.peek = false;
      const side = Math.abs(c.x - g.cx) < 4 ? (rnd() < 0.5 ? 1 : -1) : Math.sign(c.x - g.cx);
      const dir = rnd() < 0.8 ? side : -side;
      c.vx = dir * (130 + rnd() * 220); c.vy = -(520 + rnd() * 260); c.spin = dir * (5 + rnd() * 6);
    }

    // ── física
    function collide(c, b, r, g) {
      const qx = Math.max(b[0], Math.min(b[2], c.x)), qy = Math.max(b[1], Math.min(b[3], c.y));
      const dx = c.x - qx, dy = c.y - qy, d2 = dx * dx + dy * dy;
      if (d2 >= r * r) return;
      let nx, ny, pen;
      if (d2 > 1e-6) { const d = Math.sqrt(d2); nx = dx / d; ny = dy / d; pen = r - d; }
      else {
        const toL = c.x - b[0], toR = b[2] - c.x, toT = c.y - b[1], toB = b[3] - c.y, m = Math.min(toL, toR, toT, toB);
        if (m === toT) { nx = 0; ny = -1; } else if (m === toB) { nx = 0; ny = 1; } else if (m === toL) { nx = -1; ny = 0; } else { nx = 1; ny = 0; }
        pen = m + r;
      }
      c.x += nx * pen; c.y += ny * pen;
      const vn = c.vx * nx + c.vy * ny;
      if (vn < 0) {
        const bounce = vn < -260 ? 0.38 : 0.08;
        c.vx -= nx * vn * (1 + bounce); c.vy -= ny * vn * (1 + bounce);
        const tx = -ny, ty = nx, vt = c.vx * tx + c.vy * ty;
        c.vx -= tx * vt * 0.035; c.vy -= ty * vt * 0.035;
        c.spin += (vt / r - c.spin) * 0.35;
      }
      // dinheiro saindo empurrado contra a parte de baixo: a carteira inclina e a moeda rola para o lado
      if (c.g < 0 && ny > 0.6) {
        const side = Math.abs(c.x - g.cx) < 3 ? (rnd() < 0.5 ? 1 : -1) : Math.sign(c.x - g.cx);
        st.tiltTarget = -side * 0.075; st.tiltHold = st.now + 0.18;
        c.vx += side * 22; c.spin += side * 0.4;
      }
    }
    function separate(r) {
      const f = st.coins.filter((c) => !c.peek && c.pointer == null && !c.front);
      for (let i = 0; i < f.length; i++) for (let j = i + 1; j < f.length; j++) {
        const a = f[i], b = f[j]; const dx = b.x - a.x, dy = b.y - a.y, dist = Math.hypot(dx, dy), min = r * 1.9;
        if (dist >= min || dist < 1e-4) continue;
        const nx = dx / dist, ny = dy / dist, corr = (min - dist) / 2;
        a.x -= nx * corr; a.y -= ny * corr; b.x += nx * corr; b.y += ny * corr;
        const rel = (b.vx - a.vx) * nx + (b.vy - a.vy) * ny;
        if (rel < 0) { const im = rel * 0.65; a.vx += nx * im; a.vy += ny * im; b.vx -= nx * im; b.vy -= ny * im; }
      }
    }
    function step(dt, g) {
      const r = g.r; const gone = [];
      for (const c of st.coins) {
        if (c.peek) continue;
        if (c.pointer != null) {
          const k = 1 - Math.exp(-dt * 28); const nx = c.x + (c.fx - c.x) * k, ny = c.y + (c.fy - c.y) * k;
          if (dt > 0) { c.vx = (nx - c.x) / dt; c.vy = (ny - c.y) / dt; }
          c.x = nx; c.y = ny; c.a += c.spin * dt; c.spin *= Math.exp(-dt * 5); continue;
        }
        c.vy += GRAVITY * c.g * dt;
        const drag = Math.exp(-dt * 0.35); c.vx *= drag; c.vy *= drag;
        const sp = Math.hypot(c.vx, c.vy); if (sp > 2600) { c.vx *= 2600 / sp; c.vy *= 2600 / sp; }
        c.x += c.vx * dt; c.y += c.vy * dt; c.a += c.spin * dt;
        if (!c.front) {
          for (const b of g.boxes) collide(c, b, r, g);
          // entrou pela boca: afunda atrás da frente da carteira e some
          if (c.g > 0 && c.y > g.top + r * 0.95 && c.x > g.mouthL && c.x < g.mouthR) { gone.push(c); st.bumpStart = st.now; continue; }
        }
        if (c.x + r < -30 || c.x - r > innerWidth + 30 || c.y - r > innerHeight + 20 || (c.g < 0 && c.y + r < -20) || c.y < -4000) gone.push(c);
      }
      if (gone.length) st.coins = st.coins.filter((c) => !gone.includes(c));
      separate(r);
    }

    // ── toque / mouse (só onde há moeda ou carteira; o resto vai para o cartão)
    function coinAt(x, y) {
      const g = st.geo; if (!g) return null;
      const order = [...st.coins.filter((c) => !c.front && c.pointer == null), ...st.coins.filter((c) => c.front || c.pointer != null)].reverse();
      for (const c of order) { if (c.pointer != null) continue; if (c.peek && c.peekT < 0.5) continue; if (Math.hypot(c.x - x, c.y - y) <= g.r) return c; }
      return null;
    }
    const onBody = (x, y) => { const g = st.geo; return g && x >= g.left && x <= g.right && y >= g.backTop && y <= g.bottom; };
    function down(e) {
      if (st.closed) return;
      const c = coinAt(e.clientX, e.clientY);
      if (c) {
        e.preventDefault(); e.stopPropagation();
        st.lastInteraction = st.now; c.peek = false; c.pointer = e.pointerId; c.fx = e.clientX; c.fy = e.clientY; c.hist = [[st.now, e.clientX, e.clientY]];
        return;
      }
      if (onBody(e.clientX, e.clientY)) { e.preventDefault(); e.stopPropagation(); st.lastInteraction = st.now; tapWallet(); }
    }
    function move(e) {
      for (const c of st.coins) if (c.pointer === e.pointerId) { c.fx = e.clientX; c.fy = e.clientY; c.hist.push([st.now, e.clientX, e.clientY]); c.hist = c.hist.filter((s) => st.now - s[0] <= 0.09); st.lastInteraction = st.now; e.preventDefault(); }
    }
    function up(e) {
      const g = st.geo;
      for (const c of st.coins) {
        if (c.pointer !== e.pointerId) continue;
        c.pointer = null; st.lastInteraction = st.now;
        let vx = 0, vy = 0;
        if (c.hist.length >= 2) { const a = c.hist[0], b = c.hist[c.hist.length - 1]; const t = b[0] - a[0]; if (t > 0.004) { vx = (b[1] - a[1]) / t; vy = (b[2] - a[2]) / t; } }
        const sp = Math.hypot(vx, vy); if (sp > 3000) { vx *= 3000 / sp; vy *= 3000 / sp; }
        c.vx = vx; c.vy = vy; c.spin = (vx / (g ? g.r : 24)) * 0.4;
        if (!g || c.front) continue;
        if (c.x >= g.left && c.x <= g.right && c.y >= g.top && c.y <= g.bottom) {
          if (c.g > 0) { c.x = Math.max(g.mouthL + g.r, Math.min(g.mouthR - g.r, c.x)); c.y = g.top + g.r * 0.4; c.vx = 0; c.vy = 260; }
          else { c.y = g.bottom + g.r + 1; c.vy = Math.min(c.vy, -40); }
        }
      }
    }
    window.addEventListener('pointerdown', down, true); window.addEventListener('pointermove', move, true); window.addEventListener('pointerup', up, true); window.addEventListener('pointercancel', up, true);

    function tapWallet() {
      const quick = st.now - st.lastTap < 0.36; st.lastTap = st.now;
      const leaving = st.coins.filter((c) => c.g < 0 && !c.front);
      if (leaving.length) { shake(true); for (const c of leaving) { c.front = true; c.vx *= 0.5; c.vy = Math.min(c.vy, -520); } return; }
      const units = balanceUnits();
      if (units <= 0) { shake(quick); return; }
      const peeks = st.coins.filter((c) => c.peek && !c.peekBack);
      if (!peeks.length) {
        shake(quick);
        if (quick) { const n = Math.min(units, MAX_PEEK); for (let i = 0; i < n; i++) if (!spawnPeek(i * 0.06)) break; }
        return;
      }
      shake(true, quick ? 1 : 0.8);
      const ready = peeks.filter((c) => c.peekT >= 0.6); if (!ready.length) return;
      popPeek(ready[Math.floor(rnd() * ready.length)]);
      spawnPeek(0.12);
    }

    // ── resgate
    async function doClaim() {
      if (st.busy) return; st.busy = true; render();
      try {
        const got = await opt.onClaim();
        st.got = got; st.gotUntil = st.now + 3.5;
        rain(unitsOf(got));
      } catch (e) { toast(errText(e), 'bad'); }
      finally { st.busy = false; render(); }
    }
    /** chamado pelo app quando o saldo muda com o resgate aberto */
    function balanceDelta(delta) { if (delta > 0) rain(unitsOf(delta)); else if (delta < 0) outgoing(unitsOf(-delta)); }

    // ── texto do cartão
    let lastKey = '';
    function render() {
      const w = opt.getWallet() || {}; const online = !!w.online; const left = w.claimLeftMs; const ready = online && left === 0;
      let key;
      if (!online) key = 'off'; else if (st.now < st.gotUntil) key = 'got' + st.got; else if (ready) key = 'ready'; else key = 'wait' + (left < 0 ? '-' : Math.ceil(left / 1000));
      key += '|' + st.busy + '|' + (w.claimSats || 0) + '|' + (w.cooldownMs || 0);
      if (key === lastKey) return; lastKey = key;
      clear(status);
      if (!online) status.append(h('div', { class: 'bad t1' }, L.t('Sem conexão com a rede', 'No connection to the network')));
      else if (st.now < st.gotUntil) status.append(h('div', { class: 'ok', style: { fontSize: '22px', fontWeight: '900' } }, `+${F.coins(st.got, opt.sid)} ${F.unit(opt.sid)}`));
      else if (ready) status.append(h('div', { class: 'ok', style: { fontSize: '22px', fontWeight: '900' } }, L.t('Disponível agora', 'Available now')));
      else status.append(h('div', { class: 'muted', style: { fontSize: '13px' } }, L.t('Próximo resgate em', 'Next claim in')), h('div', { style: { fontSize: '30px', fontWeight: '800' } }, left < 0 ? '—' : F.countdown(left)));
      sub.textContent = w.claimSats ? L.t(`${F.coins(w.claimSats, opt.sid)} ${F.unit(opt.sid)} a cada ${F.duration(w.cooldownMs)}`, `${F.coins(w.claimSats, opt.sid)} ${F.unit(opt.sid)} every ${F.duration(w.cooldownMs)}`) : '';
      btn.disabled = !ready || st.busy;
      btn.textContent = st.busy ? L.t('Resgatando…', 'Claiming…') : L.t('Resgatar', 'Claim');
    }

    // ── desenho
    const ctx = canvas.getContext('2d');
    function drawCoin(c, angle) {
      const g = st.geo; const s = g.coinPx * (c.pointer != null ? 1.12 : 1);
      ctx.save(); ctx.imageSmoothingEnabled = true; ctx.imageSmoothingQuality = 'high'; ctx.translate(c.x, c.y); ctx.rotate(c.a + (c.peek ? angle : 0)); ctx.drawImage(imgs.coin, -s / 2, -s / 2, s, s); ctx.restore();
    }
    function drawWallet(im, angle) {
      const g = st.geo; const i = g.img; const piv = [g.cx, g.bottom + walletDip()];
      ctx.save(); ctx.imageSmoothingEnabled = Math.abs(angle) > 0.002; ctx.translate(piv[0], piv[1]); ctx.rotate(angle); ctx.translate(-piv[0], -piv[1]);
      ctx.drawImage(im, i.x, i.y + walletDip(), i.s, i.s); ctx.restore();
    }
    function frame(ts) {
      if (st.closed) return;
      const t = ts / 1000; const dt = st.last ? Math.min(1 / 30, Math.max(0, t - st.last)) : 0; st.last = t; st.now = t;
      const g2 = geo(); if (!st.geo || g2.img.x !== st.geo.img.x || g2.img.y !== st.geo.img.y || g2.img.s !== st.geo.img.s) st.geo = g2;
      const g = st.geo;
      for (const p of st.pending.slice()) if (st.now >= p.at) { st.pending.splice(st.pending.indexOf(p), 1); st.coins.push(p.c); }
      if (st.now > st.tiltHold) st.tiltTarget = 0;
      st.tilt += (st.tiltTarget - st.tilt) * (1 - Math.exp(-dt * 7));
      const idle = st.now - st.lastInteraction > 15 && st.lastInteraction > 0;
      for (const c of st.coins.slice()) {
        if (!c.peek || c.pointer != null) continue;
        if (idle && !c.peekBack) { c.peekBack = true; c.peekT = 1; }
        c.peekT += (c.peekBack ? -dt : dt) / 0.4;
        if (c.peekBack && c.peekT <= 0) { st.coins.splice(st.coins.indexOf(c), 1); continue; }
        place(c);
      }
      for (let i = 0; i < 3; i++) step(dt / 3, g);
      // desenho em camadas: fundo · moedas no meio · frente · moedas por cima
      const k = dpr(); ctx.setTransform(k, 0, 0, k, 0, 0); ctx.clearRect(0, 0, innerWidth, innerHeight);
      ctx.imageSmoothingEnabled = false;
      const angle = walletAngle();
      if (imgs.wallet_back.complete) drawWallet(imgs.wallet_back, angle);
      for (const c of st.coins) if (!c.front && c.pointer == null) drawCoin(c, angle);
      if (imgs.wallet_front.complete) drawWallet(imgs.wallet_front, angle);
      const w = opt.getWallet() || {};
      if (w.online && w.claimLeftMs === 0 && !st.coins.length && !st.pending.length && !st.busy) {
        const s = g.coinPx * 0.84; ctx.drawImage(imgs.coin, g.cx - s / 2, g.backTop - g.coinPx * 1.05 + Math.sin(st.now * 3) * 4, s, s);
      }
      for (const c of st.coins) if (c.front || c.pointer != null) drawCoin(c, angle);
      render();
      st.raf = requestAnimationFrame(frame);
    }
    st.raf = requestAnimationFrame(frame);
    return { close, balanceDelta, rain, outgoing, get open() { return !st.closed; } };
  };
})();
