# Coin Bank 1.0 para Windows 10 e 11 (32 e 64 bits)

## Compilar (1 clique)
1. Extraia a pasta e dê dois cliques em **COMPILAR.bat**.
2. Sai o instalador **out\CoinBank-Setup.exe**, com as versões 32 e 64 bits (ele escolhe a certa sozinho).

Usa só o compilador C# que já vem no Windows (.NET Framework 4.6.2+), sem Visual Studio. A internet só é usada na primeira compilação, para baixar:
- o **Node.js 22 LTS** (22.13 ou mais novo), conferido por SHA-256 — vira o motor `runtime\CoinBankEngine.exe`;
- o **cloudflared** oficial do GitHub da Cloudflare (túnel da rede hospedada).

O WebView2 SDK já vem em `build\_deps`. Tudo baixado fica guardado em `build\_deps` (as próximas compilações são offline).

## O que o app faz
**Na bandeja (ao lado do relógio)**
- Ícone com o saldo e a rede no texto; fica apagado sem conexão.
- Clique: painel com saldo, contagem do resgate, Receber / Pagar / Extrato / Contas, rede local (IP, visível, quem está por perto), rede hospedada e os últimos avisos.
- Botão direito: Resgate, Receber (QR na tela), Pagar, Por perto, Hospedar, Configurações e chaves rápidas (resgate automático, visível na rede local, rede hospedada ligada).
- Avisos do Windows em **todas** as redes em que você entrou: coins recebidos, enviados, resgates, cobranças novas e pessoas cobrando você por perto. Clicar no aviso abre o lugar certo (comprovante, contas, cobrança).
- Inicia com o Windows (só na bandeja) e volta sozinho com o resgate automático, os avisos e a rede hospedada.

**Janela (igual ao app do celular, no estilo do site)**
- **Carteira:** saldo (esconder, 8 casas · 2 casas · inteiro), Pagar, Receber, Enviar, Gerar conta, Pagar conta, Cartão, Resgate, pessoas por perto e últimas transações.
- **Cartão:** cartão black (mostrar, copiar, resetar com confirmação), como funciona e exemplo de uso na API.
- **Histórico:** gráfico do saldo (7/30/90 dias) e extrato completo; cada item abre o comprovante (QR, link, PNG e PDF).
- **Contas:** a pagar / a receber, gerar conta (com QR do ID), pagar por ID, enviar uma conta para alguém por perto.
- **Receber:** QR de cobrança na tela (valor livre ou fixo, descrição) que vira **"Recebido!"** sozinho quando pagam; QR fixo da conta; enviar a cobrança para alguém por perto.
- **Pagar:** cole o link do QR, `coinbank://…`, um ID de conta ou de cobrança; o app mostra quem recebe e o valor antes de pagar. Links `coinbank://` abertos no Windows também caem aqui.
- **Resgate 🎁:** o mesmo modal do celular, com a carteira em camadas e as moedas com física:
  - as moedas caem de fora da janela com gravidade e entram na carteira (1 moedinha por unidade da última casa exibida, até 12);
  - elas passam **entre** o fundo e a frente da carteira, batem nas bordas e nunca atravessam;
  - arraste com o mouse (o círculo exato da moeda), jogue para dentro, para fora ou para cima;
  - clique na carteira = balança; 2 cliques rápidos = moedinhas sobem meio para fora; clicando de novo = pulam para fora;
  - transferência recebida com o resgate aberto = moedas caem; pagamento enviado = a carteira chacoalha e as moedas saem voando para cima (gravidade invertida; colocadas embaixo, a carteira inclina e elas rolam);
  - só fecha pelo X ou pelo Esc.
- **Por perto:** pessoas e redes hospedadas na mesma rede (Wi-Fi/cabo), **compatível com o app do celular** (UDP 26452). Cobrar, enviar, entrar na rede de alguém e as cobranças recebidas.
- **Hospedar:** liga o **servidor Coin Bank completo** neste PC (API, site, comprovantes; o mesmo `CoinBank-v2.2`). Nome, porta, valor e intervalo do resgate, endereços (este PC, rede local e internet) com copiar/QR/abrir, túnel **Cloudflare** (`https://….trycloudflare.com`, sem abrir porta) e apagar a rede.
- **Redes:** rede principal, outras redes e a rede hospedada; entrar/sair, moeda e casas decimais por rede.
- **Configurações:** iniciar com o Windows, resgate automático, avisos, visível na rede local, esconder saldo/cartão, não suspender com a rede hospedada, idioma (sistema/PT/EN) e tema (Windows/claro/escuro).
- **Sobre:** Termos, Privacidade e Documentação da API **embutidos no app** (abrem sem internet), links e doação.

## Segurança e privacidade
- Login com usuário e senha da rede. Com "Lembrar", a senha fica **cifrada pela chave do Windows (DPAPI, só este usuário abre)** e o app renova a sessão sozinho quando ela vence (24 h).
- A interface só fala com o motor local (`127.0.0.1`) usando um token novo a cada início.
- Na rede local só aparecem nome, ID e rede, e só enquanto você estiver visível. Nunca o saldo.
- Coins não têm valor real e nenhum cartão real é usado.

## Portas
| Porta | Para quê |
|---|---|
| UDP 26452 | pessoas por perto (rede local, igual ao celular) |
| TCP 26450 | rede hospedada (padrão; muda em Hospedar) |

O instalador libera o motor no Firewall do Windows (pede administrador uma vez). O túnel Cloudflare só faz conexões de saída.

## Pastas do projeto
- **Build:** `COMPILAR.bat`, `build\build.ps1`, `build\app.ico`, `build\app.manifest`, `build\app.config`.
- **App (C# 5, WinForms + WebView2):** `src\app\Program.cs` (instância única, links `coinbank://`), `TrayApp.cs` (bandeja, avisos, comandos), `Windows.cs` (janela e painel), `Engine.cs` (motor), `Util.cs`.
- **Instalador:** `src\setup\Setup.cs` (escolhe 32/64 bits, atalhos, iniciar com o Windows, Firewall, WebView2, desinstalador).
- **Motor:** `engine\engine.js` (Node.js) · `engine\server\` (servidor Coin Bank v2.2 embutido para a rede hospedada) · `engine\ui\` (janela, painel, resgate com física, QR offline) · `engine\site\terms\` (documentos offline).
- **Dados:** `%LOCALAPPDATA%\CoinBank` → `config.json`, `secrets.bin` (contas, cifrado), `seal.dpapi`, `host\` (banco e backups da rede hospedada), `engine.log`, `coinbank.log`, `WebView2\`.

## O que foi testado aqui
- **Motor (Node 22):** rede hospedada ligando com o servidor embutido (node:sqlite), criar conta, login, resgate automático, aviso de coins recebidos, cobrança por QR, proxy autenticado, duas instâncias se achando na rede local e cobrança enviada por perto.
- **Interface (Chromium):** todas as telas, painel da bandeja, receber com QR, resgate com moedas caindo, saindo e pulando da carteira — sem erros de script.
- **C#:** sintaxe conferida com o analisador do C#; **a compilação com o csc.exe não pôde ser feita aqui** (não há compilador .NET neste ambiente). Se o `COMPILAR.bat` mostrar algum erro, mande o texto que eu corrijo.
